package com.bom.smamonitor.bzsummary


import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.custlist.CustomerListActivity
import com.bom.smamonitor.customViews.CustomTickerView
import com.bom.smamonitor.customViews.RecyclerItemClickListener
import com.bom.smamonitor.dashboardbb.*
import com.bom.smamonitor.dashboardbb.models.Announcement
import com.bom.smamonitor.dashboardbb.models.Rep6
import com.bom.smamonitor.dashboardbb.models.Rep7
import com.bom.smamonitor.dashboardbb.models.Sma012
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.DateUtil
import com.bom.smamonitor.util.ValidationUtils
import com.bom.smamonitor.zonesectrsumry.ZoneSectorSumActivity
import com.bom.smamonitor.zonesectrsumry.ZoneSummaryActivity
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.item_dash_sma.view.*
import kotlinx.android.synthetic.main.item_rep6.view.*
import java.sql.DriverManager
import java.util.*
import javax.inject.Inject

class BZSummaryActivity : BaseActivity(), DashBBView {

    private var isBranch: Boolean = false
    private var userBranch = "9999"
    private var userRegCode = "99"
    private var loggedInMode = 0
    private var callFromMode = 3
    val tag = "BZSumActi"

    @Inject
    lateinit var presenter: DashBBPresenter<DashBBView, DashBBInteractor>

    @Inject
    internal lateinit var tickerAdapter: TickerTvAdapter

    @Inject
    internal lateinit var smaSummaryAdapter: SmaSummaryAdapter

    @Inject
    internal lateinit var rep6SummaryAdapter: Rep6SummaryAdapter;

    @Inject
    internal lateinit var rep7SummaryAdapter: Rep7SummaryAdapter;

    private lateinit var user: AppUser
    private var regCode = "99";

    private val String.capitalizeWords
        get() = this.toLowerCase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.capitalize(Locale.getDefault())
        }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_home)
        presenter.onAttach(this)
        supportActionBar?.setHomeAsUpIndicator(resources.getDrawable(R.drawable.ic_action_back))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        presenter.onViewPrepared()
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    private fun checkUserRole(branch: String): String {
        val brCode = Integer.parseInt(branch)
        when {
            brCode == 9999 -> { //HO
                "Head Office"
            }
            brCode < 5000 -> { //branch
                //brCode = Integer.parseInt(preferenceHelper.getUserRegionCode()!!)
            }
            brCode in 5002..8998 -> {//Zone  = brCode>5001 && brCode<8999)
            }
        }
        return brCode.toString()

    }


    override fun inflateUserDetails(userDetails: AppUser?) {
        user = userDetails!!
        Log.d(
            tag, "User Details:{ ${user.pfNo}  ${
                user.name?.trim()
            } and Branch: ${user.curBranch} - ${user.branchName}}"
        )
        Log.d(tag,"User Pf:${user.pfNo}")
        Log.d(tag,"User Name:  ${user.name?.trim()} and Branch: ${user.branchName}- ${user.curBranch}")
        userBranch = user.curBranch.toString();
        Log.d(tag,"User Notification token:${user.notificationId}")
        loggedInMode = presenter.getLoggedInMode()
        callFromMode = loggedInMode
        userRegCode = user.regionCode.toString()
        if(loggedInMode==1)
             userRoleTv.text = user.branchName

        setUp()


    }

    private fun checkUserRole(loggedInMode: Int): String {
        var branchCode = "9999"
        when (loggedInMode) {
            3 -> branchCode = "99"
            2 -> branchCode = userRegCode
            1 -> branchCode = userBranch
        }
        return branchCode
    }

    private fun setUp() {

        val regionCode = intent.getStringExtra("regionCode")
        val regionName = intent.getStringExtra("regionName")
        val branchCode = intent.getStringExtra("branchCode")
        val branchName = intent.getStringExtra("branchName")

        if (regionCode != null) {
            regCode = regionCode
            userRoleTv.text = regionName

            supportActionBar?.title = resources.getString(R.string.zoneDashboard)
            supportActionBar?.subtitle = "$regionCode -  $regionName"
            isBranch = false // if this is branch dashboard true else false
            callFromMode = 2;
            callFirstApiToRefresh(callFromMode = callFromMode)
            zoneSumBtnFab2.visibility = View.VISIBLE
            zoneSectorSumBtnFab3.visibility = View.VISIBLE

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                zoneSumBtnFab2.tooltipText = resources.getString(R.string.branchwiseSum)
                zoneSectorSumBtnFab3.tooltipText = resources.getString(R.string.branchwiseSectorSum)

            }
        }


        if (branchCode != null) {

            userRoleTv.text = branchName

            supportActionBar?.title = resources.getString(R.string.branchDashboard)
            supportActionBar?.subtitle = "$branchCode -  $branchName"
            regCode = branchCode
            callFromMode = 1
            isBranch = true // if this is branch dashboard true else false
            callFirstApiToRefresh(callFromMode)
            zoneSumBtnFab2.visibility = View.VISIBLE
            zoneSumBtnFab2.setImageResource(R.drawable.ic_doubts)
            zoneSectorSumBtnFab3.visibility = View.GONE

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                zoneSumBtnFab2.tooltipText = resources.getString(R.string.listOfCusts)
            }
        }
        tickeLL.visibility=View.GONE
        annLL.visibility= View.INVISIBLE

//        SMA Table
        figuresTitle.text= getString(R.string.FiguresinCrores) +" "+ "as on " + DateUtil.getYesterdayDateString()

        headerSmaINC.sma0TV.text = getString(R.string.sma0)
        headerSmaINC.sma1TV.text = getString(R.string.sma1)
        headerSmaINC.sma2TV.text = getString(R.string.sma2)
        smaSummaryAdapter = SmaSummaryAdapter()
        smaRv.layoutManager = LinearLayoutManager(this)
        smaRv.itemAnimator = DefaultItemAnimator()
        smaRv.adapter = smaSummaryAdapter
        smaRv.isNestedScrollingEnabled = false;

//        set rep6 Adapter
        headerRep6.todayTV.text = DateUtil.getYesterdayDateString()
        headerRep6.lastDayTV.text = DateUtil.getDateBeforeYesterdayString()
        rep6SummaryAdapter = Rep6SummaryAdapter()
        rep6RV.layoutManager = LinearLayoutManager(this);
        rep6RV.adapter = rep6SummaryAdapter
        rep6RV.isNestedScrollingEnabled = false;

//        set rep7 Adapter
        headerRep7INC.sma0TV.text = getString(R.string.sevenF)
        headerRep7INC.sma1TV.text = getString(R.string.sevenNf)
        headerRep7INC.sma2TV.text = getString(R.string.sevenD)
        rep7SummaryAdapter = Rep7SummaryAdapter()
        rep7Rv.layoutManager = LinearLayoutManager(this);
        rep7Rv.adapter = rep7SummaryAdapter;
        rep7Rv.isNestedScrollingEnabled = false;

//        Ticker horizontal scrolling
        tickerAdapter = TickerTvAdapter()
//        tickerRv.layoutManager = LinearLayoutManager(this)
//        tickerRv.itemAnimator = DefaultItemAnimator()
//        tickerRv.adapter = tickerAdapter

        swipeRefresh.setOnRefreshListener {
            callFirstApiToRefresh(callFromMode)
            Handler().postDelayed(Runnable { // Stop animation (This will be after 3 seconds)
                swipeRefresh.isRefreshing = false
            }, 4000) // Delay in millis
        }

        zoneSectorSumBtnFab3.setOnClickListener {
            val intent = Intent(this, ZoneSectorSumActivity::class.java)
            intent.putExtra("regionCode", regionCode)
            intent.putExtra("regionName", regionName)
            startActivity(intent)
        }

        zoneSumBtnFab2.setOnClickListener {

            if (callFromMode == 1 && branchCode != null) {
                val intent = Intent(this, CustomerListActivity::class.java)
                intent.putExtra("branchCode", branchCode)
                intent.putExtra("branchName", branchName)
                startActivity(intent)
            } else {
                val intent = Intent(this, ZoneSummaryActivity::class.java)
                intent.putExtra("regionCode", regionCode)
                intent.putExtra("regionName", regionName)
                startActivity(intent)
            }
        }


        fab.setOnClickListener {

            if (isFABExpaned) {
                isFABExpaned = false
                collapseFABMenu()
            } else {
                isFABExpaned = true
                expendFABMenu()
            }
        }
    }

    private var isFABExpaned = false


    private fun callFirstApiToRefresh(callFromMode: Int) {
        if (ValidationUtils.isNetworkAvailable(this))
            presenter.getSummarySma(regCode, callFromMode)
        else CustomDialog().showNoInternetAlert(this, "")
    }

    override fun displaySmaList(smaList: List<Sma012>) {
        presenter.getSummaryRep7(regCode, callFromMode)
        smaSummaryAdapter.setSmaList(smaList)
    }

    override fun displayRep7List(rep7List: List<Rep7>) {
        presenter.getSummaryRep6(regCode, callFromMode)
        rep7SummaryAdapter.setRep7List(rep7List)
    }

    override fun displayRep6List(rep6List: List<Rep6>) {
        //println("call announcement from BZ summary activity")
        //callAnnouncement()
        rep6SummaryAdapter.setRep6List(rep6List)
    }
    private fun callAnnouncement() {
        if (ValidationUtils.isNetworkAvailable(this) )
                presenter.getAnnouncement()
        else CustomDialog().showNoInternetAlert(this, "")
    }
    override fun callRep7Api() {
        presenter.getSummaryRep7(regCode, callFromMode)
    }

    override fun callRep6Api() {
        presenter.getSummaryRep6(regCode, callFromMode)
    }

    override fun displayTickerList(listZoneSum: List<ZoneSummary>) {
    }

    override fun displayAnnouncement(listAnc: List<Announcement>) {
        try {
            annLL.removeAllViewsInLayout()
            val announceTicker = CustomTickerView(this)
            announceTicker.layoutParams = LinearLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
//        for (alert: Announcement in listAnc) {

            val alert = listAnc[0]
            val tv = TextView(this)
            tv.layoutParams = LinearLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            announceTicker.setBackgroundColor(resources.getColor(R.color.light_orange))
            tv.setBackgroundColor(ContextCompat.getColor(this, R.color.light_orange))
            tv.setTextColor(ContextCompat.getColor(this, R.color.dark_red))
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            tv.setCompoundDrawables(ResourcesCompat.getDrawable(resources,R.drawable.ic_announcement,null),null,null,null)
            tv.textAlignment = View.TEXT_ALIGNMENT_CENTER
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.gravity = Gravity.CENTER
            tv.setPadding(5, 10, 5, 0)
            tv.text = alert.annContent.trim()
            announceTicker.addChildView(tv)
            annLL.addView(announceTicker)
            announceTicker.displacement = 60
            announceTicker.showTickers()

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    override fun displaySmaSummaryMonthly(smaList: List<Sma012>) {
        TODO("Not yet implemented")
    }

    private fun expendFABMenu() {
        fab.animate().rotationBy(180F)
        zoneSumBtnFab2.animate().translationY(-resources.getDimension(R.dimen.dimen80dp))
        zoneSectorSumBtnFab3.animate().translationY(-resources.getDimension(R.dimen.dimen150dp))
    }

    private fun collapseFABMenu() {
        isFABExpaned = false
        fab.animate().rotationBy(0F)
        zoneSumBtnFab2.animate().translationY(0F)
        zoneSectorSumBtnFab3.animate().translationY(0F)
    }


    private fun setRecyclerItemClickListener() {

        smaRv.addOnItemTouchListener(
            RecyclerItemClickListener(this,
                smaRv, object : RecyclerItemClickListener.OnItemClickListener {
                    override fun onItemClick(view: View, position: Int) {
                        when (position) {
                            3 -> openContactUsActivity()
                            4 -> basicAlertDialog()
                        }
                    }

                    override fun onItemLongClick(view: View?, position: Int) {
                    }
                })
        )
    }

//    private fun openOTSActivity() {
//        val intent = Intent(activity, OtsActivity::class.java)
//        this.startActivity(intent)
//    }
//    private fun openMyProfileActivity() {
//        val intent = Intent(activity, MyProfileActivity::class.java)
//        this.startActivity(intent)
//    }

    private fun basicAlertDialog() {
        val builder = AlertDialog.Builder(this, R.style.MyAlertDialogStyle)
        with(builder) {
            title = "Alert !"
            setMessage("Are you sure, you want to logout?")
            setPositiveButton("OK", null)
            setNegativeButton("Cancel", null)
//            setNeutralButton("NEUTRAL", null)
//            setPositiveButtonIcon(resources.getCuDrawable(android.R.drawable.ic_menu_call, theme))
            setIcon(resources.getDrawable(android.R.drawable.ic_dialog_alert))
        }
        val alertDialog = builder.create()
        alertDialog.show()
        val cancelBtn = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE)
        cancelBtn.setTextColor(Color.BLACK)
        cancelBtn.setOnClickListener {
            alertDialog.dismiss()
        }
        val okBtn = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE)
        with(okBtn) {
//            setBackgroundColor(Color.BLACK)
//            setPadding(0, 0, 20, 0)
            setTextColor(resources.getColor(R.color.colorPrimary))
            setOnClickListener {
                presenter.performUserLogout()
            }
        }

    }


    override fun openLoginActivity() {
//        val intent = Intent(activity, LoginActivity::class.java)
//        startActivity(intent)
//        activity?.finish()
    }


    override fun openBranchesActivity() {
        TODO("Not yet implemented")
    }

    override fun openRegionActivity() {
        TODO("Not yet implemented")
    }

    override fun openContactUsActivity() {
        TODO("Not yet implemented")
    }


    override fun showError(errorMsg: String) {
        CustomDialog().showAlert(this, errorMsg)
    }


}