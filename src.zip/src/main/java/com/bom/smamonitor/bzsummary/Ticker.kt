package com.bom.smamonitor.bzsummary

data class Ticker(val name:String, val amount:String)
