package com.bom.smamonitor.bzsummary

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import kotlinx.android.synthetic.main.item_dash_sma.view.*
import kotlinx.android.synthetic.main.item_ticker.view.*

class TickerTvAdapter : RecyclerView.Adapter<TickerTvAdapter.ChildSmaViewHolder>() {

    private var list = listOf<Ticker>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildSmaViewHolder {
        return ChildSmaViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_ticker, parent, false
            )
        )
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ChildSmaViewHolder, position: Int) {
        holder.setIsRecyclable(false);
        holder.onBind(position)
    }

    internal fun setDisplayList(smaList: List<Ticker>) {
        this.list = smaList
        notifyDataSetChanged()
    }

    inner class ChildSmaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        @SuppressLint("SetTextI18n")
        fun onBind(position: Int) {
            try {
                val sma = list[position]

                val amount: String = sma.amount.substring(0, sma.amount.indexOf('('))
                val start=sma.amount.indexOf('(')
                val variation =
                    sma.amount.substring(start+1, sma.amount.indexOf(')'))
                //itemView.sma0TV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;

                itemView.nameTv.text = sma.name + "-"+amount
                itemView.valueTv.text = "($variation)"

                if (variation.toDouble() < 0) {
                    itemView.valueTv.setTextColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.green
                        )
                    )

                } else {
                    itemView.valueTv.setTextColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.dark_red
                        )
                    )
                }


            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


}