package com.bom.smamonitor.bzsummary

import com.google.gson.annotations.SerializedName

data class BranchSectSummary(

    @SerializedName("BRANCHNAME")
    val branchName: String,

    @SerializedName("BRCODE")
    val brCode: String,

    @SerializedName("RETAIL_LOAN_BAL")
    val retailLoanBal: Double,

    @SerializedName("AGRI_LOAN_BAL")
    val agriLoanBal: Double,

    @SerializedName("MSME_LOAN_BAL")
    val msmeLoanBal: Double,

    @SerializedName("LARGE_LOAN_BAL")
    val largeLoanBal: Double,

    @SerializedName("OTHER_BAL")
    val otherBal: Double,

    @SerializedName("LOAN_BAL")
    val loanBal: Double,

    @SerializedName("VARIATION")
    val variation: Double

    )



