package com.bom.smamonitor.bzsummary

import com.google.gson.annotations.SerializedName

data class ZoneSummary(

    @SerializedName("ZONE_NAME")
    val zoneName: String,

    @SerializedName("ZONE_CODE")
    val regCode: String,

//    @SerializedName("BRNAME")
//    val brName: String,

    @SerializedName("BRANCHNAME")
    val brName: String,

    @SerializedName("BRCODE")
    val brCode: String,

    @SerializedName("REP6")
    val rep6: String,

    @SerializedName("REP7F")
    val rep7f: String,

    @SerializedName("REP7NF")
    val rep7nf: String,

    @SerializedName("REP7D")
    val rep7d: String,

    @SerializedName("SMA0")
    val sma0: String,

    @SerializedName("SMA1")
    val sma1: String,

    @SerializedName("SMA2")
    val sma2: String

)

data class ZoneSummaryObj(
    @SerializedName("RepSum")
    val listZoneSum: List<ZoneSummary>
)

data class DataObj(
    @SerializedName("Data")
    val data: String
)

data class EncDataObj(
    @SerializedName("EnDataList")
    val enDataListObj: String
)
