package com.bom.smamonitor.bzsummary.zontable;


import com.bom.smamonitor.bzsummary.ZoneSummary;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.ColumnHeaderModel;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;

import java.util.ArrayList;
import java.util.List;

public class ZoneSumTableViewModel {
    // Columns indexes
    public static final int LINK_COLUMN_INDEX1 = 1;
    public static final int LINK_COLUMN_INDEX2 = 0;

    // Constant size for dummy data sets
//    private static final int COLUMN_SIZE = 500;
//    private static final int ROW_SIZE = 500;

    private List<ColumnHeaderModel> mColumnHeaderModelList;
    private List<RowHeaderModel> mRowHeaderModelList;
    private List<List<Cell>> mCellModelList;


    public ZoneSumTableViewModel() {
    }


    private List<ColumnHeaderModel> createColumnHeaderModelList(Integer callFromMode) {
        List<ColumnHeaderModel> list = new ArrayList<>();

        list.add(new ColumnHeaderModel("0", "CODE"));
        list.add(new ColumnHeaderModel("1", "SMA-0"));
        list.add(new ColumnHeaderModel("2", "SMA-1"));
        list.add(new ColumnHeaderModel("3", "SMA-2"));
        list.add(new ColumnHeaderModel("4", "Rep-7F"));
        list.add(new ColumnHeaderModel("5", "Rep-7NF"));
        list.add(new ColumnHeaderModel("6", "Rep-7D"));
        list.add(new ColumnHeaderModel("7", "Rep-6"));

        return list;
    }

    private List<List<Cell>> createCellModelList(List<ZoneSummary> zoneSummaries, Integer callFromMode) {

        List<List<Cell>> cellList = new ArrayList<>();
        try {
            for (int i = 0; i < zoneSummaries.size(); i++) {
                ZoneSummary zoneSummary = zoneSummaries.get(i);
                List<Cell> list = new ArrayList<>();
                if (callFromMode == 2) {
                    list.add(new Cell("1-" + i, zoneSummary.getBrCode()));
                } else {
                    list.add(new Cell("1-" + i, zoneSummary.getRegCode()));
                }

                list.add(new Cell("2-" + i, zoneSummary.getSma0()));
                list.add(new Cell("3-" + i, zoneSummary.getSma1()));
                list.add(new Cell("4-" + i, zoneSummary.getSma2()));
                list.add(new Cell("5-" + i, zoneSummary.getRep7f()));
                list.add(new Cell("6-" + i, zoneSummary.getRep7nf()));
                list.add(new Cell("7-" + i, zoneSummary.getRep7d()));
                list.add(new Cell("8-" + i, zoneSummary.getRep6()));
                //list.add(new Cell("9-" + i, String.valueOf(i + 1)));

                cellList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cellList;
    }

    private String formatRoundUp(double num) {
        return String.format("%.02f", num);
    }

    private List<RowHeaderModel> createRowHeaderList(List<ZoneSummary> zoneSummaries, int size, int callFromMode) {
        List<RowHeaderModel> list = new ArrayList<>();

        for (int i = 0; i < size; i++) { //ROW_SIZE=usersList.size();
            ZoneSummary zoneSummary = zoneSummaries.get(i);
            if (callFromMode == 2) {
                if (zoneSummary.getBrName() != null|| (!zoneSummary.getBrName().isEmpty())) {
                    String branchName = zoneSummary.getBrName().toString();
                    if (branchName.equals(" ()")|| branchName.equals("ZZTOTAL")){
                        list.add(new RowHeaderModel(String.valueOf(i), "TOTAL"));
                    } else {
                        String brName = branchName.substring(0, zoneSummary.getBrName().indexOf('('));
                        list.add(new RowHeaderModel(String.valueOf(i), brName));
                    }
                }
            } else {
                if (zoneSummary.getZoneName() != null) {
                    String zoneName = zoneSummary.getZoneName();
                    if (zoneName.trim().equals("ZZTOTAL")) {
                        list.add(new RowHeaderModel(String.valueOf(i), "TOTAL"));
                    } else {
                        if(zoneName.contains("ZONE")) {
                            String zoName = zoneName.substring(0, zoneName.indexOf("ZONE"));
                            list.add(new RowHeaderModel(String.valueOf(i), zoName));
                        } else{
                            list.add(new RowHeaderModel(String.valueOf(i), "Central Office"));
                        }
                    }
                }
            }
        }
        return list;
    }

    public List<ColumnHeaderModel> getColumnHeaderModeList() {
        return mColumnHeaderModelList;
    }

    public List<RowHeaderModel> getRowHeaderModelList() {
        return mRowHeaderModelList;
    }

    public List<List<Cell>> getCellModelList() {
        return mCellModelList;
    }

    public void generateListForTableView(List<ZoneSummary> zoneSummaries, Integer callFromMode) {
        mColumnHeaderModelList = createColumnHeaderModelList(callFromMode);
        mCellModelList = createCellModelList(zoneSummaries, callFromMode);
        mRowHeaderModelList = createRowHeaderList(zoneSummaries, zoneSummaries.size(), callFromMode);

    }


}



