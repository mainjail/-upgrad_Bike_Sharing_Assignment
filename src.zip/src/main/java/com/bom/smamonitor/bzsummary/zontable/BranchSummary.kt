package com.bom.smamonitor.bzsummary.zontable

import com.google.gson.annotations.SerializedName

data class BranchSummary(
    @SerializedName("BRNAME")
    val zoneName: String,

    @SerializedName("BRCODE")
    val regCode: String,

    @SerializedName("REP6")
    val rep6: Double,

    @SerializedName("REP7F")
    val rep7f: Double,

    @SerializedName("REP7NF")
    val rep7nf: Double,

    @SerializedName("REP7D")
    val rep7d: Double,

    @SerializedName("SMA0")
    val sma0: Double,

    @SerializedName("SMA1")
    val sma1: Double,

    @SerializedName("SMA2")
    val sma2: Double,
)
