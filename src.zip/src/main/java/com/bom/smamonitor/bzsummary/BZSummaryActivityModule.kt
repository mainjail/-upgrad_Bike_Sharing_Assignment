package com.bom.smamonitor.bzsummary


import com.bom.smamonitor.dashboardbb.*
import dagger.Module
import dagger.Provides


@Module
class BZSummaryActivityModule {

    @Provides
    internal fun provideHomeInteractor(interactor: DashBBInteractorImpl): DashBBInteractor =
        interactor

    @Provides
    internal fun provideHomePresenter(presenter: DashBBPresenterImpl<DashBBView, DashBBInteractor>)
            : DashBBPresenter<DashBBView, DashBBInteractor> = presenter

    @Provides
    internal fun provideTickerAdapter(): TickerTvAdapter = TickerTvAdapter()
    @Provides
    internal fun provideAdapter(): SmaSummaryAdapter = SmaSummaryAdapter()
    @Provides
    internal fun provideRep6Adapter(): Rep6SummaryAdapter = Rep6SummaryAdapter()
    @Provides
    internal fun provideRep7Adapter(): Rep7SummaryAdapter = Rep7SummaryAdapter()

}