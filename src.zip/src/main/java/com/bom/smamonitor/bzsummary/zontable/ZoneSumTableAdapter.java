package com.bom.smamonitor.bzsummary.zontable;

import android.annotation.SuppressLint;
import android.graphics.Typeface;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bom.smamonitor.R;
import com.bom.smamonitor.bzsummary.ZoneSummary;
import com.bom.smamonitor.details.tablew.holder.CellViewHolder;
import com.bom.smamonitor.details.tablew.holder.ColumnHeaderViewHolder;
import com.bom.smamonitor.details.tablew.holder.RowHeaderViewHolder;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.ColumnHeaderModel;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;
import com.evrencoskun.tableview.adapter.AbstractTableAdapter;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractSorterViewHolder;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractViewHolder;
import com.evrencoskun.tableview.sort.SortState;

import org.jetbrains.annotations.NotNull;

import java.util.List;


public class ZoneSumTableAdapter extends AbstractTableAdapter<ColumnHeaderModel, RowHeaderModel, Cell> {

    private static final int LINK_CELL_TYPE1 = 1;
    private final int mCallFromMode;

    private static final String LOG_TAG = ZoneSumTableAdapter.class.getSimpleName();

    @NonNull
    private final ZoneSumTableViewModel mTableViewModel;

    public ZoneSumTableAdapter(@NonNull ZoneSumTableViewModel tableViewModel, int callFromMode) {
        super();
        this.mTableViewModel = tableViewModel;
        this.mCallFromMode = callFromMode;
    }

    @NonNull
    @Override
    public AbstractViewHolder onCreateCellViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View layout;
        layout = inflater.inflate(R.layout.table_view_cell_layout, parent, false);
        return new CellViewHolder(layout);
    }

    /**
     * That is where you set Cell View Model data to your custom Cell ViewHolder. This method is
     * Called by Cell RecyclerView of the TableView to display the data at the specified position.
     * This method gives you everything you need about a cell item.
     *
     * @param holder         : This is one of your cell ViewHolders that was created on
     *                       ```onCreateCellViewHolder``` method. In this example we have created
     *                       "CellViewHolder" holder.
     * @param cellItemModel  : This is the cell view model located on this X and Y position. In this
     *                       example, the model class is "Cell".
     * @param columnPosition : This is the X (Column) position of the cell item.
     * @param rowPosition    : This is the Y (Row) position of the cell item.
     * @see #onCreateCellViewHolder(ViewGroup, int) ;
     */
    @Override
    public void onBindCellViewHolder(@NonNull AbstractViewHolder holder, @Nullable Cell cellItemModel, int
            columnPosition, int rowPosition) {
        CellViewHolder viewHolder = (CellViewHolder) holder;
        viewHolder.setCellModel(cellItemModel, columnPosition);
        viewHolder.setCellTypeFace(rowPosition == (mTableViewModel.getCellModelList().size() - 1));
    }

    @NotNull
    @Override
    public AbstractSorterViewHolder onCreateColumnHeaderViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout
                .table_view_column_header_layout, parent, false);
        return new ColumnHeaderViewHolder(layout, getTableView());
    }

    @Override
    public void onBindColumnHeaderViewHolder(@NonNull AbstractViewHolder holder, @Nullable ColumnHeaderModel columnHeaderItemModel,
                                             int columnPosition) {
        ColumnHeaderViewHolder columnHeaderViewHolder = (ColumnHeaderViewHolder) holder;
        columnHeaderViewHolder.setColumnHeaderModel(columnHeaderItemModel, columnPosition);
    }

    @NotNull
    @Override
    public AbstractViewHolder onCreateRowHeaderViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.table_view_row_header_layout,
                parent, false);
        return new RowHeaderViewHolder(layout);
    }

    @Override
    public void onBindRowHeaderViewHolder(@NonNull AbstractViewHolder holder, @Nullable RowHeaderModel rowHeaderItemModel, int rowPosition) {
        RowHeaderViewHolder rowHeaderViewHolder = (RowHeaderViewHolder) holder;
        rowHeaderViewHolder.row_header_textview.setText(String.valueOf(rowHeaderItemModel.getData()));
        if(rowHeaderItemModel.getData()=="TOTAL"){
            rowHeaderViewHolder.row_header_textview.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        }
        else {
            rowHeaderViewHolder.row_header_textview.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        }
        rowHeaderViewHolder.row_header_textview.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
//        rowHeaderViewHolder.row_header_textview.getLayoutParams().width = LinearLayout.LayoutParams.WRAP_CONTENT;
//        rowHeaderViewHolder.row_header_textview.requestLayout();
    }


    @SuppressLint("SetTextI18n")
    @NonNull
    @Override
    public View onCreateCornerView(@NonNull ViewGroup parent) {
        View corner = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.table_view_corner_layout, parent, false);
        TextView cornerTV = corner.findViewById(R.id.cornerTextView);
        cornerTV.getLayoutParams().width = LinearLayout.LayoutParams.WRAP_CONTENT;
        cornerTV.requestLayout();

        if (mCallFromMode == 2)
            cornerTV.setText("BRANCH NAME");
        else
            cornerTV.setText("ZONE NAME");

        corner.setOnClickListener(v -> {
            SortState sortState = ZoneSumTableAdapter.this.getTableView()
                    .getRowHeaderSortingStatus();
            if (sortState != SortState.ASCENDING) {
                Log.d("TableViewAdapter", "Order Ascending");
                ZoneSumTableAdapter.this.getTableView().sortRowHeader(SortState.ASCENDING);
            } else {
                Log.d("TableViewAdapter", "Order Descending");
                ZoneSumTableAdapter.this.getTableView().sortRowHeader(SortState.DESCENDING);
            }
        });

        return corner;
    }

    @Override
    public int getColumnHeaderItemViewType(int position) {
        return 0;
    }

    @Override
    public int getRowHeaderItemViewType(int position) {
        return 0;
    }

    @Override
    public int getCellItemViewType(int position) {

        if (position == ZoneSumTableViewModel.LINK_COLUMN_INDEX1) {
            return LINK_CELL_TYPE1;
        }

        return 0;
    }


    /**
     * This method is not a generic Adapter method. It helps to generate lists from single user
     * list for this adapter.
     */
    public void setUserList(List<ZoneSummary> zoneSummaries, Integer callFromMode) {

        mTableViewModel.generateListForTableView(zoneSummaries, callFromMode);

        setAllItems(mTableViewModel.getColumnHeaderModeList(),
                mTableViewModel.getRowHeaderModelList(),
                mTableViewModel.getCellModelList());
    }

}
