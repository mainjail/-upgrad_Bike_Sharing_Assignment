package com.bom.smamonitor.model

import com.google.gson.annotations.SerializedName

data class Base64String(

    @SerializedName("Data")
    val base64String: String
)
