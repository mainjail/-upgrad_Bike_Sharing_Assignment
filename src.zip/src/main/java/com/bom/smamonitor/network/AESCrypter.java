package com.bom.smamonitor.network;


import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.MessageDigest;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import kotlin.text.Charsets;

public class AESCrypter {

    private static final String TAG ="AESCrypter" ;
    private final Cipher cipher;
    private SecretKeySpec key;
    private AlgorithmParameterSpec spec;


    public AESCrypter() throws Exception
    {
        String password="SMita Ranveer";
        // hash password with SHA-256 and crop the output to 128-bit for key
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update(password.getBytes("UTF-8"));

        byte[] keyBytes = new byte[32];
        System.arraycopy(digest.digest(), 0, keyBytes, 0, keyBytes.length);

//        cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
        cipher = Cipher.getInstance("AES/CBC/NoPadding");

        key = new SecretKeySpec(keyBytes, "AES");
        spec = getIV();
    }

    public AlgorithmParameterSpec getIV()
    {
        byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, };
        IvParameterSpec ivParameterSpec;
        ivParameterSpec = new IvParameterSpec(iv);
        return ivParameterSpec;
    }

    public String encrypt(String plainText) throws Exception
    {
        cipher.init(Cipher.ENCRYPT_MODE, key, spec);
        byte[] encrypted = cipher.doFinal(plainText.getBytes("UTF-8"));
        String encryptedText = new String(Base64.encode(encrypted, Base64.DEFAULT), "UTF-8");
        return encryptedText;
    }

//    public String decrypt(String cryptedText) throws Exception
//    {
//        cipher.init(Cipher.DECRYPT_MODE, key, spec);
//        byte[] bytes = Base64.decode(cryptedText, Base64.DEFAULT);
//
//        byte[] decrypted = cipher.doFinal(bytes);
//        String decryptedText = new String(decrypted, "UTF-8");
//        return decryptedText;
//    }
    public String decrypt(String decodedText)
            throws Exception
    {


            final Cipher cipher = Cipher.getInstance("AES_128/CBC/NoPadding");

            //byte[] keyBytes = new byte[32];
            String keyTXT = "1234567812345678";
            byte[] keyBytes = keyTXT.getBytes(StandardCharsets.UTF_8);
            SecretKeySpec key = new SecretKeySpec(keyBytes, "AES");



            System.out.println("decodedText: " + decodedText);

            String IVFromServer = decodedText.substring(0, decodedText.indexOf('.'));
            System.out.println("IVFromServer: " +        IVFromServer     );
            IvParameterSpec ivParameterSpec = new IvParameterSpec(IVFromServer.getBytes(StandardCharsets.UTF_8),0,cipher.getBlockSize());
            cipher.init(Cipher.DECRYPT_MODE, key, ivParameterSpec);

            String hMacDigest = decodedText.substring(decodedText.indexOf('.'), decodedText.indexOf('|'));
            System.out.println("Hmac FromServer: " + hMacDigest);
            String cipherText = decodedText.substring(decodedText.indexOf('|')+1,decodedText.length());
            System.out.println("cipherText FromServer: " + cipherText);

            // byte[] bytes = Base64.decode(cipherText, Base64.DEFAULT);

           // byte[] decrypted = cipher.doFinal(cipherText.getBytes(StandardCharsets.UTF_8));
        byte[] decrypted = cipher.doFinal(cipherText.getBytes());

        String decryptedText = new String(decrypted, StandardCharsets.UTF_8);
            System.out.println("decryptedText FromServer: " + decryptedText);
            return decryptedText;





    }


}