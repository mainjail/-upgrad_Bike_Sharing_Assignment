package com.bom.smamonitor.network

import com.google.gson.annotations.SerializedName


data class EncryptDataObj(
    @SerializedName("Data")
    val data: String
)