package com.bom.smamonitor.network

import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.addVisit.Visit
import com.bom.smamonitor.branchMaster.Branch
import com.bom.smamonitor.branchMaster.Region
import com.bom.smamonitor.busifig.BusiMetrics
import com.bom.smamonitor.busifig.NpaFigures
import com.bom.smamonitor.bzsummary.EncDataObj
import com.bom.smamonitor.bzsummary.ZoneSummaryObj
import com.bom.smamonitor.custlist.model.EnCustAcDetailsObj
import com.bom.smamonitor.custlist.model.MapCustomerList
import com.bom.smamonitor.dashboardbb.models.*
import com.bom.smamonitor.details.paymentmodels.CreatePayMsgLinkResp
import com.bom.smamonitor.details.paymentmodels.PaymentMsgLinkReq
import com.bom.smamonitor.details.paymentmodels.WhatsAppMessage
import com.bom.smamonitor.details.paymentmodels.WhatsappResponse
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.LoginResponse
import com.bom.smamonitor.login.OTPResponse
import com.bom.smamonitor.login.User
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.ots.CbsCustomer
import com.bom.smamonitor.ots.OtsModel
import com.bom.smamonitor.ots.OtsStatus
import com.bom.smamonitor.ots.applEntry.OtsEntryDetail
import com.bom.smamonitor.zonesectrsumry.HoSectObj
import io.reactivex.Observable
import okhttp3.Response

interface ApiHelper {

    fun performServerLogin(user: User): Observable<LoginResponse>

    fun getNpaCustomers(brCode: Int): Observable<List<NpaCustomer>>
    fun getBranches(regionCode: Int): Observable<List<Branch>>
    fun getBranchHeadInfo(brCode: String?):Observable<List<Branch>>
    fun getRegions(): Observable<List<Region>>

    fun getEmployee(user: User): Observable<List<User>>
    fun addUser(user: AppUser): Observable<AppUser>

    fun addVisit(visit: Visit) :Observable<List<Visit>>

    fun getVisits(custNo: String): Observable<List<Visit>>

    fun getSearchCustomer(keyword: String): Observable<List<NpaCustomer>>
    fun getNpaCustomerByCustNo(custNo: String): Observable<List<NpaCustomer>>

    fun getNpaFigures(brCode: String,date:String): Observable<List<NpaFigures>>
    fun getTotalBusinessFigures(brCode: String, date: String): Observable<List<BusiMetrics>>

    fun getCustomerCbsDetails(cif: String): Observable<List<CbsCustomer>>

    fun getAllOtsEntries(): Observable<List<OtsEntryDetail>>
    fun getOtsEntryDetails(custNo: String): Observable<List<OtsEntryDetail>>
    fun getOtsByInwardNo(inwardNo: String): Observable<List<OtsEntryDetail>>

    fun getOtsModels(): Observable<List<OtsModel>>
    fun getOtsStatusMaster(): Observable<List<OtsStatus>>

    fun getSummarySma012(brCode:String,loggedInMode: Int): Observable<Sma012Obj>
    fun getSummaryRep6(brCode:String ,loggedInMode: Int): Observable<Rep6Obj>
    fun getSummaryRep7(brCode:String ,loggedInMode: Int): Observable<Rep7Obj>
    fun getZoneSectSumryReportWise(brCode:String, repType:String, loggedInMode: Int): Observable<HoSectObj>
    fun getZoneSummary(brCode:String, isViewInLacs:Boolean, loggedInMode: Int): Observable<ZoneSummaryObj>
    fun getHoZoneSummary(brCode:String,isViewInLacs:Boolean,  loggedInMode: Int): Observable<ZoneSummaryObj>

    fun getSmaCustList(brCode: Int,report:Int,sortBy:Int): Observable<EncDataObj>
    fun getCustDetails(custNo: String): Observable<EnCustAcDetailsObj>

    fun addSmaVisit(smaVisit: SmaVisit) :Observable<List<SmaVisit>>

    fun getSmaVisits(custNo: String): Observable<List<SmaVisit>>
    fun getNotification(brCode:String,loggedInMode:Int): Observable<NotiObj>
    fun getSmaSummaryMonthly(brCode: String, callFromMode: Int): Observable<Sma012Obj>
    fun getAnnouncement(): Observable<List<Announcement>>
    fun getNearbySmaCustList(address: String): Observable<MapCustomerList>
    fun getEncryptedText(): Observable<EncryptDataObj>
/*************************Arjun App Second Phase APIs  *************************************************************************/
    fun sendOtp(mobileNo: String?, otp: String): Observable<OTPResponse>
    fun createPaymentLink(payMsgLinkReq: PaymentMsgLinkReq): Observable<CreatePayMsgLinkResp>
    fun postWhatsAppMessage(whatsAppMessage: WhatsAppMessage): Observable<WhatsappResponse>
    fun sendSMS(mobileNo: String,custName: String, custNo:String,reportName:String): Observable<WhatsappResponse>
    fun getAgriDashb( ): Observable<List<AgriObj>>

}