package com.bom.smamonitor.network

import com.bom.smamonitor.BuildConfig
import io.reactivex.Observable
import okhttp3.ResponseBody
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface ApiServiceInterface {

//    @GET("posts/{id}")
//    fun getUser(@Path("id") id: Int): Observable<User>

    @DELETE("albums/{id}")
    fun deleteUser(@Path("id") id: Int)

//    @POST("login/user/{id}")
//    fun loginBranchUser(@Path("id") id: Int)
//
//    @GET
//    fun getStockStatementList(@Path("branchCode") branchCode:Int): Observable<List<StockStatementModel>>
//
//    @GET("posts")
//    fun getPostList(): Observable<List<Product>>

    @POST("Login")
    fun getToken(@Body Username: String):Observable<ResponseBody>

    companion object Factory {
        fun create(): ApiServiceInterface {
            val retrofit = retrofit2.Retrofit.Builder()
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(BuildConfig.BASE_URL)
                .build()
            return retrofit.create(ApiServiceInterface::class.java)
        }
    }
}