package com.bom.smamonitor.network

import android.util.Log
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.gsonparserfactory.GsonParserFactory
import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.addVisit.Visit
import com.bom.smamonitor.branchMaster.Branch
import com.bom.smamonitor.branchMaster.Region
import com.bom.smamonitor.busifig.BusiMetrics
import com.bom.smamonitor.busifig.NpaFigures
import com.bom.smamonitor.bzsummary.EncDataObj
import com.bom.smamonitor.bzsummary.ZoneSummaryObj
import com.bom.smamonitor.custlist.model.EnCustAcDetailsObj
import com.bom.smamonitor.custlist.model.MapCustomerList
import com.bom.smamonitor.dashboardbb.models.*
import com.bom.smamonitor.details.paymentmodels.CreatePayMsgLinkResp
import com.bom.smamonitor.details.paymentmodels.PaymentMsgLinkReq
import com.bom.smamonitor.details.paymentmodels.WhatsAppMessage
import com.bom.smamonitor.details.paymentmodels.WhatsappResponse
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.LoginResponse
import com.bom.smamonitor.login.OTPResponse
import com.bom.smamonitor.login.User
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.ots.CbsCustomer
import com.bom.smamonitor.ots.OtsModel
import com.bom.smamonitor.ots.OtsStatus
import com.bom.smamonitor.ots.applEntry.OtsEntryDetail
import com.bom.smamonitor.zonesectrsumry.HoSectObj
import com.google.gson.GsonBuilder
import com.rx2androidnetworking.Rx2AndroidNetworking
import io.reactivex.Observable
import okhttp3.*
import javax.inject.Inject


class AppApiHelper @Inject constructor(private val apiHeader: ApiHeader) : ApiHelper {


    val TAG = "ApiCall"

    override fun performServerLogin(user: User): Observable<LoginResponse> {
        val rx2AndroidNetworking = Rx2AndroidNetworking.post(ApiEndPoint.ENDPOINT_LoginServer)
            .addHeaders("Content-Type", "application/json")
            .addBodyParameter("pfNo", user.pfNo)
            .build()
        return rx2AndroidNetworking.getObjectObservable(LoginResponse::class.java)
    }

    override fun getNpaCustomers(brCode: Int): Observable<List<NpaCustomer>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_NPA_CUSTOMERS + "/" + brCode)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(NpaCustomer::class.java)
    }

    override fun getSearchCustomer(keyword: String): Observable<List<NpaCustomer>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_SEARCH_CUSTOMERS + "/" + keyword)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(NpaCustomer::class.java)
    }

    override fun getNpaCustomerByCustNo(custNo: String): Observable<List<NpaCustomer>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_CUSTOMER_BY_CUSTNO + "/" + custNo)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(NpaCustomer::class.java)
    }

    override fun getBranches(regionCode: Int): Observable<List<Branch>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_BRANCHES + regionCode)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(Branch::class.java)
    }

    override fun getRegions(): Observable<List<Region>> =
        Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_REGIONS)
            .addHeaders("Content-Type", "application/json")
            .build()
            .getObjectListObservable(Region::class.java)

    //    override fun getEmployeeOld(user: User): Observable<List<User>> {
//        val rx2AndroidNetworking = Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_EMPLOYEE + user.pfNo)
//                .addHeaders("Content-Type", "application/json")
//                .build()
//        return rx2AndroidNetworking.getObjectListObservable(User::class.java)
//    }
//    http://125.17.112.44:7003/recovery/webserverapi/v1/
    override fun getEmployee(user: User): Observable<List<User>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get("https://bomapi.bankofmaharashtra.in/recovery/webserverapi/v1/users/getEmployee/" + user.pfNo)
                .addHeaders("Content-Type", "application/json")
                .build()
        Log.d(
            TAG,
            " getEmployee:- " + "https://bomapi.bankofmaharashtra.in/recovery/webserverapi/v1/users/getEmployee/" + user.pfNo
        )

        return rx2AndroidNetworking.getObjectListObservable(User::class.java)
    }

    override fun sendOtp(mobileNo: String?, otp: String): Observable<OTPResponse> {
//https://bomapi.bankofmaharashtra.in/login/api/ArjunaOTP/generateOTP?mnumber=9890802231&otp=123456
        val apiUrl =
            "https://bomapi.bankofmaharashtra.in/login/api/ArjunaOTP/generateOTP?mnumber=$mobileNo&otp=$otp"
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(apiUrl)
                .addHeaders("Content-Type", "application/json")
                .build()
        Log.d(TAG, " sendOtp:- $apiUrl")

        return rx2AndroidNetworking.getObjectObservable(OTPResponse::class.java)
    }


    override fun getBranchHeadInfo(brCode: String?): Observable<List<Branch>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_BRANCH_Head_details + brCode)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(Branch::class.java)
    }

    override fun addUser(user: AppUser): Observable<AppUser> {
        return Rx2AndroidNetworking.post(ApiEndPoint.ENDPOINT_Add_USER)
            .addHeaders("Content-Type", "application/json")
            .addBodyParameter(user)
            .build()
            .getObjectObservable(AppUser::class.java)
    }

    override fun addVisit(visit: Visit): Observable<List<Visit>> {
        val gson = GsonBuilder()
            .setLenient()
            .create()
        AndroidNetworking.setParserFactory(GsonParserFactory(gson))

        val rx2AndroidNetworking = Rx2AndroidNetworking.post(ApiEndPoint.ENDPOINT_POST_SMA_VISIT)
            .addHeaders("Content-Type", "application/json")
            .addBodyParameter("visitDate", visit.visitDate)
            .addBodyParameter("custNo", visit.custNo)
            .addBodyParameter("custName", visit.custName)
            .addBodyParameter("visitorName", visit.visitorName)
            .addBodyParameter("visitorPfNo", visit.visitorPfNo)
            .addBodyParameter("comments", visit.comments)
            .build()
        return rx2AndroidNetworking.getObjectListObservable(Visit::class.java)
    }


    override fun getVisits(custNo: String): Observable<List<Visit>> {

// NOt in use
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_SMA_VISITS + custNo)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(Visit::class.java)
    }

    //business figures APi
    override fun getTotalBusinessFigures(
        brCode: String,
        date: String
    ): Observable<List<BusiMetrics>> {
//        http://localhost:5000/recovery/api/v1/business/getTotalFigures/00140/2020-04-05
//         Five digit Branch Code required here
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_TOTAL_FIGURES + brCode + "/" + date)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(BusiMetrics::class.java)
    }

    override fun getNpaFigures(brCode: String, date: String): Observable<List<NpaFigures>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_NPA_FIGURES + brCode + "/" + date)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(NpaFigures::class.java)
    }


    //Ots Apis  figures APi

    override fun getCustomerCbsDetails(cif: String): Observable<List<CbsCustomer>> {
        //get customer CBS details for OTS
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_OTS_CUSTOMER + "/" + cif)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(CbsCustomer::class.java)
    }

    override fun getAllOtsEntries(): Observable<List<OtsEntryDetail>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_ALL_OTS_ENTRIES)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(OtsEntryDetail::class.java)
    }

    override fun getOtsEntryDetails(cif: String): Observable<List<OtsEntryDetail>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_OTS_ENTRY_BY_CIF + cif)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(OtsEntryDetail::class.java)
    }

    override fun getOtsByInwardNo(inwardNo: String): Observable<List<OtsEntryDetail>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_OTS_ENTRY_BY_INWARD_NO + inwardNo)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(OtsEntryDetail::class.java)
    }

    override fun getOtsModels(): Observable<List<OtsModel>> {
        val rx2AndroidNetworking = Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_OTS_MODELS)
            .addHeaders("Content-Type", "application/json")
            .build()
        return rx2AndroidNetworking.getObjectListObservable(OtsModel::class.java)
    }


    override fun getOtsStatusMaster(): Observable<List<OtsStatus>> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(ApiEndPoint.ENDPOINT_GET_OTS_STATUS_MASTER)
                .addHeaders("Content-Type", "application/json")
                .build()
        return rx2AndroidNetworking.getObjectListObservable(OtsStatus::class.java)
    }

    //************************************* ARJUNA APP APIS **********************************************************************/
    override fun getSummarySma012(
        brCode: String,
        loggedInMode: Int
    ): Observable<Sma012Obj> {

        var apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_SMA012
        when (loggedInMode) {
            1 -> apiUrl = ApiEndPoint.ENDPOINT_GET_BRANCH_SUMMARY_SMA012 + brCode
            2 -> apiUrl = ApiEndPoint.ENDPOINT_GET_ZONE_SUMMARY_SMA012 + brCode
            3 -> apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_SMA012
        }

        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        Log.d(TAG, " getDashboardSummarySMA012:- $apiUrl")
        return rx2AndroidNetworking.getObjectObservable(Sma012Obj::class.java)
    }

    override fun getSummaryRep6(
        brCode: String,
        loggedInMode: Int
    ): Observable<Rep6Obj> {
        var apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_REP6
        when (loggedInMode) {
            1 -> apiUrl = ApiEndPoint.ENDPOINT_GET_BRANCH_SUMMARY_REP6 + brCode
            2 -> apiUrl = ApiEndPoint.ENDPOINT_GET_ZONE_SUMMARY_REP6 + brCode
            3 -> apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_REP6
        }


        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        Log.d(TAG, " getDashboardSummaryRep6:- $apiUrl")

        return rx2AndroidNetworking.getObjectObservable(Rep6Obj::class.java)
    }

    override fun getSummaryRep7(
        brCode: String,
        loggedInMode: Int
    ): Observable<Rep7Obj> {

        var apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_REP7
        when (loggedInMode) {

            1 -> apiUrl = ApiEndPoint.ENDPOINT_GET_BRANCH_SUMMARY_REP7 + brCode
            2 -> apiUrl = ApiEndPoint.ENDPOINT_GET_ZONE_SUMMARY_REP7 + brCode
            3 -> apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_REP7

        }


        Log.d(TAG, " getDashboardSummaryRep7:- $apiUrl")

        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        return rx2AndroidNetworking.getObjectObservable(Rep7Obj::class.java)
    }

    override fun getZoneSectSumryReportWise(
        brCode: String,
        repType: String,
        loggedInMode: Int
    ): Observable<HoSectObj> {

        var apiUrl = ApiEndPoint.ENDPOINT_GET_HO_ZONESECTOR_SUMMARY_SMA1

        when (loggedInMode) {
            1 -> apiUrl = ApiEndPoint.ENDPOINT_GET_HO_ZONESECTOR_SUMMARY_SMA1 + brCode
            2 -> apiUrl = getZoneUrls(repType) + brCode
            3 -> apiUrl = getHOSectorUrls(repType)
        }


        Log.d(TAG, " getZoneSectSummary:- $apiUrl")
        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        return rx2AndroidNetworking.getObjectObservable(HoSectObj::class.java)
    }

    override fun getHoZoneSummary(
        brCode: String,
        isViewInLacs: Boolean,
        loggedInMode: Int
    ): Observable<ZoneSummaryObj> {

        var apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_Reportwise
        when (loggedInMode) {

            2 ->
                apiUrl = ApiEndPoint.ENDPOINT_GET_ZONE_SUMMARY_Reportwise + brCode

            3 ->
                apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_Reportwise + "99"

        }

        apiUrl = if (isViewInLacs) {
            "$apiUrl&AmtFlag=1" //in lacs
        } else {
            "$apiUrl&AmtFlag=0" //in crores
        }

        Log.d(TAG, "getHoZoneSummaryRep :- $apiUrl ")


        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")


            .build()
        val zoneSummaryObj = rx2AndroidNetworking.getObjectObservable(ZoneSummaryObj::class.java)
        Log.d(TAG, "getHoZoneSummaryRep :- $zoneSummaryObj ")

        return zoneSummaryObj

    }

    override fun getZoneSummary(
        brCode: String, isViewInLacs: Boolean,
        loggedInMode: Int
    ): Observable<ZoneSummaryObj> {

        var apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_Reportwise

        when (loggedInMode) {
//            1 -> {
//                apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_Reportwise + brCode
//            }
            2 -> {
                apiUrl = ApiEndPoint.ENDPOINT_GET_ZONE_SUMMARY_Reportwise + brCode
                if (isViewInLacs) {
                    apiUrl = "$apiUrl&AmtFlag=0" // in lacs
                } else {
                    apiUrl = "$apiUrl&AmtFlag=1" // in crore
                }
            }
            3 -> {
                apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_Reportwise + "99"
                if (isViewInLacs) {
                    apiUrl = "$apiUrl&AmtFlag=1" //in lacs
                } else {
                    apiUrl = "$apiUrl&AmtFlag=0" // in crore
                }
            }
        }


        Log.d(TAG, "getZoneSummary :- $apiUrl")

        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        return rx2AndroidNetworking.getObjectObservable(ZoneSummaryObj::class.java)
    }

    private fun getZoneUrls(repType: String): String {
        var zoneUrl = ""
        when (repType) {
            "sma0" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_ZO_SECTOR_SUMMARY_SMA0
            "sma1" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_ZO_SECTOR_SUMMARY_SMA1
            "sma2" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_ZO_SECTOR_SUMMARY_SMA2
            "totalsma" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_ZO_SECTOR_SUMMARY_TOTALSMA
            "report7f" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_ZO_SECTOR_SUMMARY_REP7f
            "report7d" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_ZO_SECTOR_SUMMARY_REP7D
            "report7nf" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_ZO_SECTOR_SUMMARY_REP7NF
            "total7" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_ZO_SECTOR_SUMMARY_TOTAL7
            "report6" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_ZO_SECTOR_SUMMARY_REP6
        }
        return zoneUrl
    }

    private fun getHOSectorUrls(repType: String): String {
        var zoneUrl = ""
        when (repType) {

            "sma0" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_HO_ZONESECTOR_SUMMARY_SMA0
            "sma1" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_HO_ZONESECTOR_SUMMARY_SMA1
            "sma2" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_HO_ZONESECTOR_SUMMARY_SMA2
            "totalsma" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_HO_SECTOR_SUMMARY_TOTALSMA
            "report7f" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_HO_SECTOR_SUMMARY_REP7f
            "report7d" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_HO_SECTOR_SUMMARY_REP7D
            "report7nf" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_HO_SECTOR_SUMMARY_REP7NF
            "total7" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_HO_SECTOR_SUMMARY_TOTAL7
            "report6" -> zoneUrl = ApiEndPoint.ENDPOINT_GET_HO_SECTOR_SUMMARY_REP6
        }
        return zoneUrl
    }


    override fun getSmaCustList(brCode: Int, report: Int, sortBy: Int): Observable<EncDataObj> {
        //https://bomapi.bankofmaharashtra.in/NPADASH/NPADASH.php?brcode=687&report=2&sortno=5
        val apiUrl =
            ApiEndPoint.ENDPOINT_GET_SMA_CUST_LIST + "brcode=" + brCode +
                    "&report=" + report + "&sortno=" + sortBy
//        interceptor.level = HttpLoggingInterceptor.Level.BODY

        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(apiUrl)
                .addHeaders("Content-Type", "application/json")
                .build()
        Log.d(TAG, "getSmaCustList :- $apiUrl")

        return rx2AndroidNetworking.getObjectObservable(EncDataObj::class.java)
    }

    override fun getCustDetails(custNo: String): Observable<EnCustAcDetailsObj> {
        //AllCustAcDetails
        val apiUrl = ApiEndPoint.ENDPOINT_GET_SMA_CUST_DETAILS + custNo
        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        Log.d(TAG, "getCustDetails :- $apiUrl")

        return rx2AndroidNetworking.getObjectObservable(EnCustAcDetailsObj::class.java)
    }

    override fun addSmaVisit(visit: SmaVisit): Observable<List<SmaVisit>> {
        val gson = GsonBuilder()
            .setLenient()
            .create()
        AndroidNetworking.setParserFactory(GsonParserFactory(gson))

        val rx2AndroidNetworking =
            Rx2AndroidNetworking.post(ApiEndPoint.ENDPOINT_POST_SMA_VISIT)
                .addHeaders("Content-Type", "application/json")
                .addBodyParameter("ptpDate", visit.ptpDate)
                .addBodyParameter("report", visit.report)
                .addBodyParameter("defaultSince", visit.defaultSinceDate)
                .addBodyParameter("visitDate", visit.visitDate)
                .addBodyParameter("custNo", visit.custNo)
                .addBodyParameter("custName", visit.custName)
                .addBodyParameter("visitorName", visit.visitorName)
                .addBodyParameter("visitorPfNo", visit.visitorPfNo)
                .addBodyParameter("comments", visit.comments)
                .build()
        return rx2AndroidNetworking.getObjectListObservable(SmaVisit::class.java)
//        AndroidNetworking.post("https://fierce-cove-29863.herokuapp.com/createUser")
//            .addBodyParameter(user) // posting java object
//            .setTag("test")
//            .setPriority(Priority.MEDIUM)
//            .build()
//            .getAsJSONArray(object : JSONArrayRequestListener {
//                override fun onResponse(response: JSONArray) {
//                    // do anything with response
//                }
//                override fun onError(error: ANError) {
//                    // handle error
//                }
//            })
    }

    override fun getSmaVisits(custNo: String): Observable<List<SmaVisit>> {
        val apiUrl = ApiEndPoint.ENDPOINT_GET_SMA_VISITS + custNo
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(apiUrl)
                .addHeaders("Content-Type", "application/json")
                .build()
        Log.d(TAG, "getSmaVisits :- $apiUrl")
        return rx2AndroidNetworking.getObjectListObservable(SmaVisit::class.java)
    }


    override fun getNotification(brCode: String, loggedInMode: Int): Observable<NotiObj> {

        var apiUrl = ApiEndPoint.ENDPOINT_GET_SMA_NOTIFICATION + brCode
        if (loggedInMode == 2) {
            apiUrl = ApiEndPoint.ENDPOINT_GET_SMA_NOTIFICATION_ZO + brCode
        }
        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        Log.d(TAG, "getNotification :- $apiUrl")
        return rx2AndroidNetworking.getObjectObservable(NotiObj::class.java)
    }

    override fun getSmaSummaryMonthly(
        brCode: String,
        callFromMode: Int
    ): Observable<Sma012Obj> {

        var apiUrl = ApiEndPoint.ENDPOINT_GET_SMA_MONTHLY_SUMMARY
        when (callFromMode) {
            1 -> apiUrl = ApiEndPoint.ENDPOINT_GET_BRANCH_SUMMARY_SMA012 + brCode
            2 -> apiUrl = ApiEndPoint.ENDPOINT_GET_ZONE_SUMMARY_SMA012 + brCode
            3 -> apiUrl = ApiEndPoint.ENDPOINT_GET_HO_SUMMARY_SMA012
        }
        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        Log.d(TAG, " getDashboardSummarySMA012:- $apiUrl")

        return rx2AndroidNetworking.getObjectObservable(Sma012Obj::class.java)
        Log.d(TAG, " getDashboardSummarySMA012:- ${rx2AndroidNetworking.responseAs}")

    }

    override fun getAnnouncement(): Observable<List<Announcement>> {

        val apiUrl = ApiEndPoint.ENDPOINT_GET_ANNOUNCEMENT
        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        Log.d(TAG, "getAnnouncement :- $apiUrl")
        return rx2AndroidNetworking.getObjectListObservable(Announcement::class.java)
    }

    override fun getNearbySmaCustList(address: String): Observable<MapCustomerList> {

        val apiUrl = ApiEndPoint.ENDPOINT_GET_MAP_CUSTOMER_LIST + address
        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        Log.d(TAG, "getNearbySmaCustList :- $apiUrl")
        return rx2AndroidNetworking.getObjectObservable(MapCustomerList::class.java)
    }

    override fun getEncryptedText(): Observable<EncryptDataObj> {
        val apiUrl = ApiEndPoint.ENDPOINT_EncryptionTestUrl

        val rx2AndroidNetworking =
            Rx2AndroidNetworking.get(apiUrl)
                .addHeaders("Content-Type", "application/json")
                .build()
        Log.d(TAG, "getEncryptedText Url :- $apiUrl")

        return rx2AndroidNetworking.getObjectObservable(EncryptDataObj::class.java)
    }


    /*************************************PAyment APIS Arjun APP Phase 2 ***********************************************************************/

    override fun createPaymentLink(payMsgLinkReq: PaymentMsgLinkReq): Observable<CreatePayMsgLinkResp> {
        val rx2AndroidNetworking =
            Rx2AndroidNetworking.post(ApiEndPoint.ENDPOINT_CREATE_PAYMENT_LINK)
                .addHeaders("Content-Type", "application/json")
                .addApplicationJsonBody(payMsgLinkReq)
                .build()
        Log.d(TAG, "createPaymentLink Url :- ${rx2AndroidNetworking.url}")

        return try {
            rx2AndroidNetworking.getObjectObservable(CreatePayMsgLinkResp::class.java)

        } catch (e: Exception) {
            e.printStackTrace()
            rx2AndroidNetworking.getObjectObservable(CreatePayMsgLinkResp::class.java)
        }

    }

    override fun postWhatsAppMessage(whatsAppMessage: WhatsAppMessage): Observable<WhatsappResponse> {

        val rx2AndroidNetworking =
            Rx2AndroidNetworking.post(ApiEndPoint.ENDPOINT_POST_WHATSAPP_MSG)
                .addHeaders("Content-Type", "application/json")
                .addApplicationJsonBody(whatsAppMessage)
                .build()
        Log.d(TAG, "postWhatsAppMessage Url :- ${rx2AndroidNetworking.url}")

        return try {
            rx2AndroidNetworking.getObjectObservable(WhatsappResponse::class.java)

        } catch (e: Exception) {
            e.printStackTrace()
            rx2AndroidNetworking.getObjectObservable(WhatsappResponse::class.java)
        }

    }
    override fun sendSMS(mobileNo:String,custName: String, custNo:String,reportName:String): Observable<WhatsappResponse> {


        val rx2AndroidNetworking =
            Rx2AndroidNetworking.post(ApiEndPoint.SEND_KARIX_MSG + "?mnumber="+mobileNo+"&custName="+custName+"&custNo="+custNo+"&reportName="+reportName)
                .addHeaders("Content-Type", "application/json")
                .build()
        Log.d(TAG, "sendSMS Url :- ${rx2AndroidNetworking.url}")

        return try {
            rx2AndroidNetworking.getObjectObservable(WhatsappResponse::class.java)

        } catch (e: Exception) {
            e.printStackTrace()
            rx2AndroidNetworking.getObjectObservable(WhatsappResponse::class.java)
        }

    }





    override fun getAgriDashb(): Observable<List<AgriObj>> {

        val apiUrl = ApiEndPoint.ENDPOINT_GET_AGRI_DASHBOARD
        val rx2AndroidNetworking = Rx2AndroidNetworking.get(apiUrl)
            .addHeaders("Content-Type", "application/json")
            .build()
        Log.d(TAG, "getAgriDashb :- $apiUrl")
        return rx2AndroidNetworking.getObjectListObservable(AgriObj::class.java)
    }
}




