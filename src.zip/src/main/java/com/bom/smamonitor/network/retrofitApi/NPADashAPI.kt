package com.bom.smamonitor.network.retrofitApi

import com.bom.smamonitor.addVisit.SmaStressVisit
import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.dashboardbb.models.Announcement
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.LoginResponse
import okhttp3.RequestBody
import okhttp3.Response
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST

interface NPADashAPI {

    @Headers("Content-Type: application/json")
    @POST("smaapp/addSmaAppVisit")
    fun addVisitSmaNew(@Body smaVisit: SmaVisit): Call<List<SmaVisit>>

    @Headers("Content-Type: application/json")
    @POST("smaapp/addSmaStressAppVisit")
    fun addVisitSmaStressNew(@Body smaVisit: SmaStressVisit): Call<List<SmaStressVisit>>

    @Headers("Content-Type: application/json")
    @POST("smaapp/addSmaAppUserLog")
    fun addSmaAppUser(@Body appUser: AppUser): Call<LoginResponse>

    @Headers("Content-Type: application/json")
    @POST("REMARKS.PHP")
    fun addSmaVisit(@Body smaVisit: RequestBody): Call<List<SmaVisit>>


    @Headers("Content-Type: application/json")
    @POST("smaapp/addAnnouncement")
    fun addAnnouncement(@Body announcement: Announcement): Call<LoginResponse>

    @Headers("Content-Type: application/json")
    @POST("smaapp/addSmaAppUserLog")
    fun addSmaAppUserLog(@Body appUser: AppUser): Call<LoginResponse>

}