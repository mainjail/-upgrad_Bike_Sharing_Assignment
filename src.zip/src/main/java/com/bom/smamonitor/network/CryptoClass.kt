package com.bom.smamonitor.network

import android.os.Build
import androidx.annotation.RequiresApi
import java.util.*
import javax.crypto.*
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

object CryptoClass {
    private const val CIPHER_KEY_LEN = 16 //128 bits

    const val ENCRYPTION_KEY = "9822378851989080" // 128 bit key

//    @Throws(
//        NoSuchAlgorithmException::class,
//        NoSuchPaddingException::class,
//        InvalidKeyException::class,
//        InvalidParameterSpecException::class,
//        IllegalBlockSizeException::class,
//        BadPaddingException::class,
//        UnsupportedEncodingException::class
//    )
//     fun encryptMsgECB(message: String, secret: SecretKey?): String? {
//        var cipher: Cipher? = null
//        cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
//        cipher.init(Cipher.ENCRYPT_MODE, secret)
//        val cipherText: ByteArray = cipher.doFinal(message.toByteArray(charset("UTF-8")))
//        Log.d("Mesg", "cipherText:  $cipherText")
//        return Base64.encodeToString(cipherText, Base64.NO_WRAP)
//    }
//
//    @Throws(
//        NoSuchPaddingException::class,
//        NoSuchAlgorithmException::class,
//        InvalidParameterSpecException::class,
//        InvalidAlgorithmParameterException::class,
//        InvalidKeyException::class,
//        BadPaddingException::class,
//        IllegalBlockSizeException::class,
//        UnsupportedEncodingException::class
//    )
//     fun decryptMsgECB(cipherText: String?, secret: SecretKey?): String {
//        var cipher: Cipher? = null
//        cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
//        cipher.init(Cipher.DECRYPT_MODE, secret)
//        val decode: ByteArray = Base64.decode(cipherText, Base64.NO_WRAP)
//        Log.d("Mesg", "decode:$decode")
//
//        return String(cipher.doFinal(decode), StandardCharsets.UTF_8)
//    }
//
//    @Throws(NoSuchAlgorithmException::class, InvalidKeySpecException::class)
//    fun generateKeyECB(key: String): SecretKey {
//        val secret: SecretKeySpec = SecretKeySpec(key.toByteArray(), "AES")
//        return secret
//    }


//    @RequiresApi(Build.VERSION_CODES.O)
//    fun decryptAes(
//        algorithm: String,
//        cipherText: String,
//        key: SecretKeySpec,
//        iv: IvParameterSpec
//    ): String {
//        val cipher = Cipher.getInstance(algorithm)
//        cipher.init(Cipher.DECRYPT_MODE, key, iv)
//        val plainText = cipher.doFinal(Base64.getDecoder().decode(cipherText))
//        return String(plainText)
//    }
//
//    @RequiresApi(Build.VERSION_CODES.O)
//    fun encryptAes(
//        algorithm: String,
//        inputText: String,
//        key: SecretKeySpec,
//        iv: IvParameterSpec
//    ): String {
//        val cipher = Cipher.getInstance(algorithm)
//        cipher.init(Cipher.ENCRYPT_MODE, key, iv)
//        val cipherText = cipher.doFinal(inputText.toByteArray())
//        return Base64.getEncoder().encodeToString(cipherText)
//    }

//    val inputText = "abcdefghigklmnopqrstuvwxyz0123456789"
//    val algorithm = "AES/CBC/PKCS5Padding"
//    val key = SecretKeySpec("1234567890123456".toByteArray(), "AES")




    @RequiresApi(Build.VERSION_CODES.O)
    fun decryptFromHex(hexdata: String): String? {
        var key = ENCRYPTION_KEY
        var orgString = ""
        try {
            if (key.length < CIPHER_KEY_LEN) {
                val numPad: Int = CIPHER_KEY_LEN - key.length
                for (i in 0 until numPad) {
                    key += "0" //0 pad to len 16 bytes
                }
            } else if (key.length > CIPHER_KEY_LEN) {
                key = key.substring(0, CIPHER_KEY_LEN) //truncate to 16 bytes
            }
            val data = hexToAscii(hexdata)
            val parts = data.split(":".toRegex()).toTypedArray()
                val iv = IvParameterSpec(Base64.getDecoder().decode(parts[1]))
                val skeySpec = SecretKeySpec(key.toByteArray(charset("UTF-8")), "AES")
                val cipher = Cipher.getInstance(CIPHER_NAME)
                cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv)
                val decodedEncryptedData = Base64.getDecoder().decode(parts[0])
                val originalByteArry = cipher.doFinal(decodedEncryptedData)
                orgString = String(originalByteArry)


            return orgString
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
        return null
    }

    private fun asciiToHex(asciiStr: String): String? {
        val chars = asciiStr.toCharArray()
        val hex = StringBuilder()
        for (ch in chars) {
            hex.append(Integer.toHexString(ch.code))
        }
        return hex.toString()
    }

    private fun hexToAscii(hexStr: String): String {
        val output = StringBuilder("")
        var i = 0
        while (i < hexStr.length) {
            val str = hexStr.substring(i, i + 2)
            output.append(str.toInt(16).toChar())
            i += 2
        }
        return output.toString()
    }

    val iv = IvParameterSpec(ByteArray(16))

    private const val CIPHER_NAME = "AES/CBC/PKCS5PADDING"

    @RequiresApi(Build.VERSION_CODES.O)
    fun encryptToHex(  data: String): String? {
        var key = ENCRYPTION_KEY
        val iv = iv
        try {
            if (key.length <  CIPHER_KEY_LEN) {
                val numPad: Int =  CIPHER_KEY_LEN - key.length
                for (i in 0 until numPad) {
                    key += "0" //0 pad to len 16 bytes
                }
            } else if (key.length >  CIPHER_KEY_LEN) {
                key = key.substring(0, CIPHER_KEY_LEN) //truncate to 16 bytes
            }
           // val initVector = IvParameterSpec(iv.toByteArray(charset("UTF-8")))
            val initVector = IvParameterSpec(ByteArray(16))
            val skeySpec = SecretKeySpec(key.toByteArray(charset("UTF-8")), "AES")
            val cipher = Cipher.getInstance( CIPHER_NAME)
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, initVector)
            val encryptedData = cipher.doFinal(data.toByteArray())
            val base64_EncryptedData = Base64.getEncoder().encodeToString(encryptedData)
            val base64_IV = Base64.getEncoder().encodeToString(ByteArray(16))
            return asciiToHex("$base64_EncryptedData:$base64_IV")

        } catch (ex: java.lang.Exception) {
            ex.printStackTrace()
        }
        return null
    }


}