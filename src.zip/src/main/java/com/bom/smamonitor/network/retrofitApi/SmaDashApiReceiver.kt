package com.bom.smamonitor.network.retrofitApi

import android.util.Log
import com.androidnetworking.interceptors.HttpLoggingInterceptor
import com.bom.smamonitor.addVisit.SmaStressVisit
import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.dashboardbb.models.Announcement
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.LoginResponse
import com.bom.smamonitor.network.ApiEndPoint
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import okhttp3.*
import retrofit2.Callback
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory


class SmaDashApiReceiver {

    private val npaDashAPI: NPADashAPI

    //    val BaseApiUrl = ApiEndPoint.API_BASE_URL_Post_NPADASH //
    // https://bomapi.bankofmaharashtra.in/npadash/REMARKS.PHP
    val BaseApiUrl = ApiEndPoint.API_BASE_URL_FromOldNPATracker

    init {
        val gson = GsonBuilder().setLenient().create()

        val certPinner = CertificatePinner.Builder()
            .add(
                BaseApiUrl,//BuildConfig.BASE_URL or just add 125.17.112.44:7003
                "sha256/E368BC374D7FBCD0FBA60BD7DBA87DD5C360F90C55D73BBB1C648682318B9F0A" //Key hash value of server api certificate
            )
            .build()
        val interceptor = HttpLoggingInterceptor()
        interceptor.level = HttpLoggingInterceptor.Level.BODY
        // val client = OkHttpClient.Builder().addInterceptor(interceptor).build()

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(interceptor)
            .certificatePinner(certPinner)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(BaseApiUrl)
            .client(okHttpClient) // for SSL Pinning in retrofit add it before build()
            .addConverterFactory(ScalarsConverterFactory.create())
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()

        npaDashAPI = retrofit.create(NPADashAPI::class.java)


    }

    /*This method takes a callback that will be called once the API call has finished.
    This method calls our mService and then enqueues it, which means that it will run asynchronously.*/

    fun addSmaVisitRetroService(visit: SmaVisit, callBack: Callback<List<SmaVisit>>) {
        val smaVisitJson = JsonObject()
        smaVisitJson.addProperty("visitId", "")
        smaVisitJson.addProperty("ptpDate", visit.ptpDate)
        smaVisitJson.addProperty("report", visit.report)
        smaVisitJson.addProperty("defaultSince", visit.defaultSinceDate)
        smaVisitJson.addProperty("visitDate", visit.visitDate)
        smaVisitJson.addProperty("custNo", visit.custNo)
        smaVisitJson.addProperty("custName", visit.custName)
        smaVisitJson.addProperty("collectionAction", visit.collectionAction)
        smaVisitJson.addProperty("visitorName", visit.visitorName)
        smaVisitJson.addProperty("visitorPfNo", visit.visitorPfNo)
        smaVisitJson.addProperty("comments", visit.comments)

        val requestBody: RequestBody = RequestBody.create(
            MediaType.parse("application/json; charset=utf-8"),
            smaVisitJson.toString()
        )
        val videos = npaDashAPI.addSmaVisit(requestBody)
        videos.enqueue(callBack)
    }

    fun addSmaVisitRetroService2(visit: SmaVisit, callBack: Callback<List<SmaVisit>>) {
        Log.d("npaDashApi", BaseApiUrl)
        val videos = npaDashAPI.addVisitSmaNew(visit)
       videos.enqueue(callBack)
    }

    fun addSmaStressVisitRetroService2(visit: SmaStressVisit, callBack: Callback<List<SmaStressVisit>>) {
        Log.d("npaDashApi", BaseApiUrl)
        val videos = npaDashAPI.addVisitSmaStressNew(visit)
        videos.enqueue(callBack)
    }

    fun addSmaUserRetroService2(appUser: AppUser, callBack: Callback<LoginResponse>) {
        Log.d("addSmaUserRetro", BaseApiUrl)
        val gson = GsonBuilder().setLenient().create()
        Log.d("addSmaUserRetro Obj", gson.toJson(appUser))

        val videos = npaDashAPI.addSmaAppUser(appUser)
        videos.enqueue(callBack)
    }

    fun addAnnouncementRetrofit(announcement: Announcement, callBack: Callback<LoginResponse>) {
        Log.d("npaDashApi", BaseApiUrl)
        val videos = npaDashAPI.addAnnouncement(announcement)
        videos.enqueue(callBack)
    }

    fun addSmaUserLogRetroService2(appUser: AppUser, callBack: Callback<LoginResponse>) {
        Log.d("addSmaUserLog", BaseApiUrl)
        val gson = GsonBuilder().setLenient().create()
        Log.d("addSmaUserLog Obj", gson.toJson(appUser))

        val videos = npaDashAPI.addSmaAppUserLog(appUser)
        videos.enqueue(callBack)
    }



}