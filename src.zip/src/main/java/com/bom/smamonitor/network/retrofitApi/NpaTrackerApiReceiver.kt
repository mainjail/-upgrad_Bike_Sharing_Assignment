package com.bom.smamonitor.network.retrofitApi

import com.androidnetworking.interceptors.HttpLoggingInterceptor
import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.addVisit.Visit
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.LoginResponse
import com.bom.smamonitor.network.ApiEndPoint
import com.bom.smamonitor.ots.Repayment
import com.bom.smamonitor.ots.applEntry.OtsEntryDetail
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import okhttp3.CertificatePinner
import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import retrofit2.Callback
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory


class NpaTrackerApiReceiver {

    private val npaTrackerApi: NpaTrackerApi

    val BaseApiUrl= ApiEndPoint.API_BASE_URL_FromOldNPATracker

    // https://bomapi.bankofmaharashtra.in/npadash/REMARKS.PHP
    init {
        val gson = GsonBuilder().setLenient().create()

        val certPinner = CertificatePinner.Builder()
            .add(
                BaseApiUrl,//BuildConfig.BASE_URL or just add 125.17.112.44:7003
                "sha256/E368BC374D7FBCD0FBA60BD7DBA87DD5C360F90C55D73BBB1C648682318B9F0A" //Key hash value of server api certificate
            )
            .build()
        val interceptor = HttpLoggingInterceptor()
        interceptor.level = HttpLoggingInterceptor.Level.BODY
        // val client = OkHttpClient.Builder().addInterceptor(interceptor).build()

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(interceptor)
            .certificatePinner(certPinner)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(BaseApiUrl)
            .client(okHttpClient) // for SSL Pinning in retrofit add it before build()
//            .addConverterFactory(ScalarsConverterFactory.create())
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()

        npaTrackerApi = retrofit.create(NpaTrackerApi::class.java)
    }

    /*This method takes a callback that will be called once the API call has finished.
    This method calls our mService and then enqueues it, which means that it will run asynchronously.*/
    fun addVisitRetroService(visit: Visit, callBack: Callback<List<Visit>>) {
        val videos = npaTrackerApi.addVisit(visit)
        videos.enqueue(callBack)
    }




    fun addSmaUserRetroService(appUser: AppUser, callBack: Callback<LoginResponse>) {

        val jsonBody: String? = Gson().toJson(appUser, AppUser::class.java)
        val requestBody: RequestBody =            RequestBody.create(MediaType.parse("application/json; charset=utf-8"), jsonBody.toString())
//      API_BASE_URL_FromOldNPATracker ->  https://bomapi.bankofmaharashtra.in/recovery/webserverapi/v1/users/addSmaAppUser}
        val videos = npaTrackerApi.addSmaUserToDb(requestBody)
        videos.enqueue(callBack)
    }

    fun addUserRetroService(appUser: AppUser, callBack: Callback<LoginResponse>) {
        val videos = npaTrackerApi.addUserToDb(appUser)
        videos.enqueue(callBack)
    }

    fun addOtsApplication(
        otsEntryDetail: OtsEntryDetail,
        callBack: Callback<List<OtsEntryDetail>>
    ) {
        val videos = npaTrackerApi.addOtsApplicationApi(otsEntryDetail)
        videos.enqueue(callBack)
    }

    fun addRepaymentPlanService(repayment: Repayment, callBack: Callback<List<Repayment>>) {
        val videos = npaTrackerApi.addOtsRepaymentPlan(repayment)
        videos.enqueue(callBack)
    }


}