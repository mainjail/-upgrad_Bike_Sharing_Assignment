package com.bom.smamonitor.network.retrofitApi

import okhttp3.RequestBody
import okhttp3.Response
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface OTPAPI {
    @Headers("Accept: application/json","Content-Type: application/x-www-form-urlencoded")

    @GET("HttpLink?aid=646128&pin=f~M)h5p!&mnumber=8956345918&signature=MAHABK&message=Dear%20Sir/Madam,%20your%20OTP%20is%20123456%20for%20ARJUN%20App.MahaBank")
    fun getOtp(): Call<String>

    @GET("/my/API/call")
    fun getMyThing(
        @Query("aid") param1: String?,
        @Query("pin") param2: String?,
        @Query("mnumber") param3: String?,
        @Query("message") param4: String?,
    ): Response?
}