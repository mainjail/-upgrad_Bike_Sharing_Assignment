package com.bom.smamonitor.network.retrofitApi

import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.addVisit.Visit
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.LoginResponse
import com.bom.smamonitor.ots.Repayment
import com.bom.smamonitor.ots.applEntry.OtsEntryDetail
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface NpaTrackerApi {

    @Headers("Content-Type: application/json")
    @POST("npa/addVisit")
    fun addVisit(@Body visit: Visit): Call<List<Visit>>



    @Headers("Content-Type: application/json")
    @POST("users/addNewUser")
    fun addUserToDb(@Body appUser: AppUser): Call<LoginResponse>

    @Headers("Content-Type: application/json")
    @POST("users/addSmaAppUser")
    fun addSmaUserToDb(@Body appUser: RequestBody): Call<LoginResponse>

//    fun addSmaUserToDb(@Body appUser: AppUser): Call<LoginResponse>

    @Headers("Content-Type: application/json")
    @POST("ots/addOtsCustomer")
    fun addOtsApplicationApi(@Body otsEntry: OtsEntryDetail): Call<List<OtsEntryDetail>>

    @Headers("Content-Type: application/json")
    @POST("ots/addOtsRepayment")
    fun addOtsRepaymentPlan(@Body repayment: Repayment): Call<List<Repayment>>
}