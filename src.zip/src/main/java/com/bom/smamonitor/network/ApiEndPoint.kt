package com.bom.smamonitor.network

import com.bom.smamonitor.BuildConfig


object ApiEndPoint {

    //    http://localhost:5000/recovery/api/v1/npa/getNpaCustomers/676
    // https://bomapi.bankofmaharashtra.in/Arjuna/npadash.php?
    private const val API_BASE_URL = BuildConfig.BASE_URL + "npadash.php?"

    private const val API_BASE_URL_PHASE2 = "https://bomapi.bankofmaharashtra.in/arjunwebapis/api/"

//    const val API_BASE_URL_Post_NPADASH = "https://bomapi.bankofmaharashtra.in/npadash/"




   const val API_BASE_URL_FromOldNPATracker = "https://bomapi.bankofmaharashtra.in/recovery/webserverapi/v1/"

   // const val API_BASE_URL_FromOldNPATracker = "http://localhost:5000/recovery/api/v1/"





    //    test server api
    val TOKEN_API = "Login"
    val ENDPOINT_LoginServer = BuildConfig.BASE_URL + "Login"
    val ENDPOINT_DOWNLOAD_FILE = BuildConfig.BASE_URL + "download"

    //Product Files Api endpoint
    val SUBBASE_URL_NPA = "npa/"
    val ENDPOINT_GET_NPA_CUSTOMERS = BuildConfig.BASE_URL + SUBBASE_URL_NPA + "getNpaCustomers"
    val ENDPOINT_GET_BRANCHES = BuildConfig.BASE_URL + SUBBASE_URL_NPA + "getBranches/"
    val ENDPOINT_GET_REGIONS = BuildConfig.BASE_URL + SUBBASE_URL_NPA + "getRegions"
    val ENDPOINT_GET_BRANCH_Head_details =
        API_BASE_URL_FromOldNPATracker + SUBBASE_URL_NPA + "getBranchHeadDetails/"
    val ENDPOINT_GET_SEARCH_CUSTOMERS =
        BuildConfig.BASE_URL + SUBBASE_URL_NPA + "getSearchCustomer/"
    val ENDPOINT_GET_CUSTOMER_BY_CUSTNO =
        BuildConfig.BASE_URL + SUBBASE_URL_NPA + "getCustomerByCustNo/"
    val ENDPOINT_GET_BRANCH_Head_Photo =
        API_BASE_URL_FromOldNPATracker + SUBBASE_URL_NPA + "getBranchHeadPhoto/"
    val ENDPOINT_ADD_VISIT = BuildConfig.BASE_URL + SUBBASE_URL_NPA + "addVisit"
    //val ENDPOINT_GET_VISITS = BuildConfig.BASE_URL + SUBBASE_URL_NPA + "getVisits/"

    //Business Figures Api endpoint
    val SUBBASE_URL_BUSINESS = "business/"
    val ENDPOINT_GET_TOTAL_FIGURES =
        BuildConfig.BASE_URL + SUBBASE_URL_BUSINESS + "getTotalFigures/"
    val ENDPOINT_GET_NPA_FIGURES = BuildConfig.BASE_URL + SUBBASE_URL_BUSINESS + "getNpaFigures/"

    //Users Apis Endpoint
    val SUBBASE_URL_USERS = "users/"
    val ENDPOINT_GET_EMPLOYEE = BuildConfig.BASE_URL + SUBBASE_URL_USERS + "getEmployee/"
    val ENDPOINT_Add_USER = SUBBASE_URL_USERS + "addNewUser"

    //OTS Api endpoint
    val SUBBASE_URL_OTS = "ots/"
    val ENDPOINT_GET_OTS_CUSTOMER =
        BuildConfig.BASE_URL + SUBBASE_URL_OTS + "getOtsCustomer/" // cbs details of Customer api
    val ENDPOINT_GET_OTS_ENTRY_BY_CIF =
        BuildConfig.BASE_URL + SUBBASE_URL_OTS + "getOtsEntryDetails/"
    val ENDPOINT_GET_OTS_ENTRY_BY_INWARD_NO =
        BuildConfig.BASE_URL + SUBBASE_URL_OTS + "getOtsByInwardNo/"
    val ENDPOINT_GET_ALL_OTS_ENTRIES = BuildConfig.BASE_URL + SUBBASE_URL_OTS + "getAllOtsEntries"

    val ENDPOINT_GET_OTS_MODELS = BuildConfig.BASE_URL + SUBBASE_URL_OTS + "getOtsModels"
    val ENDPOINT_GET_OTS_STATUS_MASTER =
        BuildConfig.BASE_URL + SUBBASE_URL_OTS + "getOtsStatusMaster"

    val ENDPOINT_ADD_OTS_REPAYMENT_PLAN = SUBBASE_URL_OTS + "addOtsRepayment"

    val ENDPOINT_ADD_OTS_APPLTN = SUBBASE_URL_OTS + "addOtsCustomer"

    //SMA Monitor  ApiS endpoint
    // Head office, Zone sector summary
    const val ENDPOINT_GET_HO_SUMMARY_SMA012 = API_BASE_URL + "HOSMA012=test"
    const val ENDPOINT_GET_HO_SUMMARY_REP6 = API_BASE_URL + "HOREP6=test"
    const val ENDPOINT_GET_HO_SUMMARY_REP7 = API_BASE_URL + "HOREP7=test"

    const val ENDPOINT_GET_ZONE_SUMMARY_SMA012 = API_BASE_URL + "ZOSMA012="
    const val ENDPOINT_GET_ZONE_SUMMARY_REP6 = API_BASE_URL + "ZOREP6="
    const val ENDPOINT_GET_ZONE_SUMMARY_REP7 = API_BASE_URL + "ZOREP7="

    const val ENDPOINT_GET_BRANCH_SUMMARY_SMA012 = API_BASE_URL + "BRSMA012="
    const val ENDPOINT_GET_BRANCH_SUMMARY_REP6 = API_BASE_URL + "BRREP6="
    const val ENDPOINT_GET_BRANCH_SUMMARY_REP7 = API_BASE_URL + "BRREP7="


    //    HO zone sectorwise summary urls
    const val ENDPOINT_GET_HO_ZONESECTOR_SUMMARY_SMA0 = API_BASE_URL + "HoSectSumSma0=99"
    const val ENDPOINT_GET_HO_ZONESECTOR_SUMMARY_SMA1 = API_BASE_URL + "HoSectSumSma=99"
    const val ENDPOINT_GET_HO_ZONESECTOR_SUMMARY_SMA2 = API_BASE_URL + "HoSectSumSma2=99"
    const val ENDPOINT_GET_HO_SECTOR_SUMMARY_TOTALSMA = API_BASE_URL + "HoSectSumTotalSma=99"
    const val ENDPOINT_GET_HO_SECTOR_SUMMARY_REP7f = API_BASE_URL + "HoSectSumRep7F=99"
    const val ENDPOINT_GET_HO_SECTOR_SUMMARY_REP7D = API_BASE_URL + "HoSectSumRep7D=99"
    const val ENDPOINT_GET_HO_SECTOR_SUMMARY_REP7NF = API_BASE_URL + "HoSectSumRep7NF=99"
    const val ENDPOINT_GET_HO_SECTOR_SUMMARY_REP6 = API_BASE_URL + "HoSectSumRep6=99"
    const val ENDPOINT_GET_HO_SECTOR_SUMMARY_TOTAL7 = API_BASE_URL + "HoSectSumRep7=99"

    //    Zone sector wise summary URls
    const val ENDPOINT_GET_ZO_SECTOR_SUMMARY_SMA0 = API_BASE_URL + "ZoSectSumSma0="
    const val ENDPOINT_GET_ZO_SECTOR_SUMMARY_SMA1 = API_BASE_URL + "ZoSectSumSma="
    const val ENDPOINT_GET_ZO_SECTOR_SUMMARY_SMA2 = API_BASE_URL + "ZoSectSumSma2="
    const val ENDPOINT_GET_ZO_SECTOR_SUMMARY_TOTALSMA = API_BASE_URL + "ZoSectSumTotalSma="
    const val ENDPOINT_GET_ZO_SECTOR_SUMMARY_REP7f = API_BASE_URL + "ZoSectSumRep7F="
    const val ENDPOINT_GET_ZO_SECTOR_SUMMARY_REP7D = API_BASE_URL + "ZoSectSumRep7D="
    const val ENDPOINT_GET_ZO_SECTOR_SUMMARY_REP7NF = API_BASE_URL + "ZoSectSumRep7NF="
    const val ENDPOINT_GET_ZO_SECTOR_SUMMARY_REP6 = API_BASE_URL + "ZoSectSumRep6="
    const val ENDPOINT_GET_ZO_SECTOR_SUMMARY_TOTAL7 = API_BASE_URL + "ZoSectSumRep7="

    //    Zone sector wise summary URls HO

    const val ENDPOINT_GET_HO_SUMMARY_Reportwise = API_BASE_URL + "HoRepSum="
    const val ENDPOINT_GET_ZONE_SUMMARY_Reportwise = API_BASE_URL + "ZoRepSum="

    //     SMA MONTHLY SUMMARY
    const val ENDPOINT_GET_SMA_MONTHLY_SUMMARY = API_BASE_URL + "HOSMA012="

    // Branch Customer list
//https://bomapi.bankofmaharashtra.in/NPADASH/NPADASH.php?brcode=687&report=2&sortno=5
    const val ENDPOINT_GET_SMA_CUST_LIST = API_BASE_URL
    const val ENDPOINT_GET_SMA_CUST_DETAILS = API_BASE_URL + "AllCustAcDetails="

    const val ENDPOINT_POST_SMA_VISIT = "https://bomapi.bankofmaharashtra.in/npadash/REMARKS.PHP"

   // const val ENDPOINT_GET_SMA_VISITS = API_BASE_URL + "VisitDetails="
    const val ENDPOINT_GET_SMA_NOTIFICATION = API_BASE_URL + "Notification="
    const val ENDPOINT_GET_SMA_NOTIFICATION_ZO = API_BASE_URL + "NotificationZo="
    const val ENDPOINT_GET_SMA_NOTIFICATION_BR = API_BASE_URL + "NotificationBr="

//    const val ENDPOINT_GET_ANNOUNCEMENT = API_BASE_URL + "Announcement=9999"

    const val ENDPOINT_GET_MAP_CUSTOMER_LIST = API_BASE_URL

    //SMA APP Node js Api
    const val Sub_Url_SMAAPP = "smaapp/"
    const val ENDPOINT_GET_ANNOUNCEMENT = API_BASE_URL_FromOldNPATracker + Sub_Url_SMAAPP + "getAnnouncements"
    val ENDPOINT_GET_SMA_VISITS = API_BASE_URL_FromOldNPATracker + Sub_Url_SMAAPP+ "getSmaAppVisit/"

    const val ENDPOINT_EncryptionTestUrl = API_BASE_URL + "Encrypt=12345"


    /*************************************ENdpoints Arjun APP Phase 2 ***********************************************************************/

    /// SHA 512 Algorithm Key
    val SHA512_ALGO_KEY= "A2OEHVZPKS"
    var SHA512_ALGO_SALT = "YLVD3RJJ4N"
    //     Third Party MONTHLY SUMMARY
    const val ENDPOINT_CREATE_PAYMENT_LINK = API_BASE_URL_PHASE2 + "ThirdPartyApi/CreateEasyCollectLink"
    const val ENDPOINT_POST_WHATSAPP_MSG = API_BASE_URL_PHASE2 + "ThirdPartyApi/PostWhatsAppMsg"
    const val ENDPOINT_SEND_KARIX_MSG = API_BASE_URL_PHASE2 + "ThirdPartyApi/SendSMS"
    const val ENDPOINT_GET_AGRI_DASHBOARD = API_BASE_URL_PHASE2 + "AgriABCD/GetHOReportABCD"

 //send defaulter sms
 const val SEND_KARIX_MSG = "https://bomapi.bankofmaharashtra.in/arjunwebapinew/api/ArjunaOTP/SendDefaulterSMS"


}