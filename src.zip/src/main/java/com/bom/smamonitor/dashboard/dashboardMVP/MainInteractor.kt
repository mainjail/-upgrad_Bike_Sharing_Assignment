package com.bom.smamonitor.dashboard.dashboardMVP

import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.login.User
import com.bom.smamonitor.network.ApiHelper
import javax.inject.Inject


class MainInteractor @Inject internal constructor(
    preferenceHelper: PreferenceHelper, apiHelper: ApiHelper
)
    : BaseInteractor(preferenceHelper = preferenceHelper, apiHelper = apiHelper), MainMVPInteractor {

//    override fun getUserDetails() = Pair(preferenceHelper.getCurrentUserName(),
//            preferenceHelper.getCurrentUserEmail())

    override fun getUserDetails(): User {
        return User(
//            preferenceHelper.getCurrentUserName().toString(),
//            preferenceHelper.getCurrentUserEmail().toString(),
//            preferenceHelper.getCurrentBranchCode().toString()
            preferenceHelper.getCurrentUserPfNo().toString(),
            preferenceHelper.getCurrentUserName().toString(),
            preferenceHelper.getCurrentBranchCode().toString(),
            "","",preferenceHelper.getCurrentDeptCode(),
            "",
            preferenceHelper.getCurrentUserMobileNo().toString(),
        preferenceHelper.getCurrentBranchName().toString())

    }
//    override fun makeLogoutApiCall() = apiHelper.performLogoutApiCall()

}


