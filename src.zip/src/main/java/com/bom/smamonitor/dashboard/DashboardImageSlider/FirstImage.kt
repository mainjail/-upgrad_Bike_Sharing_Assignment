package com.bom.smamonitor.dashboard.DashboardImageSlider

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.bom.smamonitor.R
import kotlinx.android.synthetic.main.onboarding_first_fragment.view.*

class FirstImage : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.onboarding_first_fragment, container, false)
//        view.notificationTextView.text=resources.getString(R.string.onboardingTagline1)
//        view.mainOnbLL.setBackgroundResource(R.mipmap.onb3)
        view.notificationTextView.visibility=View.GONE
//        view.bgImageView.setImageResource(R.mipmap.onb4)
        return view
    }
}
