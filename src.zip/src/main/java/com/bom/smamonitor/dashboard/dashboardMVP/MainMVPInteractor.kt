package com.bom.smamonitor.dashboard.dashboardMVP

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.login.User


interface MainMVPInteractor : MVPInteractor {

    //    fun getQuestionCardData(): Single<List<QuestionCardData>>
    fun getUserDetails(): User?
//    fun makeLogoutApiCall() : Observable<LogoutResponse>

}