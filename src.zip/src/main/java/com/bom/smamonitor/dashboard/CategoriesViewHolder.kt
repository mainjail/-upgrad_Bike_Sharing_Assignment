package com.bom.smamonitor.dashboard

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.category_item_layout.view.*

class CategoriesViewHolder (itemView : View): RecyclerView.ViewHolder(itemView){
    fun bindView(movieModel: CatModel) {
        itemView.catTitle.text = movieModel.categoryName
        itemView.imageCat.setImageDrawable(movieModel.catImage)
//        Glide.with(itemView.context).load(movieModel.moviePicture!!).into(itemView.imageMovie)
    }
}