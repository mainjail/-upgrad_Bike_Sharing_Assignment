package com.bom.smamonitor.dashboard

import com.bom.smamonitor.dashboard.dashboardMVP.*
import dagger.Module
import dagger.Provides

@Module
class DashboardActivityModule {

    @Provides
    internal fun provideMainInteractor(mainInteractor: MainInteractor): MainMVPInteractor = mainInteractor

    @Provides
    internal fun provideMainPresenter(mainPresenter: DashboardPresenterImpl<MainMVPView, MainMVPInteractor>)
            : DashboardPresenter<MainMVPView, MainMVPInteractor> = mainPresenter

}