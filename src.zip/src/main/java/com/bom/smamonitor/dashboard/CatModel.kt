package com.bom.smamonitor.dashboard

import android.graphics.drawable.Drawable
import android.net.Uri
import java.net.URI


data class CatModel (val categoryName:String,  val catImage: Drawable)
data class ImageViewModel (val imageName:String,  val imageUri: Uri)
