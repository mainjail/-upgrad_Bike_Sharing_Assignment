package com.bom.smamonitor.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R

class CategoriesItemAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var listOfCategories = listOf<CatModel>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CategoriesViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.category_item_layout,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int = listOfCategories.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val categoriesViewHolder = viewHolder as CategoriesViewHolder
        categoriesViewHolder.bindView(listOfCategories[position])
    }

    fun setCategoryList(listOfMovies: List<CatModel>) {
        this.listOfCategories = listOfMovies
        notifyDataSetChanged()
    }


}