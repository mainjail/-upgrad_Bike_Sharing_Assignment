package com.bom.smamonitor.dashboard.dashboardMVP

import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

class DashboardPresenterImpl<V : MainMVPView, I : MainMVPInteractor>
@Inject internal constructor(interactor: I, schedulerProvider: SchedulerProvider, disposable: CompositeDisposable) :
    BasePresenter<V, I>(
        interactor = interactor,
        schedulerProvider = schedulerProvider,
        compositeDisposable = disposable
    ),
    DashboardPresenter<V, I> {

    override fun onDrawerOptionShareClick() {}

    override fun onDrawerOptionPrivacyClick() {}

    override fun onDrawerOptionBLCCClick() {}


    override fun refreshCards(): Boolean? {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onDrawerOptionHomeClick() = getView()?.openFeedActivity()
    override fun onDrawerOptionCategoriesClick() = getView()?.openFeedActivity()
    override fun onDrawerOptionProfileClick() = getView()?.openAboutFragment()
    override fun onDrawerOptionContactUsClick() = getView()?.openContactUsActivity()

    override fun onAttach(view: V?) {
        super.onAttach(view)
        getUserData()
//        getQuestionCards()
    }


    override fun onDrawerOptionLogoutClick() {
        interactor?.performUserLogout()

//        interactor?.let {
//            compositeDisposable.add(
//                it.makeLogoutApiCall()
//                    .compose(schedulerProvider.ioToMainObservableScheduler())
//                    .subscribe({
//                        interactor?.performUserLogout()
//                        getView()?.let {
//                            it.hideProgress()
//                            it.openLoginActivity()
//                        }
//                    }, { err -> println(err) }))
//        }
    }


    private fun getUserData() = interactor?.let {
        val userData = it.getUserDetails()
        getView()?.inflateUserDetails(userData)
    }



}