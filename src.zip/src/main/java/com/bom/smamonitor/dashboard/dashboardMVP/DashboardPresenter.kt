package com.bom.smamonitor.dashboard.dashboardMVP

import com.bom.smamonitor.base.presenter.MVPPresenter

interface DashboardPresenter<V : MainMVPView, I : MainMVPInteractor> : MVPPresenter<V, I> {

    fun refreshCards(): Boolean?
    fun onDrawerOptionHomeClick() : Unit?
    fun onDrawerOptionCategoriesClick(): Unit?
    fun onDrawerOptionProfileClick(): Unit?
    fun onDrawerOptionLogoutClick()
    fun onDrawerOptionShareClick()
    fun onDrawerOptionContactUsClick(): Unit?

    fun onDrawerOptionPrivacyClick()
    fun onDrawerOptionBLCCClick()


}