package com.bom.smamonitor.dashboard.dashboardMVP

import com.bom.smamonitor.base.view.BaseMVPView
import com.bom.smamonitor.login.User

interface MainMVPView : BaseMVPView {

    fun inflateUserDetails(userDetails: User?)
    fun openLoginActivity()
    fun openFeedActivity()
    fun openAboutFragment()
    fun openContactUsActivity()
    fun goToAvgBusMixActivity()
//    fun goToInfoBlogActivity()
    fun goToProductsServiceActivity()
    fun goToCalciActivity()
    fun goToMISReportsActivity()
    fun goToAlertsActivity()
    fun goToTop100AcsActivity()
    fun goToNPAMonitoringActivity()
}