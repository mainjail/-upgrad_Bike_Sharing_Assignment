package com.bom.smamonitor.dashboard

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.bom.smamonitor.R
import kotlinx.android.synthetic.main.onboarding_first_fragment.view.*


@Suppress("DEPRECATION")
class DashboardSlideImageAdapter(fz: FragmentActivity, images: List<String>) : PagerAdapter() {

    val activity = fz
    private val imagesUrls = images

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun getCount(): Int {
        return imagesUrls.size
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val inflater =
            activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.onboarding_first_fragment, null)

        view.notificationTextView.visibility = View.GONE
        view.sliderImageView.visibility = View.VISIBLE

        view.sliderImageView.setImageDrawable(activity.resources.getDrawable(R.mipmap.bankofmh))
//        view.sliderImageView.setImageURI(images[position].toUri())

        val viewPager = container as ViewPager
        viewPager.addView(view, 0)

        return view
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        val viewPager = container as ViewPager
        val view = `object` as View
        viewPager.removeView(view)
    }
}