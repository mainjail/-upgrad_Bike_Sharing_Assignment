package com.bom.smamonitor.dashboard;

data class Categories( val categoryId:Int, val categoryName:String)
