@file:Suppress("DEPRECATION")

package com.bom.smamonitor.util

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.ContentValues.TAG
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.widget.Toast
import androidx.annotation.RawRes
import androidx.appcompat.widget.AppCompatButton
import androidx.core.graphics.drawable.toDrawable
import com.bom.smamonitor.R
import com.bom.smamonitor.dashboardbb.DashboardBBActivity
import com.bom.smamonitor.zonesectrsumry.HoSectObj
import com.google.gson.Gson
import kotlinx.android.synthetic.main.custom_dialog_layout.view.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.net.URLEncoder
import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.*


object CommonUtil {

    fun showLoadingDialog(context: Context?): ProgressDialog {
        val progressDialog = ProgressDialog(context)
        progressDialog.let {
            try {
                it.show()
                it.window?.setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
                it.setContentView(R.layout.progress_dialog)
                it.isIndeterminate = true
                it.setCancelable(false)
                it.setCanceledOnTouchOutside(false)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return it
        }
    }
    fun showSessionTimedOutDialog(context: Context?, msg: String?) {
        val builder = AlertDialog.Builder(context)
        val positiveButtonClick = { dialog: DialogInterface, which: Int ->
            Toast.makeText(context,
                android.R.string.yes, Toast.LENGTH_SHORT).show()
        }
        val negativeButtonClick = { dialog: DialogInterface, which: Int ->
            Toast.makeText(context,
                android.R.string.no, Toast.LENGTH_SHORT).show()
        }
        val neutralButtonClick = { dialog: DialogInterface, which: Int ->
            Toast.makeText(context,
                "Maybe", Toast.LENGTH_SHORT).show()
        }
        with(builder)
        {
            setTitle("Alert Session Timeout")
            setMessage("Session timed out after 3 minutes on inactivity.")
            setPositiveButton("OK", DialogInterface.OnClickListener(function = positiveButtonClick))
           // setNegativeButton(android.R.string.no, negativeButtonClick)
            //setNeutralButton("Maybe", neutralButtonClick)
            show()
        }


    }
    fun getFormattedAmount(amount: Int): String {
        var formatNumber = ""
        try {
            formatNumber =
                NumberFormat.getNumberInstance(Locale.getDefault()).format(amount.toLong())
        } catch (e: NumberFormatException) {
            Log.e(TAG, "getFormattedAmount NumberFormatException")
        }
        return formatNumber
    }

    @Suppress("RECEIVER_NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
    fun getDeformableIntAmount(number: String): String {
        var value = number
        try {
            if (number.contains(",")) {
                value =
                    NumberFormat.getIntegerInstance(Locale.getDefault()).parse(number).toString()
            }
        } catch (e: NumberFormatException) {
            Log.e(TAG, "getDeformableIntAmount NumberFormatException")
        }
        return value
    }

    fun Double.toLacs(): String {
        val df = DecimalFormat("#.##")
        df.roundingMode = RoundingMode.DOWN
        return df.format(this / 100000)
    }

    fun Double.toCrores(): String {
        val df = DecimalFormat("#.##")
        df.roundingMode = RoundingMode.DOWN
        return df.format(this / 10000000)
    }
    fun roundUpto2Decimal(number: Double): String {
        val df = DecimalFormat("#.##")
        df.roundingMode = RoundingMode.CEILING
        return df.format(number).toString()
    }

    private fun formatRoundUp2dec(num: Double): String? {
        return String.format("%.02f", num)
    }

    fun formatRoundUp(number: String?): String {
        //println("formatRoundUp:-${number}")
        val numDouble = number?.toDoubleOrNull() ?: 0.0
        val decimal = BigDecimal(numDouble).setScale(2, RoundingMode.HALF_EVEN)
        var formatNumber = ""
        try {
            val myFormatter = DecimalFormat("###,###.###")
            val output: String = myFormatter.format(decimal)
            formatNumber = output
            //println("formatNumber:-${formatNumber}")

//            formatNumber = NumberFormat.getNumberInstance(Locale.getDefault()).format(amount.toLong())
        } catch (e: Exception) {
            Log.e(TAG, "getFormattedAmount NumberFormatException")
        }
        return formatNumber
    }

    fun makeACall(number: String, context: Context) {
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse("tel:$number")
//         if (intent.resolveActivity(context.packageManager) != null)
        context.startActivity(intent)
    }

    fun sendASMS(number: String, message: String,  context: Context) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("sms:$number"))
        intent.putExtra("sms_body", message)
        context.startActivity(intent)
    }

    fun openWhatsApp(phoneNumber: String, message: String, context: Context) {
        try {
            val packageManager: PackageManager = context.packageManager
            val i = Intent(Intent.ACTION_VIEW)
            val url =
                "https://api.whatsapp.com/send?phone=$phoneNumber&text=" + URLEncoder.encode(
                    message,
                    "UTF-8"
                )
            Log.d(TAG,"watsAppUrl:-"+url)
            i.setPackage("com.whatsapp")
            i.data = Uri.parse(url)
            // if (i.resolveActivity(packageManager) != null) {
            context.startActivity(i)
//            } else {
//                Toast.makeText(context,"Whats app not available.",Toast.LENGTH_LONG).show();
//            }
        } catch (e: java.lang.Exception) {
            Toast.makeText(context, "Whats app not available.", Toast.LENGTH_LONG).show();
            Log.e("ERROR WHATSAPP", e.toString())
        }
    }

    fun goBackToHome(context: Context) {
        val intent = Intent(context, DashboardBBActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        context.startActivity(intent)
//        context.finish()
    }
     fun getAddressFromLatLong(context: Context, latitude: Double, longitude: Double): String {
        val geoCoder = Geocoder(context, Locale.getDefault())
        val addresses: List<Address>?
        val address: Address?
        var fulladdress = ""
        addresses = geoCoder.getFromLocation(latitude, longitude, 1)

        if (addresses.isNotEmpty()) {
            address = addresses[0]
            fulladdress =
                address.getAddressLine(0) // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex
            var city = address.locality
            var state = address.adminArea
            var country = address.countryName
            var postalCode = address.postalCode
            var knownName = address.featureName // Only if available else return NULL
        } else {
            fulladdress = "Location not found"
        }
        return fulladdress
    }

    fun readJsonFile( context: Context) {
        val objectArrayString: String =            context.resources.openRawResource(R.raw.hosectsumsma).bufferedReader()
                .use { it.readText() }
        val objectArray = Gson().fromJson(objectArrayString, HoSectObj ::class.java)
    }

    inline fun <reified T> Context.jsonToClass(@RawRes resourceId: Int): T =
        Gson().fromJson(
            resources.openRawResource(resourceId).bufferedReader().use { it.readText() },
            T::class.java
        )
    // Which you would then simply call like this:

    //context.jsonToClass<MyObject>(R.raw.my_object)
}