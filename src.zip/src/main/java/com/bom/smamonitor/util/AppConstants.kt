package com.bom.smamonitor.util


/**
 * Created by  Smita
 */
object AppConstants {

    internal val APP_DB_NAME = "mahabank_mahareports.db"
    internal val PREF_NAME = "mahabank_pref"

    //Same error codes can be used in user profile / branch profile/zonal profile screen for validations.
    internal val EMPTY_EMAIL_ERROR = 1001
    internal val EMPTY_MOBILENO_ERROR = 1002
    internal val EMPTY_BRANCHCODE_ERROR = 1003
    internal val EMPTY_PFNO_ERROR = 1004

    internal val INVALID_EMAIL_ERROR = 1005
    internal val INVALID_MOBILENO_ERROR = 1006
    internal val INVALID_BRANCH_CODE = 1007
    internal val INVALID_PFNO = 1008
    val LOGIN_CredentialsWrong= 3001

    internal val LOGIN_FAILURE = 1009
    internal val NULL_INDEX = -1L
    internal val EMPTY_PFNO_Mobile_ERROR = 1010

    internal val MAX_TIME_OUT_SESSION = 10 * 60 * 1000  // 3 minutes , // 3 min= 60*3*1000

    enum class LoggedInMode constructor(val type: Int) {
        LOGGED_IN_MODE_LOGGED_OUT(0),
        LOGGED_IN_MODE_BRANCH(1),
        LOGGED_IN_MODE_ZONE(2),
        LOGGED_IN_MODE_HO(3)
    }
}