package com.bom.smamonitor.util

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import java.text.SimpleDateFormat
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*


object DateUtil {

    private val calendar = Calendar.getInstance()


    @SuppressLint("SimpleDateFormat")
    fun convertToDateDDMMMYYYY(firstDate: String): String {
//        val firstDate = "08/08/2019"
        val date = SimpleDateFormat("yyyy-MM-dd").parse(firstDate)
//        val formatter = SimpleDateFormat("dd/MM/yyyy")
//        val date = formatter.parse(firstDate)
        val desiredFormat = SimpleDateFormat("dd, MMM yyyy").format(date)
        println(desiredFormat) //08, Aug 2019
        return desiredFormat
    }

    fun convertDateToddMMyy(firstDate: String): String {
//        val firstDate = "08/08/2019"
        val date = SimpleDateFormat("yyyy-MM-dd").parse(firstDate)
        val formatter = SimpleDateFormat("dd/MM/yyyy")
//        val date = formatter.parse(firstDate)
        val desiredFormat = formatter.format(date)
//        val desiredFormat = SimpleDateFormat("dd, MMM yyyy").format(date)
        println(desiredFormat) //08, Aug 2019
        return desiredFormat
    }

    fun getYesterdayDateString(): String {
//        val dateFormat =  SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        val calendar = Calendar.getInstance()

        val dateFormat = SimpleDateFormat("dd/MM/yyyy");
        calendar.add(Calendar.DATE, -1);
        return dateFormat.format(calendar.time);
    }

    fun getDateBeforeYesterdayString(): String {
//        val dateFormat =  SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        val dateFormat = SimpleDateFormat("dd/MM/yyyy");
        val calendar = Calendar.getInstance()

        //  calendar.add(Calendar.DATE, -2);
        calendar.add(Calendar.DAY_OF_YEAR, -2);

        return dateFormat.format(calendar.time);
    }

    //    private fun findNextDay(localdate: LocalDate): LocalDate? {
//        return localdate.plusDays(1)
//    }
//
    @RequiresApi(Build.VERSION_CODES.O)
    fun findDateDiff(fromApiDate: String): Int {
        var fromDate = fromApiDate
        //Log.d("DateUtil", "fromApiDate =$fromApiDate")

//        if (fromDate.length < 11) {
//            fromDate = "$fromDate 00:00:00.000"
//            SimpleDateFormat("MMM d, yyyy HH:mm:ss").parse(fromDate)
//        }

        //Log.d("DateUtil", "TodayToday =${Date().toInstant()}")
       //Log.d("DateUtil", "FromDate =$fromDate")

        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(fromDate)
        println("Date: $date")
       // Log.d("DateUtil", "DateConverted =$date")
       // Log.d("DateUtil", "DateConvertedInstant =${date?.toInstant()}")

        val diff = Duration.between(Date().toInstant(), date?.toInstant()).abs()
       // Log.d("DateUtil", "finalDiff =${diff.toDays().toInt()+1}")

        return (diff.toDays().toInt() + 1)

    }

    fun getTodayDate(): String {
//        val dateFormat =  SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        val dateFormat = SimpleDateFormat("dd/MM/yyyy")
        return dateFormat.format(Date())
    }
    @RequiresApi(Build.VERSION_CODES.O)
    fun getTodaysDateTime(): String {
        val currentDate = LocalDate.now()
        val formatterDate = DateTimeFormatter.ofPattern("dd-MM-yyyy")
       // return currentDate.format(formatterDate)
        val currentDateTime = LocalDateTime.now()

        val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")
        return currentDateTime.format(formatter)
    }


    @RequiresApi(Build.VERSION_CODES.O)
    fun getDateAfterAddingDays(daysToAdd: Long): String {
        val currentDate = LocalDate.now()
        val futureDate = currentDate.plusDays(daysToAdd)
        val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
        return futureDate.format(formatter)
    }


    private fun openDatePickerDialog(
        context: Context,
        dateSetListener: DatePickerDialog.OnDateSetListener
    ) {
        val datePickerDialog1 = DatePickerDialog(
            context, dateSetListener,
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )

        datePickerDialog1.datePicker.maxDate = (Calendar.getInstance().timeInMillis)
//        datePickerDialog1.datePicker.updateDate(Calendar.YEAR,1,1)App
        datePickerDialog1.show()
    }


}