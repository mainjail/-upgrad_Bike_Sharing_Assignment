package com.bom.smamonitor.util

import android.app.Activity
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import com.bom.smamonitor.R
import kotlinx.android.synthetic.main.custom_dialog_layout.view.*

class CustomDialog {

    fun showAlert(activity: Activity, msg: String?) {
        val layoutInflater: LayoutInflater = activity.layoutInflater
        val dialogView = layoutInflater.inflate(R.layout.custom_dialog_layout, null)
        dialogView.tvMsgDialog.text = msg
        dialogView.ivError.setImageResource(R.drawable.ic_error_alert)
        val customDialog = AlertDialog.Builder(activity).setView(dialogView).show()
//        dialogView.tvDialogTitle.setText("")
        val btDismiss = dialogView.findViewById<AppCompatButton>(R.id.btDismissCustomDialog)

        btDismiss.setOnClickListener {
            customDialog.dismiss()
        }
    }

    fun popUpToast(activity: Activity, msg: String?) {
        Toast.makeText(activity, msg, Toast.LENGTH_LONG).show()
    }

    fun showNoInternetAlert(activity: Activity, msg: String?) {
        var errorMsg = msg
        if (msg.isNullOrEmpty())
            errorMsg = activity.resources.getString(R.string.noInternetError)
        val layoutInflater: LayoutInflater = activity.layoutInflater

        val dialogView = layoutInflater.inflate(R.layout.custom_dialog_layout, null)
        dialogView.tvMsgDialog.text = errorMsg
        dialogView.ivError.setImageResource(R.drawable.ic_network)
        val customDialog = AlertDialog.Builder(activity).setView(dialogView).show()
//        dialogView.tvDialogTitle.setText("")
        val btDismiss = dialogView.findViewById<AppCompatButton>(R.id.btDismissCustomDialog)
        btDismiss.setOnClickListener {
            customDialog.dismiss()
        }
    }

    fun showAlertWithTitle(activity: Activity, msg: String?, title: String) {
        val layoutInflater: LayoutInflater = activity.layoutInflater

        val dialogView = layoutInflater.inflate(R.layout.custom_dialog_layout, null)
        dialogView.tvMsgDialog.apply {
            text = msg
            gravity = Gravity.START
        }
        dialogView.tvDialogTitle.text = title
        dialogView.ivError.setImageResource(R.drawable.ic_error_alert)
        dialogView.ivError.visibility = View.GONE

        val customDialog = AlertDialog.Builder(activity).setView(dialogView).show()
//        dialogView.tvDialogTitle.setText("")
        val btDismiss = dialogView.findViewById<AppCompatButton>(R.id.btDismissCustomDialog)
        btDismiss.setOnClickListener {
            customDialog.dismiss()
        }
    }
//    fun showMessageDialog(activity: Context, msg:String?) {
//        val layoutInflater: LayoutInflater = activity.c.layoutInflater
//        val dialogView = layoutInflater.inflate(R.layout.custom_dialog_layout, null)
//        dialogView.tvMsgDialog.text = msg
//        dialogView.ivError.setImageResource(R.drawable.ic_error_alert)
//        val customDialog =  AlertDialog.Builder(activity).setView(dialogView).show()
////        dialogView.tvDialogTitle.setText("")
//        val btDismiss = dialogView.findViewById<AppCompatButton>(R.id.btDismissCustomDialog)
//        btDismiss.setOnClickListener {
//            customDialog.dismiss()
//        }
//    }


}