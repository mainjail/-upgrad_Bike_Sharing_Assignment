package com.bom.smamonitor.custlist.model

import com.google.gson.annotations.SerializedName

data class CustAcDetails(
//{ "Report": "SMA0", "PROD_NAME": "HSG MAHASUP PRI-U&METRO ",
//    "ACNO": 60406473639, "AC_NAME": "AKASH PRADIPBHAI PANCHAL ",
//    "SANC_AMT": 2465000, "BALANCE": 2465002,
//    "OLD_IRAC": 0, "OVERDUE": 18817,
//    "NPA_DATE": "2022-02-10 00:00:00.000",
//    "CIF": 40243248925
//} //old CstAcDetails Api results

    @SerializedName("SMA_FLAG")
    val smaFlag: String,

    @SerializedName("PROD_NAME")
    val prodName: String,

//    @SerializedName("AC_NAME")
//    val acName: String,

    @SerializedName("ACNO")
    val acNo: String,

    @SerializedName("CIF")
    val cif: String,

    @SerializedName("BALANCE")
    val balance: String,

    @SerializedName("SANC_AMT")
    val sancAmt: String,

    @SerializedName("OVERDUE")
    val overdue: String,

    @SerializedName("OLD_IRAC")
    val oldIrac: String,

    @SerializedName("NEW_IRAC")
    val newIrac: String,

    @SerializedName("AC_OPEN_DATE")
    val acOpenDate: String,

    @SerializedName("REPAY_OPTION")
    val repayOption: String,

    @SerializedName("PEND_DUES_DATE")
    val pendDuesDate: String,

    @SerializedName("INST_AMT")
    val instAmt: String,

    @SerializedName("PROBABLE_NPA_DATE")
    val probableNpaDate: String,

    @SerializedName("DEFAULT_DATE")
    val defaultDate: String,

    @SerializedName("ptpDate")
    val ptpDate: String,

    @SerializedName("CIF_DATEOFDEF")
    val cifDateOfDefault: String

//    PROD_NAME	:	MAHA BNK GOLD LN RETAIL
//ACNO	:	60409584643
//CUST_NAME	:	DADA BALASAHEB PAWAR
//SANC_AMT	:	25000
//BALANCE	:	25005
//OLD_IRAC	:	0
//OVERDUE	:	0
//DEFAULT_DATE	:	null
//CIF	:	40026659159
//AC_OPEN_DATE	:	2022-02-28 00:00:00.000
//NEW_IRAC	:	0
//REPAY_OPTION	:	2
//PEND_DUES_DATE	:	2023-02-27 00:00:00.000
//INST_AMT	:	26750
//SMA_FLAG	:	null
//PROBABLE_NPA_DATE

){
    override fun toString(): String {
        return "$acNo"
    }
}


data class CustAcDetailsObj(
    @SerializedName("AllCustAcDetails")
    val custAcDetailsList: List<CustAcDetails>
)

data class EnCustAcDetailsObj(
    @SerializedName("EnAllCustAcDetails")
    val enCustDetailsObj: String
)
//{ "CustAcDetails": [
//    { "Report": "SMA0", "PROD_NAME": "CrGuaSchforSubDebt-CGSSD ",
//    "ACNO": 60366162221, "AC_NAME": "SHAH BROTHERS ",
//    "SANC_AMT": 1700000, "BALANCE": 1711955.27, "OLD_IRAC": 0,
//    "OVERDUE": 11955.27, "NPA_DATE": "2022-03-01 00:00:00.000",
//    "CIF": 40017980345 }
//
