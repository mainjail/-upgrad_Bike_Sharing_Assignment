package com.bom.smamonitor.custlist.model

import com.google.gson.annotations.SerializedName
import java.math.BigDecimal

data class CustomerRep2(



    @SerializedName("PROD_NAME")
    val prodName: String,

    @SerializedName("REGCODE")
    val regCode: String,

    @SerializedName("BRNAME")
    val brName: String,

    @SerializedName("BRCODE")
    val brCode: String,

    @SerializedName("CIF")
    val cif: String,

    @SerializedName("ACNO")
    val acNo: String,

    @SerializedName("BALANCE")
    val balance: Double,

    @SerializedName("SANC_AMT")
    val sancAmt: Double,

    @SerializedName("OVERDUE")
    val overdue: Double,

    @SerializedName("CUST_BAL")
    val custBal: BigDecimal,

    @SerializedName("OLD_IRAC")
    val oldIrac: Int,

    @SerializedName("NEW_IRAC")
    val newIrac: Int,

    @SerializedName("SANC_DATE")
    val sancDate: String,

    @SerializedName("AC_OPEN_DATE")
    val acOpenDate: String,

    @SerializedName("ARREAR_CONDITION")
    val ArrearCond: String,

    @SerializedName("CR_AMOUNT")
    val crAmount: Double,

    @SerializedName("CR_DATE")
    val crDate: String,

    @SerializedName("MOBILE")
    val mobNo: String,

    @SerializedName("CUST_NAME")
    val custName: String,

//    @SerializedName("Default_date")
//    val defaultDate: String,

// Report 6 params

    @SerializedName("AC_NAME")
    val acName: String,

    @SerializedName("STATUS_ID")
    val statusId: Int,

    @SerializedName("REMARKS")
    val remarks: String,

    @SerializedName("VISIT_DATE")
    val visitDate: String,

    @SerializedName("NEXT_FOLLOW_UP_DATE")
    val nextFollowUpDate: String,

    @SerializedName("AMT_FOR_UPGRADATION")
    val amtForUpgradation: Double,

    @SerializedName("NPA_DATE")
    val npaDate: String,

    @SerializedName("LOAN_BAL")
    val loanBal: Double,

    @SerializedName("LAST_ARREAR_DATE")
    val lastArrearDate: String,

    @SerializedName("REPAY_OPTION")
    val repayOption: String,

    @SerializedName("EARLY_STK_CR_DATE")
    val earlyStkCrDate: String,

    @SerializedName("LAST_CUST_CR_DATE")
    val lastCustCrDate: String,

    @SerializedName("LAST_INT_ARRVL_DATE")
    val lastIntArrvlDate: String,

    @SerializedName("LAST_OVER_LIM_DATE")
    val LastOverLimDate: String,

    @SerializedName("CURR_REN_DATE")
    val currRenDate: String,

    @SerializedName("LOAN_REPAY")
    val loanRepay: String,

    @SerializedName("LAST_UNDER_LIM_DATE")
    val lastUnderLimDate: String,

    @SerializedName("LAST_NO_INT_ARREAR_DATE")
    val lastNoIntArrearDate: String,

    @SerializedName("STRESSED_AC_FLG")
    val stressedAcFlg: String,

    @SerializedName("PROBABLE_NPA_DATE")
    val probableNpaDate: String,

    @SerializedName("HO_REMARKS")
    val hoRemarks: String,

    @SerializedName("Default_date")
    val defaultDate: String,

    @SerializedName("CIF_DATEOFDEF")
    val cifDateofDef: String,

    @SerializedName("PEND_DUES_DATE")
    val pendDuesDate: String,

    @SerializedName("INST_AMT")
    val instAmt: String,

    @SerializedName("SMA_FLAG")
    val smaFlag: String,
// New APi for location wise customer

//{ "ADD1": "806 SHIVAJI NAGAR KAMGAR PUTALA", "ADD2": "PUNE", "ADD3": "SHIVAJI NAGAR PUNE 411005",
//    "POSTCODE": 411005, "CIF": 4004339592C1, "ACNO": 60402873187,
//    "CUST_NAME": "VIDYA BHAU AWHAD ", "BALANCE": 511663,
//    "BRCODE": 43, "latitude": null, "longitude": null, "custName": null, "custNo": null, "ptpDate": null }

    @SerializedName("ADD1")
val add1: String,
@SerializedName("ADD2")
val add2: String,
@SerializedName("ADD3")
val add3: String,
@SerializedName("POSTCODE")
val postcode: String,
@SerializedName("latitude")
val lat: String,
@SerializedName("longitude")
val long: String,
@SerializedName("custName")
val custMapName: String,
@SerializedName("custNo")
val custNo: String,
@SerializedName("ptpDate")
val ptpDate: String


)

//": [
//{
//    "BRCODE": 687,
//    "BRNAME": "IEET ",
//    "REGCODE": 25,
//    "PROD_NAME": "PM-SVANidhi                   ",
//    "CIF": 40024923808,
//    "ACNO": 60397112104,
//    "BALANCE": 10128.02,
//    "SANC_AMT": 10000,
//    "OVERDUE": 2474.02,
//    "CUST_BAL": 10128.02,
//    "OLD_IRAC": 0,
//    "NEW_IRAC": 2,
//    "SANC_DATE": "2021-10-11 00:00:00.000",
//    "AC_OPEN_DATE": "2021-10-11 00:00:00.000",
//    "ARREAR_CONDITION": 262,
//    "CR_AMOUNT": 874,
//    "CR_DATE": "-",
//    "MOBILE": null,
//    "CUST_NAME": "GOKUL ROHIDAS KADAM "

//Report 10
//"AMT_FOR_UPGRADATION": -67.72,
//"NPA_DATE": "31/07/2020",

// Report 7 params
//"LOAN_BAL": 320291,
//"OVERDUE": 287712.56,
//"HO_REMARKS": null,
//"HO_STATUS": null,
//"LAST_ARREAR_DATE": "28-Jun-2017",
//"CURR_REN_DATE": "-",
//"EARLY_STK_CR_DATE": "09-Jun-2016",
//"LAST_CUST_CR_DATE": "-",
//"LAST_INT_ARRVL_DATE": "28-Jun-2018",
//"LAST_OVER_LIM_DATE": "-",
//"REPAY_OPTION": "2         ",
//"LOAN_REPAY": 40822,
//"LAST_UNDER_LIM_DATE": "27/06/2017",
//"LAST_NO_INT_ARREAR_DATE": "27-Jun-2018",
//"STRESSED_AC_FLG": "-",
//"PROBABLE_NPA_DATE": "-",


data class ReportObj0(
    @SerializedName("Report0")
    val report0CustList: List<CustomerRep2>
)

data class ReportObj1(
    @SerializedName("Report1")
    val report1CustList: List<CustomerRep2>
)

data class ReportObj2(
    @SerializedName("Report2")
    val report2CustList: List<CustomerRep2>
)

data class ReportObj6(
    @SerializedName("Report6")
    val report6CustList: List<CustomerRep2>
)

data class ReportObj10(
    @SerializedName("Report10")
    val report10CustList: List<CustomerRep2>
)

data class ReportObj11(
    @SerializedName("Report10_2")
    val report10_2CustList: List<CustomerRep2>
)

data class MapCustomerList(
    @SerializedName("CustAcDetails")
    val mapCustomerList: List<CustomerRep2>
)

