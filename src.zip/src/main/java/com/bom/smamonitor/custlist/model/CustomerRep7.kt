package com.bom.smamonitor.custlist.model

import com.google.gson.annotations.SerializedName

data class CustomerRep7(


    @SerializedName("PROD_NAME")
    val prodName: String,

    @SerializedName("REGCODE")
    val regCode: String,

    @SerializedName("BRNAME")
    val brName: String,

    @SerializedName("BRCODE")
    val brCode: String,

    @SerializedName("CIF")
    val cif: String,

    @SerializedName("ACNO")
    val acNo: String,

    @SerializedName("BALANCE")
    val balance: Double,

    @SerializedName("SANC_AMT")
    val sancAmt: Double,

    @SerializedName("OVERDUE")
    val overdue: Double,

    @SerializedName("CUST_BAL")
    val custBal: Double,

    @SerializedName("OLD_IRAC")
    val oldIrac: Int,

    @SerializedName("NEW_IRAC")
    val newIrac: Int,

    @SerializedName("SANC_DATE")
    val sancDate: String,

    @SerializedName("AC_OPEN_DATE")
    val acOpenDate: String,

    @SerializedName("ARREAR_CONDITION")
    val ArrearCond: String,

    @SerializedName("CR_AMOUNT")
    val crAmount: Double,

    @SerializedName("CR_DATE")
    val crDate: String,

    @SerializedName("MOBILE")
    val mobNO: String,

    @SerializedName("CUST_NAME")
    val custName: String,

    @SerializedName("AC_NAME")
    val acName: String,

    @SerializedName("STATUS_ID")
    val statusId: Int,

    @SerializedName("REMARKS")
    val remarks: String,

    @SerializedName("VISIT_DATE")
    val visitDate: String,

    @SerializedName("NEXT_FOLLOW_UP_DATE")
    val nextFollowUpDate: String,

    @SerializedName("LOAN_BAL")
    val loanBal: Double,

    @SerializedName("LAST_ARREAR_DATE")
    val lastArrearDate: String,

    @SerializedName("REPAY_OPTION")
    val repayOption: String,

    @SerializedName("EARLY_STK_CR_DATE")
    val earlyStkCrDate: String,

    @SerializedName("LAST_CUST_CR_DATE")
    val lastCustCrDate: String,

    @SerializedName("LAST_INT_ARRVL_DATE")
    val lastIntArrvlDate: String,

    @SerializedName("LAST_OVER_LIM_DATE")
    val LastOverLimDate: String,

    @SerializedName("CURR_REN_DATE")
    val currRenDate: String,

    @SerializedName("LOAN_REPAY")
    val loanRepay: String,

    @SerializedName("LAST_UNDER_LIM_DATE")
    val lastUnderLimDate: String,

    @SerializedName("LAST_NO_INT_ARREAR_DATE")
    val lastNoIntArrearDate: String,

    @SerializedName("STRESSED_AC_FLG")
    val stressedAcFlg: String,

    @SerializedName("PROBABLE_NPA_DATE")
    val probableNpaDate: String,

    @SerializedName("HO_REMARKS")
    val hoRemarks: String,

    @SerializedName("HO_STATUS")
    val hoStatus: String

    )


//"LOAN_BAL": 25520.44,
//"OLD_IRAC": 0,
//"NEW_IRAC": 2,
//"OVERDUE": 520.44,
//"CIF": 10214835445,
//"LAST_ARREAR_DATE": "25-Mar-2022",
//"CURR_REN_DATE": "-",
//"EARLY_STK_CR_DATE": "01-Jan-2021",
//"LAST_CUST_CR_DATE": "08-Feb-2022",
//"LAST_INT_ARRVL_DATE": "31-Mar-2021",
//"LAST_OVER_LIM_DATE": "30-Nov-2021",
//"REPAY_OPTION": "-         ",
//"LOAN_REPAY": 0,
//"LAST_UNDER_LIM_DATE": "24/08/2021",
//"LAST_NO_INT_ARREAR_DATE": "24-Aug-2021",
//"STRESSED_AC_FLG": "Y",
//"PROBABLE_NPA_DATE": "2022-02-28",
//"CUST_BAL": 25520,
//"STATUS_ID": 1,
//"REMARKS": "ASSURED TO REPAY",
//"NEXT_FOLLOW_UP_DATE": "08/05/2017",
//"VISIT_DATE": "02/05/2017",
//"HO_REMARKS": null,
//"HO_STATUS": null,
//"MOBILE": null
//

data class ReportObj7(
    @SerializedName("Report7")
    val report7CustList: List<CustomerRep2>
)

data class ReportObj7NF(
    @SerializedName("Report8")
    val report7NFCustList: List<CustomerRep2>
)

data class ReportObj7D(
    @SerializedName("Report9")
    val report7DCustList: List<CustomerRep2>
)
