package com.bom.smamonitor.custlist

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Filter
import android.widget.Filterable
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.util.CommonUtil
import com.bom.smamonitor.util.DateUtil
import com.bom.smamonitor.util.DateUtil.convertDateToddMMyy
import kotlinx.android.synthetic.main.item_sma_customer_layout.view.*
import java.lang.reflect.InvocationTargetException
import java.util.*


class SmaCustAdapter(activity: Activity) :
    RecyclerView.Adapter<SmaCustAdapter.CustomerViewHolder>(), Filterable {



    private var rvClickListener:RecyclerViewClickListener?=null

    private var originalListCustomers = mutableListOf<CustomerRep2>()
    private var customersList = mutableListOf<CustomerRep2>()

    // private val viewPool = RecyclerView.RecycledViewPool()
    private val context = activity

    val String.capitalizeWords
        get() = this.toLowerCase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.capitalize(
                Locale.getDefault()
            )
        }


    interface RecyclerViewClickListener {
        fun recyclerViewListClicked(v: View?, position: Int,customerRep2: CustomerRep2)
    }
    fun setOnItemClickListener(listener: RecyclerViewClickListener?) {
        rvClickListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = CustomerViewHolder(
        LayoutInflater.from(parent.context)
            .inflate(R.layout.item_sma_customer_layout, parent, false)
    )

    override fun getItemCount() = this.customersList.size

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItemViewType(position: Int): Int {
        return position // necessary for maintaining scroll position on scroll for views so they dont change values.
    }

    override fun onBindViewHolder(holder: CustomerViewHolder, position: Int) = holder.let {
        it.setIsRecyclable(false) // necessary for maintaining scroll position on scroll for views so they dont change values.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            it.onBind(position)
        }
//        val anim: Animation = AlphaAnimation(1.0f, 0.0f)
//        anim.duration = 2000
        holder.itemView.animation = AnimationUtils.loadAnimation(context, R.anim.anim_three)
//        val item = getDataAdapter.get(position)
//        holder.bind(item)
    }

    private fun openMapSearchAddress(address: String) {
        val mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(address))
        //        val gmmIntentUri = Uri.parse("geo:0,0?q=1600 Amphitheatre Parkway, Mountain+View, California")

        val mapIntent = Intent(Intent.ACTION_VIEW, mapUri)
        mapIntent.setPackage("com.google.android.apps.maps")
        if (mapIntent.resolveActivity(context.packageManager) != null)
            context.startActivity(mapIntent)
    }

    internal fun addResultsToList(products: List<CustomerRep2>) {
        println("addResultsToList called:-" + products.size)
        this.customersList = products.toMutableList()
        notifyDataSetChanged()
        this.originalListCustomers = customersList
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(charSequence: CharSequence): FilterResults {
                val results = FilterResults()
                if (charSequence.isNotEmpty()) {
                    val charString = charSequence.toString().toLowerCase(Locale.getDefault())

                    val filteredPlayers = ArrayList<CustomerRep2>()
                    for (item in originalListCustomers) {
                        if (item.custName.toLowerCase(Locale.getDefault()).contains(
                                charString.toLowerCase(
                                    Locale.getDefault()
                                )
                            )
                            || item.cif.contains(charString)
                        ) {
                            filteredPlayers.add(item)
                        }
                    }
                    results.count = filteredPlayers.size
                    results.values = filteredPlayers
                } else {
                    results.count = originalListCustomers.size
                    results.values = originalListCustomers
                }
                return results
            }

            @SuppressLint("NotifyDataSetChanged")
            override fun publishResults(charSequence: CharSequence, filterResults: FilterResults) {
                customersList = filterResults.values as MutableList<CustomerRep2>
                notifyDataSetChanged()
            }
        }
    }

    inner class CustomerViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        @RequiresApi(Build.VERSION_CODES.O)
        fun onBind(position: Int) {
            val custPostObj: CustomerRep2 = customersList[position]
            val customerObj = custPostObj
            inflateData(customerObj)
        }

        @RequiresApi(Build.VERSION_CODES.O)
        @SuppressLint("SetTextI18n")
        private fun inflateData(smaCustomer: CustomerRep2) {
            try {
                if (smaCustomer?.custName != null && !smaCustomer.custName.isNullOrBlank()) {
                    itemView.customerNameTv.text = smaCustomer.custName.trim()
                }
                itemView.custNoTv.text = smaCustomer.cif
//            itemView.actNoTv.text = smaCustomer.acNo

                val custBal = smaCustomer.custBal

                itemView.custBalanceTv.text =  context.resources.getString(R.string.rs) + " " + custBal

                if (smaCustomer?.mobNo != "null" || smaCustomer?.mobNo != null)
                    itemView.custMobileTv.text = smaCustomer.mobNo
                else
                    itemView.custMobileTv.text = " "

                if (smaCustomer?.defaultDate != null) {
                    Log.d("SmaCustAdptr","DateUtil:defaultDate ="+smaCustomer?.defaultDate)
                    if (!smaCustomer.defaultDate.equals("null", ignoreCase = true)) {
//                        println("defaultDate:" + smaCustomer.defaultDate)
                        itemView.defaultDateTv.text =
                            DateUtil.findDateDiff(smaCustomer.defaultDate).toString() + " Days"
                    } else {
                        itemView.defaultDateTv.text = " "
                    }

                } else if (smaCustomer?.npaDate != null) {
                    Log.d("SmaCustAdptr","DateUtil:npaDate ="+smaCustomer?.npaDate)

                    if (!smaCustomer.npaDate.equals("null", ignoreCase = true)) {
                        println("npaDate:" + smaCustomer.npaDate)
                        itemView.defaultDateTv.text =
                            DateUtil.findDateDiff(smaCustomer.npaDate).toString() + " Days"
                    }
                } else {
                    itemView.defaultDateTv.text = " "
                }

                if (smaCustomer?.ptpDate != null) {
                    if (!smaCustomer.ptpDate.equals("null", ignoreCase = true)) {
                        itemView.ptpDateTv.text = convertDateToddMMyy(smaCustomer.ptpDate)
                    } else {
                        itemView.ptpDateTv.text = " "
                    }
                } else {
                    itemView.ptpDateTv.text = " "
                }


                if (smaCustomer?.postcode != null) {
                    var address = ""
                    if (smaCustomer.add1 != null) {
                        address += smaCustomer.add1 + " "
                    }
                    if (smaCustomer.add2 != null) {
                        address += smaCustomer.add2 + " "
                    }
                    if (smaCustomer.add3 != null) {
                        address += smaCustomer.add3 + " "
                    }
                    address += smaCustomer.postcode
                    itemView.custSMaAddTv.text = address.capitalizeWords

                } else {
                    itemView.custSMaAddTv.visibility = View.GONE
                }

                itemView.custMobileTv.setOnClickListener {
                    try {
                        CommonUtil.makeACall(smaCustomer.mobNo, context)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                itemView.custSMaAddTv.setOnClickListener {
                    openMapSearchAddress(itemView.custSMaAddTv.text.toString())
                }

                // on item click
                itemView.cardView.setOnClickListener {
                    val pos = adapterPosition
                    if (pos != RecyclerView.NO_POSITION) {
                        val custPostObj: CustomerRep2 = customersList[pos]
                        val clickedDataItem: CustomerRep2 = customersList[pos] // this gives wrong position as per activities list.
                        rvClickListener?.recyclerViewListClicked(itemView.cardView, pos,custPostObj)
                    }
                }
            } catch (e: InvocationTargetException) {
                e.printStackTrace()
            }
        }
    }
}
