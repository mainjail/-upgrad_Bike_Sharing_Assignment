package com.bom.smamonitor.custlist

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.SearchManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.os.PersistableBundle
import android.provider.Settings
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.appcompat.widget.SearchView
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.R
import com.bom.smamonitor.addVisit.LocationHelper
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.customViews.RVEmptyObserver
import com.bom.smamonitor.customViews.RecyclerItemClickListener
import com.bom.smamonitor.dashboardbb.models.NotiObj
import com.bom.smamonitor.details.CustDetailsSmaActivity
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.npa.NpaCustomersMVPInteractor
import com.bom.smamonitor.npa.NpaCustomersMVPPresenter
import com.bom.smamonitor.npa.NpaCustomersMVPView
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.util.CommonUtil
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import com.google.android.gms.location.*
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_npa_account.*
import kotlinx.android.synthetic.main.dialog_bottom_sheet_filters.*
import java.util.*
import javax.inject.Inject


class CustomerListActivity : BaseActivity(), NpaCustomersMVPView, SmaCustAdapter.RecyclerViewClickListener {


    private lateinit var mFusedLocationClient: FusedLocationProviderClient
    private var myLocation: Location? = null
    private var isLocSaved = false
    var myLatitude: String = "Null"
    var myLongitude: String = "Null"
    private val PERMISSION_ID = 110

    private var selectedSortBy = "Account No" //default selected sort by parameter for filter
    private var selectedReport = "SMA-0"//default selected report for filter

    private var customersList = listOf<CustomerRep2>()
    private var branchCode = ""
    var rotationAngle = 0

    private val TAG = "CustListActivity"

    @Inject
    internal lateinit var smaCustAdapter: SmaCustAdapter

    @Inject
    internal lateinit var layoutManager: LinearLayoutManager

    @Inject
    internal lateinit var presenter: NpaCustomersMVPPresenter<NpaCustomersMVPView, NpaCustomersMVPInteractor>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_npa_account)
        presenter.onAttach(this)
        supportActionBar?.title = this.resources.getString(R.string.listOfCusts)
        supportActionBar?.setHomeAsUpIndicator(resources.getDrawable(R.drawable.ic_action_back))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        setUp()
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    private fun setUp() {

        branchCode = intent.getStringExtra("branchCode").toString()
        val branchName = intent.getStringExtra("branchName")
        supportActionBar?.subtitle = "$branchCode -  $branchName"
// for temporarily branch code hardcode
        // branchCode="687"

        layoutManager.orientation = LinearLayoutManager.VERTICAL
        npaCustomersRV.layoutManager = layoutManager
        npaCustomersRV.itemAnimator = DefaultItemAnimator()
        npaCustomersRV.adapter = smaCustAdapter
        val emptyRvObserver =
            RVEmptyObserver(emptyView = emptyListsMsgTv, recyclerView = npaCustomersRV)
        smaCustAdapter.registerAdapterDataObserver(emptyRvObserver)

        homeFab_npa.setOnClickListener {
            CommonUtil.goBackToHome(this@CustomerListActivity)
        }

      //  setRecyclerItemClickListener()
        smaCustAdapter.setOnItemClickListener(this)

        apiCallForCustomerListDetails(selectedReport, selectedSortBy)

        selectedFilterTitle.text = selectedReport

        //getLocation()
        expColapIV.setOnClickListener {
            filterBtn.callOnClick()
        }

        filterBtn.setOnClickListener {
            rotationAngle = if (rotationAngle == 0) 180 else 0 //toggle
            expColapIV.animate().rotation(rotationAngle.toFloat()).setDuration(500).start()
            showBottomSheetDialog()
        }

    }

    private fun showBottomSheetDialog() {

        val dialog = BottomSheetDialog(this)
        dialog.setContentView(R.layout.dialog_bottom_sheet_filters)
        val sortChipGrp = dialog.findViewById<ChipGroup>(R.id.sortChipGrp)
        val reportChipGrp1 = dialog.findViewById<ChipGroup>(R.id.reportChipGrp1)
        reportChipGrp1?.visibility = View.VISIBLE

        val reportChipGrp2 = dialog.findViewById<ChipGroup>(R.id.reportChipGrp2)
        reportChipGrp2?.visibility = View.GONE
        val locationChipGrp = dialog.findViewById<ChipGroup>(R.id.locationChipGrp)

        val mapFilterLL = dialog.findViewById<LinearLayoutCompat>(R.id.mapFilterLL)
        mapFilterLL?.visibility = View.VISIBLE

        val applyBtn = dialog.findViewById<AppCompatButton>(R.id.applyBtn)

        reportChipGrp1?.isSelected = true

        reportChipGrp1?.setOnCheckedChangeListener { chipGroup, i ->
            selectedReport = reportChipGrp1.findViewById<Chip>(reportChipGrp1.checkedChipId).text.toString()
        }

        sortChipGrp?.setOnCheckedChangeListener { chipGroup, i ->
            selectedSortBy = sortChipGrp.findViewById<Chip>(sortChipGrp.checkedChipId).text.toString()
        }

        locationChipGrp?.setOnCheckedChangeListener { chipGroup, i ->
            if (myLocation != null) {
                apiCallGetNearByCustomers()
                dialog.dismiss()

            } else {
                Toast.makeText(
                    this@CustomerListActivity,
                    "Finding your location please wait....",
                    Toast.LENGTH_LONG
                ).show()
                dialog.dismiss()

                getLocation()
            }
        }

        applyBtn?.setOnClickListener {
            rotationAngle = if (rotationAngle == 0) 180 else 0 //toggle
            expColapIV.animate().rotation(rotationAngle.toFloat()).setDuration(500)
                .start()
            selectedFilterTitle.text = selectedReport
            apiCallForCustomerListDetails(selectedReport, selectedSortBy)
            dialog.dismiss()
        }
        dialog.show()
    }


    private fun apiCallGetNearByCustomers() {
        val address = getAddressFromLocation(myLocation)
        val queryString =
            "mFeatureName=${address?.featureName}&mPostalCode=${address?.postalCode}" +
                    "&mSubAdminArea=${address?.subAdminArea}&mSubLocality=${address?.subLocality}&mBrCode=${branchCode}"
        presenter.getNearbySmaCustList(queryString)
    }

    private fun getReportNoFromChip(position: String): Int {
        var reportPosition = 0
        when (position) {
            "SMA-0" -> reportPosition = 0
            "SMA-1" -> reportPosition = 1
            "SMA-2" -> reportPosition = 2
            "Report-6" -> reportPosition = 6
            "Report-7" -> reportPosition = 7
            "Report-7NF" -> reportPosition = 8
            "Report-7D" -> reportPosition = 9
            "Report-10" -> reportPosition = 10
            "Report-10(2)" -> reportPosition = 11
        }
        return reportPosition
    }

    private fun getPositionSortNo(sortBy: String): Int {
        var reportPosition = 0
        when (sortBy) {
            "Account No" -> reportPosition = 0
            "Balance" -> reportPosition = 1
            "Cust Name" -> reportPosition = 2
            "PTP Date" -> reportPosition = 3
        }
        return reportPosition
    }
    override fun recyclerViewListClicked(v: View?, position: Int,customerRep2: CustomerRep2) {
        try {
            val intent = Intent( this@CustomerListActivity, CustDetailsSmaActivity::class.java )
            val smaCustomer = customerRep2
            intent.putExtra("smacustomer", Gson().toJson(smaCustomer))
            intent.putExtra("customerBranchCode", branchCode)
            startActivity(intent)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

//    private fun setRecyclerItemClickListener() {
//
//        npaCustomersRV.addOnItemTouchListener(
//            RecyclerItemClickListener(this@CustomerListActivity,
//                npaCustomersRV, object : RecyclerItemClickListener.OnItemClickListener {
//
//                    override fun onItemClick(view: View, position: Int) {
//                        try {
//                            val intent = Intent( this@CustomerListActivity,
//                                CustDetailsSmaActivity::class.java
//                            )
//                            val smaCustomer = customersList[position]
//                            intent.putExtra("smacustomer", Gson().toJson(smaCustomer))
//                            startActivity(intent)
//
//                        } catch (e: Exception) {
//                            e.printStackTrace()
//                        }
//                    }
//                    override fun onItemLongClick(view: View?, position: Int) {
//                    }
//                })
//        )
//    }

    private fun apiCallForCustomerListDetails(
        selectedReport: String,
        sortBy: String
    ) {

        if (branchCode.isNotEmpty() && ValidationUtils.isNetworkAvailable(this))
            presenter.getSmaCustList(
                branchCode.toInt(),
                getReportNoFromChip(selectedReport),
                getPositionSortNo(sortBy)
            )
        else CustomDialog().showNoInternetAlert(this, "")
    }

    override fun onSaveInstanceState(
        outState: Bundle,
        outPersistentState: PersistableBundle
    ) {
        super.onSaveInstanceState(outState, outPersistentState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.d(TAG, "onRestoreInstanceState")
        apiCallForCustomerListDetails(selectedReport, selectedSortBy)
    }

    @SuppressLint("SetTextI18n")
    override fun displayResultsFromApi(products: List<NpaCustomer>?) {
        //
    }

    override fun showLoading() {
        TODO("Not yet implemented")
    }

    override fun hideLoading() {
        TODO("Not yet implemented")
    }

    override fun showError(errorMsg: String) {
        CustomDialog().showAlert(this, errorMsg)
    }

    override fun inflateUserDetails(userDetails: AppUser?) {
        TODO("Not yet implemented")
    }

    override fun displayCustListFromApi(customers: List<CustomerRep2>?) =
        customers?.let {
            text_view.text = it.size.toString()
            customersList = it
            smaCustAdapter.addResultsToList(it)
        }


    @SuppressLint("SetTextI18n")
    private fun getLocation() {

        if (checkPermissions()) {
            if (isLocationEnabled()) {
                val locationHelper = LocationHelper(this@CustomerListActivity, activity = this@CustomerListActivity)
                locationProBar1.show()
                getCurrentLocTv.visibility = View.GONE
                locationLL.visibility = View.VISIBLE

                try {
                    locationHelper.startListeningUserLocation(object :
                        LocationHelper.MyLocationListener {

                        override fun onLocationChanged(location: Location?) {
                            Log.d(                                "Location cached",
                                " : onLocationChanged " + location!!.latitude + "," + location.longitude
                            )
                            isLocSaved = true
                            locationLL.visibility = View.GONE
                            myLatitude = location.latitude.toString()
                            myLongitude = location.longitude.toString()
                            myLocation = location
                            if (myLocation != null) {
                                apiCallGetNearByCustomers()
                            } else {
                                getLocationFromMap()
                            }

                        }

                        override fun onLocationDetected(location: Location?) {
                            isLocSaved = true
                            myLocation = location
                            myLatitude = location?.latitude.toString()
                            myLongitude = location?.longitude.toString()
                            Log.d(
                                "Location cached ",
                                ": onLocationDetected " + location!!.latitude + "," + location.longitude
                            )
                            locationProBar1.visibility = View.GONE
                            locationLL.visibility = View.GONE
                            if (myLocation != null) {
                                apiCallGetNearByCustomers()
                            } else {
                                getLocationFromMap()
                            }

                        }

                        override fun onLocationFailed(error: String) {
                            getLocationFromMap()
                            locationLL.visibility = View.GONE
                            Toast.makeText(this@CustomerListActivity, error, Toast.LENGTH_LONG)
                                .show()
                            Toast.makeText(
                                this@CustomerListActivity,
                                "Error capturing Location. Please check app permissions in settings.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    })
//            locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
//            // Request location updates
////            locationManager?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, locationListener)
                    //        locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)
                } catch (ex: SecurityException) {
                    CustomDialog().popUpToast(
                        this@CustomerListActivity,
                        "Security Exception, No location Available"
                    )
                    Log.d("myTag", "Security Exception, no location available")
                }

            } else {
                turnOnGPSDialog()
            }
        } else {
            requestPermissions()
        }
    }
    private fun turnOnGPSDialog() {
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Location Permission")
        builder.setMessage("The app needs location permissions. Please grant this permission to continue using the features of the app.")
        builder.setPositiveButton(android.R.string.yes,
            DialogInterface.OnClickListener { dialogInterface, i ->
                val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                startActivity(intent)
            })
        builder.setNegativeButton(android.R.string.no, null)
        builder.show()
    }

    private fun getAddressFromLocation(location: Location?): Address? {
        val address: Address? = null
        try {
            val latitude = location!!.latitude
            val longitude = location.longitude
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(latitude, longitude, 1)

            if (addresses != null && addresses.size > 0) {

                val addressString: String = addresses[0].getAddressLine(0)
                val city: String = addresses[0].locality
                val state: String = addresses[0].adminArea
                val country: String = addresses[0].countryName
                val postalCode: String = addresses[0].postalCode
                return addresses[0]

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return address
    }

    private fun isLocationEnabled(): Boolean {
        val locationManager: LocationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager

        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun checkPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            ),
            PERMISSION_ID
        )
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_ID) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                getLocation()
                getLastLocation()
            }else {
                turnOnGPSDialog()
            }
        }else{
            turnOnGPSDialog()
        }
    }

    override fun displayNotis(notifis: NotiObj) {
        TODO("Not yet implemented")
    }

    @Suppress("DEPRECATION")
    @SuppressLint("NewApi")
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu_search, menu)
        val searchManager = getSystemService(SEARCH_SERVICE) as SearchManager
        val searchView = menu?.findItem(R.id.action_search)?.actionView as SearchView
        val searchableInfo = searchManager.getSearchableInfo(componentName)
        searchView.setSearchableInfo(searchableInfo)

        searchView.queryHint = resources.getString(R.string.search_hint)
//        searchView.outlineSpotShadowColor = resources.getColor(R.color.white)
        searchView.maxWidth = Integer.MAX_VALUE
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                smaCustAdapter.filter.filter(query)
                return false
            }

            override fun onQueryTextChange(query: String): Boolean {
                smaCustAdapter.filter.filter(query)
                return false
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return if (id == R.id.action_search) {
            true
        } else super.onOptionsItemSelected(item)
    }

    private fun getLocationFromMap() {
        Log.i("custlistact", "getLocationFromMap")
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        getLastLocation()
    }

    @SuppressLint("MissingPermission")
    private fun getLastLocation() {
        Log.i("custlistact", "getLastLocation")
        if (checkPermissions()) {
            if (isLocationEnabled()) {

                mFusedLocationClient.lastLocation.addOnCompleteListener(this) { task ->
                    val location: Location? = task.result
                    if (location == null) {
                        requestNewLocationData()
                    } else {
                        locationLL.visibility = View.GONE

                        myLatitude = location.latitude.toString()
                        myLongitude = location.longitude.toString()
                        myLocation = location
                        if (myLocation != null)
                            apiCallGetNearByCustomers()
                        else
                            Toast.makeText(this, "Error fetching location", Toast.LENGTH_LONG)
                                .show()
                    }
                }
            } else {
                requestPermissions()
            }
        } else {
            requestPermissions()
        }
    }

    @SuppressLint("MissingPermission")
    private fun requestNewLocationData() {
        val mLocationRequest = LocationRequest()
        mLocationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        mLocationRequest.interval = 0
        mLocationRequest.fastestInterval = 0
        mLocationRequest.numUpdates = 1

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        mFusedLocationClient.requestLocationUpdates(
            mLocationRequest, mLocationCallback,
            Looper.myLooper()
        )
    }

    private val mLocationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            val mLastLocation: Location = locationResult.lastLocation
            myLocation = mLastLocation
            myLatitude = mLastLocation.latitude.toString()
            myLongitude = mLastLocation.longitude.toString()
        }
    }




//    fun initiateMapLocationProcess()
//    {
//
//        //Create location callback when it's ready.
//        createLocationCallback()
//
//        //createing location request, how mant request would be requested.
//        createLocationRequest()
//
//        //Build check request location setting request
//        buildLocationSettingsRequest()
//
//        //FusedLocationApiClient which includes location
//        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
//        //Location setting client
//        mSettingsClient = LocationServices.getSettingsClient(this)
//
//    }
//

//    private fun createLocationCallback() {
//        //Here the location will be updated, when we could access the location we got result on this callback.
//        mLocationCallback = object : LocationCallback() {
//            override fun onLocationResult(locationResult: LocationResult) {
//                super.onLocationResult(locationResult)
//                mCurrentLocation = locationResult.lastLocation
//            }
//        }
//    }
//
//    private fun buildLocationSettingsRequest() {
//        val builder = LocationSettingsRequest.Builder()
//        builder.addLocationRequest(mLocationRequest!!)
//        mLocationSettingsRequest = builder.build()
//        builder.setAlwaysShow(true)
//    }
//
//    private fun createLocationRequest() {
//        mLocationRequest = LocationRequest.create()
//        mLocationRequest!!.interval = 0
//        mLocationRequest!!.fastestInterval = 0
//        mLocationRequest!!.numUpdates = 1
//        mLocationRequest!!.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
//    }
//
//    public fun checkLocationIsTurnedOn() { // Begin by checking if the device has the necessary location settings.
//        mSettingsClient!!.checkLocationSettings(mLocationSettingsRequest)
//            .addOnSuccessListener(this) {
//                Log.i(TAG, "All location settings are satisfied.")
//                startLocationUpdates()
//            }
//            .addOnFailureListener(this) { e ->
//                val statusCode = (e as ApiException).statusCode
//                when (statusCode) {
//                    LocationSettingsStatusCodes.RESOLUTION_REQUIRED -> {
//                        try {
//                            val rae = e as ResolvableApiException
//                            rae.startResolutionForResult(this@CustomerListActivity, LOCATION_IS_OPENED_CODE)
//                        } catch (sie: IntentSender.SendIntentException) {
//                        }
//                    }
//                    LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE -> {
//                        mRequestingLocationUpdates = false
//                    }
//                }
//            }
//    }
//
//    @SuppressLint("MissingPermission")
//    private fun startLocationUpdates() {
//        mFusedLocationClient.requestLocationUpdates(
//            mLocationRequest,
//            mLocationCallback, null
//        )
//    }


}