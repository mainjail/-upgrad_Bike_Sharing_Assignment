package com.bom.smamonitor.npa

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.npa.modelNpa.NpaAccount
import com.bom.smamonitor.util.CommonUtil.formatRoundUp
import kotlinx.android.synthetic.main.sub_item_layout_account_no.view.*

class ChildItemNpaAdapter : RecyclerView.Adapter<ChildItemNpaAdapter.ChildAccountViewHolder>() {

    private var accountsList = listOf<NpaAccount>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildAccountViewHolder {
        return ChildAccountViewHolder(LayoutInflater.from(parent.context).inflate(
                        R.layout.sub_item_layout_account_no, parent, false)
        )
    }

    override fun getItemCount(): Int = accountsList.size

    override fun onBindViewHolder(holder: ChildAccountViewHolder, position: Int) {
        holder.setIsRecyclable(false);
        holder.onBind(position)
    }

    internal fun setAccountsList(listOfMovies: List<NpaAccount>) {
        this.accountsList = listOfMovies
        notifyDataSetChanged()
    }

    inner class ChildAccountViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        @SuppressLint("SetTextI18n")
        fun onBind(position: Int) {
            try {
                val npaAccount = accountsList[position]
                itemView.accNoTV_SIL.text = npaAccount.accountNo
                itemView.balanceTV_SIL.text = formatRoundUp(npaAccount.loanBalance)
                itemView.unIntTv_SIL.text = formatRoundUp(npaAccount.unappliedInt)

                if ((npaAccount.overdue.toDouble() < 0)) {
                    itemView.overdueTv_SIL.setTextColor(ContextCompat.getColor(itemView.context, R.color.green))
                    itemView.overdueTv_SIL.text = formatRoundUp(npaAccount.overdue)
                } else {
                    itemView.overdueTv_SIL.setTextColor(ContextCompat.getColor(itemView.context, R.color.red))
                    itemView.overdueTv_SIL.text = formatRoundUp(npaAccount.overdue)
                }
            }catch(e:Exception){
                e.printStackTrace()
            }
        }
    }


}