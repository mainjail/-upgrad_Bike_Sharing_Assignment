package com.bom.smamonitor.npa

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.VERTICAL
import com.bom.smamonitor.R
import com.bom.smamonitor.details.DetailsNpaTableActivity
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.util.CommonUtil.formatRoundUp
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_details.*
import kotlinx.android.synthetic.main.item_layout_npa_accounts.view.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.*


class NpaCustAdapter : RecyclerView.Adapter<NpaCustAdapter.CustomerViewHolder>(), Filterable {

    private var originalListCustomers = mutableListOf<NpaCustomer>()
    private var customersList = mutableListOf<NpaCustomer>()
    private val viewPool = RecyclerView.RecycledViewPool()

    val String.capitalizeWords
        get() = this.toLowerCase(Locale.getDefault()).split(" ").joinToString(" ") { it.capitalize(Locale.getDefault()) }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = CustomerViewHolder(
            LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_layout_npa_accounts, parent, false)
    )

    override fun getItemCount() = this.customersList.size

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }
    override fun getItemViewType(position: Int): Int {
        return position // necessary for maintaining scroll position on scroll for views so they dont change values.
    }
    override fun onBindViewHolder(holder: CustomerViewHolder, position: Int) = holder.let {
        it.setIsRecyclable(false) // necessary for maintaining scroll position on scroll for views so they dont change values.
        it.onBind(position)
//        inflateData(customersList[position], holder)
    }

    internal fun addResultsToList(products: List<NpaCustomer>) {
        println("addResultsToList called:-" + products.size)
        this.customersList = products.toMutableList()
        notifyDataSetChanged()
        this.originalListCustomers = customersList
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(charSequence: CharSequence): FilterResults {
                val results = FilterResults()
                if (charSequence.isNotEmpty()) {
                    val charString = charSequence.toString().toLowerCase(Locale.getDefault())

                    val filteredPlayers = ArrayList<NpaCustomer>()
                    for (item in originalListCustomers) {
                        if (item.custName.toLowerCase(Locale.getDefault()).contains(charString.toLowerCase(Locale.getDefault()))
                                || item.custNo.contains(charString)
                        ) {
                            filteredPlayers.add(item)
                        }
                    }
                    results.count = filteredPlayers.size
                    results.values = filteredPlayers
                } else {
                    results.count = originalListCustomers.size
                    results.values = originalListCustomers
                }
                return results
            }

            override fun publishResults(charSequence: CharSequence, filterResults: FilterResults) {
                customersList = filterResults.values as MutableList<NpaCustomer>
                notifyDataSetChanged()
            }
        }
    }

    inner class CustomerViewHolder(view: View) : RecyclerView.ViewHolder(view) {


        fun onBind(position: Int) {
            val npaCustPostObj: NpaCustomer = customersList[position]
            val npaCustomerObj = npaCustPostObj
            inflateData(npaCustomerObj)
//            setItemClickListener(npaCustomerObj)
        }

        @SuppressLint("SetTextI18n")
        private fun inflateData(npaCustomer: NpaCustomer) {

            itemView.customerNameTv.text = npaCustomer.custName
            itemView.custNoTv.text = npaCustomer.custNo

            var i = 0
            var custTotBalance = npaCustomer.custBalance?.toDoubleOrNull() ?: 0.0
            while (i < npaCustomer.accountsList.size) {
                val loanBal = npaCustomer.accountsList[i].loanBalance?.toDoubleOrNull() ?: 0.0
                custTotBalance += loanBal
                i++
            }
            val decimal = BigDecimal(custTotBalance).setScale(2, RoundingMode.HALF_EVEN)
            itemView.custBalanceTv.text = formatRoundUp(decimal.toString())

            val address = npaCustomer.address
            if (address != null) {
                itemView.custAddressTv.text = address.add1?.capitalizeWords + ", " +
                        address.add2?.capitalizeWords + ", " +
                        address.add3?.capitalizeWords+ ", " +
                        address.add4?.capitalizeWords + " - " +
                        address.postcode
            }

            val childLayoutManager = LinearLayoutManager(itemView.accountsRV.context, VERTICAL, false)
            itemView.accountsRV.apply {
                layoutManager = childLayoutManager
                adapter = ChildItemNpaAdapter()
                (adapter as ChildItemNpaAdapter).setAccountsList(npaCustomer.accountsList)
                setRecycledViewPool(viewPool)
                val mDivider = ContextCompat.getDrawable(itemView.context, R.drawable.divider)
                val hItemDecoration = DividerItemDecoration(itemView.context,
                        DividerItemDecoration.VERTICAL)
                hItemDecoration.setDrawable(mDivider!!)
            }

            itemView.sfsiNextBtn.setOnClickListener {
                try {
                    val intent = Intent(itemView.context, DetailsNpaTableActivity::class.java)
                    intent.putExtra("NpaCustomer", Gson().toJson(npaCustomer))
                    itemView.context.startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

    }
}
