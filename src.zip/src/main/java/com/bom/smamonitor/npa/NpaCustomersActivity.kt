package com.bom.smamonitor.npa

import android.annotation.SuppressLint
import android.app.SearchManager
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.customViews.RVEmptyObserver
import com.bom.smamonitor.dashboardbb.models.NotiObj
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.util.CommonUtil
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import kotlinx.android.synthetic.main.activity_npa_account.*
import kotlinx.android.synthetic.main.activity_npa_account.text_view
import javax.inject.Inject

class NpaCustomersActivity : BaseActivity(), NpaCustomersMVPView {

    private var branchCode=""
    private val TAG = "NpaCustomersActivity"

    @Inject
    internal lateinit var npaCustAdapter: NpaCustAdapter

    @Inject
    internal lateinit var layoutManager: LinearLayoutManager

    @Inject
    internal lateinit var presenter: NpaCustomersMVPPresenter<NpaCustomersMVPView, NpaCustomersMVPInteractor>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_npa_account)
        presenter.onAttach(this)
        supportActionBar?.title = this.resources.getString(R.string.NpaBorrowersTitle)
        supportActionBar?.setHomeAsUpIndicator(resources.getDrawable(R.drawable.ic_action_back))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        setUp()
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    private fun setUp() {
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        npaCustomersRV.layoutManager = layoutManager
        npaCustomersRV.itemAnimator = DefaultItemAnimator()
        npaCustomersRV.adapter = npaCustAdapter
        val emptyRvObserver = RVEmptyObserver(emptyView = emptyListsMsgTv, recyclerView = npaCustomersRV)
        npaCustAdapter.registerAdapterDataObserver(emptyRvObserver)
         branchCode = intent.getStringExtra("branchCode").toString()
        val branchName = intent.getStringExtra("branchName")
        supportActionBar?.subtitle = "$branchCode -  $branchName"

        homeFab_npa.setOnClickListener {
            CommonUtil.goBackToHome(this@NpaCustomersActivity)
        }
        apiCallForCustomerNpaDetails()

    }

    private fun apiCallForCustomerNpaDetails(){
        if( branchCode.isNotEmpty()&&ValidationUtils.isNetworkAvailable(this))
            presenter.onGetCustomerClicked(branchCode.toInt())
        else CustomDialog().showNoInternetAlert(this,"")
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.d(TAG,"onRestoreInstanceState")
        apiCallForCustomerNpaDetails()
    }

    @SuppressLint("SetTextI18n")
    override fun displayResultsFromApi(products: List<NpaCustomer>?) = products?.let {
        text_view.text = it.size.toString()
        npaCustAdapter.addResultsToList(it)
    }

    override fun displayCustListFromApi(customers: List<CustomerRep2>?): Unit? {
        TODO("Not yet implemented")
    }

    override fun displayNotis(notifis: NotiObj) {
        TODO("Not yet implemented")
    }

    override fun showLoading() {
        TODO("Not yet implemented")
    }

    override fun hideLoading() {
        TODO("Not yet implemented")
    }

    override fun showError(errorMsg: String) {
        CustomDialog().showAlert(this, errorMsg)
    }

    override fun inflateUserDetails(userDetails: AppUser?) {
        TODO("Not yet implemented")
    }

    @Suppress("DEPRECATION")
    @SuppressLint("NewApi")
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu_search, menu)
        val searchManager = getSystemService(SEARCH_SERVICE) as SearchManager
        val searchView = menu?.findItem(R.id.action_search)?.actionView as SearchView
        val searchableInfo =
                searchManager.getSearchableInfo(componentName)
        searchView.setSearchableInfo(searchableInfo)

        searchView.queryHint = resources.getString(R.string.search_hint)
//        searchView.outlineSpotShadowColor = resources.getColor(R.color.white)
        searchView.maxWidth = Integer.MAX_VALUE
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                npaCustAdapter.filter.filter(query)
                return false
            }

            override fun onQueryTextChange(query: String): Boolean {
                npaCustAdapter.filter.filter(query)
                return false
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return if (id == R.id.action_search) {
            true
        } else super.onOptionsItemSelected(item)
    }


}