package com.bom.smamonitor.npa.modelNpa

import com.google.gson.annotations.SerializedName


