package com.bom.smamonitor.npa.modelNpa

import com.google.gson.annotations.SerializedName

data class AllPaData(
        @SerializedName("CUSTNO")
        val custNo: Int,
        @SerializedName("CUST_NAME")
        val custName: String,

        @SerializedName("accountsList")
        val accountList: List<NpaAccount>
)