package com.bom.smamonitor.npa.modelNpa

import com.google.gson.annotations.SerializedName

data class Suit (@SerializedName("SUIT_REF_NO")
                       val suitRefNo: String,
                 @SerializedName("SU_FI_DT")
                       val suitFIDate: String,
                 @SerializedName("SU_FI_DT1")
                       val suitFIDate1: String,
                 @SerializedName("COURT_NAME")
                       val courtName: String,
                 @SerializedName("SUIT_AMT")
                       val suitAmount: String,
                 @SerializedName("NEXT_HEARING_DT")
                       val nextHearingDate: String,
                 @SerializedName("NEXT_HEARING_DT1")
                       val nextHearingDate1: String
                       )


