package com.bom.smamonitor.npa

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import com.androidnetworking.error.ANError
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.bzsummary.DataObj
import com.bom.smamonitor.bzsummary.EncDataObj
import com.bom.smamonitor.custlist.model.*
import com.bom.smamonitor.dashboardbb.models.NotiObj
import com.bom.smamonitor.network.CryptoClass
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.util.SchedulerProvider
import com.google.gson.Gson
import io.reactivex.disposables.CompositeDisposable
import java.nio.charset.StandardCharsets
import java.util.*
import javax.inject.Inject


class NpaCustPresenterImpl<V : NpaCustomersMVPView, I : NpaCustomersMVPInteractor>
@Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) :
    BasePresenter<V, I>(
        interactor = interactor,
        schedulerProvider = schedulerProvider,
        compositeDisposable = disposable
    ),
    NpaCustomersMVPPresenter<V, I> {

    val TAG = "NpaPresenterImpl"

    @RequiresApi(Build.VERSION_CODES.O)
    override fun getSmaCustList(brCode: Int, report: Int, sortBy: Int) {
        Log.d("getSmaCustList brCode", brCode.toString())
        Log.d("getSmaCustList report", report.toString())
        Log.d("getSmaCustList sortBy", sortBy.toString())

        getView()?.showProgress()
        interactor?.let {
            it.getSmaCustList(brCode, report, sortBy)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ encDataObj: EncDataObj ->
                    try {
                       // Log.d(TAG, "EncryptedObj Results:-${encDataObj.enDataListObj}")

                        val decText: String = CryptoClass.decryptFromHex(encDataObj.enDataListObj)!!
                      //  Log.d(TAG, "Decrypted Text : $decText")

                        val dataObj: DataObj = Gson().fromJson(decText, DataObj::class.java)

                        //Log.d(TAG, "data Results:-${dataObj.data}")
                        val data = dataObj.data

                        if (data != null) {
                            val bytes: ByteArray = data.toByteArray(Charsets.UTF_8)
                            val decodedArray = Base64.getDecoder().decode(bytes)
                            val decodedString = decodedArray.toString(StandardCharsets.UTF_8)
                            Log.d(TAG, "decodedString:-${decodedString}")
                            var customersList = listOf<CustomerRep2>()
                            Log.d(TAG, "customersList:-${customersList}")
//                    var customersList7 = listOf<CustomerRep7>()

                            when (report) {
                                0 -> {
                                    val repObj =
                                        Gson().fromJson(decodedString, ReportObj0::class.java)
                                    customersList = repObj.report0CustList
                                }
                                1 -> {
                                    val repObj =
                                        Gson().fromJson(decodedString, ReportObj1::class.java)
                                    customersList = repObj.report1CustList

                                }
                                2 -> {
                                    val repObj =
                                        Gson().fromJson(decodedString, ReportObj2::class.java)
                                    customersList = repObj.report2CustList
                                }
                                6 -> {
                                    val repObj =
                                        Gson().fromJson(decodedString, ReportObj6::class.java)
                                    customersList = repObj.report6CustList
                                }
                                7 -> {
                                    val repObj =
                                        Gson().fromJson(decodedString, ReportObj7::class.java)
                                    customersList = repObj.report7CustList
                                }
                                8 -> {
                                    Log.d(TAG, "REPORT8:-${decodedString}")
                                    val repObj =
                                        Gson().fromJson(decodedString, ReportObj7NF::class.java)
                                    customersList = repObj.report7NFCustList
                                }
                                9 -> {
                                    Log.d(TAG, "REPORT9:-${decodedString}")
                                    val repObj =
                                        Gson().fromJson(decodedString, ReportObj7D::class.java)
                                    customersList = repObj.report7DCustList
                                }
                                10 -> {
                                    val repObj =
                                        Gson().fromJson(decodedString, ReportObj10::class.java)
                                    customersList = repObj.report10CustList
                                }
                                11 -> {
                                    val repObj =
                                        Gson().fromJson(decodedString, ReportObj11::class.java)
                                    customersList = repObj.report10_2CustList
                                }
                            }
                            getView()?.let { view ->
                                //view.displayCustListFromApi(customersList)
                                Log.d("IN getView",customersList.toString())
                                view.displayCustListFromApi(customersList)
                                view.hideProgress()
                            }
                        } else {
                            getView()?.hideProgress()
                            getView()?.showError("Data not received.")
                        }
                    }catch (e:Exception){
                        e.printStackTrace()
                        Log.d("Exception", e.message.toString())
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("NpaCustPresImpl", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }
//    @RequiresApi(Build.VERSION_CODES.O)
//    override fun getSmaCustList(brCode: Int, report: Int, sortBy: Int) { //Old without ENcryption
//        getView()?.showProgress()
//        interactor?.let {
//            it.getSmaCustList(brCode, report, sortBy)
//                .compose(schedulerProvider.ioToMainObservableScheduler())
//                .subscribe({ dataObj: DataObj ->
//
//                    println("data Results:-$dataObj")
//                    val data = dataObj.data
//
//                    if (data != null) {
//                        val bytes: ByteArray = data.toByteArray(Charsets.UTF_8)
//                        val decodedArray = Base64.getDecoder().decode(bytes)
//                        val decodedString = decodedArray.toString(StandardCharsets.UTF_8)
//                        var customersList = listOf<CustomerRep2>()
////                    var customersList7 = listOf<CustomerRep7>()
//
//                        when (report) {
//                            0 -> {
//                                val repObj = Gson().fromJson(decodedString, ReportObj0::class.java)
//                                customersList = repObj.report0CustList
//                            }
//                            1 -> {
//                                val repObj = Gson().fromJson(decodedString, ReportObj1::class.java)
//                                customersList = repObj.report1CustList
//
//                            }
//                            2 -> {
//                                val repObj = Gson().fromJson(decodedString, ReportObj2::class.java)
//                                customersList = repObj.report2CustList
//                            }
//                            6 -> {
//                                val repObj = Gson().fromJson(decodedString, ReportObj6::class.java)
//                                customersList = repObj.report6CustList
//                            }
//                            7 -> {
//                                val repObj = Gson().fromJson(decodedString, ReportObj7::class.java)
//                                customersList = repObj.report7CustList
//                            }
//                            10 -> {
//                                val repObj = Gson().fromJson(decodedString, ReportObj10::class.java)
//                                customersList = repObj.report10CustList
//                            }
//                        }
//                        getView()?.let { view ->
//                            view.displayCustListFromApi(customersList)
//                            view.hideProgress()
//                        }
//                    } else {
//                        getView()?.hideProgress()
//                        getView()?.showError("Data not received.")
//                    }
//                }, { error ->
//                    val aNError = error as ANError
//                    Log.d("NpaCustPresImpl", aNError.message.toString())
//                    getView()?.hideProgress()
//                    getView()?.showError(aNError.errorDetail.toString())
//                })
//        }
//    }

    override fun onGetCustomerClicked(brCode: Int) {
        getView()?.showProgress()
        interactor?.let {
            it.getNpaCustomers(brCode)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ products: List<NpaCustomer> ->
                    println("Products Results:-$products")
                    getView()?.let { view ->
                        view.displayResultsFromApi(products)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("NpaCustPresImpl", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun getSearchCustomer(keyword: String) {
        getView()?.showLoading()
        interactor?.let {
            it.getSearchCustomers(keyword)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ products: List<NpaCustomer> ->
                    println("Products Results:-$products")
                    getView()?.displayResultsFromApi(products)
                }, { error ->
                    val aNError = error as ANError
                    Log.d("NpaCustPresImpl", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    private fun getUserData() = interactor?.let {
        Log.d(TAG,"getUserdata from prefs NotiFrag")
        val userData = it.getUserFromSharedPref()
        getView()?.inflateUserDetails(userData)

    }

    override fun getLoggedInMode(): Int = interactor?.getLoggedInMode()!!

    override fun getNotification(brCode: String, loggedInMode: Int) {
        getView()?.showProgress()
        interactor?.let {
            it.getNotification(brCode,loggedInMode)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ products: NotiObj ->
                    println("notificationList Results:-$products")
                    getView()?.let { view ->
                        view.displayNotis(products)
                        view.hideProgress()
                    }
                }, { error ->
                    if(error!=null) {
                        val aNError = error as ANError
                        Log.d("NpaCustPresImpl", aNError.message.toString())
                        getView()?.showError(aNError.errorDetail.toString())
                    }else{
                        getView()?.showError("Exception error has occurred. Please retry.")
                    }
                    getView()?.hideProgress()

                })
        }
    }

    override fun getNearbySmaCustList(address: String) {
        getView()?.showProgress()
        interactor?.let {
            it.getNearbySmaCustList(address)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ mapCustObj: MapCustomerList ->
                    println("Products Results:-${mapCustObj.mapCustomerList}")
                    getView()?.let { view ->
                        view.displayCustListFromApi(mapCustObj.mapCustomerList)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("NpaCustPresImpl", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun onViewPrepared() {
        getUserData()
    }


}