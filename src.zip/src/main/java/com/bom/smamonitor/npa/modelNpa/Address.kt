package com.bom.smamonitor.npa.modelNpa

import com.google.gson.annotations.SerializedName

data class Address (

        @SerializedName("add1")
        val add1: String?,
        @SerializedName("add2")
        val add2: String?,
        @SerializedName("add3")
        val add3: String?,
        @SerializedName("add4")
        val add4: String?,
        @SerializedName("postcode")
        val postcode: String

        )
