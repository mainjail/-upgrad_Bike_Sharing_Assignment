package com.bom.smamonitor.npa

import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.bzsummary.DataObj
import com.bom.smamonitor.bzsummary.EncDataObj
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.custlist.model.MapCustomerList
import com.bom.smamonitor.dashboardbb.models.NotiObj
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.network.ApiHelper
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import io.reactivex.Observable
import javax.inject.Inject

class NpaCustInteractorImpl @Inject internal constructor(preferenceHelper: PreferenceHelper, apiHelper: ApiHelper) :
        BaseInteractor(preferenceHelper, apiHelper), NpaCustomersMVPInteractor {


    override fun getNpaCustomers(branchCode: Int) = apiHelper.getNpaCustomers(branchCode)

    override fun getSearchCustomers(keyword: String): Observable<List<NpaCustomer>> = apiHelper.getSearchCustomer(keyword)

    override fun getSmaCustList(brCode: Int, report: Int, sortBy: Int): Observable<EncDataObj> =
        apiHelper.getSmaCustList(brCode,report,sortBy)


    override fun getNearbySmaCustList(address: String): Observable<MapCustomerList>
    = apiHelper.getNearbySmaCustList(address)

    override fun getLoggedInMode() = preferenceHelper.getCurrentUserLoggedInMode()

    override fun getNotification(
        brCode: String,
        loggedInMode: Int
    ): Observable<NotiObj> = apiHelper.getNotification(brCode,loggedInMode)


//    override fun getUserDetails(): AppUser {
//        return AppUser(
//
//            preferenceHelper.getCurrentUserPfNo().toString(),
//            preferenceHelper.getCurrentUserName().toString(),
//            preferenceHelper.getCurrentBranchCode().toString(),
//            preferenceHelper.getUserRegionCode().toString(),
//            preferenceHelper.getCurrentUserEmail().toString(),
//            "",
//            "",
//            preferenceHelper.getCurrentUserMobileNo().toString(),
//            preferenceHelper.getCurrentDeviceNotificationToken().toString()
//
//        )
//    }
}