package com.bom.smamonitor.npa.modelNpa

import com.google.gson.annotations.SerializedName

data class NpaAccount(
        @SerializedName("ACNO")
        val accountNo: String,
        @SerializedName("ACCT_TYPE")
        val acctType: String,
        @SerializedName("PROD_NAME")
        val prodName: String,
        @SerializedName("LOAN_BAL")
        val loanBalance: String?,
        @SerializedName("OLD_IRAC")
        val oldIrac: String,
        @SerializedName("SANC_AMT")
        val sancAmount: String,
        @SerializedName("SANC_DATE")
        val sancDate: String,
        @SerializedName("INT_CAT")
        val intCat: String,
        @SerializedName("AC_OPEN_DATE")
        val acOpenDate: String,
        @SerializedName("OVERDUE")
        val overdue: String,
        @SerializedName("REPAY_OPTION")
        val repayOption: String,

        @SerializedName("PRINC_REP_FREQ")
        val princRepFrequency: String,

        @SerializedName("INT_REP_FREQ")
        val intRepFreq: String,
        @SerializedName("NPA_DATE")
        val npaDate: String,
        @SerializedName("LOAN_REPAY")
        val loanRepay: String,
        @SerializedName("REPAY_FREQ")
        val repayFreq: String,
        @SerializedName("REPAY_DAY")
        val repayDay: String,
        @SerializedName("LIMIT")
        val limit: String,
        @SerializedName("unapplied_interest")
        val unappliedInt: String
)

