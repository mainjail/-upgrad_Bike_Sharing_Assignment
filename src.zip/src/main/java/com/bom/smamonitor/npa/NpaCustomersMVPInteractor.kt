package com.bom.smamonitor.npa

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.bzsummary.DataObj
import com.bom.smamonitor.bzsummary.EncDataObj
import com.bom.smamonitor.custlist.model.MapCustomerList
import com.bom.smamonitor.dashboardbb.models.NotiObj
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import io.reactivex.Observable

interface NpaCustomersMVPInteractor : MVPInteractor {

    fun getNpaCustomers(branchCode: Int): Observable<List<NpaCustomer>>
    fun getSearchCustomers(keyword: String): Observable<List<NpaCustomer>>
  //  fun getSmaCustList(brCode: Int,report:Int,sortBy:Int): Observable<DataObj>
    fun getSmaCustList(brCode: Int,report:Int,sortBy:Int): Observable<EncDataObj>

//    fun getUserDetails(): AppUser?
//    fun doServerLoginApiCall(user: User): Observable<LoginResponse>
//    fun updateUserInSharedPref(loginResponse: LoginResponse, user: User, loggedInMode: AppConstants.LoggedInMode)

    fun getLoggedInMode() : Int
    fun getNearbySmaCustList(address:String): Observable<MapCustomerList>
    fun getNotification(brCode: String, loggedInMode: Int): Observable<NotiObj>
}

