package com.bom.smamonitor.npa.modelNpa

import com.google.gson.annotations.SerializedName

data class NpaCustomer(

        @SerializedName("custNo")
        val custNo: String,
        @SerializedName("custName")
        val custName: String,
        @SerializedName("custBalance")
        val custBalance: String?,
        @SerializedName("telNo")
        val mobNo: String,
        @SerializedName("fraud")
        val fraud: String?,
        @SerializedName("address")
        val address: Address?,
        @SerializedName("sFsi")
        val sFsi: SFSI?,
        @SerializedName("suit")
        val suit: Suit?,
        @SerializedName("reportDate")
        val reportDate: String,
        @SerializedName("branchCode")
        val brCode: Int,
        @SerializedName("branchName")
        val brName: String,
        @SerializedName("regionCode")
        val regCode: Int,
        @SerializedName("accountsList")
        val accountsList: List<NpaAccount>

)
