package com.bom.smamonitor.npa


import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.custlist.CustomerListActivity
import com.bom.smamonitor.custlist.SmaCustAdapter
import com.bom.smamonitor.custlist.SmaCustAdapter.RecyclerViewClickListener
import dagger.Module
import dagger.Provides


@Module
class NpaActivityModule {

    @Provides
    internal fun provideNpaInteractor(interactor: NpaCustInteractorImpl): NpaCustomersMVPInteractor = interactor

    @Provides
    internal fun provideNpaPresenter(presenter: NpaCustPresenterImpl<NpaCustomersMVPView, NpaCustomersMVPInteractor>)
            : NpaCustomersMVPPresenter<NpaCustomersMVPView, NpaCustomersMVPInteractor> = presenter

    @Provides
    internal fun provideAdapter(activity: CustomerListActivity)
    :            SmaCustAdapter = SmaCustAdapter(activity)

    @Provides
    internal fun provideLinearLayoutManager(activity:  CustomerListActivity):
            LinearLayoutManager = LinearLayoutManager(activity)

}