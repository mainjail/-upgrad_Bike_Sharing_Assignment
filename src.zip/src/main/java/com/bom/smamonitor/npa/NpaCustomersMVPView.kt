package com.bom.smamonitor.npa

import com.bom.smamonitor.base.view.BaseMVPView
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.dashboardbb.models.NotiModel
import com.bom.smamonitor.dashboardbb.models.NotiObj
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.npa.modelNpa.NpaCustomer

interface NpaCustomersMVPView :BaseMVPView{

    fun showError(errorMsg:String)
    fun inflateUserDetails(userDetails: AppUser?)

    fun displayResultsFromApi(customers: List<NpaCustomer>?): Unit?
    fun displayCustListFromApi(customers: List<CustomerRep2>?): Unit?
   // fun displayCustListFromApiRep7(customers: List<CustomerRep2>?)

    fun displayNotis(notifis: NotiObj)

    fun showLoading()
    fun hideLoading()
}