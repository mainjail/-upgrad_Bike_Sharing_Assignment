package com.bom.smamonitor.npa

import com.bom.smamonitor.base.presenter.MVPPresenter

interface NpaCustomersMVPPresenter<V:NpaCustomersMVPView, I:NpaCustomersMVPInteractor> :MVPPresenter<V,I>{

    fun onViewPrepared()

    fun onGetCustomerClicked(brCode: Int)

    fun getSearchCustomer(keyword:String)

    fun getSmaCustList(brCode: Int, report: Int, sortBy: Int)

    fun getNearbySmaCustList(address:String)

    fun getLoggedInMode(): Int

    fun getNotification(brCode: String, loggedInMode: Int)
}