package com.bom.smamonitor.npa.modelNpa

import com.google.gson.annotations.SerializedName

data class SFSI ( @SerializedName("DT_OF_ISSUEE_13_2")
                  val dateOfIssue13_2: String,
                  @SerializedName("DT_OF_ISSUEE_13_4")
                  val dateOfIssue13_4: String,
                  @SerializedName("SYMB_PS_DT")
                  val symbPsDate: String,
                  @SerializedName("APPL_FILL_DT")
                  val applFillDate: String,
                  @SerializedName("PERM_RESVD_DT")
                  val permResvdDate: String,
                  @SerializedName("DT_OF_PHY_POSN")
                  val dateOfPHYPosn: String,
                  @SerializedName("DT_OF_PUB_SALE")
                  val dateOfPubSale: String,
                  @SerializedName("REMARKS")
                  val remarks: String,
                  @SerializedName("DT_OF_AUCTN")
                  val dateOfAuction: String,
)