package com.bom.smamonitor

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Application
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.bom.smamonitor.base.SessionOutListener
import com.bom.smamonitor.depInjection.DaggerAppComponent
import com.bom.smamonitor.pinLockScreen.PinLockActivity
import com.bom.smamonitor.util.AppConstants
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasActivityInjector
import java.util.*
import javax.inject.Inject


@SuppressLint("Registered")
class ProjectApplicationClass : Application(), HasActivityInjector {

    private val TAG = "ProjectAppClas"

    @Inject
    lateinit internal var activityDispatchingAndroidInjector: DispatchingAndroidInjector<Activity>

    override fun activityInjector() = activityDispatchingAndroidInjector

    private var lastInteractionTime = 0
    private val isScreenOff = false
    private var listener: SessionOutListener? = null
    private var timer: Timer? = null
    // private val INACTIVE_TIMEOUT: Long = 30000 // 3 min= 60*3*1000


    override fun onCreate() {
        super.onCreate()

       // startUserInactivityDetectThread(); // start the thread to detect inactivity
       // ScreenReceiver()  // creating receive SCREEN_OFF and SCREEN_ON broadcast msgs from the device.

        DaggerAppComponent.builder()
            .application(this)
            .build()
            .inject(this)
    }

    fun startUserSession() {
        cancelTimer()
        timer = Timer()
        timer!!.schedule(object : TimerTask() {
            override fun run() {
                listener?.onSessionTimeout()
            }
        }, AppConstants.MAX_TIME_OUT_SESSION.toLong())
    }

    private fun cancelTimer() {
        timer?.cancel()
    }

    fun registerSessionListener(listener: SessionOutListener?) {
        this.listener = listener
    }

    fun onUserInteracted() {
        startUserSession()
    }

    private fun startUserInactivityDetectThread() {
        Thread {
            while (true) {
                Thread.sleep(15000) // checks every 15sec for inactivity
                if (isScreenOff || getLastInteractionTime() > AppConstants.MAX_TIME_OUT_SESSION) {
                    //...... means USER has been INACTIVE over a period of
                    // and you do your stuff like log the user out
                    Log.d(TAG, "Session Timed  after 3 minutes on inactivity.")
                    Toast.makeText(this, "Session Timed out.", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, PinLockActivity::class.java)
                    intent.flags =
                        Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    startActivity(intent)
                }
            }
        }.start()
    }

    private fun getLastInteractionTime(): Long {
        return lastInteractionTime.toLong()
    }

    fun setLastInteractionTime(lastInteractionTime: Int) {
        this.lastInteractionTime = lastInteractionTime
    }


}