package com.bom.smamonitor.login

import android.util.Log
import com.androidnetworking.error.ANError
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.network.ApiServiceInterface
import com.bom.smamonitor.network.retrofitApi.SmaDashApiReceiver
import com.bom.smamonitor.util.AppConstants
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject

class LoginPresenterImpl<V : LoginMVPView, I : LoginMVPInteractor>
@Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) :
    BasePresenter<V, I>(
        interactor = interactor,
        schedulerProvider = schedulerProvider,
        compositeDisposable = disposable
    ),
    LoginMVPPresenter<V, I> {

    val TAG = "LoginPrsImpl"
    private val subscriptions = CompositeDisposable()
    private val api: ApiServiceInterface = ApiServiceInterface.create()


    override fun onServerLoginClicked(user: User) {
        when {
            user.pfNo.isEmpty() && user.mobileNo.equals("91") -> getView()?.validateDetails(
                AppConstants.EMPTY_PFNO_Mobile_ERROR
            )
            user.pfNo.isEmpty() -> getView()?.validateDetails(AppConstants.EMPTY_PFNO_ERROR)
            user.mobileNo.equals("91") -> getView()?.validateDetails(AppConstants.EMPTY_MOBILENO_ERROR)

            user.mobileNo.toString().length != 12 -> getView()?.validateDetails(AppConstants.INVALID_MOBILENO_ERROR)
            user.pfNo.length != 5 -> getView()?.validateDetails(AppConstants.INVALID_PFNO)

            else -> {
                // url=https://bomapi.bankofmaharashtra.in/recovery/webserverapi/v1/users/getEmployee/35571}

                getView()?.showProgress()
                interactor?.let {
                    it.getEmployee(user)
                        .compose(schedulerProvider.ioToMainObservableScheduler())
                        .subscribe({ usersList ->
                            getView()?.let { it ->
                                getView()?.hideProgress()
                                println("GetEmployee Result:-$usersList")
                                try {
                                    if (usersList.isNotEmpty()) {
                                        val dbUser = usersList[0]
                                        if (isUserExists(user, dbUser)) {
                                            it.passUser(dbUser)
                                            it.generateOtp()
                                        } else {
                                            getView()?.showError("This mobile no. is not associated with entered PF No.")
                                        }
                                    } else {
                                        getView()?.showError("This PF no is invalid.")
                                    }
                                } catch (e: Exception) {
                                    getView()?.showError("This PF no is invalid.")
                                    e.printStackTrace()
                                }
                            }
                        }, { error ->
                            val aNError = error as ANError
                            Log.d(TAG, aNError.message.toString())
                            getView()?.hideProgress()
                            getView()?.showError(aNError.errorDetail.toString())
                        })
                }
            }
        }
    }

    private fun isUserExists(user: User, dbUser: User): Boolean {
        //Log.d("isUsername", "user: ${user.pfNo?.trim()} and Mb ${user.mobileNo}")
        // Log.d("isUsername", "dbUser: ${dbUser.pfNo?.trim()} and Mb ${dbUser.mobileNo}")
        var dbMobile = dbUser.mobileNo?.trim()
        when (val mbNoLength = dbUser.mobileNo?.length) {
            10 -> {
                dbMobile = "91" + dbUser.mobileNo
            }
            12 -> {
                dbMobile = dbUser.mobileNo.substring(0, mbNoLength)
            }
            13 -> {
                dbMobile = dbUser.mobileNo.substring(2, mbNoLength)
            }
            else -> {
            }
        }
        //Log.d("isUsername", "dbUserN: ${dbUser.pfNo?.trim()} and Mb $dbMobile")

        return (user.pfNo?.trim() == dbUser.pfNo?.trim() && user.mobileNo?.trim() == dbMobile)
    }

    private fun updateUserInSharedPref(
        user: AppUser,
        loggedInMode: AppConstants.LoggedInMode
    ) = interactor?.updateUserInSharedPref(user, loggedInMode)


    override fun getPinFromSharedPrefs(): String? {
        return interactor?.getPinFromSharedPrefs()
    }

    //    fun generate_random(min: Int, max: Int): Int {
//        return Random(System.nanoTime()).nextInt(max - min + 1) + min
//    }


    override fun sendOtp(mobileNo: String?, otpNo: String) {

        Log.d(TAG, "generate_random no=$otpNo")
        getView()?.showProgress()

        interactor?.let {
            it.sendOTP(mobileNo, otpNo)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ otpResponse ->
                    getView()?.let { it ->
                        getView()?.hideProgress()
                        Log.d(TAG, "sendOTP Result:-$otpResponse")
                        try {
                            if (otpResponse.success == "true")
                                getView()?.otpCodeSent(otpNo)
                            else
                                getView()?.otpCodeError("OTP Error.")
                        } catch (e: Exception) {
                            getView()?.showError("OTP Error.")
                            e.printStackTrace()
                        }
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d(TAG, aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

//        val retriever = SmaDashApiReceiver()//
//        val callBack = object : Callback<String> {
//            override fun onFailure(call: Call<String>, t: Throwable) {
//                getView()?.hideProgress()
//                Log.d(TAG, t.localizedMessage.toString())
//                Log.d(TAG, t.message.toString())
//                getView()?.showError("Network Error for user. Please retry login.")
//            }
//
//            override fun onResponse(
//                call: Call<String>,
//                response: Response<String>
//            ) {
//                response.isSuccessful.let {
//                    println(" response:- $response ")
//                    Log.i(TAG, "sendOtp  Results:-${response.body().toString()}")
//                    try {
//
//                    } catch (e: Exception) {
//                        Log.e(TAG, e.toString())
//                        getView()?.showError("Error saving user.")
//                        e.printStackTrace()
//                    }
//                    getView()?.hideProgress()
//
//                }
//            }
//
//        }
//        retriever.sendOtpRetroService(mobileNo!!, callBack)


    //    override fun onOTPSuccess(appUser: AppUser) {
    //        val loggedInRole = checkUserPosting(appUser.curBranch.toString().toInt())
//        println("loggedInRole:-${loggedInRole}")
//
//        getView()?.showProgress()
//        val retriever = CircularApiReceiver()

    //        val callBack = object : Callback<ResponseBody> {
//            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
//                getView()?.hideProgress()
//                Log.d(TAG, t.localizedMessage.toString())
//                Log.d(TAG, t.message.toString())
//                getView()?.showError("Network Error for user. Please retry login.")
//            }
//
//            override fun onResponse(call: Call<ResponseBody>,
//                    response: Response<ResponseBody>) {
//                response.isSuccessful.let {
//                    println("response:-$response")
//                    Log.i(TAG,"AddUser Results:-${response.body().toString()}")
//                    try {
//                        if(response.body().toString().contains("Please fill all the details")){
//                            getView()?.showError(response.body().toString())
//                        }else {
//                            updateUserInSharedPref(appUser, loggedInRole)
//                            getView()?.goToPinLockActivity()
//                        }
//                    } catch (e: Exception) {
//                        Log.e(TAG,e.toString())
//                        getView()?.showError("Error saving user.")
//                        e.printStackTrace()
//                    }
//                    getView()?.hideProgress()
//
//                }
//            }
//        }
//        retriever.addUserRetroService(appUser, callBack)
//    }
    override fun onOTPSuccess(appUser: AppUser) {

        val loggedInRole = checkUserPosting(appUser.curBranch.toString().toInt())
        println("loggedInRole:-${loggedInRole}")

        getView()?.showProgress()
        val retriever = SmaDashApiReceiver()
        val callBack = object : Callback<LoginResponse> {
            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                getView()?.hideProgress()
                Log.d(TAG, t.localizedMessage.toString())
                Log.d(TAG, t.message.toString())
                getView()?.showError("Network Error for user. Please retry login.")
            }

            override fun onResponse(
                call: Call<LoginResponse>,
                response: Response<LoginResponse>
            ) {
                response.isSuccessful.let {


                    Log.d(TAG, "response: $response")
                    Log.i(TAG, "AddUser Results:-${response.body().toString()}")
                    try {
                        when {
                            response.body().toString().contains("Please fill all the details") -> {
                                getView()?.showError(response.message().toString())
                            }
                            response.body().toString().contains("Not Found") -> {
                                getView()?.showError(response.message().toString())
                            }
                            response.message().toString().contains("Internal Server Error") -> {
                               // getView()?.showError(response.message().toString())
                                Log.d(TAG, "response: "+response.message().toString())
                                updateUserInSharedPref(appUser, loggedInRole)
                                getView()?.goToPinLockActivity()
                            }
                            else -> {
                                updateUserInSharedPref(appUser, loggedInRole)
                                getView()?.goToPinLockActivity()
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, e.toString())
                        getView()?.showError("Error saving user.")
                        e.printStackTrace()
                    }
                    getView()?.hideProgress()

                }
            }
        }
        retriever.addSmaUserRetroService2(appUser, callBack)
    }


    private fun checkUserPosting(branchCode: Int): AppConstants.LoggedInMode {
        when {
            branchCode < 5000 -> return AppConstants.LoggedInMode.LOGGED_IN_MODE_BRANCH
            branchCode in 5001..8999 -> return AppConstants.LoggedInMode.LOGGED_IN_MODE_ZONE
            else -> (branchCode == 9999)
        }
        return AppConstants.LoggedInMode.LOGGED_IN_MODE_HO
    }
}
