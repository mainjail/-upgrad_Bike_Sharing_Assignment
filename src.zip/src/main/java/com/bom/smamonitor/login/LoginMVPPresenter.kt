package com.bom.smamonitor.login

import com.bom.smamonitor.base.presenter.MVPPresenter

interface LoginMVPPresenter<V : LoginMVPView, I : LoginMVPInteractor> : MVPPresenter<V, I> {
    fun onServerLoginClicked(user: User)
    fun onOTPSuccess(user: AppUser)
    fun getPinFromSharedPrefs(): String?
    fun sendOtp(mobileNo:String?, otpNo:String)

//    fun addUserServerLoginRetrofit(user: AppUser)
}
