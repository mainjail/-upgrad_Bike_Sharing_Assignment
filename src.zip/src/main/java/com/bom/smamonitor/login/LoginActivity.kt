package com.bom.smamonitor.login

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.base.view.BaseLockActivity
import com.bom.smamonitor.pinLockScreen.PinLockActivity
import com.bom.smamonitor.util.AppConstants
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.DateUtil
import com.bom.smamonitor.util.ValidationUtils
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.*
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.android.synthetic.main.activity_login.*
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import kotlin.random.Random


class LoginActivity : BaseLockActivity(), LoginMVPView {

    private lateinit var verificationCode: String
    val TAG = "LoginAct"
    private var isFinish = false
    private var otpSent: String? = null

    // [START declare_auth]
    private lateinit var auth: FirebaseAuth
    // [END declare_auth]

    private var verificationInProgress = false
    private var storedVerificationId: String? = ""
    private lateinit var resendToken: PhoneAuthProvider.ForceResendingToken
    private lateinit var callbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks

    @Inject
    internal lateinit var presenter: LoginMVPPresenter<LoginMVPView, LoginMVPInteractor>
    private lateinit var user: User

    private lateinit var notificationToken: String





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        presenter.onAttach(this)
        presenter.sessionTimeout()
        loginProBar.hide()
        manageOtpView(false)
        window.statusBarColor = ContextCompat.getColor(this, R.color.colorPrimaryDark)

        setOnClickListeners()
        startFirebaseLogin()
        retrieveFirebaseNotifToken()

        if (checkGooglePlayServices()) {
            retrieveFirebaseNotifToken()
        } else {
            //You won't be able to send notifications to this device
            Log.w(
                TAG,
                "Device doesn't have google play services. You won't be able to receive notifications to this device"
            )
        }

    }

    private fun checkGooglePlayServices(): Boolean {
        // 1
        val status = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this)
        // 2
        return if (status != ConnectionResult.SUCCESS) {
            Log.e(TAG, "Error")
            // ask user to update google play services and manage the error.
            false
        } else {
            // 3
            Log.i(TAG, "Google play services updated")
            true
        }
    }

    private fun retrieveFirebaseNotifToken() {
//        Retrieve the current registration token
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w(TAG, "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }

            // Get new FCM registration token
            val token = task.result
            notificationToken = token.toString()
            // Log and toast
            val msg = "Registered Token of this device:-$token"
            Log.d(TAG, msg)
//            Toast.makeText(baseContext, "Registered Token of this device", Toast.LENGTH_SHORT).show()
        })

    }


    private fun manageOtpView(isOtpCheckTrue: Boolean) {
        if (isOtpCheckTrue) {
            loginBtn.visibility = View.GONE
            et_mobileNoInpL.visibility = View.GONE
            et_pfnoInpL.visibility = View.GONE
            et_otpIL.visibility = View.VISIBLE
            verifyBtn.visibility = View.VISIBLE
        } else {
            loginBtn.visibility = View.VISIBLE
            et_mobileNoInpL.visibility = View.VISIBLE
            et_pfnoInpL.visibility = View.VISIBLE
            et_otpIL.visibility = View.GONE
            verifyBtn.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        signOut()
        presenter.onDetach()
        super.onDestroy()
    }

    override fun showError(errorMsg: String) {
        CustomDialog().popUpToast(this@LoginActivity, errorMsg)
    }

    override fun validateDetails(errorCode: Int) {
        var errorMsg = ""
        when (errorCode) {
            AppConstants.EMPTY_PFNO_Mobile_ERROR -> errorMsg =
                getString(R.string.empty_pf_mobile_error_message)
            AppConstants.EMPTY_EMAIL_ERROR -> errorMsg =
                getString(R.string.empty_email_error_message)
            AppConstants.EMPTY_MOBILENO_ERROR -> errorMsg =
                getString(R.string.empty_mobileno_error_message)
            AppConstants.EMPTY_BRANCHCODE_ERROR -> errorMsg =
                getString(R.string.empty_branchcode_error_message)
            AppConstants.EMPTY_PFNO_ERROR -> errorMsg = getString(R.string.empty_pfno_error_message)

            AppConstants.INVALID_EMAIL_ERROR -> errorMsg =
                getString(R.string.invalid_email_error_message)
            AppConstants.INVALID_MOBILENO_ERROR -> errorMsg =
                getString(R.string.invalid_mbno_error_message)
            AppConstants.INVALID_BRANCH_CODE -> errorMsg =
                getString(R.string.invalid_branch_code_error_message)
            AppConstants.INVALID_PFNO -> errorMsg = getString(R.string.invalid_pfno_error_message)
            AppConstants.LOGIN_FAILURE -> errorMsg = getString(R.string.login_failure)
            AppConstants.LOGIN_CredentialsWrong -> errorMsg = getString(R.string.login_wrong)

        }
        Toast.makeText(this, errorMsg, Toast.LENGTH_LONG).show()
    }

    override fun goToPinLockActivity() {
        val intent = Intent(this, PinLockActivity::class.java)
//        val intent = Intent(this, DashboardBBActivity::class.java)
        startActivity(intent)
        finish()
    }


    private fun setOnClickListeners() {

        loginBtn.setOnClickListener {
            user = User(
                et_pfno.text.toString(),
                "",
                "",
                "",
                "",
                "",
                "",
                "91" + et_mobileNo.text.toString(),
                ""
            )
            println("mobile:" + user.mobileNo)
            if (ValidationUtils.isNetworkAvailable(this@LoginActivity))
                presenter.onServerLoginClicked(user)
            else CustomDialog().showNoInternetAlert(this, "")

        }

        verifyBtn.setOnClickListener {
            try {
                loginProBar.show()
                val otpText = et_otp.text.toString()
                if (!et_otp.text.isNullOrEmpty()) {
                    Log.d(TAG, "onCodeSent: codeSent = $otpSent  otpET $otpText")
                    // if (otpText == "123456") {  for testing purpose

                    if (otpText == otpSent) {
                        Toast.makeText(
                            this@LoginActivity,
                            "OTP Verification Successful",
                            Toast.LENGTH_SHORT
                        ).show()
                        loginProBar.hide()
                        if (::notificationToken.isInitialized) {
                            presenter.onOTPSuccess(setAppUserFromEmployee(user))
                        }

                    } else {
                        loginProBar.hide()

                        Toast.makeText(
                            this@LoginActivity,
                            "OTP verification failed.",
                            Toast.LENGTH_SHORT
                        ).show()

                    }


                   // presenter.onOTPSuccess(setAppUserFromEmployee(user)) // for demo temporary use
//uncomment following lines in production movement
//                    val credential = PhoneAuthProvider.getCredential(verificationCode, otp)
//                    signInWithPhoneAuthCredential(credential)

                } else {
                    CustomDialog().popUpToast(this, "Please enter OTP.")
                }
            } catch (e: UninitializedPropertyAccessException) {
                e.printStackTrace()
            }
        }


    }

    override fun generateOtp() {
        loginProBar.show()
        manageOtpView(true)
        var dbMobile = user.mobileNo?.trim()
        when (val mbNoLength = user.mobileNo?.length) {
            10 -> {
                dbMobile = "91" + user.mobileNo
            }
            12 -> {
                dbMobile = user.mobileNo?.substring(0, mbNoLength)
            }
            13 -> {
                dbMobile = user.mobileNo?.substring(2, mbNoLength)
            }
            else -> {
            }
        }
        //New code fo rotp api
        val otpNo = getRandomNumberString()!!
        Log.d(TAG, "generate_random no=$otpNo")
        otpSent = otpNo
        presenter.sendOtp(dbMobile, otpNo)


//Commenting following code to check new bank API 15-02-2023
//        val options = PhoneAuthOptions.newBuilder(auth)
//            .setPhoneNumber("+$dbMobile")
//            .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
//            .setActivity(this)                 // Activity (for callback binding)
//            .setCallbacks(callbacks)          // OnVerificationStateChangedCallbacks
//            .build()
//        PhoneAuthProvider.verifyPhoneNumber(options)
//        verificationInProgress = true
    }

    private fun generateRandomNo(start: Int, end: Int): Int {
        require(!(start > end || end - start + 1 > Int.MAX_VALUE)) { "Illegal Argument" }
        return Random(System.nanoTime()).nextInt(end - start + 1) + start
    }

    private fun getRandomNumberString(): String? {
        // It will generate 6 digit random Number.
        // from 0 to 999999
        val rnd = Random(System.nanoTime())
        val number: Int = rnd.nextInt(999999)

        // this will convert any number sequence into 6 character.
        return String.format("%06d", number)
    }

    override fun passUser(dbUserFromApi: User) {
        user = dbUserFromApi
        println("User Name:  ${user.name?.trim()} and Branch: ${user.curBranch}")
    }

    override fun otpCodeSent(otpNo: String) {
        Log.d(TAG, "onCodeSent:")
        Toast.makeText(this@LoginActivity, "Code sent", Toast.LENGTH_SHORT).show()
        otpSent = otpNo
        loginProBar.hide()
    }
    override fun otpCodeError(message: String) {
        Log.d(TAG, "onCodeSending error occured:")
        Toast.makeText(this@LoginActivity, "Error in sending otp.", Toast.LENGTH_SHORT).show()
        loginProBar.hide()
    }

    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(
                        this@LoginActivity,
                        "OTP Verification Successful",
                        Toast.LENGTH_SHORT
                    ).show()
                    loginProBar.hide()

                    presenter.onOTPSuccess(setAppUserFromEmployee(user))

                } else {
                    loginProBar.hide()
                    //for temporary use to make code work without otp
                    //  presenter.onOTPSuccess(setAppUserFromEmployee(user))

                    Toast.makeText(
                        this@LoginActivity,
                        "OTP verification failed.",
                        Toast.LENGTH_SHORT
                    ).show()

                }
            }
    }

    private fun setAppUserFromEmployee(user: User): AppUser {
        return AppUser(
            user.pfNo,
            user.name?.trim(),
            user.curBranch?.trim(),
            user.branchName?.trim(),
            user.regionCode?.trim(),
            "",
            user.email?.trim(),
            user.deptCode?.trim(),
            user.deptDesc?.trim(),
            user.mobileNo,
            notificationToken,
           null,
            null,
            null,
            null
        )
    }

    private fun signOut() {
        auth.signOut()
    }

    private fun startFirebaseLogin() {
//        FirebaseApp.initializeApp(this@LoginActivity);
// Initialize Firebase Auth
        auth = Firebase.auth
        // Initialize phone auth callbacks
        callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                // This callback will be invoked in two situations:
                // 1 - Instant verification. In some cases the phone number can be instantly
                //     verified without needing to send or enter a verification code.
                // 2 - Auto-retrieval. On some devices Google Play services can automatically
                //     detect the incoming verification SMS and perform verification without
                //     user action.
                Log.d(TAG, "onVerificationCompleted:$credential")
                loginProBar.hide()
                Toast.makeText(this@LoginActivity, "Verification completed", Toast.LENGTH_SHORT)
                    .show()

            }

            override fun onVerificationFailed(e: FirebaseException) {
                Toast.makeText(this@LoginActivity, "Verification failed", Toast.LENGTH_SHORT)
                    .show()
                loginProBar.hide()
                manageOtpView(false)
               // manageOtpView(true) //for temporary use demo

                Log.w(TAG, "onVerificationFailed", e)
                Log.d(TAG, e.printStackTrace().toString())

                if (e is FirebaseAuthInvalidCredentialsException) {
                    Log.d(TAG, e.printStackTrace().toString())
                    Toast.makeText(this@LoginActivity, e.message, Toast.LENGTH_SHORT).show()

                } else if (e is FirebaseTooManyRequestsException) {
                    Log.d(TAG, e.printStackTrace().toString())
                    Toast.makeText(this@LoginActivity, e.message, Toast.LENGTH_SHORT).show()
                }

            }

            override fun onCodeSent(
                verificationId: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                // The SMS verification code has been sent to the provided phone number, we
                // now need to ask the user to enter the code and the5n construct a credential
                // by combining the code with a verification ID.
                Log.d(TAG, "onCodeSent:verification id")
                Toast.makeText(this@LoginActivity, "Code sent", Toast.LENGTH_SHORT).show()
                verificationCode = verificationId
                loginProBar.hide()

                // Save verification ID and resending token so we can use them later
//            storedVerificationId = verificationId
//            resendToken = token
            }
        }
    }

    override fun onBackPressed() {
        if (isFinish)
            super.onBackPressed()
        else {
            isFinish = true
            CustomDialog().popUpToast(this, resources.getString(R.string.backTofinish))
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) {
            Log.i(TAG, "Login Activity window focus changed")
        }
    }
}