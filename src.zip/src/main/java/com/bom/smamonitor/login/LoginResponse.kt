package com.bom.smamonitor.login

import com.google.gson.annotations.SerializedName

data class LoginResponse(
    @SerializedName("success")
    val success: String,
    @SerializedName("rowsAffected")
    val rowsAffected: String,
    @SerializedName("message")
    val message: String
)

data class OTPResponse(
    @SerializedName("success")
    val success: String,

    @SerializedName("message")
    val message: String
)
//{
//    "success": "false",
//    "rowsAffected": "",
//    "message": "Failed to connect to 10.128.68.70:56276 in 15000ms"
//}