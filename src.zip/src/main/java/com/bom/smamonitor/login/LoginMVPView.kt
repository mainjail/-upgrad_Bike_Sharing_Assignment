package com.bom.smamonitor.login

import com.bom.smamonitor.base.view.BaseMVPView

interface LoginMVPView : BaseMVPView {
    fun goToPinLockActivity()
    fun validateDetails(errorCode:Int)
    fun showError(errorMsg:String)
    fun generateOtp()
    fun passUser(user: User)
    fun otpCodeSent(otpNo:String)
    fun otpCodeError(otpNo:String)

}
