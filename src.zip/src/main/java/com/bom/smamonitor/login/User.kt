package com.bom.smamonitor.login

import com.google.gson.annotations.SerializedName


data class User(
    @SerializedName("PF_NO")
    val pfNo: String,
    @SerializedName("NAME")
    val name: String?,
    @SerializedName("CUR_BRANCH")
    val curBranch: String?,

    @SerializedName("REGION_CODE")
    val regionCode: String?,
    @SerializedName("EMAIL_ID")
    val email: String?,
    @SerializedName("DEPTCODE")
    val deptCode: String?,

    @SerializedName("DEPT_DES")
    val deptDesc: String?,
    @SerializedName("MOBILE_NO")
    val mobileNo: String?,
    @SerializedName("BRANCH_NAME")
    var branchName: String?
    )



data class AppUser(

    @SerializedName("PF_NO")
    val pfNo: String,

    @SerializedName("NAME")
    val name: String?,

    @SerializedName("CUR_BRANCH")
    val curBranch: String?,

    @SerializedName("BRANCH_NAME")
    var branchName: String?,

    @SerializedName("REGION_CODE")
    val regionCode: String?,

    @SerializedName("REGION_NAME")
    var regionName: String?,

    @SerializedName("EMAIL_ID")
    val email: String?,

    @SerializedName("DEPTCODE")
    val deptCode: String?,

    @SerializedName("DEPT_DES")
    val deptDesc: String?,

    @SerializedName("MOBILE_NO")
    val mobileNo: String?,

    @SerializedName("NOTIFICATION_ID")
    var notificationId: String?,

    @SerializedName("USER_CREATION_DATE")
    var userCreationDate: String?,

    @SerializedName("LAST_LOGIN_DATE")
    var lastLoginDate: String?,

    var sessionId: String?,

    @SerializedName("USER_LOCK_PIN")
    var userLockPin: String?

//{"PF_NO":30567,"NAME":"PUNIT PITTAMBARBHAI VADHER","CUR_BRANCH":86,
//        "BRANCH_NAME":null,"REGION_CODE":"18","REGION_NAME":null,
//        "DEPTCODE":0,"DEPT_DES":null,"MOBILE_NO":919737191105,"EMAIL_ID":"emailid@gmail.com",
//        "NOTIFICATION_ID":"kjsbvksbdsvbsb263547jbdvjs98e9ih98yc9hvisuhvisuvskvjbsjdvhbskdjvhbsdkvjh",
//        "USER_CREATION_DATE":"2022-05-04T11:59:52.547Z","LAST_LOGIN_DATE":"2022-05-04T11:59:52.547Z"}
)
