package com.bom.smamonitor.login

import com.google.gson.annotations.SerializedName

data class Employee(
    @SerializedName("PF_NO")
    val pfNo: String,
    @SerializedName("NAME")
    val name: String,
    @SerializedName("CUR_BRANCH")
    val curBranch: String,
    @SerializedName("REGION_CODE")
    val regCode: String,
    @SerializedName("DEPTCODE")
    val deptCode: String,
    @SerializedName("DEPT_DES")
    val deptDes: String,
    @SerializedName("MOBILE_NO")
    val mobileNo: String,
    @SerializedName("EMAIL_ID")
    val emailId: String

)

//{
//    "PF_NO": 30567,
//    "NAME": "PUNIT PITTAMBARBHAI VADHER",
//    "CUR_BRANCH": 86,
//    "REGION_CODE": "18",
//    "DEPTCODE": null,
//    "DEPT_DES": null,
//    "MOBILE_NO": 919737191105,
//    "EMAIL_ID": null
//}