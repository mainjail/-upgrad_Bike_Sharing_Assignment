package com.bom.smamonitor.login

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.util.AppConstants
import io.reactivex.Observable
import okhttp3.Response

interface LoginMVPInteractor : MVPInteractor {
    fun doServerLoginApiCall(user: User): Observable<LoginResponse>
    fun updateUserInSharedPref( user: AppUser, loggedInMode: AppConstants.LoggedInMode)
    fun logOutUserInSharedPref( user: AppUser, loggedInMode: AppConstants.LoggedInMode)
    fun getEmployee(user: User): Observable<List<User>>
    fun addAppUserToDb(user: AppUser): Observable<AppUser>
    fun getPinFromSharedPrefs(): String?
    fun sendOTP(mobileNo:String?,otpNo:String): Observable<OTPResponse>


}