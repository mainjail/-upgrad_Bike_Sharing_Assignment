package com.bom.smamonitor.login

import android.view.View
import androidx.appcompat.app.AppCompatActivity

class PhoneAuthActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        TODO("Not yet implemented")
    }

// Initialize Firebase Auth
//    auth = Firebase.auth





}