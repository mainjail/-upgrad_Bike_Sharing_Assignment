package com.bom.smamonitor.login

import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.network.ApiHelper
import com.bom.smamonitor.util.AppConstants
import io.reactivex.Observable
import okhttp3.Response
import javax.inject.Inject

class LoginInteractorImpl @Inject internal constructor(
    preferenceHelper: PreferenceHelper,
    apiHelper: ApiHelper
) :
    BaseInteractor(preferenceHelper, apiHelper), LoginMVPInteractor {

    override fun doServerLoginApiCall(user: User) = apiHelper.performServerLogin(user)

    override fun getEmployee(user: User) = apiHelper.getEmployee(user)

    override fun addAppUserToDb(user: AppUser): Observable<AppUser> = apiHelper.addUser(user)

    override fun getPinFromSharedPrefs(): String? {
        return preferenceHelper.getCurrentUserPIN()
    }

    override fun sendOTP(mobileNo: String?, otpNo: String): Observable<OTPResponse> =
        apiHelper.sendOtp(mobileNo, otpNo)


    override fun updateUserInSharedPref(
        user: AppUser,
        loggedInMode: AppConstants.LoggedInMode
    ) {
        preferenceHelper.setCurrentUserLoggedInMode(loggedInMode)
        preferenceHelper.setCurrentUserName(user.name!!.trim())
        preferenceHelper.setCurrentBranchCode(user.curBranch!!.trim())
        preferenceHelper.setCurrentBranchName(user.branchName)

        if (user.deptCode != null) {
            preferenceHelper.setCurrentDeptCode(user.deptCode!!.trim())
        } else {
            preferenceHelper.setCurrentDeptCode("0000")
        }
        preferenceHelper.setUserRegionCode(user.regionCode!!.trim())
        preferenceHelper.setUserRegionName(user.regionName)

        preferenceHelper.setCurrentUserPfNo(user.pfNo)
        preferenceHelper.setCurrentUserEmail(user.email)
        preferenceHelper.setCurrentUserMobileNo(user.mobileNo)
        preferenceHelper.setCurrentDeviceNotificationToken(user.notificationId)
        preferenceHelper.setSessionId(user.pfNo + user.mobileNo)

    }


    override fun logOutUserInSharedPref(
        user: AppUser,
        loggedInMode: AppConstants.LoggedInMode
    ) {
        preferenceHelper.setCurrentUserLoggedInMode(loggedInMode)
        preferenceHelper.setCurrentUserName(user.name)
        preferenceHelper.setCurrentBranchCode(user.curBranch)
        preferenceHelper.setCurrentBranchName(user.branchName)
        preferenceHelper.setUserRegionCode(user.regionCode)
        preferenceHelper.setUserRegionName(user.regionName)
        preferenceHelper.setCurrentUserPfNo(user.pfNo)
        preferenceHelper.setCurrentUserMobileNo(user.mobileNo)
        preferenceHelper.setCurrentUserEmail(user.email)
        preferenceHelper.setCurrentDeviceNotificationToken(user.notificationId)
        preferenceHelper.setUserLastLogindate(user.lastLoginDate)
        preferenceHelper.setSessionId(user.pfNo + user.mobileNo)

    }

}