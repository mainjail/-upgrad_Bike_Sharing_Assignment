package com.bom.smamonitor.zonesectrsumry

import com.google.gson.annotations.SerializedName

//HoSectSumSma		[41]
//0		{9}
//	:	DELHI ZONE (5517)
//	:	1
//Retail_LOAN_BAL	:	61.460283
//AGRI_LOAN_BAL	:	3.477079
//MSME_LOAN_BAL	:	49.431494
//LARGE_LOAN_BAL	:	5.785081
//OTHER_BAL	:	3.75342
//LOAN_BAL	:	123.90736
//variation	:	-1.719457

data class ZoneSectorSum(
    @SerializedName("ZONE_NAME")
    val zoneName: String,

    @SerializedName("ZONE_CODE")
    val zoneCode: String,

    @SerializedName("BRANCHNAME")
    val branchName: String,

    @SerializedName("BRCODE")
    val brCode: String,

    @SerializedName("RETAIL_LOAN_BAL")
    val retailLoanBal: Double,

    @SerializedName("AGRI_LOAN_BAL")
    val agriLoanBal: Double,

    @SerializedName("MSME_LOAN_BAL")
    val msmeLoanBal: Double,

    @SerializedName("LARGE_LOAN_BAL")
    val largeLoanBal: Double,

    @SerializedName("OTHER_BAL")
    val otherBal: Double,

    @SerializedName("LOAN_BAL")
    val loanBal: Double,

    @SerializedName("VARIATION")
    val variation: Double
    )

data class HoSectObj(
    @SerializedName("HoSectSumSma")
    val listZoneSectorSum: List<ZoneSectorSum>
)


