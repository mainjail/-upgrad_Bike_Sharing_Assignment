package com.bom.smamonitor.zonesectrsumry.zontable;


import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.ColumnHeaderModel;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;
import com.bom.smamonitor.zonesectrsumry.ZoneSectorSum;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class ZoneSectTableViewModel {
    // Columns indexes
    public static final int LINK_COLUMN_INDEX1 = 1;
    public static final int LINK_COLUMN_INDEX2 = 2;

    // Constant size for dummy data sets
//    private static final int COLUMN_SIZE = 500;
//    private static final int ROW_SIZE = 500;

    private List<ColumnHeaderModel> mColumnHeaderModelList;
    private List<RowHeaderModel> mRowHeaderModelList;
    private List<List<Cell>> mCellModelList;


    public ZoneSectTableViewModel() {
    }

    private List<ColumnHeaderModel> createColumnHeaderModelList(Integer callFromMode) {
        List<ColumnHeaderModel> list = new ArrayList<>();


        list.add(new ColumnHeaderModel("0", "CODE"));
        list.add(new ColumnHeaderModel("1", "AGRI"));
        list.add(new ColumnHeaderModel("2", "LARGE"));
        list.add(new ColumnHeaderModel("3", "MSME"));
        list.add(new ColumnHeaderModel("4", "RETAIL"));
        list.add(new ColumnHeaderModel("5", "OTHER"));
        list.add(new ColumnHeaderModel("6", "TOTAL"));
        list.add(new ColumnHeaderModel("7", "VARIATION"));

        return list;
    }

    private String toLacs(double num) {
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.DOWN);
        try {
            num = (num / 100000);  // in lac
        } catch (Exception e) {
            e.printStackTrace();
        }
        return df.format(num);
    }

    private String toCrores(double num) {
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.DOWN);
        try {
            num = num / 10000000;// in crores
        } catch (Exception e) {
            e.printStackTrace();
        }
        return df.format(num);
    }

    private List<List<Cell>> createCellModelList(List<ZoneSectorSum> zoneSectorSumList, Integer callFromMode, Boolean isViewInLacs) {

        List<List<Cell>> cellList = new ArrayList<>();
        try {
            for (int i = 0; i < zoneSectorSumList.size(); i++) {
                ZoneSectorSum zoneSectorSum = zoneSectorSumList.get(i);
                List<Cell> list = new ArrayList<>();

                if (callFromMode == 2) {
                    list.add(new Cell("1-" + i, zoneSectorSum.getBrCode()));
                } else {
                    list.add(new Cell("1-" + i, zoneSectorSum.getZoneCode()));
                }
                if (isViewInLacs) {
                    list.add(new Cell("2-" + i, toLacs(zoneSectorSum.getAgriLoanBal())));
                    list.add(new Cell("3-" + i, toLacs(zoneSectorSum.getLargeLoanBal())));
                    list.add(new Cell("4-" + i, toLacs(zoneSectorSum.getMsmeLoanBal())));
                    list.add(new Cell("5-" + i, toLacs(zoneSectorSum.getRetailLoanBal())));
                    list.add(new Cell("6-" + i, toLacs(zoneSectorSum.getOtherBal())));
                    list.add(new Cell("7-" + i, toLacs(zoneSectorSum.getLoanBal())));
                    list.add(new Cell("8-" + i, toLacs(zoneSectorSum.getVariation())));
                    // list.add(new Cell("8-" + i, String.valueOf(i + 1)));
                } else {

                    list.add(new Cell("2-" + i, toCrores(zoneSectorSum.getAgriLoanBal())));
                    list.add(new Cell("3-" + i, toCrores(zoneSectorSum.getLargeLoanBal())));
                    list.add(new Cell("4-" + i, toCrores(zoneSectorSum.getMsmeLoanBal())));
                    list.add(new Cell("5-" + i, toCrores(zoneSectorSum.getRetailLoanBal())));
                    list.add(new Cell("6-" + i, toCrores(zoneSectorSum.getOtherBal())));
                    list.add(new Cell("7-" + i, toCrores(zoneSectorSum.getLoanBal())));
                    list.add(new Cell("8-" + i, toCrores(zoneSectorSum.getVariation())));
                }


                cellList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cellList;
    }

    private String formatRoundUp(double num) {
        return String.format("%.02f", num);
    }

    private List<RowHeaderModel> createRowHeaderList(List<ZoneSectorSum> zoneSectorSumList, int size, int callFromMode) {
        List<RowHeaderModel> list = new ArrayList<>();

        try {
            for (int i = 0; i < size; i++) {
                ZoneSectorSum zoneSectorSum = zoneSectorSumList.get(i);
                if (callFromMode == 2) {
                    if (zoneSectorSum.getBranchName() != null) {
                        if (!zoneSectorSum.getBranchName().isEmpty()) {
                            if (zoneSectorSum.getBranchName().equals("ZZTOTAL")) {
                                list.add(new RowHeaderModel(String.valueOf(i), "TOTAL"));
                            } else if (zoneSectorSum.getBranchName().contains("ZONE")) {
                                list.add(new RowHeaderModel(String.valueOf(i), "TOTAL"));
                            } else {
                                if(zoneSectorSum.getBranchName().contains("(")){
                                    String branchName = zoneSectorSum.getBranchName().substring(0, zoneSectorSum.getBranchName().indexOf('('));
                                    list.add(new RowHeaderModel(String.valueOf(i), branchName));
                                }else{
                                    String branchName = zoneSectorSum.getBranchName();
                                    list.add(new RowHeaderModel(String.valueOf(i), branchName));
                                }
                            }
                        }
                    }
                } else {
                    if (!zoneSectorSum.getZoneName().isEmpty() || zoneSectorSum.getZoneName() != null) {
                        String zoneName1 = zoneSectorSum.getZoneName();
                        if (zoneSectorSum.getZoneName().trim().contains("ZZTOTAL")) {
                            list.add(new RowHeaderModel(String.valueOf(i), "TOTAL"));
                        } else {
                            if(zoneName1.contains("ZONE")) {
                                String zoneName = zoneSectorSum.getZoneName().substring(0, zoneSectorSum.getZoneName().indexOf("ZONE"));
                                list.add(new RowHeaderModel(String.valueOf(i), zoneName));
                            } else {
                                list.add(new RowHeaderModel(String.valueOf(i), "Central Office"));
                            }
                        }
                    }
                }
            }
        }catch(IndexOutOfBoundsException e){
            e.printStackTrace();
        }
        return list;
    }

    public List<ColumnHeaderModel> getColumnHeaderModeList() {
        return mColumnHeaderModelList;
    }

    public List<RowHeaderModel> getRowHeaderModelList() {
        return mRowHeaderModelList;
    }

    public List<List<Cell>> getCellModelList() {
        return mCellModelList;
    }

    public void generateListForZoneWiseTableView(List<ZoneSectorSum> zoneSectorSums,
                                                 Integer callFromMode, Boolean isViewInLacs) {
        mColumnHeaderModelList = createColumnHeaderModelList(callFromMode);
        mCellModelList = createCellModelList(zoneSectorSums, callFromMode, isViewInLacs);
        mRowHeaderModelList = createRowHeaderList(zoneSectorSums, zoneSectorSums.size(), callFromMode);
    }

//    public void generateListForBranchWiseTableView(List<BranchSectSummary> branchSectSummaries, Boolean isZone) {
//        mColumnHeaderModelList = createColumnHeaderModelList(isZone);
//        mCellModelList = createCellModelList(branchSectSummaries,isZone);
//        mRowHeaderModelList = createRowHeaderList(branchSectSummaries.size());
//    }
}



