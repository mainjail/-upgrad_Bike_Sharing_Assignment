package com.bom.smamonitor.zonesectrsumry

import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.bzsummary.ZoneSummaryObj
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.network.ApiHelper
import io.reactivex.Observable
import javax.inject.Inject

class ZoneSectSumInteractorImpl @Inject internal constructor(
    preferenceHelper: PreferenceHelper,
    apiHelper: ApiHelper
) :
    BaseInteractor(preferenceHelper, apiHelper), ZoneSectorSumMVPInteractor {


    override fun getZoneSectSumryReportWise(
        brCode: String,
        repType: String
    ): Observable<HoSectObj> {
        return apiHelper.getZoneSectSumryReportWise(brCode, repType, checkUserRole(brCode))
    }

    override fun getZoneSummary(brCode: String, isViewInLacs: Boolean): Observable<ZoneSummaryObj> {
        return apiHelper.getZoneSummary(brCode, isViewInLacs, checkUserRole(brCode))
    }

    override fun getHoZoneSummary(brCode: String, isViewInLacs: Boolean): Observable<ZoneSummaryObj> {
        return apiHelper.getHoZoneSummary(
            brCode,
            isViewInLacs,
            preferenceHelper.getCurrentUserLoggedInMode()
        )
    }

    private fun checkUserRole(branch: String): Int {
//        if(brCode == 9999){ //HO
//        }else if(brCode<5000){ //branch
//            brCode = Integer.parseInt(preferenceHelper.getUserRegionCode()!!)
//        }else if (brCode in 5002..8998){//Zone  = brCode>5001 && brCode<8999)
//
//        }
//        var brCode=0;
//
//        if(branch.length> 2)
//            brCode = Integer.parseInt(preferenceHelper.getUserRegionCode()!!)
//        else
        var loggedInMode = preferenceHelper.getCurrentUserLoggedInMode()
        if (Integer.parseInt(branch) == 99) {
            loggedInMode = 3
        } else {
            loggedInMode = 2
        }
        return loggedInMode;

    }

}