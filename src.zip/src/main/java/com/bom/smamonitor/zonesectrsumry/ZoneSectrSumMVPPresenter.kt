package com.bom.smamonitor.zonesectrsumry

import com.bom.smamonitor.base.presenter.MVPPresenter

interface ZoneSectrSumMVPPresenter<V: ZoneSectSumMVPView, I: ZoneSectorSumMVPInteractor> :MVPPresenter<V,I>{


    fun getZoneSectSumryReportWise(brCode:String, repType:String)
    fun getHoZoneSummaryReportWise(brCode:String, isViewInlacs:Boolean)

    fun getZoneSummaryBranchRepWise(brCode:String, isViewInlacs:Boolean)

}