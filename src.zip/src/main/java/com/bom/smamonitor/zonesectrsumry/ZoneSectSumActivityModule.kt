package com.bom.smamonitor.zonesectrsumry


import dagger.Module
import dagger.Provides


@Module
class ZoneSectSumActivityModule {

    @Provides
    internal fun provideBusiMetricsInteractor(interactor: ZoneSectSumInteractorImpl):
            ZoneSectorSumMVPInteractor = interactor

    @Provides
    internal fun provideBusiMetricsPresenter(presenter: ZoneSectSumPresenterImpl<ZoneSectSumMVPView,
            ZoneSectorSumMVPInteractor>    )            : ZoneSectrSumMVPPresenter<ZoneSectSumMVPView, ZoneSectorSumMVPInteractor> = presenter

//    @Provides
//    internal fun provideAdapter(): FiguresAdapter = FiguresAdapter()

//    @Provides
//    internal fun provideLinearLayoutManager(activity:  ZoneSectorSumActivity):
//            LinearLayoutManager = LinearLayoutManager(activity)

}