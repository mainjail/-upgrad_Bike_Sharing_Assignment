package com.bom.smamonitor.zonesectrsumry

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.LinearLayoutCompat
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.bzsummary.ZoneSummary
import com.bom.smamonitor.bzsummary.zontable.ZoneSumTableAdapter
import com.bom.smamonitor.bzsummary.zontable.ZoneSumTableViewListener
import com.bom.smamonitor.bzsummary.zontable.ZoneSumTableViewModel
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import kotlinx.android.synthetic.main.activity_zone_sector_sum.*
import kotlinx.android.synthetic.main.activity_zone_sector_sum.tableDataTitle
import kotlinx.android.synthetic.main.dialog_bottom_sheet_filters.*
import java.util.*
import javax.inject.Inject

class ZoneSummaryActivity : BaseActivity(), ZoneSectSumMVPView {


    private var isViewInLacs= false
    private var selectedSortBy = "Crores"
    private lateinit var reportsShortArray: Array<String>
    private lateinit var reportsArray: Array<String>
    private var rotationAngle = 0
    private lateinit var tableViewAdapter: ZoneSumTableAdapter
    private var isZone = false
    private val tableViewModel = ZoneSumTableViewModel()

    private val String.capitalizeWords
        get() = this.toLowerCase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.capitalize(Locale.getDefault())
        }
    private var tableInputList = listOf<ZoneSummary>()
    private var brCodeForApi = "99"
    private var callFromMode = 0

    @Inject
    internal lateinit var presenter: ZoneSectrSumMVPPresenter<ZoneSectSumMVPView, ZoneSectorSumMVPInteractor>

    var regCodeIntent = "00000"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zone_sector_sum)
        presenter.onAttach(this)
        supportActionBar?.title = this.resources.getString(R.string.zoneSummary)
        supportActionBar?.setHomeAsUpIndicator(resources.getDrawable(R.drawable.ic_action_back))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        setUp()
    }


    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }


    @SuppressLint("SimpleDateFormat")
    private fun setUp() {


        val regionCode = intent.getStringExtra("regionCode")
        var regionName = intent.getStringExtra("regionName")
        val branchCode = intent.getStringExtra("branchCode")
        val branchName = intent.getStringExtra("branchName")

        if (regionCode != null) {

            brCodeForApi = regionCode
            if (regionCode == "99") {
                regionName = "Head Office"
                supportActionBar?.subtitle = "$regionCode -  $regionName"
                callFromMode = 3
                isZone = true;
                this.regCodeIntent = regionCode
                callReportApi(regionCode, selectedSortBy)

            } else {
                supportActionBar?.subtitle = "$regionCode -  $regionName"
                isZone = true
                callFromMode = 2
                supportActionBar?.title = this.resources.getString(R.string.branchwiseSum)
                callReportApi(regionCode, "sma1")
            }
        } else {
            if (branchCode != null) {
                brCodeForApi = branchCode
                isZone = false
                callFromMode = 1
            }

        }


        initializeTableView()
        reportsArray = resources.getStringArray(R.array.reportsArray)
        reportsShortArray = resources.getStringArray(R.array.reportsShortArray)
//        figuresTitle.text= "Amount in $selectedSortBy"
        figuresTitle.visibility= View.GONE

        tableDataTitle.text= "Amount in $selectedSortBy"

        tableDataTitle.visibility = View.VISIBLE
        expColapIV.setOnClickListener {
            filterBtn.callOnClick()
        }

        filterBtn.setOnClickListener {
            rotationAngle = if (rotationAngle == 0) 180 else 0 //toggle
            expColapIV.animate().rotation(rotationAngle.toFloat()).setDuration(500).start()
            showBottomSheetDialog(regionCode.toString())
        }

    }

    private fun checkUserRole(branch: String): String {
        val brCode = Integer.parseInt(branch)
        when {
            brCode == 9999 -> { //HO
                "Head Office"
            }
            brCode < 5000 -> { //branch
                //brCode = Integer.parseInt(preferenceHelper.getUserRegionCode()!!)
            }
            brCode in 5002..8998 -> {//Zone  = brCode>5001 && brCode<8999)
            }
        }
        return brCode.toString()

    }

    private fun callReportApi(regionCode: String, unitType: String) {
        if (ValidationUtils.isNetworkAvailable(this))
            if (callFromMode == 3)
                presenter.getHoZoneSummaryReportWise(regionCode, isViewInLacs )
            else
                presenter.getZoneSummaryBranchRepWise(regionCode, isViewInLacs)
        else CustomDialog().showNoInternetAlert(this, "")
    }

    private fun initializeTableView() {
        tableViewAdapter = ZoneSumTableAdapter(tableViewModel, callFromMode)
        tableView1.setAdapter(tableViewAdapter)
        tableView1.rowHeaderWidth = resources.getDimension(R.dimen.row_header_width).toInt()
        val myTableViewListener = ZoneSumTableViewListener(tableView1, callFromMode)
        tableView1.tableViewListener = myTableViewListener
        //setHeightToTable(accountsList?.size!!)
    }

    override fun showError(errorMsg: String) {
        CustomDialog().showAlert(this, errorMsg)
    }

    override fun displayZoneSectrListSma0(smaList: List<ZoneSectorSum>) {
//        this.tableInputList = smaList
//        tableViewAdapter.setUserList(smaList)
    }

    override fun displayZoneSumList(zoneSumList: List<ZoneSummary>) {
        this.tableInputList = zoneSumList
        tableViewAdapter.setUserList(zoneSumList, callFromMode)
    }

    @SuppressLint("SetTextI18n")
    private fun showBottomSheetDialog(regionCode: String) {

        val dialog = BottomSheetDialog(this)
        dialog.setContentView(R.layout.dialog_bottom_sheet_filters)
        dialog.reportFilLL.visibility = View.GONE
        dialog.fieldDivider.visibility = View.GONE

        val sortChipGrp = dialog.findViewById<ChipGroup>(R.id.sortChipGrp)
        val sortByTitle = dialog.findViewById<AppCompatTextView>(R.id.sortByTitle)
        sortByTitle?.text = resources.getString(R.string.amountIn)

        val lacChip = dialog.findViewById<Chip>(R.id.firstSortChip)
        val crChip = dialog.findViewById<Chip>(R.id.secondSortChip)
        val thirdChip = dialog.findViewById<Chip>(R.id.thirdSortChip)
        val ptpDateChip = dialog.findViewById<Chip>(R.id.ptpDateChip)
        val fieldDivider2 = dialog.findViewById<View>(R.id.fieldDivider2)
        fieldDivider2?.visibility = View.GONE

        ptpDateChip?.visibility = View.GONE
        thirdChip?.visibility = View.GONE
        lacChip?.text = resources.getString(R.string.lacs)
        crChip?.text = resources.getString(R.string.crores)

        val applyBtn = dialog.findViewById<AppCompatButton>(R.id.applyBtn)
        val mapFilterLL = dialog.findViewById<LinearLayoutCompat>(R.id.mapFilterLL)
        mapFilterLL?.visibility = View.GONE
        sortChipGrp?.setOnCheckedChangeListener { chipGroup, i ->
            selectedSortBy =
                sortChipGrp.findViewById<Chip>(sortChipGrp.checkedChipId).text.toString()
        }

        applyBtn?.setOnClickListener {
            rotationAngle = if (rotationAngle == 0) 180 else 0 //toggle
            expColapIV.animate().rotation(rotationAngle.toFloat()).setDuration(500)
                .start()
            figuresTitle.text= "Amount in $selectedSortBy"
            figuresTitle.visibility=View.GONE
            tableDataTitle.text = "Amount in $selectedSortBy"

            setPositionSortNo(selectedSortBy)
            callReportApi(regionCode, selectedSortBy)
            dialog.dismiss()
        }

        dialog.show()
    }



    private fun setPositionSortNo(sortBy: String) {
        var reportPosition = 0
        when (sortBy) {
            "Lacs" -> {
                reportPosition = 0
                isViewInLacs=true
            }
            "Crores" -> {
                reportPosition = 1
                isViewInLacs=false

            }
        }
        // return reportPosition
    }

}