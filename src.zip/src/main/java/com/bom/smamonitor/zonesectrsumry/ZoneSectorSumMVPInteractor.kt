package com.bom.smamonitor.zonesectrsumry

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.bzsummary.DataObj
import com.bom.smamonitor.bzsummary.ZoneSummaryObj
import io.reactivex.Observable

interface ZoneSectorSumMVPInteractor : MVPInteractor {

//    fun getTotalFigures(branchCode: String, date:String): Observable<List<BusiMetrics>>
//    fun getNpaFigures(branchCode: String, date: String): Observable<List<NpaFigures>>
    fun getZoneSectSumryReportWise(branchCode: String, repType:String): Observable<HoSectObj>
    fun getZoneSummary(branchCode: String, isViewInLacs:Boolean): Observable<ZoneSummaryObj>

    fun getHoZoneSummary(branchCode: String, isViewInLacs:Boolean): Observable<ZoneSummaryObj>


}

