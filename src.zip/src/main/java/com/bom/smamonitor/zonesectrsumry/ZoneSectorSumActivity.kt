package com.bom.smamonitor.zonesectrsumry

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.LinearLayoutCompat
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.bzsummary.ZoneSummary
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import com.bom.smamonitor.zonesectrsumry.zontable.ZoneSectTableAdapter
import com.bom.smamonitor.zonesectrsumry.zontable.ZoneSectTableViewListener
import com.bom.smamonitor.zonesectrsumry.zontable.ZoneSectTableViewModel
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import kotlinx.android.synthetic.main.activity_zone_sector_sum.*
import java.util.*
import javax.inject.Inject

class ZoneSectorSumActivity : BaseActivity(), ZoneSectSumMVPView {

    private var selectedReport = "sma0"
    private lateinit var reportsShortArray: Array<String>
    private lateinit var reportsArray: Array<String>
    private var rotationAngle = 0
    private var selectedSortBy = "Crores"
    private var isViewInLacs = false
    private lateinit var tableViewAdapter: ZoneSectTableAdapter

    private var brCodeForApi = "9999"
    private var callFromMode = 0
    private val tableViewModel = ZoneSectTableViewModel()

    private val String.capitalizeWords
        get() = this.toLowerCase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.capitalize(Locale.getDefault())
        }
    private var tableInputList = listOf<ZoneSectorSum>()


    @Inject
    internal lateinit var presenter: ZoneSectrSumMVPPresenter<ZoneSectSumMVPView, ZoneSectorSumMVPInteractor>

    private var isZone =
        false // if this is HO Call which fetches Zones listing then true else false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zone_sector_sum)
        presenter.onAttach(this)
        supportActionBar?.setHomeAsUpIndicator(resources.getDrawable(R.drawable.ic_action_back))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        setUp()
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    @SuppressLint("SimpleDateFormat")
    private fun setUp() {
        reportsArray = resources.getStringArray(R.array.reportsArray)
        reportsShortArray = resources.getStringArray(R.array.reportsShortArray)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, reportsArray)
//        reportSpinner.adapter = adapter

        val regionCode = intent.getStringExtra("regionCode").toString()
        var regionName = intent.getStringExtra("regionName")
        val branchCode = intent.getStringExtra("branchCode")
        val branchName = intent.getStringExtra("branchName")

        if (regionCode != null) {
            brCodeForApi = regionCode
            if (regionCode == "99") {
                regionName = "Head Office"
                supportActionBar?.subtitle = "$regionCode -  $regionName"
                callFromMode = 3
                isZone = true
                supportActionBar?.title = this.resources.getString(R.string.zoneSectorSummary)
                callReportApi(regionCode, selectedReport)

            } else {
                supportActionBar?.subtitle = "$regionCode -  $regionName"
                isZone = true
                callFromMode = 2
                supportActionBar?.title = this.resources.getString(R.string.branchwiseSectorSum)
                callReportApi(regionCode, selectedReport)
            }
        } else if (branchCode != null) {
            brCodeForApi = branchCode
            isZone = false
            callFromMode = 1
        }
        figuresTitle.text = "Amount in $selectedSortBy"

        initializeTableView()
        expColapIV.setOnClickListener {
            filterBtn.callOnClick()
        }
        filterBtn.setOnClickListener {
            rotationAngle = if (rotationAngle == 0) 180 else 0 //toggle
            expColapIV.animate().rotation(rotationAngle.toFloat()).setDuration(500).start()
            showBottomSheetDialog(regionCode)
        }


    }

    private fun checkUserRole(branch: String): String {
        val brCode = Integer.parseInt(branch)
        when {
            brCode == 9999 -> { //HO
                "Head Office"
            }
            brCode < 5000 -> { //branch
                //brCode = Integer.parseInt(preferenceHelper.getUserRegionCode()!!)
            }
            brCode in 5002..8998 -> {//Zone  = brCode>5001 && brCode<8999)

            }
        }
        return brCode.toString()

    }

    //    private fun checkUserRole(brCode:String): String {
//        var branchCode = "9999"
//        when (loggedInMode) {
//            3 -> branchCode = "99"
//            2 -> branchCode = brCode
//            1 -> branchCode = userBranch
//        }
//        return branchCode
//    }
    private fun getReportNoFromChip(position: String): String {
        var reportPosition = 0;
        when (position) {
            "SMA-0" -> reportPosition = 0
            "SMA-1" -> reportPosition = 1
            "SMA-2" -> reportPosition = 2
            "Total-SMA" -> reportPosition = 3
            "Report-7F" -> reportPosition = 4
            "Report-7D" -> reportPosition = 5
            "Report-7NF" -> reportPosition = 6
            "Total Rep-7F,7NF,7D" -> reportPosition = 7
            "Report-6" -> reportPosition = 8
        }
        return reportsShortArray[reportPosition]
    }


    private fun callReportApi(regionCode: String, repType: String) {
        if (ValidationUtils.isNetworkAvailable(this))
            presenter.getZoneSectSumryReportWise(
                regionCode,
                getReportNoFromChip(repType)
            )
        else CustomDialog().showNoInternetAlert(this, "")
    }

    private fun initializeTableView() {
        tableViewAdapter = ZoneSectTableAdapter(tableViewModel, callFromMode)
        tableView1.setAdapter(tableViewAdapter)
        tableView1.rowHeaderWidth = resources.getDimension(R.dimen.row_header_width).toInt()

        val myTableViewListener = ZoneSectTableViewListener(tableView1, callFromMode)
        tableView1.tableViewListener = myTableViewListener
    }

    override fun showError(errorMsg: String) {
        CustomDialog().showAlert(this, errorMsg)
    }

    override fun displayZoneSectrListSma0(smaList: List<ZoneSectorSum>) {
        if (smaList.isNotEmpty()) {
            this.tableInputList = smaList
        }
        tableViewAdapter.setUserList(tableInputList, callFromMode, isViewInLacs)
    }

    override fun displayZoneSumList(smaList: List<ZoneSummary>) {
    }

    @SuppressLint("SetTextI18n")
    private fun showBottomSheetDialog(regionCode: String) {
        val dialog = BottomSheetDialog(this)
        dialog.setContentView(R.layout.dialog_bottom_sheet_filters)

        val sortChipGrp = dialog.findViewById<ChipGroup>(R.id.sortChipGrp)
        val sortByTitle = dialog.findViewById<AppCompatTextView>(R.id.sortByTitle)
        sortByTitle?.text = resources.getString(R.string.amountIn)
        val reportChipGrp1 = dialog.findViewById<ChipGroup>(R.id.reportChipGrp1)
        reportChipGrp1?.visibility = View.GONE

        val reportChipGrp2 = dialog.findViewById<ChipGroup>(R.id.reportChipGrp2)
        reportChipGrp2?.visibility = View.VISIBLE

        val lacChip = dialog.findViewById<Chip>(R.id.firstSortChip)
        val crChip = dialog.findViewById<Chip>(R.id.secondSortChip)
        val thirdChip = dialog.findViewById<Chip>(R.id.thirdSortChip)
        thirdChip?.visibility = View.GONE

        val ptpDateChip = dialog.findViewById<Chip>(R.id.ptpDateChip)
        ptpDateChip?.visibility = View.GONE

        val fieldDivider2 = dialog.findViewById<View>(R.id.fieldDivider2)
        fieldDivider2?.visibility = View.GONE

        lacChip?.text = resources.getString(R.string.lacs)
        crChip?.text = resources.getString(R.string.crores)

        val mapFilterLL = dialog.findViewById<LinearLayoutCompat>(R.id.mapFilterLL)
        mapFilterLL?.visibility = View.GONE

        val applyBtn = dialog.findViewById<AppCompatButton>(R.id.applyBtn)
        reportChipGrp2?.isSelected = true
        reportChipGrp2?.setOnCheckedChangeListener { chipGroup, i ->
            selectedReport =
                reportChipGrp2.findViewById<Chip>(reportChipGrp2.checkedChipId).text.toString()

        }
        sortChipGrp?.setOnCheckedChangeListener { chipGroup, i ->
            selectedSortBy =
                sortChipGrp.findViewById<Chip>(sortChipGrp.checkedChipId).text.toString()
        }

        applyBtn?.setOnClickListener {

            rotationAngle = if (rotationAngle == 0) 180 else 0 //toggle
            expColapIV.animate().rotation(rotationAngle.toFloat()).setDuration(500)
                .start()
            setPositionSortNo(selectedSortBy)
            tableDataTitle.text = selectedReport
            figuresTitle.text = "Amount in $selectedSortBy"

            //callReportApi(regionCode, reportsShortArray[reportSpinner.selectedItemPosition])
            callReportApi(regionCode, selectedReport)
            dialog.dismiss()
        }

        dialog.show()
    }


    private fun setPositionSortNo(sortBy: String) {
        var reportPosition = 0
        when (sortBy) {
            "Lacs" -> {
                reportPosition = 0
                isViewInLacs = true
            }
            "Crores" -> {
                reportPosition = 1
                isViewInLacs = false
            }
        }
        // return reportPosition
    }

}