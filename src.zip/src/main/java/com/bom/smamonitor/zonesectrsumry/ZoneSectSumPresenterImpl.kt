package com.bom.smamonitor.zonesectrsumry

import android.util.Log
import com.androidnetworking.error.ANError
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.bzsummary.ZoneSummaryObj
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject


class ZoneSectSumPresenterImpl<V : ZoneSectSumMVPView, I : ZoneSectorSumMVPInteractor>
@Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) :
    BasePresenter<V, I>(
        interactor = interactor,
        schedulerProvider = schedulerProvider,
        compositeDisposable = disposable
    ),
    ZoneSectrSumMVPPresenter<V, I> {

    val TAG = "ZonSectsPrsImpl"


    override fun getZoneSectSumryReportWise(brCode: String, repType: String) {

        getView()?.showProgress()
        interactor?.let {
            it.getZoneSectSumryReportWise(brCode, repType)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ hoSectObj: HoSectObj ->
                    val listZoneSectSum = hoSectObj.listZoneSectorSum
                    getView()?.let { view ->
                        view.displayZoneSectrListSma0(listZoneSectSum)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("getZoneSectSumRepWis", aNError.message.toString())
                    getView()?.hideProgress()
                    val listZoneSectSum = listOf<ZoneSectorSum>()
                    getView()?.displayZoneSectrListSma0(listZoneSectSum)
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun getZoneSummaryBranchRepWise(brCode: String, isViewInLacs:Boolean) {

        getView()?.showProgress()
        interactor?.let {
            it.getZoneSummary(brCode,isViewInLacs)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ dataObj: ZoneSummaryObj ->
                    Log.d(TAG, "HoSectorObj Results:-$dataObj")
//                    val data = dataObj.data
//                    val bytes: ByteArray = data.toByteArray(Charsets.UTF_8)
//                    val decodedArray = Base64.getDecoder().decode(bytes)
//                    val decodedString = decodedArray.toString(StandardCharsets.UTF_8)
//                    val mapObj = Gson().fromJson(decodedString, ZoneSummaryObj::class.java)
//                    Log.d(TAG, ("Decoded Data: $decodedString"))

                    getView()?.let { view ->
                        view.displayZoneSumList(dataObj.listZoneSum)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("getZoneSuBrRepWise", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun getHoZoneSummaryReportWise(brCode: String, isViewInLacs:Boolean) {

        getView()?.showProgress()
        interactor?.let {
            it.getHoZoneSummary(brCode,isViewInLacs)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ dataObj: ZoneSummaryObj ->
                    getView()?.let { view ->
                        view.displayZoneSumList(dataObj.listZoneSum)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("getZoneSuRepWise", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

//    private fun decodeString(encoded: String): String? {
//        val dataDec: ByteArray = Base64.decode(encoded, Base64.DEFAULT)
//        var decodedString = ""
//        try {
////            decodedString = String(dataDec, "UTF-8")
//            decodedString= dataDec.toString()
//            val datasd = Base64.decode(encoded, Base64.DEFAULT)
//            val decoded = String(dataDec)
//            Log.d(TAG,("Decoded Data: $decoded")
//            val text = String(datasd, charset("UTF-8"))
//            Log.d(TAG,(decodedString)
//        } catch (e: UnsupportedEncodingException) {
//            e.printStackTrace()
//        } finally {
//            return decodedString
//        }
//    }


}