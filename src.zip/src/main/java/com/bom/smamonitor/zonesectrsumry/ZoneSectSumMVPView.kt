package com.bom.smamonitor.zonesectrsumry

import com.bom.smamonitor.base.view.BaseMVPView
import com.bom.smamonitor.bzsummary.ZoneSummary

interface ZoneSectSumMVPView :BaseMVPView{

    fun showError(errorMsg:String)
    fun displayZoneSectrListSma0(smaList: List<ZoneSectorSum>)
    fun displayZoneSumList(smaList: List<ZoneSummary>)

//    fun displayZoneSectrListSma0(rep6List:List<Rep6>)
//    fun displayZoneSectrListSma0(rep7List:List<Rep7>)
//    fun displayNpaFigures(npaFigures: List<NpaFigures>?): Unit?
//    fun displayTotalFigures(busiMetrics: List<BusiMetrics>?): Unit?
}