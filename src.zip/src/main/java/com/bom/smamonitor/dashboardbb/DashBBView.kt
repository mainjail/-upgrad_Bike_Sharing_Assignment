package com.bom.smamonitor.dashboardbb

import com.bom.smamonitor.base.view.BaseMVPView
import com.bom.smamonitor.bzsummary.ZoneSummary
import com.bom.smamonitor.dashboardbb.models.Announcement
import com.bom.smamonitor.dashboardbb.models.Rep6
import com.bom.smamonitor.dashboardbb.models.Rep7
import com.bom.smamonitor.dashboardbb.models.Sma012
import com.bom.smamonitor.login.AppUser

interface DashBBView : BaseMVPView {

    fun inflateUserDetails(userDetails: AppUser?)
    fun openLoginActivity()
   fun  openBranchesActivity()
    fun openRegionActivity()
    fun openContactUsActivity()
    fun displaySmaList(smaList: List<Sma012>)
    fun displayRep6List(rep6List:List<Rep6>)
    fun displayRep7List(rep7List:List<Rep7>)

    fun showError(errorMsg:String)
    fun callRep7Api()
    fun callRep6Api()
    fun displayTickerList(listZoneSum: List<ZoneSummary>)
    fun displayAnnouncement(listAnc: List<Announcement>)
    fun displaySmaSummaryMonthly(smaList: List<Sma012>)

//    fun goToAvgBusMixActivity()
//    fun goToProductsServiceActivity()
//    fun goToCalciActivity()
//    fun goToMISReportsActivity()
//    fun goToAlertsActivity()
//    fun goToTop100AcsActivity()
//    fun goToNPAMonitoringActivity()
}