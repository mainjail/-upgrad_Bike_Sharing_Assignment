package com.bom.smamonitor.dashboardbb.models

import com.google.gson.annotations.SerializedName


data class NotiModel(

    @SerializedName("Color")
    val color: Int,

    @SerializedName("Message")
    val message: String


)