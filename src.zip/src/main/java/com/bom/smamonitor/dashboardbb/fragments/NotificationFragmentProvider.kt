package com.bom.smamonitor.dashboardbb.fragments

import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class NotificationFragmentProvider {

    @ContributesAndroidInjector(modules = [NotiFragmentModule::class])
    internal abstract fun provideNotiFragment(): NotiFragment

}
