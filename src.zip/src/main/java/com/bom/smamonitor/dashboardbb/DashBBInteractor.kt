package com.bom.smamonitor.dashboardbb

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.bzsummary.ZoneSummaryObj
import com.bom.smamonitor.dashboardbb.models.Announcement
import com.bom.smamonitor.dashboardbb.models.Rep6Obj
import com.bom.smamonitor.dashboardbb.models.Rep7Obj
import com.bom.smamonitor.dashboardbb.models.Sma012Obj
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.network.EncryptDataObj
import io.reactivex.Observable

interface DashBBInteractor : MVPInteractor {

    //    fun getQuestionCardData(): Single<List<QuestionCardData>>
//    fun getUserDetails(): AppUser?
    fun getLoggedInMode(): Int
    fun getSummarySma(brCode: String, callFromMode: Int): Observable<Sma012Obj>
    fun getSummaryRep6(brCode: String, callFromMode: Int): Observable<Rep6Obj>
    fun getSummaryRep7(brCode: String, callFromMode: Int): Observable<Rep7Obj>
    fun getZoneSummary(brCode: String, isViewInLacs: Boolean): Observable<ZoneSummaryObj>
    fun getAnnouncement(): Observable<List<Announcement>>
    fun getSmaSummaryMonthly(brCode: String, callFromMode: Int): Observable<Sma012Obj>
     fun getHoZoneSummary(brCode: String, viewInLacs: Boolean):  Observable<ZoneSummaryObj>
fun getEncryptedText():Observable<EncryptDataObj>
    //fun getHoZoneSummary(brCode: String, repType: String):  Observable<ZoneSummaryObj>
//    fun getRegions(): Observable<List<Region>>
//    fun makeLogoutApiCall() : Observable<LogoutResponse>

}