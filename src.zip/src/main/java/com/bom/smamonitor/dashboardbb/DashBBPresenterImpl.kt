package com.bom.smamonitor.dashboardbb

import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.androidnetworking.error.ANError
import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.bzsummary.ZoneSummaryObj
import com.bom.smamonitor.dashboardbb.models.*
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.LoginResponse
import com.bom.smamonitor.network.AESCrypter
import com.bom.smamonitor.network.CryptoClass
import com.bom.smamonitor.network.EncryptDataObj
import com.bom.smamonitor.network.retrofitApi.SmaDashApiReceiver
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.UnsupportedEncodingException
import java.nio.charset.StandardCharsets
import java.security.InvalidAlgorithmParameterException
import java.security.InvalidKeyException
import java.security.NoSuchAlgorithmException
import java.sql.DriverManager.println
import java.util.*
import javax.crypto.BadPaddingException
import javax.crypto.IllegalBlockSizeException
import javax.crypto.NoSuchPaddingException
import javax.crypto.ShortBufferException
import javax.inject.Inject

class DashBBPresenterImpl<V : DashBBView, I : DashBBInteractor>
@Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) :
    BasePresenter<V, I>(
        interactor = interactor,
        schedulerProvider = schedulerProvider,
        compositeDisposable = disposable
    ),
    DashBBPresenter<V, I> {


    private val TAG="DashBBPrsImpl"
    override fun refreshCards(): Boolean? {
        // TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        return true
    }

    override fun onDrawerOptionHomeClick() = getView()?.openLoginActivity()

    override fun onDrawerOptionCategoriesClick() = getView()?.openContactUsActivity()

    override fun onAttach(view: V?) {
        super.onAttach(view)
    }

    override fun onDrawerOptionLogoutClick() {
        interactor?.performUserLogout()
    }

    private fun getUserData() = interactor?.let {
        Log.d(TAG,"getuserdata from prefs")
        val userData = it.getUserFromSharedPref()
        getView()?.inflateUserDetails(userData)
    }

    override fun performUserLogout() {
        getView()?.showProgress()
        interactor?.performUserLogout() //    private fun logOutUserInSharedPrefs() = interactor?.performUserLogout()
        getView()?.hideProgress()
        getView()?.openLoginActivity()
    }

    override fun getLoggedInMode(): Int = interactor?.getLoggedInMode()!!

    override fun onViewPrepared() {
        getUserData()
    }

    override fun getSummarySma(brCode: String, callFromMode: Int) {

        getView()?.showProgress()
        interactor?.let {
            it.getSummarySma(brCode, callFromMode)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ smaObj: Sma012Obj ->
                    val smaList = smaObj.smalist
                    Log.d(TAG, "getSummarySma :$smaList")

                    getView()?.let { view ->
                        view.displaySmaList(smaList)
                        view.hideProgress()
                    }

                }, { error ->
                    val aNError = error as ANError
                    Log.d(TAG,"GetSMA Error :"+ aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                    getView()?.callRep7Api()
                })
        }
    }


    override fun getSummaryRep6(brCode: String, callFromMode: Int) {

        getView()?.showProgress()
        interactor?.let {
            it.getSummaryRep6(brCode, callFromMode)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ rep6Obj: Rep6Obj ->
                    val rep6List = rep6Obj.rep6List
                    Log.d(TAG,"Rep6 Summary Results:-$rep6Obj")
                    Log.d(TAG,"Rep6 Summary Results:-$rep6List")

                    getView()?.let { view ->
                        view.displayRep6List(rep6List)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("getSummaryRep6 Error:", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }


    override fun getSummaryRep7(brCode: String, callFromMode: Int) {

        getView()?.showProgress()
        interactor?.let {
            it.getSummaryRep7(brCode, callFromMode)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ rep7Obj: Rep7Obj ->
                    val rep7List = rep7Obj.rep7List
                    Log.d(TAG,"rep7 list Summary Results:-$rep7Obj")
                    Log.d(TAG,"rep 7 Summary Results:-$rep7List")

                    getView()?.let { view ->
                        view.displayRep7List(rep7List)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d(TAG,"getSummaryRep7 Error:"+ aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.callRep6Api()

                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun getZoneSummaryBranchRepWise(brCode: String, isViewInLacs: Boolean) {

        getView()?.showProgress()
        interactor?.let {
            it.getZoneSummary(brCode, isViewInLacs)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ dataObj: ZoneSummaryObj ->
                    Log.d(TAG, "HoSectorObj Results:-$dataObj")

                    getView()?.let { view ->
                        view.displayTickerList(dataObj.listZoneSum)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("getZoneSuBrRepWise", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun getHoSummaryZoneReportWise(brCode: String, isViewInLacs: Boolean) {

        getView()?.showProgress()
        interactor?.let {
            it.getHoZoneSummary(brCode, isViewInLacs)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ dataObj: ZoneSummaryObj ->
                    Log.d(TAG, "HoSectorObj Results:-$dataObj")

                    getView()?.let { view ->
                        view.displayTickerList(dataObj.listZoneSum)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d(TAG,"getZoneSuBrRepWise "+ aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun getAnnouncement() {
        getView()?.showProgress()
        interactor?.let {
            it.getAnnouncement()
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ listAnc: List<Announcement> ->
                   Log.d(TAG,"Announcement Results:-$listAnc")
                    getView()?.let { view ->
                        view.displayAnnouncement(listAnc)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d(TAG,"Announcement Error :"+ aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                    getView()?.callRep7Api()
                })
        }
    }

    override fun getSmaSummaryMonthly(brCode: String, callFromMode: Int) {

        getView()?.showProgress()
        interactor?.let {
            it.getSmaSummaryMonthly(brCode, callFromMode)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ smaObj: Sma012Obj ->
                    val smaList = smaObj.smalist
                    println("getSmaSummaryMonthly:-$smaObj")

                    getView()?.let { view ->
                        view.displaySmaSummaryMonthly(smaList)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("GetSMA Error :", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                    getView()?.callRep7Api()
                })
        }
    }

    override fun addAnnouncement(announcement: Announcement) {

        getView()?.showProgress()
        val retriever = SmaDashApiReceiver()
        val callBack = object : Callback<LoginResponse> {

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                getView()?.hideProgress()
                getView()?.showError(t.localizedMessage.toString())
                Log.d("DashPrsIml", t.localizedMessage.toString())
            }

            override fun onResponse(
                call: Call<LoginResponse>,
                response: Response<LoginResponse>
            ) {
                Log.d(
                    "DashPrsIml",
                    "Success ${response.body()},${response.code()}, " +
                            "${response.errorBody()}"
                )
                response.isSuccessful.let {
                    kotlin.io.println(" Response:- $response")
                    val res: LoginResponse = response.body()!!
                    kotlin.io.println("List.size:-${res}")
                    getView()?.hideProgress()
                    if (response.body().toString().isNotEmpty())
                        if (response.body().toString().contains("Not Found")) {
                            getView()?.showError(response.body().toString())
                        } else {
                            getView()?.showError("Announcement published successfully.")
                        }
                    else
                        getView()?.showError("Announcement publishing failed.")
                }
            }
        }
        retriever.addAnnouncementRetrofit(announcement, callBack)

    }


    override fun saveUserLog(appUser: AppUser) {


        //val loggedInRole = checkUserPosting(appUser.curBranch.toString().toInt())
       // kotlin.io.println("loggedInRole:-${loggedInRole}")

        getView()?.showProgress()
        val retriever = SmaDashApiReceiver()
        val callBack = object : Callback<LoginResponse> {
            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                getView()?.hideProgress()
                Log.d(TAG, t.localizedMessage.toString())
                Log.d(TAG, t.message.toString())
                getView()?.showError("Network Error for user. Please retry login.")
            }

            override fun onResponse(
                call: Call<LoginResponse>,
                response: Response<LoginResponse>
            ) {
                response.isSuccessful.let {


                    Log.d(TAG, "AddUserLog response: $response")
                    Log.i(TAG, "AddUserLog Results:-${response.body().toString()}")
                    try {
                        when {
                            response.body().toString().contains("Please fill all the details") -> {
                                getView()?.showError(response.message().toString())
                            }
                            response.body().toString().contains("Not Found") -> {
                                getView()?.showError(response.message().toString())
                            }
                            response.message().toString().contains("Internal Server Error") -> {
                                 getView()?.showError(response.message().toString())
                                Log.d(TAG, "AddUserLog response: "+response.message().toString())
                               // updateUserInSharedPref(appUser, loggedInRole)
                               // getView()?.goToPinLockActivity()
                            }
                            else -> {
                                Log.d(TAG, "AddUserLog response: "+response.message().toString())
                                Log.d(TAG,"AddUserLog Sent successfully. ")
                               // getView()?.showError("Data Displayed")

                                //  updateUserInSharedPref(appUser, loggedInRole)
                               // getView()?.goToPinLockActivity()
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, e.toString())
                        getView()?.showError("Error saving user.")
                        e.printStackTrace()
                    }
                    getView()?.hideProgress()

                }
            }
        }
        retriever.addSmaUserRetroService2(appUser, callBack)
    }



    @RequiresApi(Build.VERSION_CODES.O)
    override fun getEncryptedText() {
        println("getEncryptedText:-Api Called")

        getView()?.showProgress()
        interactor?.let {
            it.getEncryptedText()
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ encryObj: EncryptDataObj ->
                    Log.d("DashPrsnter", "getEncryptedText:-${encryObj.data}")
                    println("getEncryptedText:-${encryObj.data}")
                    val data = encryObj.data
                    try{
                    val dec: String = CryptoClass.decryptFromHex(data)!!
                    Log.d("DashPrsnter","Input Text     : $data")
                    Log.d("DashPrsnter","Decrypted Text : $dec")
                        getView()?.showError(dec.toString())
//                    val bytes: ByteArray = data.toByteArray(Charsets.UTF_8)
//                    val decodedArray = Base64.getDecoder().decode(bytes)
//                    val decodedString = decodedArray.toString(StandardCharsets.UTF_8)
                    // val mapObj = Gson().fromJson(decodedString, ZoneSummaryObj::class.java)

                    } catch (e: InvalidAlgorithmParameterException) {
                        Log.e("DashPresImpl", "Exception " + e.stackTrace);
                    } catch (uee: UnsupportedEncodingException) {
                        uee.printStackTrace()
                    } catch (ibse: IllegalBlockSizeException) {
                        ibse.printStackTrace()
                    } catch (bpe: BadPaddingException) {
                        bpe.printStackTrace()
                    } catch (ike: InvalidKeyException) {
                        ike.printStackTrace()
                    } catch (nspe: NoSuchPaddingException) {
                        nspe.printStackTrace()
                    } catch (nsae: NoSuchAlgorithmException) {
                        nsae.printStackTrace()
                    } catch (e: ShortBufferException) {
                        e.printStackTrace()
                    } catch (e: Exception) {
                        Log.e("DashPresImpl", e.stackTrace.toString());
                    }

                    getView()?.let { view ->
                        println("getEncryptedText:-$encryObj")
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("DashPrsImpl", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                    getView()?.callRep7Api()
                })
        }
    }

}