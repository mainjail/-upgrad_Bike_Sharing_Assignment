package com.bom.smamonitor.dashboardbb

import com.bom.smamonitor.base.presenter.MVPPresenter
import com.bom.smamonitor.dashboardbb.models.Announcement
import com.bom.smamonitor.login.AppUser

interface DashBBPresenter<V : DashBBView, I : DashBBInteractor> : MVPPresenter<V, I> {

    fun refreshCards(): Boolean?
    fun onDrawerOptionHomeClick(): Unit?
    fun onDrawerOptionCategoriesClick(): Unit?

    //    fun onDrawerOptionProfileClick(): Unit?
    fun onDrawerOptionLogoutClick()
    fun performUserLogout()
    fun getLoggedInMode(): Int
    fun onViewPrepared()
    fun getEncryptedText()

    fun getSummarySma(brCode: String, callFromMode: Int)
    fun getSummaryRep6(brCode: String, callFromMode: Int)
    fun getSummaryRep7(brCode: String, callFromMode: Int)

//    fun onDrawerOptionShareClick()
//    fun onDrawerOptionContactUsClick(): Unit?

//    fun onDrawerOptionPrivacyClick()
//    fun onDrawerOptionBLCCClick()

    fun getHoSummaryZoneReportWise(brCode: String, isViewInLacs: Boolean)
    fun getZoneSummaryBranchRepWise(brCode: String, isViewInLacs: Boolean)
    fun getSmaSummaryMonthly(brCode: String, callFromMode: Int)
    fun getAnnouncement()
    fun addAnnouncement(announcement: Announcement)
    fun saveUserLog(user: AppUser)
}