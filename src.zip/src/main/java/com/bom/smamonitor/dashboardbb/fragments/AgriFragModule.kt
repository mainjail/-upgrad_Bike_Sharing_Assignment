package com.bom.smamonitor.dashboardbb.fragments

import dagger.Module
import dagger.Provides


@Module
class AgriFragModule {

    @Provides
    internal fun provideAgriInteractor(interactor: AgriDashbInteractorImpl): AgriDashbMVPInteractor =
        interactor

    @Provides
    internal fun provideAgriPresenter(presenter: AgriDashbPresenterImpl<AgriDashbMVPView, AgriDashbMVPInteractor>)
            : AgridDashbMVPPresenter<AgriDashbMVPView, AgriDashbMVPInteractor> = presenter


//    @Provides
//    internal fun provideAdapter(): SmaSummaryAdapter = SmaSummaryAdapter()
//    @Provides
//    internal fun provideRep6Adapter(): Rep6SummaryAdapter = Rep6SummaryAdapter()
//    @Provides
//    internal fun provideRep7Adapter(): Rep7SummaryAdapter = Rep7SummaryAdapter()
//    @Provides
//    internal fun provideTickerAdapter(): TickerTvAdapter = TickerTvAdapter()
//
//    @Provides
//    internal fun provideLinearLayoutManager(fragment: HomeFragment): LinearLayoutManager =
//        LinearLayoutManager(fragment.activity)

}