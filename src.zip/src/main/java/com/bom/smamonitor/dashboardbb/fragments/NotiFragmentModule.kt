package com.bom.smamonitor.dashboardbb.fragments

import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.dashboardbb.NotificationAdapter
import com.bom.smamonitor.npa.*
import dagger.Module
import dagger.Provides

@Module
class NotiFragmentModule {


    @Provides
    internal fun provideNpaInteractor(interactor: NpaCustInteractorImpl): NpaCustomersMVPInteractor =
        interactor

    @Provides
    internal fun provideNpaPresenter(presenter: NpaCustPresenterImpl<NpaCustomersMVPView, NpaCustomersMVPInteractor>)
            : NpaCustomersMVPPresenter<NpaCustomersMVPView, NpaCustomersMVPInteractor> = presenter

    @Provides
    internal fun provideAdapter(fragment:NotiFragment): NotificationAdapter = NotificationAdapter(fragment.activity)

    @Provides
    internal fun provideLinearLayoutManagerFragment(fragment: NotiFragment):
            LinearLayoutManager = LinearLayoutManager(fragment.activity)


}
