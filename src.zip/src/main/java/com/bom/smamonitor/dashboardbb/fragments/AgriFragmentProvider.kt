package com.bom.smamonitor.dashboardbb.fragments

import dagger.Module
import dagger.android.ContributesAndroidInjector


@Module
abstract class AgriFragmentProvider{

    @ContributesAndroidInjector(modules = [AgriFragModule::class])
    internal abstract fun provideAgriFragment() : AgriDashbFragment
}