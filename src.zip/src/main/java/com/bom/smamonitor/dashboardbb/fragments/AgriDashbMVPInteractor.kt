package com.bom.smamonitor.dashboardbb.fragments

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.bzsummary.EncDataObj
import com.bom.smamonitor.custlist.model.MapCustomerList
import com.bom.smamonitor.dashboardbb.models.AgriObj
import com.bom.smamonitor.dashboardbb.models.NotiObj
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import io.reactivex.Observable

interface AgriDashbMVPInteractor : MVPInteractor {


    fun getAgriDashb(): Observable<List<AgriObj>>


    fun getLoggedInMode() : Int
    //fun getNearbySmaCustList(address:String): Observable<MapCustomerList>
}