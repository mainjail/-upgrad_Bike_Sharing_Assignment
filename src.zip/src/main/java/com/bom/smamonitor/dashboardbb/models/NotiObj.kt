package com.bom.smamonitor.dashboardbb.models

import com.google.gson.annotations.SerializedName

data class NotiObj(

//{ "SMA1SumBalance": [
//    { "SMA1SumBalance": "606937772.93" } ],
//    "SMA2SumBalance": [
//    { "SMA2SumBalance": "-959912104.36" } ],
//    "ProbableNPANext7": [
//    { "ProbableNPACount": "5769", "SumBalance": "3109504801.32" } ],
//    "Slippages": [
//    { "NPACount": "549", "SumBalance": "15.220179" } ],
//    "NPA": [
//    { "NPACount": "13274", "SumBalance": "278.30" } ],
//    "NonFinNext7": [
//    { "NPACount": "2207", "SumBalance": "97.013960" } ]
//}

@SerializedName("SMA1SumBalance")
val sma1SumbalanceList: List<SMA1SumBalance>,

@SerializedName("SMA2SumBalance")
val sma2SumBalanceList: List<SMA2SumBalance>,

@SerializedName("ProbableNPANext7")
val probableNext7List: List<ProbableNPANext7>,

@SerializedName("Slippages")
val slippageList: List<NPA>,

@SerializedName("NPA")
val npaList: List<NPA>,

@SerializedName("NonFinNext7")
val nonFinNext7List: List<NPA>,
)

data class SMA1SumBalance(
    @SerializedName("SMA1SumBalance")
    val sma1SumBalance: String?
)

data class SMA2SumBalance(
    @SerializedName("SMA2SumBalance")
    val sma2SumBalance: String?
)

data class ProbableNPANext7(
    @SerializedName("ProbableNPACount")
    val probableNpaCount: String,
    @SerializedName("SumBalance")
    val sumBalance: String?
)


data class NPA(
    @SerializedName("NPACount")
    val probableNpaCount: String,
    @SerializedName("SumBalance")
    val sumBalance: String?
)
