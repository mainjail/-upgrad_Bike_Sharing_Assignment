package com.bom.smamonitor.dashboardbb.fragments

import android.util.Log
import com.androidnetworking.error.ANError
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.dashboardbb.models.AgriObj
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

class AgriDashbPresenterImpl <V : AgriDashbMVPView, I : AgriDashbMVPInteractor>
@Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) :
    BasePresenter<V, I>(
        interactor = interactor,
        schedulerProvider = schedulerProvider,
        compositeDisposable = disposable
    ),
    AgridDashbMVPPresenter<V, I> {

    val TAG = "AgriPrsntImpl"





    private fun getUserData() = interactor?.let {
        Log.d(TAG, "getUserdata from prefs NotiFrag")
        val userData = it.getUserFromSharedPref()
        getView()?.inflateUserDetails(userData)

    }

    override fun getLoggedInMode(): Int = interactor?.getLoggedInMode()!!
    override fun onViewPrepared() {
        getUserData()
    }



    override fun getAgriDashb() {
        getView()?.showProgress()
        interactor?.let {
            it.getAgriDashb( )
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ agriObjsList:List<AgriObj> ->
                  Log.d(TAG,"getAgriDashb : "+agriObjsList.count())

                    getView()?.let { view ->
                        view.displayResultsFromApi(agriObjsList)
                        view.hideProgress()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("GetSMA Error :", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())

                })
        }
    }

}