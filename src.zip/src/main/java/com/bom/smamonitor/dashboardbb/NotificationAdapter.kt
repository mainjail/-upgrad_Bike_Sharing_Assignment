package com.bom.smamonitor.dashboardbb

import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.dashboardbb.models.NotiModel
import kotlinx.android.synthetic.main.item_notification.view.*

class NotificationAdapter(activity: FragmentActivity?) :    RecyclerView.Adapter<NotificationAdapter.NotifViewHolder>() {

    private var list = ArrayList<NotiModel>()
    private var activity = activity

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotifViewHolder {
        return NotifViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_notification, parent, false
            )
        )
    }

    override fun getItemCount(): Int = list.size

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onBindViewHolder(holder: NotifViewHolder, position: Int) {
        holder.setIsRecyclable(false)
        holder.itemView.animation =
            AnimationUtils.loadAnimation(holder.itemView.context, R.anim.translate)
        holder.onBind(position)
    }

    internal fun setNotifications(notifications: List<NotiModel>) {
        this.list = notifications as ArrayList<NotiModel>
        notifyDataSetChanged()
    }

    inner class NotifViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        @RequiresApi(Build.VERSION_CODES.M)
        fun onBind(position: Int) {
            try {
                val notiModel = list[position]
                itemView.notifMsgTv.text = notiModel.message
                itemView.closeIv.setOnClickListener {
                    list.remove(list[position])
                    notifyItemRemoved(position)
                    notifyDataSetChanged()
                }
//                  Color Codes Red=0,Green=1, Orange=2, Other=3
                when (notiModel.color) {

                    0 -> {
                        itemView.notifContLL.NotiItemIV.setImageResource(R.drawable.ic_sad_emoji)
                        itemView.notifContLL.closeIv.setColorFilter(activity?.getColor(R.color.dark_red)!!)
                        itemView.notifContLL.background = activity?.getDrawable(R.drawable.rounded_rect_red)
                    }

                    1 -> {
                        itemView.notifContLL.NotiItemIV.setImageResource(R.drawable.ic_happy)
                        itemView.notifContLL.closeIv.setColorFilter(activity?.getColor(R.color.dark_green)!!)
                        itemView.notifContLL.background = activity?.getDrawable(R.drawable.rounded_rect_green)
                    }
                    2 -> {
                        itemView.notifContLL.NotiItemIV.setImageResource(android.R.drawable.ic_dialog_alert)
                        itemView.notifContLL.NotiItemIV.setColorFilter(activity?.getColor(R.color.dark_orange)!!)
                        itemView.notifContLL.closeIv.setColorFilter(activity?.getColor(R.color.dark_orange)!!)
                        itemView.notifContLL.background = activity?.getDrawable(R.drawable.rounded_rect_orange)
                    }
                    else -> {
                        itemView.notifContLL.NotiItemIV.setImageResource(android.R.drawable.ic_dialog_alert)
                        itemView.notifContLL.NotiItemIV.setColorFilter(activity?.getColor(R.color.dark_orange)!!)
                        itemView.notifContLL.closeIv.setColorFilter(activity?.getColor(R.color.dark_orange)!!)
                        itemView.notifContLL.background = activity?.getDrawable(R.drawable.rounded_rect_orange)
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


}