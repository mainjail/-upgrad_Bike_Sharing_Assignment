package com.bom.smamonitor.dashboardbb.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseFragment
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.customViews.RVEmptyObserver
import com.bom.smamonitor.dashboardbb.NotificationAdapter
import com.bom.smamonitor.dashboardbb.models.NotiModel
import com.bom.smamonitor.dashboardbb.models.NotiObj
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.npa.NpaCustomersMVPInteractor
import com.bom.smamonitor.npa.NpaCustomersMVPPresenter
import com.bom.smamonitor.npa.NpaCustomersMVPView
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import kotlinx.android.synthetic.main.fragment_gallery.*
import kotlinx.android.synthetic.main.fragment_search.*
import kotlinx.android.synthetic.main.fragment_search.emptyListsMsgTv
import java.math.RoundingMode
import java.text.DecimalFormat
import javax.inject.Inject
import kotlin.Exception

class NotiFragment : BaseFragment(), NpaCustomersMVPView {

    @Inject
    internal lateinit var notificationAdapter: NotificationAdapter

    @Inject
    internal lateinit var layoutManager: LinearLayoutManager

    @Inject
    internal lateinit var presenter: NpaCustomersMVPPresenter<NpaCustomersMVPView, NpaCustomersMVPInteractor>

    private lateinit var user: AppUser
    private var userBranch = "9999"
    private var userRegCode = "99"
    private var loggedInMode = 0
    private val TAG = "NotiFrag"


    companion object {
        fun newInstance(): NotiFragment {
            return NotiFragment()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(false)
        activity?.title = resources.getString(R.string.Notifications)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_gallery, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun setUp() {
        activity?.title = resources.getString(R.string.Notifications)
        presenter.onViewPrepared()

        layoutManager.orientation = LinearLayoutManager.VERTICAL
        notificationRV.layoutManager = layoutManager
        notificationRV.itemAnimator = DefaultItemAnimator()
        notificationRV.adapter = notificationAdapter
        val emptyRvObserver =
            RVEmptyObserver(emptyView = emptyListsMsgTv, recyclerView = notificationRV)
        notificationAdapter.registerAdapterDataObserver(emptyRvObserver)

        callNotifications()

    }

    override fun inflateUserDetails(userDetails: AppUser?) {
        user = userDetails!!
        Log.d(
            TAG, "User Details:{ ${user.pfNo}  ${user.name?.trim()} and Branch: ${user.curBranch}}"
        )
        Log.d(TAG, "User Pf:${user.pfNo}")
        Log.d(TAG, "User Name:  ${user.name?.trim()} and Branch: ${user.curBranch}")
        userBranch = user.curBranch.toString()
        Log.d(TAG, "User Notification token:${user.notificationId}")

        loggedInMode = presenter.getLoggedInMode()
        Log.d(TAG, "User LoggedInMode = $loggedInMode")
        Log.d(TAG, "User regCode = " + user.regionCode)
        userRegCode = user.regionCode.toString()
        callNotifications()
    }

    private fun checkUserRole(loggedInMode: Int): String {
        var branchCode = "9999"
        when (loggedInMode) {
            3 -> branchCode = "9999"
            // 2 -> branchCode = userBranch
            2 -> branchCode = user.regionCode.toString() //Zone
            1 -> branchCode = userBranch
        }
        return branchCode
    }

    override fun onResume() {
        super.onResume()
        // callNotifications()
    }

    private fun callNotifications() {
        loggedInMode = presenter.getLoggedInMode()

        if (ValidationUtils.isNetworkAvailable(requireContext())) {
            val brCodeForAPiCall = checkUserRole(loggedInMode)
            presenter.getNotification(brCodeForAPiCall, loggedInMode)
        } else CustomDialog().showNoInternetAlert(requireActivity(), "")
    }

    private fun formatRoundUp(num: Double): String? {
        return String.format("%.02f", num)
    }

    override fun showError(errorMsg: String) {
        Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show()
    }

    override fun displayResultsFromApi(customers: List<NpaCustomer>?): Unit? {
        TODO("Not yet implemented")
    }

    override fun displayCustListFromApi(customers: List<CustomerRep2>?): Unit? {
        TODO("Not yet implemented")
    }

    override fun displayNotis(notiObj: NotiObj) {

        try {

            val notificationsList = ArrayList<NotiModel>()
            //                  Color Codes Red=0,Green=1, Orange=2, Other=3
// NPA in NExt 7 Days object
            var probableNext7Bal = "0.0"
            if (notiObj.probableNext7List[0].sumBalance != null) {
                probableNext7Bal =
                    toCrores(notiObj.probableNext7List[0].sumBalance?.toDouble() ?: 0.0).toString()
            }
            val notiModel3 =
                NotiModel(
                    2,
                    "Alert !! ${notiObj.probableNext7List[0].probableNpaCount}" +
                            " accounts amounting to Rs.${probableNext7Bal} " +
                            "Crores to be stamped as NPA in next 7 days."
                )
//Npa Stamped obj
            var slipageBal = "0.0"
            if (notiObj.slippageList[0].sumBalance != null) {
                slipageBal =
                    formatRoundUp(notiObj.slippageList[0].sumBalance?.toDouble() ?: 0.0).toString()
            }
            val notiModel4 =
                NotiModel(
                    0,
                    "Ohh!! ${notiObj.slippageList[0].probableNpaCount} accounts amounting to Rs. " +
                            "$slipageBal Crores stamped as NPA yesterday.  "
                )
////second obj
            var nonFinNext7ListBal = "0.0"
            if (notiObj.nonFinNext7List[0].sumBalance != null) {
                nonFinNext7ListBal =
                    formatRoundUp(notiObj.nonFinNext7List[0].sumBalance?.toDouble()!!).toString()
            }
            val notiModel5 =
                NotiModel(
                    2,
                    "Alert !! ${notiObj.nonFinNext7List[0].probableNpaCount} accounts amounting to " +
                            "Rs.${nonFinNext7ListBal} " + " Crores to be stamped as NPA due to Non-Financial reasons in next 7 days."
                )

            //// Noti model1 SMA2 Balance
            var sma2SumBalanceToCr = "0.0"
            var sma2SumBalance = 0.0
            if (notiObj.sma2SumBalanceList[0].sma2SumBalance != null) {
                sma2SumBalance = notiObj.sma2SumBalanceList[0].sma2SumBalance?.toDouble() ?: 0.0
                sma2SumBalanceToCr =
                    toCrores(sma2SumBalance).toString()
            }
            val notiModel1 = if (sma2SumBalance < 0)
                NotiModel(
                    1,
                    "Congratulations!! Your SMA2 has decreased by Rs.${sma2SumBalanceToCr} Crores."
                )
            else
                NotiModel(
                    0,
                    "Ohh!!  Your SMA2 has increased by Rs.${sma2SumBalanceToCr} Crores."
                )

            //// Noti model1 SMA2 Balance
            var sma1SumBalanceToCr = "0.0"
            var sma1SumBalance = 0.0

            if (notiObj.sma1SumbalanceList[0].sma1SumBalance != null) {
                sma1SumBalance = notiObj.sma1SumbalanceList[0].sma1SumBalance?.toDouble() ?: 0.0
                sma1SumBalanceToCr =
                    toCrores(sma1SumBalance).toString()
            }
            val notiModel2 = if (sma1SumBalance < 0)
                NotiModel(
                    1,
                    "Congratulations!!  Your SMA1 has decreased by Rs.${sma1SumBalanceToCr} Crores."
                )
            else
                NotiModel(
                    0,
                    " Ohh!! Your SMA1 has increased by Rs.${sma1SumBalanceToCr} Crores."
                )

            notificationsList.add(notiModel1)
            notificationsList.add(notiModel2)
            notificationsList.add(notiModel3)
            notificationsList.add(notiModel4)
            notificationsList.add(notiModel5)
            notificationAdapter.setNotifications(notificationsList)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun showLoading() {
        searchProBar.visibility = View.VISIBLE
    }

    override fun hideLoading() {
        searchProBar.visibility = View.GONE
    }

    override fun initToolbar() {

    }

    private fun toLacs(num: Double): String? {
        var num = num
        val df = DecimalFormat("#.##")
        df.roundingMode = RoundingMode.DOWN
        try {
            num /= 100000 // in lac
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return df.format(num)
    }

    private fun toCrores(num: Double): String? {
        var num = num
        val df = DecimalFormat("#.##")
        df.roundingMode = RoundingMode.DOWN
        try {
            num /= 10000000 // in crores
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return df.format(num)
    }

}