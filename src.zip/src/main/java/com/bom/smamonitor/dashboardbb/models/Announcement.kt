package com.bom.smamonitor.dashboardbb.models

import com.google.gson.annotations.SerializedName

data class Announcement (
//    { "id": 299,
//        "notification": "All Branches/Zones are requested to ensure upgradation of high value accounts Rs25L and above slipped from 01-04-2022- GM CRO Cremon IRM",
//        "Createddate": "2022-04-22" }

    @SerializedName("Id")
    val id: String,

    @SerializedName("AnnContent")
    val annContent: String,

    @SerializedName("AddedBy")
    val addedBy: String,

    @SerializedName("AddedOn")
    val addedOn: String

)