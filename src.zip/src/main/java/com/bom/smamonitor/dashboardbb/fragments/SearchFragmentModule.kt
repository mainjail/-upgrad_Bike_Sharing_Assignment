package com.bom.smamonitor.dashboardbb.fragments

import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.npa.*
import dagger.Module
import dagger.Provides

@Module
class SearchFragmentModule {


        @Provides
        internal fun provideNpaInteractor(interactor: NpaCustInteractorImpl): NpaCustomersMVPInteractor = interactor

        @Provides
        internal fun provideNpaPresenter(presenter: NpaCustPresenterImpl<NpaCustomersMVPView, NpaCustomersMVPInteractor>)
                : NpaCustomersMVPPresenter<NpaCustomersMVPView, NpaCustomersMVPInteractor> = presenter

        @Provides
        internal fun provideAdapter(): NpaCustAdapter = NpaCustAdapter()

        @Provides
        internal fun provideLinearLayoutManagerFragment(fragment: SearchFragment):
                LinearLayoutManager = LinearLayoutManager(fragment.activity)


    }
