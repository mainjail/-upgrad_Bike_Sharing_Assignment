package com.bom.smamonitor.dashboardbb.models

import com.google.gson.annotations.SerializedName


data class Sma012(

//    SECTOR	:	RETAIL
//    SMA0_BALANCE	:	4883.210644
//    SMA1_BALANCE	:	1632.188703
//    SMA2_BALANCE	:	540.599174
//    BALANCE_1	:	7055.998521
//    VARIATION	:	-7.096148

    @SerializedName("SECTOR")
    val sector: String,

    @SerializedName("SMA0_BALANCE")
    val sma0bal: Double,

    @SerializedName("SMA1_BALANCE")
    val sma1bal: Double,

    @SerializedName("SMA2_BALANCE")
    val sma2bal: Double,

    @SerializedName("BALANCE_1")
    val total: Double,

    @SerializedName("VARIATION")
    val variation: Double,

    )

data class Sma012Obj(
    // SMA012
    @SerializedName("SMA012")
    val smalist: List<Sma012>
)
