package com.bom.smamonitor.dashboardbb

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.dashboardbb.models.Rep6
import com.bom.smamonitor.util.CommonUtil.roundUpto2Decimal
import kotlinx.android.synthetic.main.item_rep6.view.*
import java.util.*

class Rep6SummaryAdapter : RecyclerView.Adapter<Rep6SummaryAdapter.ChildRep6ViewHolder>() {

    private var list = listOf<Rep6>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildRep6ViewHolder {
        return ChildRep6ViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_rep6, parent, false
            )
        )
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ChildRep6ViewHolder, position: Int) {
        holder.setIsRecyclable(false);
        holder.onBind(position)
    }

    internal fun setRep6List(rep6List: List<Rep6>) {
        this.list = rep6List
        notifyDataSetChanged()
    }

    inner class ChildRep6ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        @SuppressLint("SetTextI18n")
        fun onBind(position: Int) {
            try {
                val rep6 = list[position]
                itemView.sectorTv.text = rep6.sector?.toUpperCase(Locale.getDefault())
                itemView.lastDayTV.text = roundUpto2Decimal(rep6.lastDayBal?.toString().toDouble())
                itemView.todayTV.text = roundUpto2Decimal(rep6.todayBal?.toString().toDouble())
                itemView.variationRep6TV.text =
                    roundUpto2Decimal(rep6.variation?.toString().toDouble())

                itemView.lastDayTV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.todayTV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.variationRep6TV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;

                itemView.lastDayTV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )
                itemView.todayTV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )



                if ((rep6.variation < 0)) {
                    itemView.variationRep6TV.setBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.light_green
                        )
                    )

                    itemView.variationRep6TV.setTextColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.dark_green
                        )
                    )
                } else {
                    itemView.variationRep6TV.setTextColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.dark_red
                        )
                    )
                    itemView.variationRep6TV.setBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.light_red
                        )
                    )
                }

                if (rep6.sector.equals("VARIATION", true)) {
                    if (rep6.lastDayBal < 0) {
                        itemView.lastDayTV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.lastDayTV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    } else {
                        itemView.lastDayTV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.lastDayTV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }
                    if (rep6.todayBal < 0) {
                        itemView.todayTV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.todayTV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    } else {
                        itemView.todayTV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.todayTV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }
                    itemView.variationRep6TV.text = ""
                    itemView.variationRep6TV.setBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.bg_card_color
                        )
                    )

                }


            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


}