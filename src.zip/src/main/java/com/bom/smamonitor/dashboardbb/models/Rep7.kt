package com.bom.smamonitor.dashboardbb.models

import com.google.gson.annotations.SerializedName

data class Rep7(
//    Sector	:	AGRI
//    	:	188.51521
//	:	9.88192
//	:	59.873461
//	:	81.135127

    @SerializedName("SECTOR")
    val sector: String,

    @SerializedName("7F")
    val sevenF: Double,

    @SerializedName("7NF")
    val sevenNf    : Double,

    @SerializedName("7D")
    val sevenD: Double,

    @SerializedName("7A")
    val sevenA: Double,

    @SerializedName("TOTAL")
    val total: Double,

    @SerializedName("VARIATION")
    val variation: Double

    )

data class Rep7Obj(
    @SerializedName("REP7")
    val rep7List: List<Rep7>
)