package com.bom.smamonitor.dashboardbb

import android.content.Context
import android.content.Intent
import android.content.IntentSender.SendIntentException
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.bom.smamonitor.R
import com.bom.smamonitor.aboutapp.AboutAppActivity
import com.bom.smamonitor.base.view.BaseFragmentActivity
import com.bom.smamonitor.dashboardbb.fragments.AgriDashbFragment
import com.bom.smamonitor.dashboardbb.fragments.HomeFragment
import com.bom.smamonitor.dashboardbb.fragments.SearchFragment
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.login.LoginActivity
import com.bom.smamonitor.dashboardbb.fragments.NotiFragment
import com.bom.smamonitor.util.AppConstants
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.support.HasSupportFragmentInjector
import kotlinx.android.synthetic.main.activity_dashboardbb.*
import javax.inject.Inject


class DashboardBBActivity : BaseFragmentActivity(), HasSupportFragmentInjector {

    lateinit var preferenceHelper: PreferenceHelper
    private val fragment1: Fragment = HomeFragment()
    private val fragment2: Fragment = SearchFragment()
    private val fragment3: Fragment = NotiFragment()
   private val fragment4: Fragment = AgriDashbFragment()

    private var mSelectedItem = 0
    private var isBackPressedOnce = false
    val fm: FragmentManager = supportFragmentManager
    var active = fragment1
    private val REQ_CODE_VERSION_UPDATE = 530
    private var appUpdateManager: AppUpdateManager? = null
    private var installStateUpdatedListener: InstallStateUpdatedListener? = null


    @Inject
    internal lateinit var fragmentDispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboardbb)
        setSupportActionBar(toolbarDashBB)
        window.statusBarColor = ContextCompat.getColor(this, R.color.colorPrimaryDark)
        supportActionBar?.title = resources.getString(R.string.Home)
        bottomNavigationView.menu.getItem(2).isEnabled = false
        initView()
        notificationFilter()
//        crashTest()
        checkForAppUpdate()

    }
    private fun crashTest() {
        val crashButton = Button(this)
        crashButton.text = "Crash!"
        crashButton.setOnClickListener {
            throw RuntimeException("Test Crash") // Force a crash
        }

        addContentView(
            crashButton, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
    }

    private fun notificationFilter() {

        val intent = intent
        val message = intent.getStringExtra("message")
        if (!message.isNullOrEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Notification")
                .setMessage(message)
                .setPositiveButton("Ok", { dialog, which -> }).show()
        }
    }

    private fun initView() {
        bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)

        fm.beginTransaction().add(R.id.fragContainer, fragment3, "2").hide(fragment3).commit()
       // fm.beginTransaction().add(R.id.fragContainer, fragment2, "2").hide(fragment2).commit()
        fm.beginTransaction().add(R.id.fragContainer, fragment1, "1").commit()
        fm.beginTransaction().add(R.id.fragContainer, fragment4, "4").hide(fragment4).commit()
    }



    override fun onResume() {
        super.onResume()
        checkNewAppVersionState()
    }


    private val mOnNavigationItemSelectedListener =
        BottomNavigationView.OnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.bottom_bar_home -> {
                    toast(getString(R.string.menu_home))
                    fm.beginTransaction().hide(active).show(fragment1).commit()
                    active = fragment1
                    mSelectedItem = 0
                    return@OnNavigationItemSelectedListener true
                }

                R.id.bottom_bar_fav -> {
                    //return@OnNavigationItemSelectedListener true
                    toast(getString(R.string.agriDashboard))
                    fm.beginTransaction().hide(active).show((fragment4)).commit()
                    active = fragment4
                    mSelectedItem = 4
                    return@OnNavigationItemSelectedListener true
                }

                R.id.bottom_bar_notification -> {
                    fm.beginTransaction().hide(active).show(fragment3).commit()
                    active = fragment3
                    mSelectedItem = 2
                    return@OnNavigationItemSelectedListener true
                }

                R.id.bottom_bar_logout -> {
//                    performUserLogout();
//                    openLoginActivity()
                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        }

//    private fun performUserLogout() = preferenceHelper.let {
//        it.setCurrentUserId(null)
//        it.setAccessToken(null)
//        it.setCurrentUserEmail(null)
//        it.setCurrentUserMobileNo(null)
//        it.setCurrentUserPfNo(null)
//        it.setCurrentBranchCode(null)
//        it.setUserRegionCode(null)
//        it.setCurrentUserPIN(null)
//        it.setCurrentUserLoggedInMode(AppConstants.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT)
//    }
//
//     fun openLoginActivity() {
//         performUserLogout()
//        val intent = Intent(this, LoginActivity::class.java)
//        startActivity(intent)
//        finish()
//    }

    private fun selectFragment(item: MenuItem) {
    }

    override fun onFragmentAttached() {
    }

    override fun onFragmentDetached(tag: String) {
    }

    // This is an extension method for easy Toast call
    private fun Context.toast(message: CharSequence) {
        val toast = Toast.makeText(this, message, Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.BOTTOM, 0, 325)
        toast.show()
    }

    override fun supportFragmentInjector(): AndroidInjector<Fragment> {
        return fragmentDispatchingAndroidInjector
    }

    override fun onBackPressed() {
//        MenuItem homeItem = mBottomNav.getMenu().getItem(0);
        val homeItem: MenuItem = bottomNavigationView.menu.getItem(0)
        if(isBackPressedOnce){
            super.onBackPressed()
        }else {
            if (mSelectedItem != 0) {
                bottomNavigationView.selectedItemId = homeItem.itemId     // Select home item
            } else {
                isBackPressedOnce = true //count on home screen backpress =1
                Toast.makeText(this, "Pressing back again will exit the app.", Toast.LENGTH_LONG).show()
//                super.onBackPressed()
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, intent: Intent?) {
        super.onActivityResult(requestCode, resultCode, intent)
        when (requestCode) {
            REQ_CODE_VERSION_UPDATE -> if (resultCode != RESULT_OK) { //RESULT_OK / RESULT_CANCELED / RESULT_IN_APP_UPDATE_FAILED
                Log.d("AppUpdate","Update flow failed! Result code: $resultCode")
                // If the update is cancelled or fails,
                // you can request to start the update again.
                unregisterInstallStateUpdListener()
            }
        }
    }


    override fun onDestroy() {
        unregisterInstallStateUpdListener()
        super.onDestroy()
    }


    private fun checkForAppUpdate() {
        // Creates instance of the manager.
//        appUpdateManager = AppUpdateManagerFactory.create(AppCustom.getAppContext())
        appUpdateManager = AppUpdateManagerFactory.create(applicationContext)

        // Returns an intent object that you use to check for an update.
//        val appUpdateInfoTask: Task<AppUpdateInfo> = appUpdateManager?.getAppUpdateInfo()
        val appUpdateInfoTask = appUpdateManager?.appUpdateInfo

        // Create a listener to track request state updates.
        installStateUpdatedListener =
            InstallStateUpdatedListener { installState ->
                // Show module progress, log state, or install the update.
                if (installState.installStatus() == InstallStatus.DOWNLOADED) // After the update is downloaded, show a notification
                // and request user confirmation to restart the app.
                    popupSnackbarForCompleteUpdateAndUnregister()
            }

// Checks that the platform will allow the specified type of update.
        appUpdateInfoTask?.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                // Request the update.
                if (appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
                    appUpdateManager?.registerListener(installStateUpdatedListener!!)
                    startAppUpdateFlexible(appUpdateInfo)
                } else if (appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                    startAppUpdateImmediate(appUpdateInfo)
                }
            }
        }
    }

    private fun startAppUpdateImmediate(appUpdateInfo: AppUpdateInfo) {
        try {
            appUpdateManager?.startUpdateFlowForResult(
                appUpdateInfo,
                AppUpdateType.IMMEDIATE,  // The current activity making the update request.
                this,  // Include a request code to later monitor this update request.
                this.REQ_CODE_VERSION_UPDATE
            )
        } catch (e: SendIntentException) {
            e.printStackTrace()
        }
    }

    private fun startAppUpdateFlexible(appUpdateInfo: AppUpdateInfo) {
        try {
            appUpdateManager?.startUpdateFlowForResult(
                appUpdateInfo,
                AppUpdateType.FLEXIBLE,  // The current activity making the update request.
                this,  // Include a request code to later monitor this update request.
                this.REQ_CODE_VERSION_UPDATE
            )
        } catch (e: SendIntentException) {
            e.printStackTrace()
            unregisterInstallStateUpdListener()
        }
    }

    /**
     * Displays the snackbar notification and call to action.
     * Needed only for Flexible app update
     */
    private fun popupSnackbarForCompleteUpdateAndUnregister() {
        val snackbar = Snackbar.make(cl_dashboard,
            resources.getString(R.string.update_downloaded),
            Snackbar.LENGTH_INDEFINITE
        )
        snackbar.apply {
            setAction(R.string.restart) {
                appUpdateManager?.completeUpdate()
            }
            setActionTextColor(resources.getColor(R.color.colorPrimary))
            show()
        }
        unregisterInstallStateUpdListener()
    }

    /**
     * Checks that the update is not stalled during 'onResume()'.
     * However, you should execute this check at all app entry points.
     */
    private fun checkNewAppVersionState() {
        appUpdateManager
            ?.appUpdateInfo
            ?.addOnSuccessListener { appUpdateInfo ->
                //FLEXIBLE:
                // If the update is downloaded but not installed,
                // notify the user to complete the update.
                if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED) {
                    popupSnackbarForCompleteUpdateAndUnregister()
                }

                //IMMEDIATE:
                if (appUpdateInfo.updateAvailability()
                    == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS
                ) {
                    // If an in-app update is already running, resume the update.
                    startAppUpdateImmediate(appUpdateInfo)
                }
            }
    }

    /**
     * Needed only for FLEXIBLE update
     */
    private fun unregisterInstallStateUpdListener() {
        if (appUpdateManager != null && installStateUpdatedListener != null) appUpdateManager?.unregisterListener(
            installStateUpdatedListener!!
        )
    }


}
