package com.bom.smamonitor.dashboardbb

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.dashboardbb.models.Rep7
import com.bom.smamonitor.util.CommonUtil.roundUpto2Decimal
import kotlinx.android.synthetic.main.item_dash_sma.view.*
import java.util.*

class Rep7SummaryAdapter : RecyclerView.Adapter<Rep7SummaryAdapter.ChildRep7ViewHolder>() {

    private var list = listOf<Rep7>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildRep7ViewHolder {
        return ChildRep7ViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_dash_sma, parent, false
            )
        )
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ChildRep7ViewHolder, position: Int) {
        holder.setIsRecyclable(false);
        holder.onBind(position)
    }

    internal fun setRep7List(rep7List: List<Rep7>) {
        this.list = rep7List
        notifyDataSetChanged()
    }

    inner class ChildRep7ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        @SuppressLint("SetTextI18n")
        fun onBind(position: Int) {
            try {
                val rep7 = list[position]
                itemView.sectorTv.text = rep7.sector?.toUpperCase(Locale.getDefault())
                itemView.sma0TV.text = roundUpto2Decimal(rep7.sevenF?.toString().toDouble())
                itemView.sma1TV.text = roundUpto2Decimal(rep7.sevenNf?.toString().toDouble())
                itemView.sma2TV.text = roundUpto2Decimal(rep7.sevenD?.toString().toDouble())
                itemView.totalTV.text = roundUpto2Decimal(rep7.total?.toString().toDouble())
                itemView.variationTV.text = roundUpto2Decimal(rep7.variation?.toString().toDouble())

                itemView.sma0TV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.sma1TV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.sma2TV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.totalTV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.variationTV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;


                itemView.sma0TV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )


                itemView.sma1TV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )
                itemView.sma2TV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )
                itemView.totalTV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )


                if ((rep7.variation < 0)) {
                    itemView.variationTV.setBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.light_green
                        )
                    )

                    itemView.variationTV.setTextColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.dark_green
                        )
                    )
                } else {

                    itemView.variationTV.setTextColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.dark_red
                        )
                    )

                    itemView.variationTV.setBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.light_red
                        )
                    )

                }

//Check horizontal variation
                if(rep7.sector.equals("VARIATION",true)){
                    if(rep7.sevenF<0){
                        itemView.sma0TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.sma0TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    }else{
                        itemView.sma0TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.sma0TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }

                    if(rep7.sevenNf<0){
                        itemView.sma1TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.sma1TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    }else{
                        itemView.sma1TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.sma1TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }
                    if(rep7.sevenD<0){
                        itemView.sma2TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.sma2TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    }else{
                        itemView.sma2TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.sma2TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }


                    if(rep7.total<0){
                        itemView.totalTV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.totalTV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    }else{
                        itemView.totalTV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.totalTV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }

                    itemView.variationTV.text = ""
                    itemView.variationTV.setBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.bg_card_color
                        )
                    )

                }









            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


}