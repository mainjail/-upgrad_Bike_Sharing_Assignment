package com.bom.smamonitor.dashboardbb.fragments

import dagger.Module
import dagger.android.ContributesAndroidInjector

/***/
@Module
abstract class SearchFragmentProvider{

    @ContributesAndroidInjector(modules = [SearchFragmentModule::class])
    internal abstract fun provideSearchFragment() : SearchFragment
}