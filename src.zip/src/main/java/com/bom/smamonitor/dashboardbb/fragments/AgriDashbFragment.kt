package com.bom.smamonitor.dashboardbb.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bom.smamonitor.R
import com.bom.smamonitor.abcd.AbcdTableAdapter
import com.bom.smamonitor.abcd.AbcdTableViewListener
import com.bom.smamonitor.abcd.AbcdTableViewModel
import com.bom.smamonitor.base.view.BaseFragment
import com.bom.smamonitor.dashboardbb.models.AgriObj
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import kotlinx.android.synthetic.main.fragment_agridashb.*
import javax.inject.Inject

class AgriDashbFragment : BaseFragment(),AgriDashbMVPView {

    @Inject
    internal lateinit var presenter: AgridDashbMVPPresenter<AgriDashbMVPView, AgriDashbMVPInteractor>

    private lateinit var user: AppUser
    private var userBranch = "9999"
    private var userRegCode = "99"
    private var loggedInMode = 0
    private val TAG = "AgriFrag"
    private var tableInputList = listOf<AgriObj>()
    private lateinit var tableViewAdapter: AbcdTableAdapter
    private val tableViewModel = AbcdTableViewModel()
    private var callFromMode = 0


    companion object {
        fun newInstance(): AgriDashbFragment {
            return AgriDashbFragment()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(false)
        activity?.title = resources.getString(R.string.AbcdSummary)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_agridashb, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        activity?.title = resources.getString(R.string.AbcdSummary)
    }

    override fun setUp() {
        getBaseActivity()?.title = resources.getString(R.string.AbcdSummary)
        presenter.onViewPrepared()
        initializeTableView()
        figuresTitleAgri.text = "Amount in crores"

//        if (regionCode != null) {
//            brCodeForApi = regionCode
//            if (regionCode == "99") {
//                regionName = "Head Office"
//                supportActionBar?.subtitle = "$regionCode -  $regionName"
//                callFromMode = 3
//                isZone = true
//                supportActionBar?.title = this.resources.getString(R.string.zoneSectorSummary)
//                callReportApi(regionCode, selectedReport)
//
//            } else {
//                supportActionBar?.subtitle = "$regionCode -  $regionName"
//                isZone = true
//                callFromMode = 2
//                supportActionBar?.title = this.resources.getString(R.string.branchwiseSectorSum)
//                callReportApi(regionCode, selectedReport)
//            }
//        } else if (branchCode != null) {
//            brCodeForApi = branchCode
//            isZone = false
//            callFromMode = 1
//        }

    }

    private fun initializeTableView() {
        tableViewAdapter = AbcdTableAdapter(tableViewModel, callFromMode)
        tableViewAgri.setAdapter(tableViewAdapter)
        tableViewAgri.rowHeaderWidth = resources.getDimension(R.dimen.row_header_width).toInt()

        val myTableViewListener = AbcdTableViewListener(tableViewAgri, callFromMode)
        tableViewAgri.tableViewListener = myTableViewListener
    }

    override fun showError(errorMsg: String) {
        CustomDialog().showAlert(requireActivity(), errorMsg)
    }

    override fun inflateUserDetails(userDetails: AppUser?) {
        user = userDetails!!
        Log.d(
            TAG, "User Details:{ ${user.pfNo}  ${user.name?.trim()} and Branch: ${user.curBranch}}"
        )
        Log.d(TAG, "User Pf:${user.pfNo}")
        Log.d(TAG, "User Name:  ${user.name?.trim()} and Branch: ${user.curBranch}")
        userBranch = user.curBranch.toString()
        Log.d(TAG, "User Notification token:${user.notificationId}")

        loggedInMode = presenter.getLoggedInMode()
        Log.d(TAG, "User LoggedInMode = $loggedInMode")
        Log.d(TAG, "User regCode = " + user.regionCode)
        userRegCode = user.regionCode.toString()
        callFirstApiToRefresh()
    }

    override fun displayResultsFromApi(agriObjsList: List<AgriObj>?) {
        if (agriObjsList != null) {
            Log.d(TAG, "agri displayResultsFromApi = ${agriObjsList.count()}")
            if (agriObjsList.isNotEmpty()) {
                this.tableInputList = agriObjsList
            }
            tableViewAdapter.setReportData(tableInputList, callFromMode)
        }

    }

    private fun callFirstApiToRefresh() {

        if (ValidationUtils.isNetworkAvailable(requireContext())) {
//            checkUserRole(loggedInMode), loggedInMode
            presenter.getAgriDashb()
        }
        else CustomDialog().showNoInternetAlert(requireActivity(), "")
    }

    override fun initToolbar() {

    }

    private fun checkUserRole(loggedInMode: Int): String {
        var branchCode = "9999"
        when (loggedInMode) {
            3 -> branchCode = "9999"
            // 2 -> branchCode = userBranch
            2 -> branchCode = user.regionCode.toString() //Zone
            1 -> branchCode = userBranch
        }
        return branchCode
    }

    override fun onResume() {
        super.onResume()
        // callNotifications()
    }


}