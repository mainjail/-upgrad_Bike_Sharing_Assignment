package com.bom.smamonitor.dashboardbb

import androidx.recyclerview.widget.LinearLayoutManager
import dagger.Module
import dagger.Provides

@Module
class DashboardBBActivityModule {

    @Provides
    internal fun provideDashBBInteractor(dashBBInteractorImpl: DashBBInteractorImpl):
            DashBBInteractor = dashBBInteractorImpl

    @Provides
    internal fun provideDashBBPresenter(dashBBPresenter: DashBBPresenterImpl<DashBBView, DashBBInteractor>)
            : DashBBPresenter< DashBBView,DashBBInteractor> = dashBBPresenter

//    @Provides
//    internal fun provideAdapter(): DashBBItemAdapter = DashBBItemAdapter()
//
//    @Provides
//    internal fun provideLinearLayoutManager(activity: DashboardBBActivity):
//            LinearLayoutManager = LinearLayoutManager(activity)

}