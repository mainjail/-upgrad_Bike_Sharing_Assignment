package com.bom.smamonitor.dashboardbb.fragments

import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.dashboardbb.models.AgriObj
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.network.ApiHelper
import io.reactivex.Observable
import javax.inject.Inject

class AgriDashbInteractorImpl @Inject internal constructor(
    preferenceHelper: PreferenceHelper, apiHelper: ApiHelper
) : BaseInteractor(preferenceHelper = preferenceHelper, apiHelper = apiHelper), AgriDashbMVPInteractor {


    override fun getAgriDashb(): Observable<List<AgriObj>> = apiHelper.getAgriDashb()



    override fun getLoggedInMode() = preferenceHelper.getCurrentUserLoggedInMode()

//     fun getUserDetails(): AppUser {
//        return AppUser(
//            preferenceHelper.getCurrentUserPfNo().toString(),
//            preferenceHelper.getCurrentUserName().toString(),
//            preferenceHelper.getCurrentBranchCode().toString(),
//            preferenceHelper.getCurrentBranchName().toString(),
//            preferenceHelper.getUserRegionCode().toString(),
//            preferenceHelper.getUserRegionName().toString(),
//            preferenceHelper.getCurrentUserEmail().toString(),
//            "",
//            "",
//            preferenceHelper.getCurrentUserMobileNo().toString(),
//            preferenceHelper.getCurrentDeviceNotificationToken().toString(),
//            "",
//            ""
//        )
//    }

    private fun checkUserRole(branch: String): String {
        var brCode = Integer.parseInt(branch)
        // (x > 9 && x < 100)
//     var brCode=4500
        when {
            brCode == 9999 -> { //HO

            }
            brCode < 5000 -> { //branch
                brCode = Integer.parseInt(preferenceHelper.getUserRegionCode()!!)
            }
            brCode in 5002..8998 -> {
                //Zone  = brCode>5001 && brCode<8999)
            }
        }
        return brCode.toString()
    }

}