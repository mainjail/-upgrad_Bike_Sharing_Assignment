package com.bom.smamonitor.dashboardbb

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.dashboard.CatModel
import com.bom.smamonitor.dashboard.CategoriesViewHolder
import com.google.android.gms.common.util.CollectionUtils.listOf

class OldDashBBItemAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var listOfCategories = listOf<CatModel>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CategoriesViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_dashbb_layout,
                parent,
                false)
        )
    }

    override fun getItemCount(): Int = listOfCategories.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val categoriesViewHolder = viewHolder as CategoriesViewHolder
        categoriesViewHolder.bindView(listOfCategories[position])
    }

    fun setCategoryList(listOfMovies: List<CatModel>) {
        this.listOfCategories = listOfMovies
        notifyDataSetChanged()
    }


}