package com.bom.smamonitor.dashboardbb.fragments

import com.bom.smamonitor.base.presenter.MVPPresenter

interface AgridDashbMVPPresenter<V : AgriDashbMVPView, I : AgriDashbMVPInteractor> :
    MVPPresenter<V, I> {

    fun onViewPrepared()
    fun getAgriDashb()
    fun getLoggedInMode(): Int


}