package com.bom.smamonitor.dashboardbb.models

import com.google.gson.annotations.SerializedName

data class Rep6(

    @SerializedName("SECTOR")
    val sector: String,

    @SerializedName("BALANCE_1")
    val lastDayBal: Double,

    @SerializedName("BALANCE_2")
    val todayBal: Double,

//    @SerializedName("Today")
//    val todayBalBranch: Double,
//
//    @SerializedName("Total")
//    val todayBalBranch: Double,

    @SerializedName("VARIATION")
    val variation: Double
)
data class ZoRep6(

    @SerializedName("SECTOR")
    val sector: String,

    @SerializedName("BALANCE_2")
    val lastDayBal: Double,

    @SerializedName("Today")
    val todayBalBranch: Double,

    @SerializedName("VARIATION")
    val variation: Double
)
data class Rep6Obj(
    @SerializedName("REP6")
    val rep6List: List<Rep6>
)