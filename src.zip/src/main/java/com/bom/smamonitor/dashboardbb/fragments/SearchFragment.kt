package com.bom.smamonitor.dashboardbb.fragments

import android.app.SearchManager
import android.content.Context
import android.content.Context.SEARCH_SERVICE
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseFragment
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.customViews.RVEmptyObserver
import com.bom.smamonitor.dashboardbb.models.NotiObj
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.npa.NpaCustAdapter
import com.bom.smamonitor.npa.NpaCustomersMVPInteractor
import com.bom.smamonitor.npa.NpaCustomersMVPPresenter
import com.bom.smamonitor.npa.NpaCustomersMVPView
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import kotlinx.android.synthetic.main.fragment_search.*
import javax.inject.Inject



class SearchFragment : BaseFragment(), NpaCustomersMVPView, SearchView.OnQueryTextListener {

    @Inject
    internal lateinit var npaCustAdapter: NpaCustAdapter

    @Inject
    internal lateinit var layoutManager: LinearLayoutManager

    @Inject
    internal lateinit var presenter: NpaCustomersMVPPresenter<NpaCustomersMVPView, NpaCustomersMVPInteractor>

    companion object {
        fun newInstance(): SearchFragment {
            return SearchFragment()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(false)
        activity?.title = resources.getString(R.string.search)

    }

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_search, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun setUp() {
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        npaCustomersRV.layoutManager = layoutManager
        npaCustomersRV.itemAnimator = DefaultItemAnimator()
        npaCustomersRV.adapter = npaCustAdapter
        val emptyRvObserver = RVEmptyObserver(emptyView = emptyListsMsgTv, recyclerView = npaCustomersRV)
        npaCustAdapter.registerAdapterDataObserver(emptyRvObserver)

    }

//    @RequiresApi(Build.VERSION_CODES.O)
//    override fun onCreateOptionsMenu(menu: Menu, menuInflater: MenuInflater) {
//        super.onCreateOptionsMenu(menu, menuInflater)
//        menu.getItem(0).isVisible = true
//        menu.getItem(0).isChecked = true
//        menu.getItem(1).isVisible = false
//
//        val searchManager = activity?.getSystemService(SEARCH_SERVICE) as SearchManager
//        val searchView = menu.findItem(R.id.action_search)?.actionView as SearchView
//        menu.getItem(0).expandActionView() // Expand the search menu item in order to show by default the query
//
//        val searchableInfo = searchManager.getSearchableInfo(requireActivity().componentName)
//        searchView.setSearchableInfo(searchableInfo)
////        val et = searchView.findViewById<View>(searchView.context.resources
////                .getIdentifier("android:id/search_src_text", null, null)) as EditText
////        et.filters = arrayOf<InputFilter>(LengthFilter(max_text_length))
//        searchView.queryHint = resources.getString(R.string.search_hint_anything)
//        searchView.maxWidth = Integer.MAX_VALUE
//        searchView.setOnQueryTextListener(this)
////        searchView.isFocusedByDefault = true
//    }

//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        val id = item.itemId
//        return if (id == R.id.action_search) {
//            true
//        } else super.onOptionsItemSelected(item)
//    }

    override fun showError(errorMsg: String) {
        Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show()
    }

    override fun inflateUserDetails(userDetails: AppUser?) {
        TODO("Not yet implemented")
    }

    private fun Context.toast(message: CharSequence) {
        val toast = Toast.makeText(this, message, Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.BOTTOM, 0, 325)
        toast.show()
    }

    override fun displayResultsFromApi(customers: List<NpaCustomer>?) = customers?.let {
        resultsSizeTv.visibility = View.VISIBLE
        resultsSizeTv.text = it.size.toString()
        npaCustAdapter.addResultsToList(it)
        npaCustAdapter.notifyDataSetChanged()
    }

    override fun displayCustListFromApi(customers: List<CustomerRep2>?): Unit? {
        TODO("Not yet implemented")
    }

    override fun displayNotis(notifis: NotiObj) {
        TODO("Not yet implemented")
    }

    override fun showLoading() {
        searchProBar.visibility = View.VISIBLE
    }

    override fun hideLoading() {
        searchProBar.visibility = View.GONE
    }

    override fun initToolbar() {
    }

    override fun onQueryTextSubmit(query: String?): Boolean {

        if (query!!.length >= 2)
            callAPIForSearch(query.toString())
        else {
            npaCustAdapter.filter.filter(query)
        }
        return false
    }

    override fun onQueryTextChange(query: String?): Boolean {
//        npaCustAdapter.filter.filter(query)
        if (query!!.length >= 2)
            callAPIForSearch(query.toString())
        else
            npaCustAdapter.filter.filter(query)

        return false
    }

    private fun callAPIForSearch(query: String) {
        if (ValidationUtils.isNetworkAvailable(requireContext()))
            presenter.getSearchCustomer(query)
        else CustomDialog().showNoInternetAlert(requireActivity(), "")
    }
}