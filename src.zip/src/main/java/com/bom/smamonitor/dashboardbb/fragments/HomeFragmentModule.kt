package com.bom.smamonitor.dashboardbb.fragments

import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.bzsummary.TickerTvAdapter
import com.bom.smamonitor.dashboardbb.*
import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 15/01/18.
 */
@Module
class HomeFragmentModule {

    @Provides
    internal fun provideHomeInteractor(interactor: DashBBInteractorImpl): DashBBInteractor =
        interactor

    @Provides
    internal fun provideHomePresenter(presenter: DashBBPresenterImpl<DashBBView, DashBBInteractor>)
            : DashBBPresenter<DashBBView, DashBBInteractor> = presenter


    @Provides
    internal fun provideAdapter(): SmaSummaryAdapter = SmaSummaryAdapter()
    @Provides
    internal fun provideRep6Adapter(): Rep6SummaryAdapter=Rep6SummaryAdapter()
    @Provides
    internal fun provideRep7Adapter(): Rep7SummaryAdapter=Rep7SummaryAdapter()
    @Provides
    internal fun provideTickerAdapter(): TickerTvAdapter = TickerTvAdapter()

    @Provides
    internal fun provideLinearLayoutManager(fragment: HomeFragment): LinearLayoutManager =
        LinearLayoutManager(fragment.activity)

}