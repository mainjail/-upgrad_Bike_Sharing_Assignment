package com.bom.smamonitor.dashboardbb.fragments

import android.annotation.SuppressLint
import android.widget.TextView
import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.text.Html
import android.util.Log
import android.util.TypedValue
import android.view.*
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.R
import com.bom.smamonitor.aboutapp.AboutAppActivity
import com.bom.smamonitor.base.view.BaseFragment
import com.bom.smamonitor.branchMaster.BranchListActivity
import com.bom.smamonitor.branchMaster.RegionListActivity
import com.bom.smamonitor.bzsummary.Ticker
import com.bom.smamonitor.bzsummary.TickerTvAdapter
import com.bom.smamonitor.bzsummary.ZoneSummary
import com.bom.smamonitor.custlist.CustomerListActivity
import com.bom.smamonitor.customViews.CustomTickerView
import com.bom.smamonitor.customViews.RecyclerItemClickListener
import com.bom.smamonitor.dashboardbb.*
import com.bom.smamonitor.dashboardbb.models.Announcement
import com.bom.smamonitor.dashboardbb.models.Rep6
import com.bom.smamonitor.dashboardbb.models.Rep7
import com.bom.smamonitor.dashboardbb.models.Sma012
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.LoginActivity
import com.bom.smamonitor.network.CryptoClass.decryptFromHex
import com.bom.smamonitor.network.CryptoClass.encryptToHex
import com.bom.smamonitor.profile.MyProfileActivity
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.DateUtil
import com.bom.smamonitor.util.ValidationUtils
import com.bom.smamonitor.zonesectrsumry.ZoneSectorSumActivity
import com.bom.smamonitor.zonesectrsumry.ZoneSummaryActivity
import kotlinx.android.synthetic.main.custom_dialog_addannounce.*
import kotlinx.android.synthetic.main.custom_dialog_addannounce.view.*
import kotlinx.android.synthetic.main.custom_dialog_layout.view.*
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.item_dash_sma.view.*
import kotlinx.android.synthetic.main.item_rep6.view.*
import java.sql.DriverManager.println
import javax.inject.Inject


@Suppress("DEPRECATION")
class HomeFragment : BaseFragment(), DashBBView {

    private var anim: Animation? = null
    private var selectedTickerPosition = 0
    private val milliSecondsPerInch = 500f
    private lateinit var reportsShortArray: Array<String>
    private lateinit var reportsArray: Array<String>
    private val callFromMode = 0
    private var isFABExpaned = false
    private val TAG = "HomeFrag"


    @Inject
    internal lateinit var tickerAdapter: TickerTvAdapter

    @Inject
    lateinit var presenter: DashBBPresenter<DashBBView, DashBBInteractor>

    @Inject
    internal lateinit var smaSummaryAdapter: SmaSummaryAdapter

    @Inject
    internal lateinit var rep6SummaryAdapter: Rep6SummaryAdapter

    @Inject
    internal lateinit var rep7SummaryAdapter: Rep7SummaryAdapter

    private lateinit var user: AppUser
    private var userBranch = "9999"
    private var userRegCode = "99"
    private var loggedInMode = 0

    companion object {
        fun newInstance(): HomeFragment {
            return HomeFragment()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
        activity?.title = resources.getString(R.string.Home)
    }

    override fun inflateUserDetails(userDetails: AppUser?) {
        user = userDetails!!
        Log.d(
            TAG, "User Details:{ ${user.pfNo}  ${
                user.name?.trim()
            } and Branch: ${user.curBranch}}"
        )
        Log.d(TAG, "User Pf:${user.pfNo}")
        Log.d(            TAG,            "User Name:  ${user.name?.trim()} and CurBranch : ${user.curBranch} - ${user.branchName}"
        )
        userBranch = user.curBranch.toString()
        //println("User Notification token: ${user.notificationId}")
        loggedInMode = presenter.getLoggedInMode()
        userRegCode = user.regionCode.toString()
        Log.d(TAG, "User LoggedinMode= $loggedInMode")
        Log.d(TAG, "User regcode = " + user.regionCode)
        userRoleTv.text = user.branchName
        setUpAsPerUserLogin(loggedInMode)
        callFirstApiToRefresh()
    }

    private fun setUpAsPerUserLogin(loggedInMode: Int) {

        when (loggedInMode) {
            3 -> {//HO
                tickeLL.visibility = View.VISIBLE
                userRoleTv.text = resources.getString(R.string.headOffice)
            }
            2 -> {//Zone
                tickeLL.visibility = View.VISIBLE
                userRoleTv.text = resources.getString(R.string.zoneOffice)
                if (user.branchName != null)
                    userRoleTv.text = user.branchName

            }
            1 -> {//Branch
                tickeLL.visibility = View.GONE
                userRoleTv.text = resources.getString(R.string.branchOffice)
                if (user.branchName != null)
                    userRoleTv.text = user.branchName

                zoneSumBtnFab2.visibility = View.VISIBLE
                zoneSumBtnFab2.setImageResource(R.drawable.ic_doubts)
                zoneSectorSumBtnFab3.visibility = View.GONE
                dcriBtnFab.visibility = View.GONE
                dcriBtnFab.setImageResource(R.drawable.ic_doubts)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    zoneSumBtnFab2.tooltipText = resources.getString(R.string.listOfCusts)
                }

            }
        }
    }

    private fun checkUserRole(loggedInMode: Int): String {
        var branchCode = "9999"
        when (loggedInMode) {
            3 -> branchCode = "99" //HO
            //2 -> branchCode = userBranch //ZOne
            2 -> branchCode = user.regionCode.toString() //ZOne

            1 -> branchCode = userBranch //Branch
        }
        return branchCode
    }

    private fun getBranchCodeAsPerRequest(branch: String): String {
        var brCode = Integer.parseInt(branch)
        when {
            brCode == 9999 -> { //HO
                brCode
            }
            brCode < 5000 -> { //branch
                brCode = Integer.parseInt(userBranch)
            }
            brCode in 5002..8998 -> {
                //Zone  = brCode>5001 && brCode<8999)
                brCode = Integer.parseInt(userBranch)
            }
        }
        return brCode.toString()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun setUp() {
        activity?.title = resources.getString(R.string.Home)
        presenter.onViewPrepared()
        smaRv.layoutManager = LinearLayoutManager(getBaseActivity())
        smaRv.itemAnimator = DefaultItemAnimator()

        //SMA TABle
        figuresTitle.text =
            getString(R.string.FiguresinCrores) + " " + "as on " + DateUtil.getYesterdayDateString()
        headerSmaINC.sma0TV.text = getString(R.string.sma0)
        headerSmaINC.sma1TV.text = getString(R.string.sma1)
        headerSmaINC.sma2TV.text = getString(R.string.sma2)

        smaSummaryAdapter = SmaSummaryAdapter()
        smaRv.adapter = smaSummaryAdapter
        smaRv.isNestedScrollingEnabled = false

//        set rep6 Adapter
        headerRep6.todayTV.text = DateUtil.getYesterdayDateString()
        headerRep6.lastDayTV.text = DateUtil.getDateBeforeYesterdayString()
        rep6SummaryAdapter = Rep6SummaryAdapter()
        rep6RV.layoutManager = LinearLayoutManager(getBaseActivity())
        rep6RV.adapter = rep6SummaryAdapter
        rep6RV.isNestedScrollingEnabled = false

//        set rep7 Adapter
        headerRep7INC.sma0TV.text = getString(R.string.sevenF)
        headerRep7INC.sma1TV.text = getString(R.string.sevenNf)
        headerRep7INC.sma2TV.text = getString(R.string.sevenD)
        rep7SummaryAdapter = Rep7SummaryAdapter()
        rep7Rv.layoutManager = LinearLayoutManager(getBaseActivity())
        rep7Rv.adapter = rep7SummaryAdapter
        rep7Rv.isNestedScrollingEnabled = false
        tickeLL.visibility = View.GONE


        tickerAdapter = TickerTvAdapter()

        // callEncryptionFunction()

        swipeRefresh.setOnRefreshListener {
            callFirstApiToRefresh()
            Handler().postDelayed(Runnable { // Stop animation (This will be after 3 seconds)
                swipeRefresh.isRefreshing = false
            }, 4000) // Delay in millis
        }

        reportsArray = resources.getStringArray(R.array.reportsHomeArray)
        val adapter =
            ArrayAdapter(requireContext(), R.layout.simple_item, reportsArray)
        reportSpinnerHomeFrg.adapter = adapter
        reportSpinnerHomeFrg.setSelection(selectedTickerPosition)
        anim = AnimationUtils.loadAnimation(activity, R.anim.translate)

        reportSpinnerHomeFrg.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                reportSpinnerHomeFrg.animation = anim
                reportSpinnerHomeFrg.animation.start()
//                val animator = ObjectAnimator.ofFloat(reportSpinnerHomeFrg, "textSize", 12f)
//                animator.duration = 800
//                animator.start()
                selectedTickerPosition = position
                callReportTickerApi()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            zoneSumBtnFab2.tooltipText = resources.getString(R.string.zoneSummary)
            zoneSectorSumBtnFab3.tooltipText = resources.getString(R.string.zoneSectorSummary)
        }

        zoneSectorSumBtnFab3.setOnClickListener {
            Log.d(TAG, "IntentInfo ZoneSectrAct = " + user.regionCode + user.branchName)
            val intent = Intent(activity, ZoneSectorSumActivity::class.java)
            intent.putExtra("regionCode", user.regionCode?.trim())
            if (loggedInMode == 2 && userBranch != null) {
                intent.putExtra("regionName", user.branchName)
            }
            startActivity(intent)
        }

        zoneSumBtnFab2.setOnClickListener {
            if (loggedInMode == 1 && userBranch != null) {
                Log.d(TAG, "IntentInfo CustListAct = " + user.regionCode + user.branchName)

                val intent = Intent(activity, CustomerListActivity::class.java)
                intent.putExtra("branchCode", userBranch)
                intent.putExtra("branchName", user.branchName)
                startActivity(intent)
            } else {
                Log.d(
                    TAG,
                    "IntentInfo ZoneSummAct = " + checkUserRole(loggedInMode) + user.branchName
                )

                val intent = Intent(activity, ZoneSummaryActivity::class.java)
                //intent.putExtra("regionCode", user.regionCode?.trim())
                // if (loggedInMode == 3)
                intent.putExtra("regionCode", checkUserRole(loggedInMode))
                //else
                // intent.putExtra("regionCode", userBranch)
                intent.putExtra("regionName", user.branchName)
                startActivity(intent)
            }
        }

        dcriBtnFab.setOnClickListener {
            openWebPage("https://10.128.26.143/DelinquencyUI/delinquency-details?username="+ user.name +"&pfno="+user.pfNo+"&pins_br="+user.curBranch+"&rosw_regcode="+user.regionCode)
        }

        fab.setOnClickListener {
            if (isFABExpaned) {
                isFABExpaned = false
                collapseFABMenu()
            } else {
                isFABExpaned = true
                expendFABMenu()
            }
        }
    }

    private fun openWebPage(url:String){
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(webIntent)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun callEncryptionFunction() {

        try {
//            val secretKey: SecretKey = CryptoClass.generateKey("1234567812345678")
//            val strResult: String = CryptoClass.encryptMsg("Smita Ranveer", secretKey)!!
//            Log.d("Mesg","Mesg encrypted:  $strResult")
//            val decrStrResult: String = CryptoClass.decryptMsg(strResult, secretKey)
//            Log.d("Mesg","Mesg decrypted:  $decrStrResult")

            // Method 2 AES 256
//            val cipherText = CryptoClass.encryptAes(
//                CryptoClass.algorithm,
//                CryptoClass.inputText,
//                CryptoClass.key,
//                CryptoClass.iv
//            )
//            Log.d("Mesg","Msg encrypted:  $cipherText")
//            val plainText = CryptoClass.decryptAes(
//                CryptoClass.algorithm, cipherText,
//                CryptoClass.key,
//                CryptoClass.iv
//            )
//            Log.d("Mesg","Msg decrypted:  $plainText")


            // Method 3 AES 128 withHEX
            val input = "Hi, I am using AES Enc-Dec Algorithm"
            val enc: String = encryptToHex(input)!!
            val dec: String = decryptFromHex(enc)!!
            Log.d("Mesg", "Input Text     : $input")
            Log.d("Mesg", "Encrypted Text : $enc")
            Log.d("Mesg", "Decrypted Text : $dec")


        } catch (e: Exception) {
            println("Mesg Exception:  ")
            e.printStackTrace()
        }


    }


    private fun callFirstApiToRefresh() {

        if (ValidationUtils.isNetworkAvailable(requireContext()))
            presenter.getSummarySma(checkUserRole(loggedInMode), loggedInMode)
        else CustomDialog().showNoInternetAlert(requireActivity(), "")
    }

    override fun displaySmaList(smaList: List<Sma012>) {
        // callRep7Api()
        presenter.getSummaryRep7(checkUserRole(loggedInMode), loggedInMode)
        smaSummaryAdapter.setSmaList(smaList)
    }

    override fun displayRep7List(rep7List: List<Rep7>) {
        presenter.getSummaryRep6(checkUserRole(loggedInMode), loggedInMode)
        rep7SummaryAdapter.setRep7List(rep7List)
    }

    override fun displayRep6List(rep6List: List<Rep6>) {
        rep6SummaryAdapter.setRep6List(rep6List)
        callAnnouncement()
        if (loggedInMode == 1 || loggedInMode == 0) {
            tickeLL.visibility = View.GONE
        } else {
            tickeLL.visibility = View.VISIBLE
            callReportTickerApi()
        }
    }

    override fun callRep7Api() {
        presenter.getSummaryRep7(checkUserRole(loggedInMode), loggedInMode)

    }

    override fun callRep6Api() {
        presenter.getSummaryRep6(checkUserRole(loggedInMode), loggedInMode)
    }

    override fun displayTickerList(listZoneSum: List<ZoneSummary>) {
        callAnnouncement()
        val tickerList = ArrayList<Ticker>()
        try {

            for (zoneSummary: ZoneSummary in listZoneSum) {
                when (loggedInMode) {

                    3 -> {
                        val amount = getAmountOfReportType(zoneSummary)
                        var zoneName = zoneSummary.zoneName
                        zoneName = if (zoneName.trim() == "ZZTOTAL") {
                            "TOTAL"
                        } else {
                            zoneName.substring(0, zoneSummary.zoneName.indexOf("ZONE")).trim()
                        }
                        val ticker = Ticker(zoneName, amount)
                        tickerList.add(ticker)

                    }
                    2 -> {
                        val amount = getAmountOfReportType(zoneSummary)
                        var branchName = zoneSummary.brName
                        branchName = if (branchName == "ZZTOTAL") {
                            "TOTAL"
                        } else {
                            branchName.substring(0, zoneSummary.brName.indexOf('(')).trim()
                        }
                        val ticker = Ticker(branchName, amount)
                        tickerList.add(ticker)

                    }
                    1 -> {

                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        setTickerView(tickerList)
    }

    @SuppressLint("SetTextI18n")
    fun setTickerView(tickerList: ArrayList<Ticker>) {
        try {
            tickeParentLL.removeAllViewsInLayout()
            val custTickerView = CustomTickerView(activity)
            custTickerView.layoutParams = LinearLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
            tickeParentLL.addView(custTickerView)
            custTickerView.displacement = 60
            custTickerView.setBackgroundColor(resources.getColor(R.color.white))
            for (zoneSumObj: Ticker in tickerList) {
                val tv = TextView(activity)
                tv.layoutParams = LinearLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
                tv.setBackgroundColor(
                    ContextCompat.getColor(
                        requireContext(),
                        android.R.color.white
                    )
                )
                tv.textAlignment = View.TEXT_ALIGNMENT_CENTER
                tv.typeface = Typeface.DEFAULT_BOLD
                tv.gravity = Gravity.CENTER
                val start = zoneSumObj.amount.indexOf('(')
                val amount1: String = zoneSumObj.amount.substring(0, start)
                val variation =
                    zoneSumObj.amount.substring(start + 1, zoneSumObj.amount.indexOf(')'))
                if (variation.toDouble() < 0) {
                    val text = ("<font color=#696969>" + zoneSumObj.name + "</font> "
                            + "<font color=#04BD0C>" + zoneSumObj.amount + "</font>")
//                #04BD0C = green color  , 696969 = gray color
                    tv.text = Html.fromHtml(text)
                } else {
                    val text = ("<font color=#696969>" + zoneSumObj.name + "  </font> "
                            + "<font color=#f44336> " + zoneSumObj.amount + "</font>")
                    // f44336 = red color
                    tv.text = Html.fromHtml(text)
                }
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                tv.setPadding(5, 10, 5, 0)
                custTickerView.addChildView(tv)
            }
            Log.i("TickerList", "FirstValue:-" + tickerList[0].name + "-" + tickerList[0].amount)
            custTickerView.showTickers()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun displayAnnouncement(listAnc: List<Announcement>) {
        try {
            val appUser=user
            appUser.userLockPin=null
            presenter.saveUserLog(appUser)
            annLL.removeAllViewsInLayout()
            val announceTicker = CustomTickerView(activity)
            announceTicker.layoutParams = LinearLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
//        for (alert: Announcement in listAnc) {

            val alert = listAnc[0]
            val tv = TextView(requireContext())
            tv.layoutParams = LinearLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            announceTicker.setBackgroundColor(resources.getColor(R.color.light_orange))
            tv.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.light_orange))
            tv.setTextColor(ContextCompat.getColor(requireContext(), R.color.dark_red))
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            tv.setCompoundDrawables(
                ResourcesCompat.getDrawable(
                    resources,
                    R.drawable.ic_announcement,
                    null
                ), null, null, null
            )
            tv.textAlignment = View.TEXT_ALIGNMENT_CENTER
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.gravity = Gravity.CENTER
            tv.setPadding(5, 10, 5, 0)
            tv.text = alert.annContent.trim()
            announceTicker.addChildView(tv)
            annLL.addView(announceTicker)
            announceTicker.displacement = 60
            announceTicker.showTickers()

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    override fun displaySmaSummaryMonthly(smaList: List<Sma012>) {

    }

    private fun getAmountOfReportType(zoneSummary: ZoneSummary): String {
        var amount = ""
        when (selectedTickerPosition) {
            0 -> amount = zoneSummary.sma0
            1 -> amount = zoneSummary.sma1
            2 -> amount = zoneSummary.sma2
            3 -> amount = zoneSummary.rep6
        }
        return amount
    }

    private fun callReportTickerApi() {
        if (callFromMode == 3)
            presenter.getHoSummaryZoneReportWise(checkUserRole(loggedInMode), false)
        else
            presenter.getZoneSummaryBranchRepWise(checkUserRole(loggedInMode), false)
//        presenter.getZoneSummaryBranchRepWise(checkUserRole(loggedInMode), false)
    }

    override fun showError(errorMsg: String) {
        Toast.makeText(activity, errorMsg, Toast.LENGTH_LONG).show()
    }

    private fun expendFABMenu() {
        fab.animate().rotationBy(180F)
        zoneSumBtnFab2.animate().translationY(-resources.getDimension(R.dimen.dimen80dp))
        zoneSectorSumBtnFab3.animate().translationY(-resources.getDimension(R.dimen.dimen150dp))
      //  dcriBtnFab.animate().translationY(-resources.getDimension(R.dimen.dimen200dp))

    }

    private fun collapseFABMenu() {
        isFABExpaned = false
        fab.animate().rotationBy(0F)
        zoneSumBtnFab2.animate().translationY(0F)
        zoneSectorSumBtnFab3.animate().translationY(0F)
    }

    override fun onCreateOptionsMenu(menu: Menu, menuInflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, menuInflater)
        menu.clear()
        menuInflater.inflate(R.menu.main, menu)
        menu.getItem(0).isVisible = false

        menu.getItem(1).isVisible =
            user.deptCode.toString() != "12" || user.deptCode.toString() != "15" &&
                    user.curBranch.toString() != "9999"
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {

            R.id.actionLogOut -> {
                basicAlertDialog()
            }

            R.id.addAnnouceMenu -> {
                if (user.deptCode?.toString().equals("12") || user.deptCode?.toString().equals("15")
                    && user.curBranch.toString().equals("9999")
                ) {
                    showAddAlertDialog(activity as Activity, "")
                } else {
                    Toast.makeText(activity, "You are not authorized.", Toast.LENGTH_LONG).show()
                }
            }

            R.id.actionAbtApp -> {
                openAboutAppActivity()
            }

            R.id.actionMyProfile -> {
                openMyProfileActivity()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun openMyProfileActivity() {
        val intent = Intent(context, MyProfileActivity::class.java)
        intent.putExtra("branchCode", userBranch)
        startActivity(intent)
    }

    private fun openAboutAppActivity() {
        val intent = Intent(context, AboutAppActivity::class.java)
        startActivity(intent)
    }

    override fun onDestroyView() {
        presenter.onDetach()
        super.onDestroyView()
    }

    private fun setRecyclerItemClickListener() {
        smaRv.addOnItemTouchListener(
            RecyclerItemClickListener(this.requireContext(),
                smaRv, object : RecyclerItemClickListener.OnItemClickListener {
                    override fun onItemClick(view: View, position: Int) {
                        when (position) {
                            3 -> openContactUsActivity()
                            4 -> basicAlertDialog()
                        }
                    }

                    override fun onItemLongClick(view: View?, position: Int) {
                    }
                })
        )
    }

    private fun showAddAlertDialog(activity: Activity, msg: String?) {

        val layoutInflater: LayoutInflater = activity.layoutInflater

        val dialogView = layoutInflater.inflate(R.layout.custom_dialog_addannounce, null)
        val customDialog = AlertDialog.Builder(activity).setView(dialogView).show()

        val btnSendMsg = dialogView.findViewById<AppCompatButton>(R.id.btnSendMsg)
        btnSendMsg.setOnClickListener {
            if (dialogView.et_comments.text?.isNotEmpty()!!) {
                val announcement =
                    Announcement("", dialogView.et_comments.text.toString(), user.pfNo, "")
                callApiSendAlert(announcement)
                customDialog.dismiss()
            } else {
                Toast.makeText(activity, "Please add alert message.", Toast.LENGTH_LONG).show()
                customDialog.dismiss()
            }
        }
    }

    private fun callApiSendAlert(announcement: Announcement) {
        if (ValidationUtils.isNetworkAvailable(requireContext()))
            presenter.addAnnouncement(announcement)
        else CustomDialog().showNoInternetAlert(requireActivity(), "")
    }


    private fun basicAlertDialogOld() {

        val builder = AlertDialog.Builder(requireActivity(), R.style.MyAlertDialogStyle)
        val alertDialog = builder.create()
        val positiveButtonClick = { dialog: DialogInterface, which: Int ->
            presenter.performUserLogout()
            alertDialog.dismiss()
        }
        val negativeButtonClick = { dialog: DialogInterface, which: Int ->
            alertDialog.dismiss()
        }
        builder.setTitle("Alert !")
        builder.setMessage("Are you sure, you want to logout?")
        builder.setPositiveButton("Yes", positiveButtonClick)
        builder.setNegativeButton("No", negativeButtonClick)
        builder.setIcon(resources.getDrawable(R.drawable.ic_error_alert))
        builder.show()
//        val cancelBtn =   alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE)
//        cancelBtn.setTextColor(Color.BLACK)
//        cancelBtn.setOnClickListener {
//            alertDialog.dismiss()
//        }
//        val okBtn = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE)
//        with(okBtn) {
//            setTextColor(resources.getColor(R.color.colorPrimary))
//            setOnClickListener {
//                presenter.performUserLogout()
//                alertDialog.dismiss()
//            }
//        }
        alertDialog.show()

    }

    private fun basicAlertDialog() {
        val layoutInflater: LayoutInflater = requireActivity().layoutInflater
        val dialogView = layoutInflater.inflate(R.layout.dialog_logout_layout, null)
        val customDialog = AlertDialog.Builder(requireActivity()).setView(dialogView).show()
        val btnYes = dialogView.findViewById<AppCompatButton>(R.id.btnYes)
        val btnNo = dialogView.findViewById<AppCompatButton>(R.id.btnNo)
        btnNo.setOnClickListener {
            customDialog.dismiss()
        }
        btnYes.setOnClickListener {
            presenter.performUserLogout()
            customDialog.dismiss()
        }
    }

    override fun openLoginActivity() {
        val intent = Intent(activity, LoginActivity::class.java)
        startActivity(intent)
        activity?.finish()
    }

    private fun callAnnouncement() {
        if (ValidationUtils.isNetworkAvailable(requireContext()))
            presenter.getAnnouncement()
        else CustomDialog().showNoInternetAlert(requireActivity(), "")
    }

//    override fun openNpaBorrowerActivity() {
//        when (presenter.getLoggedInMode()) {
//            1 -> {
//                val intent = Intent(activity, NpaCustomersActivity::class.java)
//                intent.putExtra("branchCode", user.curBranch?.trim())
//                startActivity(intent)
//            }
//            2 -> {
//                val intent = Intent(activity, BranchListActivity::class.java)
//                intent.putExtra("regionCode", user.curBranch?.trim())
//                startActivity(intent)
//            }
//            3 -> {
//                val intent = Intent(activity, RegionListActivity::class.java)
//                startActivity(intent)
//            }
//        }
//    }

    override fun openBranchesActivity() {
        when (presenter.getLoggedInMode()) {
            1 -> {
            }
            2 -> {
            }
            3 -> {
            }
        }
        val intent = Intent(activity, BranchListActivity::class.java)
        startActivity(intent)
    }

    override fun openRegionActivity() {
        when (presenter.getLoggedInMode()) {
            1 -> {
            }
            2 -> {
            }
            3 -> {
            }
        }
        val intent = Intent(activity, RegionListActivity::class.java)
        startActivity(intent)
    }

    override fun openContactUsActivity() {
        val email = "smita.ranveer@mahabank.co.in"
        val subject = "Regarding ..."
        composeEmail(arrayOf(email), subject)
    }

    override fun initToolbar() {

    }


    @SuppressLint("QueryPermissionsNeeded")
    private fun composeEmail(addresses: Array<String>, subject: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:") // only email apps should handle this
            putExtra(Intent.EXTRA_EMAIL, addresses)
            putExtra(Intent.EXTRA_SUBJECT, subject)
        }
        if (intent.resolveActivity(context?.packageManager!!) != null) {
            startActivity(intent)
        }



    }






}

