package com.bom.smamonitor.dashboardbb.fragments

import com.bom.smamonitor.base.view.BaseMVPView
import com.bom.smamonitor.dashboardbb.models.AgriObj
import com.bom.smamonitor.login.AppUser

interface AgriDashbMVPView : BaseMVPView {

    fun showError(errorMsg:String)
    fun inflateUserDetails(userDetails: AppUser?)
    fun displayResultsFromApi(agriObjsList: List<AgriObj>?)

}