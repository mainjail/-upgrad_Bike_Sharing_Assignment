package com.bom.smamonitor.dashboardbb

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.dashboardbb.models.Sma012
import com.google.android.gms.common.util.CollectionUtils.listOf


class DashBBItemAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var listOfCategories = listOf<Sma012>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return SmaDashViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_dash_sma,
                parent,
                false)
        )
    }

    override fun getItemCount(): Int = listOfCategories.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val categoriesViewHolder = viewHolder as SmaDashViewHolder
        categoriesViewHolder.bindView(listOfCategories[position])
    }

    fun setCategoryList(listOfMovies: List<Sma012>) {
        this.listOfCategories = listOfMovies
        notifyDataSetChanged()
    }
    class SmaDashViewHolder (itemView : View): RecyclerView.ViewHolder(itemView){
        fun bindView(movieModel: Sma012) {
//            itemView.figure1.text = movieModel.Agree
//            itemView.figure3.text = movieModel.Agree
//            itemView.figure4.text = movieModel.Agree
//            itemView.figure5.text = movieModel.Agree
//            itemView.figure6.text = movieModel.Agree
//            itemView.figure7.text = movieModel.Agree
//            itemView.figure4.text = movieModel.Agree

//        Glide.with(itemView.context).load(movieModel.moviePicture!!).into(itemView.imageMovie)
        }
    }

}