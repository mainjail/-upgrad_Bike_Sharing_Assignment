package com.bom.smamonitor.dashboardbb

import dagger.Module
import dagger.android.ContributesAndroidInjector

/***/
@Module
abstract class DashboardBBProvider{

//    @ContributesAndroidInjector(modules = [DashboardBBActivityModule::class])
//    internal abstract fun provideHomeFragment() :
}