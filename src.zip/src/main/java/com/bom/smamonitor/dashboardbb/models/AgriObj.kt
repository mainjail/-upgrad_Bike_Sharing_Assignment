package com.bom.smamonitor.dashboardbb.models

import com.google.gson.annotations.SerializedName


data class AgriObj(

    @SerializedName("REGCODE") var regCode: String? = null,
    @SerializedName("REGNAME") var regName: String? = null,
    @SerializedName("AGRI_A_CNT") var agriACnt: Int? = null,
    @SerializedName("AGRI_A_AMT") var agriAAmt: Double? = null,
    @SerializedName("AGRI_B_CNT") var agriBCnt: Int? = null,
    @SerializedName("AGRI_B_AMT") var agriBAmt: Double? = null,
    @SerializedName("AGRI_C_CNT") var agriCCnt: Int? = null,
    @SerializedName("AGRI_C_AMT") var agriCAmt: Double? = null,
    @SerializedName("AGRI_D_CNT") var agriDCnt: Int? = null,
    @SerializedName("AGRI_D_AMT") var agriDAmt: Double? = null,
    @SerializedName("AGRI_E_CNT") var agriECnt: Int? = null,
    @SerializedName("AGRI_E_AMT") var agriEAmt: Double? = null

)
