package com.bom.smamonitor.dashboardbb

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.dashboardbb.models.Sma012
import com.bom.smamonitor.util.CommonUtil.formatRoundUp
import kotlinx.android.synthetic.main.item_dash_sma.view.*
import java.math.RoundingMode
import java.text.DecimalFormat
import java.util.*

class SmaSummaryAdapter : RecyclerView.Adapter<SmaSummaryAdapter.ChildSmaViewHolder>() {

    private var list = listOf<Sma012>()

    fun Double.toLacs(): String {
        val df = DecimalFormat("#.##")
        df.roundingMode = RoundingMode.DOWN
        return df.format(this / 100000)
    }

    fun Double.toCrores(): String {
        val df = DecimalFormat("#.##")
        df.roundingMode = RoundingMode.DOWN
        return df.format(this / 10000000)
    }

    private val String.capitalizeWords
        get() = this.toLowerCase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.capitalize(Locale.getDefault())
        }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildSmaViewHolder {
        return ChildSmaViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_dash_sma, parent, false
            )
        )
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ChildSmaViewHolder, position: Int) {
        holder.setIsRecyclable(false)
        holder.onBind(position)
    }

    internal fun setSmaList(smaList: List<Sma012>) {
        this.list = smaList
        notifyDataSetChanged()
    }

    inner class ChildSmaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        @SuppressLint("SetTextI18n")
        fun onBind(position: Int) {
            try {
                val sma = list[position]

                itemView.sectorTv.text = sma.sector?.toUpperCase(Locale.getDefault())
                itemView.sma0TV.text = formatRoundUp(sma.sma0bal?.toString())
                itemView.sma1TV.text = formatRoundUp(sma.sma1bal?.toString())
                itemView.sma2TV.text = formatRoundUp(sma.sma2bal?.toString())
                itemView.totalTV.text = formatRoundUp(sma.total?.toString())
                itemView.variationTV.text = formatRoundUp(sma.variation?.toString())

                itemView.sma0TV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.sma1TV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.sma2TV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.totalTV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;
                itemView.variationTV.textAlignment = View.TEXT_ALIGNMENT_TEXT_END;



                itemView.sma0TV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )

                itemView.totalTV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )


                itemView.sma1TV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )
                itemView.sma2TV.setBackgroundColor(
                    ContextCompat.getColor(
                        itemView.context,
                        R.color.bg_card_color
                    )
                )

                if ((sma.variation < 0)) {
                    itemView.variationTV.setTextColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.dark_green
                        )
                    )
                    itemView.variationTV.setBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.light_green
                        )
                    )

                } else {
                    itemView.variationTV.setTextColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.dark_red
                        )
                    )
                    itemView.variationTV.setBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.light_red
                        )
                    )
                }

                if(sma.sector.equals("VARIATION",true)){
                    if(sma.sma0bal<0){
                        itemView.sma0TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.sma0TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    }else{
                        itemView.sma0TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.sma0TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }
                    if(sma.sma1bal<0){
                        itemView.sma1TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.sma1TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    }else{
                        itemView.sma1TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.sma1TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }
                    if(sma.sma2bal<0){
                        itemView.sma2TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.sma2TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    }else{
                        itemView.sma2TV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.sma2TV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }
                    if(sma.total<0){
                        itemView.totalTV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_green
                            )
                        )
                        itemView.totalTV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_green
                            )
                        )
                    }else{
                        itemView.totalTV.setTextColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.dark_red
                            )
                        )
                        itemView.totalTV.setBackgroundColor(
                            ContextCompat.getColor(
                                itemView.context,
                                R.color.light_red
                            )
                        )
                    }

                    itemView.variationTV.text = ""
                    itemView.variationTV.setBackgroundColor(
                        ContextCompat.getColor(
                            itemView.context,
                            R.color.bg_card_color
                        )
                    )
                }



            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


}