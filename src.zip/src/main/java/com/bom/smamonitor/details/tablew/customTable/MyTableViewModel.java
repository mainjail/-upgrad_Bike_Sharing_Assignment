package com.bom.smamonitor.details.tablew.customTable;


import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.ColumnHeaderModel;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;
import com.bom.smamonitor.npa.modelNpa.NpaAccount;

import java.util.ArrayList;
import java.util.List;

public class MyTableViewModel {
    // Columns indexes
    public static final int LINK_COLUMN_INDEX1 = 1;
    public static final int LINK_COLUMN_INDEX2 = 2;
    public static final int GENDER_COLUMN_INDEX = 9;

    // Constant size for dummy data sets
//    private static final int COLUMN_SIZE = 500;
//    private static final int ROW_SIZE = 500;

    private List<ColumnHeaderModel> mColumnHeaderModelList;
    private List<RowHeaderModel> mRowHeaderModelList;
    private List<List<Cell>> mCellModelList;


    public MyTableViewModel() {
    }



    private List<ColumnHeaderModel> createColumnHeaderModelList() {
        List<ColumnHeaderModel> list = new ArrayList<>();
        // Create Column Headers
//            list.add(new ColumnHeaderModel("0", "Sr. No"));
        list.add(new ColumnHeaderModel("0", "Account No"));
        list.add(new ColumnHeaderModel("1", "Prod Code"));
        list.add(new ColumnHeaderModel("2", "Prod Name"));
        list.add(new ColumnHeaderModel("3", "Sanc Date"));
        list.add(new ColumnHeaderModel("4", "Sanc Amount"));
        list.add(new ColumnHeaderModel("5", "Outstanding Bal"));

        list.add(new ColumnHeaderModel("6", "Irac"));
        list.add(new ColumnHeaderModel("7", "NPA Date"));
        list.add(new ColumnHeaderModel("8", "Repay Option"));
        list.add(new ColumnHeaderModel("9", "Princ Req Freq"));
        list.add(new ColumnHeaderModel("10", "Int Req Freq"));
        list.add(new ColumnHeaderModel("11", "Loan Repay"));
        list.add(new ColumnHeaderModel("12", "Repay Freq"));
        list.add(new ColumnHeaderModel("13", "Repay Day"));
        list.add(new ColumnHeaderModel("14", "Unapplied Int"));

//        list.add(new ColumnHeaderModel("15", "Limit"));
//        list.add(new ColumnHeaderModel("7", "AC Open Date"));

        return list;
    }

    private List<List<Cell>> createCellModelList(List<NpaAccount> userList) {


        List<List<Cell>> cellList = new ArrayList<>();
        // Creating cell model list from User list for Cell Items
        // In this example, User list is populated from web service
        try {
            for (int i = 0; i < userList.size(); i++) {
                NpaAccount npaAccount = userList.get(i);
                List<Cell> list = new ArrayList<>();

                // The order should be same with column header list;
//                list.add(new Cell("1-" + i, circular.getSrNo()));          // "srNo"
                list.add(new Cell("1-" + i, npaAccount.getAccountNo()));
                list.add(new Cell("2-" + i, npaAccount.getAcctType().concat(npaAccount.getIntCat())));
                list.add(new Cell("3-" + i, npaAccount.getProdName()));
                list.add(new Cell("4-" + i, npaAccount.getSancDate()));
                list.add(new Cell("5-" + i, npaAccount.getSancAmount()));
                list.add(new Cell("6-" + i, npaAccount.getLoanBalance()));

                list.add(new Cell("7-" + i, npaAccount.getOldIrac()));
                list.add(new Cell("8-" + i, npaAccount.getNpaDate()));

                list.add(new Cell("9-" + i, npaAccount.getRepayOption()));
                list.add(new Cell("10-" + i, npaAccount.getPrincRepFrequency()));
                list.add(new Cell("11-" + i, npaAccount.getIntRepFreq()));

                list.add(new Cell("12-" + i, npaAccount.getLoanRepay()));
                list.add(new Cell("13-" + i, npaAccount.getRepayFreq()));
                list.add(new Cell("14-" + i, npaAccount.getRepayDay()));
                list.add(new Cell("15-" + i, npaAccount.getUnappliedInt()));

                cellList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cellList;
    }

    private List<RowHeaderModel> createRowHeaderList(int size) {
        List<RowHeaderModel> list = new ArrayList<>();
        for (int i = 0; i < size; i++) { //ROW_SIZE=usersList.size();
            // In this example, Row headers just shows the index of the TableView List.
            list.add(new RowHeaderModel(String.valueOf(i), String.valueOf(i + 1)));
        }
        return list;
    }

    public List<ColumnHeaderModel> getColumnHeaderModeList() {
        return mColumnHeaderModelList;
    }

    public List<RowHeaderModel> getRowHeaderModelList() {
        return mRowHeaderModelList;
    }

    public List<List<Cell>> getCellModelList() {
        return mCellModelList;
    }

    public void generateListForTableView(List<NpaAccount> users) {
        mColumnHeaderModelList = createColumnHeaderModelList();
        mCellModelList = createCellModelList(users);
        mRowHeaderModelList = createRowHeaderList(users.size());
    }


}



