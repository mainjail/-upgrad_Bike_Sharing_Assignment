package com.bom.smamonitor.details.paymentmodels

import com.google.gson.annotations.SerializedName


data class PaymentMsgLinkReq(

    @SerializedName("cif") var cif: String? = null,
    @SerializedName("acno") var acno: String? = null,
    @SerializedName("brcode") var brcode: String? = null,
    @SerializedName("requested_by") var requestedBy: String? = null,
    @SerializedName("requested_on") var requestedOn: String? = null,
    @SerializedName("merchant_txn") var merchantTxn: String? = null,
    @SerializedName("key") var key: String? = null,
    @SerializedName("email") var email: String? = null,
    @SerializedName("name") var name: String? = null,
    @SerializedName("amount") var amount: String? = null,
    @SerializedName("phone") var phone: String? = null,
    @SerializedName("udf1") var udf1: String? = null,
    @SerializedName("udf2") var udf2: String? = null,
    @SerializedName("udf3") var udf3: String? = null,
    @SerializedName("udf4") var udf4: String? = null,
    @SerializedName("udf5") var udf5: String? = null,
    @SerializedName("message") var message: String? = null,
    @SerializedName("expiry_date") var expiryDate: String? = null,
    @SerializedName("operationType1") var operationType1: String? = null,
    @SerializedName("operationType2") var operationType2: String? = null,
    @SerializedName("operationType3") var operationType3: String? = null,
    @SerializedName("operation") var operation: ArrayList<Operation> = arrayListOf(),
    @SerializedName("hash") var hash: String? = null

)

data class Operation(

    @SerializedName("type") var type: String? = null,
    @SerializedName("template") var template: String? = null

)

data class EmailOperation(
    @SerializedName("status") var type: Boolean? = null
)


data class SmsOperation(
    @SerializedName("status") var type: Boolean? = null
)

data class WhatsappOperation(
    @SerializedName("status") var type: Boolean? = null

)

data class Data(

    @SerializedName("sms_operation") var smsOperation: SmsOperation? = SmsOperation(),
    @SerializedName("email_operation") var emailOperation: EmailOperation? = EmailOperation(),
    @SerializedName("whatsapp_operation") var whatsappOperation: WhatsappOperation? = WhatsappOperation(),
    @SerializedName("id") var id: Int? = null,
    @SerializedName("name") var name: String? = null,
    @SerializedName("email") var email: String? = null,
    @SerializedName("amount") var amount: String? = null,
    @SerializedName("merchant_txn") var merchantTxn: String? = null,
    @SerializedName("phone") var phone: String? = null,
    @SerializedName("payment_made") var paymentMade: Int? = null,
    @SerializedName("state") var state: String? = null,
    @SerializedName("sms_count") var smsCount: Int? = null,
    @SerializedName("email_count") var emailCount: Int? = null,
    @SerializedName("message") var message: String? = null,
    @SerializedName("udf1") var udf1: String? = null,
    @SerializedName("udf2") var udf2: String? = null,
    @SerializedName("udf3") var udf3: String? = null,
    @SerializedName("udf4") var udf4: String? = null,
    @SerializedName("udf5") var udf5: String? = null,
    @SerializedName("expiry_date") var expiryDate: String? = null,
    @SerializedName("quick_pay_transaction_date") var quickPayTransactionDate: String? = null,
    @SerializedName("offline_payment_id") var offlinePaymentId: String? = null,
    @SerializedName("offline_payment_desc") var offlinePaymentDesc: String? = null,
    @SerializedName("offline_payment_mode") var offlinePaymentMode: String? = null,
    @SerializedName("created_date") var createdDate: String? = null,
    @SerializedName("updated_date") var updatedDate: String? = null,
    @SerializedName("min_amount") var minAmount: String? = null,
    @SerializedName("max_amount") var maxAmount: String? = null,
    @SerializedName("sms_channel_count") var smsChannelCount: Int? = null,
    @SerializedName("email_channel_count") var emailChannelCount: Int? = null,
    @SerializedName("sms_credit") var smsCredit: Int? = null,
    @SerializedName("email_credit") var emailCredit: Int? = null,
    @SerializedName("transaction_id") var transactionId: String? = null,
    @SerializedName("submerchant_id") var submerchantId: String? = null,
    @SerializedName("whatsapp_count") var whatsappCount: Int? = null,
    @SerializedName("whatsapp_channel_count") var whatsappChannelCount: Int? = null,
    @SerializedName("whatsapp_credit") var whatsappCredit: Int? = null,
    @SerializedName("split_payments") var splitPayments: String? = null,
    @SerializedName("obd_count") var obdCount: Int? = null,
    @SerializedName("obd_credit") var obdCredit: Int? = null,
    @SerializedName("payment_type") var paymentType: String? = null,
    @SerializedName("is_auto_debit_link") var isAutoDebitLink: Boolean? = null,
    @SerializedName("auth_details") var authDetails: String? = null,
    @SerializedName("is_auto_debit_seamless") var isAutoDebitSeamless: Boolean? = null,
    @SerializedName("entity_type") var entityType: String? = null,
    @SerializedName("payment_url") var paymentUrl: String? = null,
    @SerializedName("sms_operation_status") var smsOperationStatus: Boolean? = null,
    @SerializedName("email_operation_status") var emailOperationStatus: Boolean? = null,
    @SerializedName("whatsapp_operation_status") var whatsappOperationStatus: Boolean? = null

)

data class CreatePayMsgLinkResp(

    @SerializedName("cif") var cif: String? = null,
    @SerializedName("acno") var acno: String? = null,
    @SerializedName("brcode") var brcode: String? = null,
    @SerializedName("requested_by") var requestedBy: String? = null,
    @SerializedName("requested_on") var requestedOn: String? = null,
    @SerializedName("requester_brcode") var requesterBrcode: String? = null,
    @SerializedName("status") var status: Boolean? = null,
    @SerializedName("data") var data: Data? = Data(),
    @SerializedName("message") var message: String? = null,
    @SerializedName("error") var error: String? = null


)