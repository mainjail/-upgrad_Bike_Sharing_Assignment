package com.bom.smamonitor.details.tablew.holder;

import android.text.Html;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.ColorRes;
import androidx.core.content.ContextCompat;


import com.bom.smamonitor.R;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractViewHolder;



public class LinkCellViewHolder extends AbstractViewHolder {

    public final TextView cell_textview;
    private final LinearLayout cell_container;

    public LinkCellViewHolder(View itemView) {
        super(itemView);
        cell_textview = itemView.findViewById(R.id.link_cell_data);
        cell_container = itemView.findViewById(R.id.cell_container);

    }

    public void setCellModel(Cell cell, int columnPosition) {
        if(cell.getData()!=null) {
            String cellText = cell.getData().toString();
            cell_textview.setTextColor(ContextCompat.getColor(itemView.getContext(),R.color.colorPrimary));
            cell_textview.setText(Html.fromHtml("<u>" + cellText + "</u>"));
            cell_textview.setClickable(true);

        }else{
            cell_textview.setTextColor(ContextCompat.getColor(itemView.getContext(),R.color.dark_gray));
            cell_textview.setText("NA");
            cell_textview.setClickable(false);
        }
        cell_container.getLayoutParams().width = LinearLayout.LayoutParams.WRAP_CONTENT;
        cell_textview.requestLayout();
    }

    @Override
    public void setSelected(SelectionState selectionState) {
        super.setSelected(selectionState);
//        if (p_nSelectionState == SelectionState.SELECTED) {
//            changeColorOfMoneyTextView(R.color.selected_text_color);
//        } else {
//            changeColorOfMoneyTextView(R.color.unselected_text_color);
//        }
    }

    private void changeColorOfMoneyTextView(@ColorRes int id) {
//        int color = ContextCompat.getColor(cell_textview.getContext(), id);
//        cell_textview.setBaseColor(color);
//        cell_textview.setDecimalsColor(color);
//        cell_textview.setSymbolColor(color);
    }
}
