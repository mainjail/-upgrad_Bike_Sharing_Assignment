

package com.bom.smamonitor.details.tablew.holder;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;

import com.bom.smamonitor.R;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractViewHolder;

/**
 * Created by evrencoskun on 23/10/2017.
 */

public class RowHeaderViewHolder extends AbstractViewHolder {
    @NonNull
    public final TextView row_header_textview;
    public final LinearLayout row_header_container;

    public RowHeaderViewHolder(@NonNull View itemView) {
        super(itemView);
        row_header_container = itemView.findViewById(R.id.row_header_container);
        row_header_textview = itemView.findViewById(R.id.row_header_textview);
    }
}
