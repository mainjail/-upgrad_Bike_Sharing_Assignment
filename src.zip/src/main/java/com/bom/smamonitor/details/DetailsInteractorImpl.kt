package com.bom.smamonitor.details

import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.custlist.model.EnCustAcDetailsObj
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.details.paymentmodels.CreatePayMsgLinkResp
import com.bom.smamonitor.details.paymentmodels.PaymentMsgLinkReq
import com.bom.smamonitor.details.paymentmodels.WhatsAppMessage
import com.bom.smamonitor.details.paymentmodels.WhatsappResponse
import com.bom.smamonitor.network.ApiHelper
import io.reactivex.Observable
import javax.inject.Inject

class DetailsInteractorImpl @Inject internal constructor(
    preferenceHelper: PreferenceHelper,
    apiHelper: ApiHelper
) :
    BaseInteractor(preferenceHelper, apiHelper), DetailsMVPInteractor {

//    override fun getVisits(custNo: String): Observable<List<Visit>>
//    = apiHelper.getVisits(custNo)

    override fun getCustDetails(custNo: String): Observable<EnCustAcDetailsObj> =
        apiHelper.getCustDetails(custNo)

    override fun createPaymentLink(payMsgLinkReq: PaymentMsgLinkReq): Observable<CreatePayMsgLinkResp> =
        apiHelper.createPaymentLink(payMsgLinkReq)

    override fun postWhatsAppMessage(whatsAppMessage: WhatsAppMessage): Observable<WhatsappResponse> =
        apiHelper.postWhatsAppMessage(whatsAppMessage)

    override fun sendSMS(mobileNo:String,custName: String, custNo:String,reportName:String): Observable<WhatsappResponse> =
        apiHelper.sendSMS(mobileNo,custName,custNo,reportName)
//    override fun getUserDetails(): AppUser {
//        return AppUser(
//
//            preferenceHelper.getCurrentUserPfNo().toString(),
//            preferenceHelper.getCurrentUserName().toString(),
//            preferenceHelper.getCurrentBranchCode().toString(),
//            preferenceHelper.getUserRegionCode().toString(),
//            preferenceHelper.getCurrentUserEmail().toString(),
//            "",
//            "",
//            preferenceHelper.getCurrentUserMobileNo().toString(),
//            preferenceHelper.getCurrentDeviceNotificationToken().toString()
//
//        )
//    }
}