/*
 * Copyright (c) 2018. Evren Coşkun
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

package com.bom.smamonitor.details.tablew.holder;

import android.graphics.Typeface;
import android.text.Html;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.bom.smamonitor.R;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractViewHolder;


public class CellViewHolder extends AbstractViewHolder {

    @NonNull
    private final TextView cell_textview;

    @NonNull
    private final LinearLayout cell_container;

    public CellViewHolder(@NonNull View itemView) {
        super(itemView);
        cell_textview = itemView.findViewById(R.id.cell_data);
        cell_container = itemView.findViewById(R.id.cell_container);
    }

    public void setCellModel(Cell cell, int pColumnPosition) {
        //        cell_textview.setGravity(ColumnHeaderViewHolder.COLUMN_TEXT_ALIGNS[pColumnPosition] |
        //                Gravity.CENTER_VERTICAL);
        switch (pColumnPosition) {
            //            case 1:
            //            cell_textview.setGravity(Gravity.End | Gravity.CENTER_VERTICAL);
            //              break;
            case 0:
            default:
                cell_textview.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        }
        cell_textview.setClickable(false);
        try {
            if (cell.getData() != null) {
                String cellTxt = cell.getData().toString();

                if (cellTxt.contains("(")) {
                    String amount1 = cellTxt.substring(0, cellTxt.indexOf('('));
                    int start = cellTxt.indexOf('(');
                    String variation = cellTxt.substring(start + 1, cellTxt.indexOf(')'));

                    if (Double.parseDouble(variation) < 0) {
                        String text = "<font color=#696969>" + amount1 + "</font> "
                                + "<font color=#04BD0C>(" + variation + ")</font>";
                        cell_textview.setText(Html.fromHtml(text));
                    } else {
                        String text = "<font color=#696969>" + amount1 + "  </font> "
                                + "<font color=#f44336> (" + variation + ")</font>";
                        cell_textview.setText(Html.fromHtml(text));
                    }

                } else if(pColumnPosition == 7 && !cellTxt.contains("(")) {

                        if (Double.parseDouble(cell.getData().toString()) < 0) {
                            String text = "<font color=#04BD0C>" + cell.getData().toString() + "</font>";
                            cell_textview.setText(Html.fromHtml(text));
                        } else {
                            String text = "<font color=#f44336>" + cell.getData().toString() + "</font>";
                            cell_textview.setText(Html.fromHtml(text));
                        }

                }else{
                    cell_textview.setText(cell.getData().toString());

                }
            } else
                cell_textview.setText("-");

            cell_container.getLayoutParams().width = LinearLayout.LayoutParams.WRAP_CONTENT;
            cell_textview.requestLayout();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void setCellTypeFace(boolean isLastItem) {
        if (isLastItem)
            cell_textview.setTypeface(Typeface.DEFAULT_BOLD);
        else
            cell_textview.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

    }

    @Override
    public void setSelected(SelectionState selectionState) {
        super.setSelected(selectionState);

        if (selectionState == SelectionState.SELECTED) {
            cell_textview.setTextColor(ContextCompat.getColor(cell_textview.getContext(), R.color
                    .selected_text_color));
        } else {
            cell_textview.setTextColor(ContextCompat.getColor(cell_textview.getContext(), R.color
                    .unselected_text_color));
        }
    }

}
