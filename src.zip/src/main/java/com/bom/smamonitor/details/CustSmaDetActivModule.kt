package com.bom.smamonitor.details

import androidx.recyclerview.widget.LinearLayoutManager
import dagger.Module
import dagger.Provides

@Module
class CustSmaDetActivModule {
    @Provides
    internal fun provideViewCircInteractor(interactor: DetailsInteractorImpl): DetailsMVPInteractor = interactor

    @Provides
    internal fun provideViewCircPresenter(presenter: DetailsPresenterImpl<DetailsMVPView, DetailsMVPInteractor>)
            : DetailsMVPPresenter<DetailsMVPView, DetailsMVPInteractor> = presenter

    @Provides
    internal fun provideAdapter(activity : CustDetailsSmaActivity): VisitsAdapter = VisitsAdapter(activity)

    @Provides
    internal fun provideLinearLayoutManager(activity: CustDetailsSmaActivity):
            LinearLayoutManager = LinearLayoutManager(activity)
}