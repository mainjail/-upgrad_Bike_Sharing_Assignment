package com.bom.smamonitor.details

import com.bom.smamonitor.base.presenter.MVPPresenter
import com.bom.smamonitor.details.paymentmodels.CreatePayMsgLinkResp
import com.bom.smamonitor.details.paymentmodels.PaymentMsgLinkReq
import com.bom.smamonitor.details.paymentmodels.WhatsAppMessage


interface DetailsMVPPresenter<V : DetailsMVPView, I : DetailsMVPInteractor> :
        MVPPresenter<V, I> {
//     fun getVisits(custNo: String)
    fun getCustDetails(custNo:String)
    fun getUserData(): Unit?
    fun createPaymentLink(payMsgLinkReq: PaymentMsgLinkReq)
    fun sendSMS(mobileNo:String, custName: String, custNo:String,reportName:String)

    fun postWhatsAppMsg(whatsAppMessage: WhatsAppMessage)
}