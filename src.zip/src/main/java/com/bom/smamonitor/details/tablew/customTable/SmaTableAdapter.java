package com.bom.smamonitor.details.tablew.customTable;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bom.smamonitor.R;
import com.bom.smamonitor.custlist.model.CustAcDetails;
import com.bom.smamonitor.details.tablew.holder.CellViewHolder;
import com.bom.smamonitor.details.tablew.holder.ColumnHeaderViewHolder;
import com.bom.smamonitor.details.tablew.holder.RowHeaderViewHolder;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.ColumnHeaderModel;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;
import com.bom.smamonitor.npa.modelNpa.NpaAccount;
import com.evrencoskun.tableview.adapter.AbstractTableAdapter;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractSorterViewHolder;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractViewHolder;
import com.evrencoskun.tableview.sort.SortState;

import org.jetbrains.annotations.NotNull;

import java.util.List;


public class SmaTableAdapter extends AbstractTableAdapter<ColumnHeaderModel, RowHeaderModel, Cell> {
    // Cell View Types by Column Position
    private static final int LINK_CELL_TYPE = 3;
    private static final int LINK_CELL_TYPE2 = 4;

    private static final int VIEW_CELL_TYPE = 9;
    // add new one if it necessary..

    private static final String LOG_TAG = SmaTableAdapter.class.getSimpleName();

    @NonNull
    private final SmaAccountTableVM mTableViewModel;

    public SmaTableAdapter(@NonNull SmaAccountTableVM tableViewModel) {
        super();
        this.mTableViewModel = tableViewModel;
    }

    @NonNull
    @Override
    public AbstractViewHolder onCreateCellViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.e(LOG_TAG, " onCreateCellViewHolder has been called");
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View layout;
        layout = inflater.inflate(R.layout.table_view_cell_layout, parent, false);
        return new CellViewHolder(layout);
    }

    /**
     * That is where you set Cell View Model data to your custom Cell ViewHolder. This method is
     * Called by Cell RecyclerView of the TableView to display the data at the specified position.
     * This method gives you everything you need about a cell item.
     *
     * @param holder         : This is one of your cell ViewHolders that was created on
     *                       ```onCreateCellViewHolder``` method. In this example we have created
     *                       "CellViewHolder" holder.
     * @param cellItemModel  : This is the cell view model located on this X and Y position. In this
     *                       example, the model class is "Cell".
     * @param columnPosition : This is the X (Column) position of the cell item.
     * @param rowPosition    : This is the Y (Row) position of the cell item.
     * @see #onCreateCellViewHolder(ViewGroup, int) ;
     */

    @Override
    public void onBindCellViewHolder(@NonNull AbstractViewHolder holder, @Nullable Cell cellItemModel, int
            columnPosition, int rowPosition) {
        CellViewHolder viewHolder = (CellViewHolder) holder;
        viewHolder.setCellModel(cellItemModel, columnPosition);
    }

    @NotNull
    @Override
    public AbstractSorterViewHolder onCreateColumnHeaderViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout
                .table_view_column_header_layout, parent, false);
        return new ColumnHeaderViewHolder(layout, getTableView());
    }

    @Override
    public void onBindColumnHeaderViewHolder(@NonNull AbstractViewHolder holder, @Nullable ColumnHeaderModel columnHeaderItemModel,
                                             int columnPosition) {
        ColumnHeaderViewHolder columnHeaderViewHolder = (ColumnHeaderViewHolder) holder;
        columnHeaderViewHolder.setColumnHeaderModel(columnHeaderItemModel, columnPosition);
    }

    @NotNull
    @Override
    public AbstractViewHolder onCreateRowHeaderViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.table_view_row_header_layout,
                parent, false);
        return new RowHeaderViewHolder(layout);
    }

    @Override
    public void onBindRowHeaderViewHolder(@NonNull AbstractViewHolder holder,
                                          @Nullable RowHeaderModel rowHeaderItemModel,
                                          int rowPosition) {
        RowHeaderViewHolder rowHeaderViewHolder = (RowHeaderViewHolder) holder;
        rowHeaderViewHolder.row_header_textview.setText(String.valueOf(rowHeaderItemModel.getData()));
    }


    @NonNull
    @Override
    public View onCreateCornerView(@NonNull ViewGroup parent) {
        View corner = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.table_view_corner_layout, parent, false);
        corner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SortState sortState = SmaTableAdapter.this.getTableView()
                        .getRowHeaderSortingStatus();
                if (sortState != SortState.ASCENDING) {
                    Log.d("TableViewAdapter", "Order Ascending");
                    SmaTableAdapter.this.getTableView().sortRowHeader(SortState.ASCENDING);
                } else {
                    Log.d("TableViewAdapter", "Order Descending");
                    SmaTableAdapter.this.getTableView().sortRowHeader(SortState.DESCENDING);
                }
            }
        });

        return corner;
    }

    @Override
    public int getColumnHeaderItemViewType(int position) {
        return 0;
    }

    @Override
    public int getRowHeaderItemViewType(int position) {
        return 0;
    }

    @Override
    public int getCellItemViewType(int position) {
//        return MyTableViewModel.getCellItemViewType(position);
        // The unique ID for this type of cell item
        // If you have different items for Cell View by X (Column) position,
        // then you should fill this method to be able create different
        // type of CellViewHolder on "onCreateCellViewHolder"
        switch (position) {
            case MyTableViewModel.LINK_COLUMN_INDEX2:
                return LINK_CELL_TYPE2;
            default:
                return 0;
        }
    }

    public void setUserList(List<CustAcDetails> userList) {
        mTableViewModel.generateListForTableView(userList);
        setAllItems(mTableViewModel.getColumnHeaderModeList(),
                mTableViewModel.getRowHeaderModelList(),
                mTableViewModel.getCellModelList());
    }

}
