package com.bom.smamonitor.details.tablew.models;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;



/**
 */

public class ColumnHeaderModel  extends Cell
{
    public ColumnHeaderModel(@NonNull String id, @Nullable String data) {
        super(id, data);
    }
}
