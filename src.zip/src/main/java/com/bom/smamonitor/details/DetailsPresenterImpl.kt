package com.bom.smamonitor.details

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import com.androidnetworking.error.ANError
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.bzsummary.DataObj
import com.bom.smamonitor.custlist.model.CustAcDetailsObj
import com.bom.smamonitor.custlist.model.EnCustAcDetailsObj
import com.bom.smamonitor.details.paymentmodels.CreatePayMsgLinkResp
import com.bom.smamonitor.details.paymentmodels.PaymentMsgLinkReq
import com.bom.smamonitor.details.paymentmodels.WhatsAppMessage
import com.bom.smamonitor.details.paymentmodels.WhatsappResponse
import com.bom.smamonitor.network.CryptoClass
import com.bom.smamonitor.util.SchedulerProvider
import com.google.gson.Gson
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

class DetailsPresenterImpl<V:DetailsMVPView,I:DetailsMVPInteractor>
@Inject internal constructor(
        interactor: I,
        schedulerProvider: SchedulerProvider,
        disposable: CompositeDisposable) : BasePresenter<V, I>(
    interactor = interactor,
    schedulerProvider = schedulerProvider,
    compositeDisposable = disposable
),
    DetailsMVPPresenter<V, I> {
    val TAG = "ViewCircPresenterImpl"

    override fun getUserData() = interactor?.let {
        val userData = it.getUserFromSharedPref()
        getView()?.loginUserDetails(userData!!)
    }

//    override fun getVisits(custNo: String) {
//
//        getView()?.showProgress()
//        interactor?.let {
//            it.getVisits(custNo)
//                .compose(schedulerProvider.ioToMainObservableScheduler())
//                .subscribe({ visitsList: List<Visit> ->
//                    println("Visits Results:-$visitsList")
//                    getView()?.hideProgress()
//                    getView()?.displayVisits(visitsList)
//                }, { error ->
//                    val aNError = error as ANError
//                    Log.d("DetailsPresImpl", aNError.message.toString())
//                    getView()?.hideProgress()
//                    getView()?.showError(aNError.errorDetail.toString())
//                })
//        }
//    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun getCustDetails(custNo: String) {
        getView()?.showProgress()
        interactor?.let {
            it.getCustDetails(custNo)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ enCustAcDetailObj: EnCustAcDetailsObj ->

                    try {
//                        Log.d(TAG, "EncryptedObj Results:-${enCustAcDetailObj.enCustDetailsObj}")


                        val decText: String =
                            CryptoClass.decryptFromHex(enCustAcDetailObj.enCustDetailsObj)!!
//                          Log.d(TAG, "Decrypted Text : $decText")

                        val custAcDetailObj: CustAcDetailsObj =
                            Gson().fromJson(decText, CustAcDetailsObj::class.java)
//                        println("getCustDetails Results:-$custAcDetailObj")

                        getView()?.hideProgress()
                        getView()?.displayCustAcDetails(custAcDetailObj)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("getCustDetails", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }


    override fun createPaymentLink(payMsgLinkReq: PaymentMsgLinkReq) {

        getView()?.showProgress()
        interactor?.let {
            it.createPaymentLink(payMsgLinkReq)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ payLinkResp: CreatePayMsgLinkResp ->
                    try {
                       Log.d(TAG, "createPaymentLink Results:-${payLinkResp.toString()}")
                        getView()?.hideProgress()
                        getView()?.displayPaymentLinkSuccess(payLinkResp)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("createPaymentLink ", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun postWhatsAppMsg(whatsAppMessage: WhatsAppMessage) {

        getView()?.showProgress()
        interactor?.let {
            it.postWhatsAppMessage(whatsAppMessage)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ whatsAppResponse: WhatsappResponse ->
                    try {
                        Log.d(TAG, "postWhatsAppMsg Results:-${whatsAppResponse.toString()}")
                        getView()?.hideProgress()
                        getView()?.displayWhatsAppMsgSuccess(whatsAppResponse)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("postWhatsAppMsg ", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun sendSMS(mobileNo:String,custName: String, custNo:String,reportName:String) {

        getView()?.showProgress()
        interactor?.let {
            it.sendSMS(mobileNo,custName,custNo,reportName)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ whatsAppResponse: WhatsappResponse ->
                    try {
                        Log.d(TAG, "sendSMS Results:-${whatsAppResponse.toString()}")
                        getView()?.hideProgress()
                        getView()?.displayWhatsAppMsgSuccess(whatsAppResponse)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("sendSMS ", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }
}