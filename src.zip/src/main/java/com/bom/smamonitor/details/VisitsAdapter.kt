package com.bom.smamonitor.details

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ShareCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.util.CustomDialog
import kotlinx.android.synthetic.main.item_visit_layout.view.*
import java.io.File
import java.io.FileWriter
import java.util.*


class VisitsAdapter(val activity: Activity) :
    RecyclerView.Adapter<VisitsAdapter.VisitsViewHolder>() {

    private var visitsList = listOf<SmaVisit>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VisitsViewHolder {
        return VisitsViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_visit_layout, parent, false
            )
        )
    }

    override fun getItemCount(): Int = visitsList.size

    override fun onBindViewHolder(holder: VisitsViewHolder, position: Int) {

        try {
            holder.onBind(position)

            val visit = visitsList[position]
            var location = "Not Available"

            if (visit.latitude.isNotEmpty())
                location = getAddress(
                    context = activity,
                    visit.latitude.toDouble(),
                    visit.longitude.toDouble()
                )

            val visitReport = "Remarks Date : ${visit.visitDate.substring(0, 10)}" + "\n" +
                    "Customer : ${visit.custNo} - ${visit.custName.capitalize(Locale.getDefault())}" + "\n" +
                    "Field Officer :  ${visit.visitorPfNo + "-"+ visit.visitorName.capitalize(Locale.getDefault())}" + "\n" +
                    "Promise To Pay Date :  ${visit.ptpDate}" + "\n\n" +
                    "Collection Action: ${visit.collectionAction} \n\n"+
                    "\nField Officer Location :${location.capitalize(Locale.getDefault())}" + "\n\n" +
                    "Remarks: ${visit.comments}"


            holder.itemView.visitCommentsTv.setOnClickListener {
                CustomDialog().showAlertWithTitle(activity, visitReport, "Remark Details")
            }

            holder.itemView.visitShareIv.setOnClickListener {
                shareAsPlainText(visitReport)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    internal fun setVisitsList(listOfMovies: List<SmaVisit>) {
        this.visitsList = listOfMovies
        notifyDataSetChanged()
    }

    inner class VisitsViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        @SuppressLint("SetTextI18n")
        fun onBind(position: Int) {
            try {
                val visit = visitsList[position]
                val visitDate = visit.visitDate.substring(0, 10)
                itemView.visitDateTv.text = visitDate
                itemView.visitCommentsTv.text = visit.comments

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }

    private fun createTextFile(reportTxt: String) {
//        val root = File(activity.filesDir, "text")
//        val root1: File = File(Environment.getExternalStorageDirectory(), "Notes")
        val root = File(activity.getExternalFilesDir("text"), "visits")
        if (!root.exists()) {
            root.mkdir()
        }
        try {
//            /data/user/0/com.bom.recovery/files/text
            val gpxFile = File(root, "report.txt")
//            /data/user/0/com.bom.recovery/files/text/report
            val writer = FileWriter(gpxFile)
            writer.append(reportTxt + "\n\n")
            writer.flush()
            writer.close()
            shareTextFile(gpxFile, reportTxt)
            Toast.makeText(activity, "Saved your text", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun shareTextFile(file: File, text: String) {
//        /data/user/0/com.bom.recovery/files/text/sample
        try {
//                val share = Intent.createChooser(Intent().apply {
//                    action = Intent.ACTION_SEND
////                    type = "text/*"
//                    type = "text/plain"
//
////                    putExtra(Intent.EXTRA_TEXT, text)
//                    // (Optional) Here we're setting the title of the content
//                    putExtra(Intent.EXTRA_TITLE, "Introducing content previews")
//                    // (Optional) Here we're passing a content URI to an image to be displayed
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
////                        val contentUri = FileProvider.getUriForFile(getContext(), "com.your.package.fileProvider", newFile)
//                        val contentUri = FileProvider.getUriForFile(activity, activity.applicationContext.packageName.toString() + ".provider", file)
//                        data = contentUri
//                    } else {
//                        data = Uri.fromFile(file)
//                    }
//                    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
//                }, null)
//                activity.startActivity(share)


            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "text/*"
            val photoURI = FileProvider.getUriForFile(
                activity,
                activity.applicationContext.packageName.toString() + ".provider",
                file
            )
            sharingIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse(photoURI.toString()))
            activity.startActivity(Intent.createChooser(sharingIntent, "share file with"))

//        val shareIntent = ShareCompat.IntentBuilder.from(this@AddVisitActivity)
//                .setType("text/plain")
//                .setText(shareText)
//                .intent
//        if (shareIntent.resolveActivity(packageManager) != null) {
//            startActivity(shareIntent)
//        }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun shareAsPlainText(reportText: String) {
        try {
//                val shareIntent = Intent.createChooser(Intent().apply {
//                    action = Intent.ACTION_SEND
//                    type = "text/*"

//                    type = "text/plain"
////                    putExtra(Intent.EXTRA_TEXT, text)
//                    // (Optional) Here we're setting the title of the content
//                    putExtra(Intent.EXTRA_TITLE, "Introducing content previews")
//                    // (Optional) Here we're passing a content URI to an image to be displayed
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
////                        val contentUri = FileProvider.getUriForFile(getContext(), "com.your.package.fileProvider", newFile)
//                        val contentUri = FileProvider.getUriForFile(activity, activity.applicationContext.packageName.toString() + ".provider", file)
//                        data = contentUri
//                    } else {
//                        data = Uri.fromFile(file)
//                    }
//                    flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
//                }, null)
//            shareIntent.putExtra(Intent.EXTRA_TEXT,reportText)
//            activity.startActivity(shareIntent)

            val shareIntent = ShareCompat.IntentBuilder.from(activity)
                .setType("text/plain")
                .setText(reportText)
                .intent
            if (shareIntent.resolveActivity(activity.packageManager) != null) {
                activity.startActivity(shareIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getAddress(context: Context, latitude: Double, longitude: Double): String {
        val geoCoder = Geocoder(context, Locale.getDefault())
        val addresses: List<Address>?
        val address: Address?
        var fulladdress = ""
        addresses = geoCoder.getFromLocation(latitude, longitude, 1)

        if (addresses.isNotEmpty()) {
            address = addresses[0]
            fulladdress =
                address.getAddressLine(0) // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex
            var city = address.locality
            var state = address.adminArea
            var country = address.countryName
            var postalCode = address.postalCode
            var knownName = address.featureName // Only if available else return NULL
        } else {
            fulladdress = "Location not found"
        }
        return fulladdress
    }


}