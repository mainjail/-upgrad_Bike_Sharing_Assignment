package com.bom.smamonitor.details

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.*
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.updateLayoutParams
import com.bom.smamonitor.R
import com.bom.smamonitor.addVisit.AddVisitActivity
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.custlist.model.CustAcDetails
import com.bom.smamonitor.custlist.model.CustAcDetailsObj
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.details.paymentmodels.*
import com.bom.smamonitor.details.tablew.customTable.*
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.network.ApiEndPoint.SHA512_ALGO_KEY
import com.bom.smamonitor.network.ApiEndPoint.SHA512_ALGO_SALT
import com.bom.smamonitor.pastvisit.PastVisitListActivity
import com.bom.smamonitor.util.CommonUtil
import com.bom.smamonitor.util.CommonUtil.makeACall
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.DateUtil
import com.bom.smamonitor.util.DateUtil.getDateAfterAddingDays
import com.bom.smamonitor.util.ValidationUtils
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_cust_sma_details.*
import kotlinx.android.synthetic.main.activity_cust_sma_details.view.*
import kotlinx.android.synthetic.main.custom_dialog_acct_pay.view.*
import kotlinx.android.synthetic.main.custom_dialog_layout.view.ivError
import kotlinx.android.synthetic.main.item_suggestionaction.view.*
import java.security.MessageDigest
import java.util.*
import javax.inject.Inject
import kotlin.collections.ArrayList


class CustDetailsSmaActivity : BaseActivity(), DetailsMVPView {


    var custAcListGlobal: MutableList<CustAcDetails> = mutableListOf()

    private var customerMobileNo: String? = null
    private var accountNoForPayment = ""
    private lateinit var custAcDetailsObjIntent: CustAcDetailsObj
    private lateinit var user: AppUser
    private lateinit var tableViewAdapter: SmaTableAdapter
    private var branchCode = ""


    @Inject
    internal lateinit var presenter: DetailsMVPPresenter<DetailsMVPView, DetailsMVPInteractor>
//    private var accountsList: ArrayList<NpaAccount?>? = ArrayList()
//    private var tableInputList: ArrayList<NpaAccount?>? = ArrayList()

    private lateinit var customer: CustomerRep2

    var todayDateString: String? = null

    //    @Inject
//    internal lateinit var visitsAdapter: VisitsAdapter
//
//    @Inject
//    internal lateinit var layoutManager: LinearLayoutManager
    private val anim: Animation = AlphaAnimation(0.0f, 1.0f)

    private val String.capitalizeWords
        get() = this.lowercase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cust_sma_details)
        presenter.onAttach(this)
        supportActionBar?.title = resources.getString(R.string.Details)
        initView()

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        //val inflater = menuInflater
//        inflater.inflate(R.menu.menu_visit, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_add_visit -> CustomDialog().popUpToast(
                activity = this,
                getString(R.string.funcComing)
            )
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return true
    }

    @RequiresApi(Build.VERSION_CODES.O)
    @SuppressLint("SetTextI18n")
    private fun initView() {

        val strObj = intent.getStringExtra("smacustomer")
        branchCode = intent.getStringExtra("customerBranchCode").toString()
        val cust: CustomerRep2 = Gson().fromJson(strObj, CustomerRep2::class.java)
        val smaFlag = cust.smaFlag
        customer = cust
        initializeTableView()
        customerNameTv.text = customer.custName.trim()
        custNoTv.text = customer.cif


        Log.d("CustDetailsSMAActivity","MobileNo ="+customer.mobNo)
     //   if (customer.mobNo != "null" || customer.mobNo != null) {
        if (customer.mobNo != null) {
            Log.d("CustDetailsSMAActivity1","MobileNo ="+customer.mobNo)
            mobileNoTv.text = "+91-" + customer.mobNo
            customerMobileNo = normalizeMobileNumber(customer.mobNo)
        } else{
            mobileNoTv.text = "-"
        }

        if (customer.mobNo == null) {
            mobileNoTv.text = "-"
        }
        if (customer.lat != null || customer.long != null) {
            custAddressTv.text = CommonUtil.getAddressFromLatLong(
                this,
                customer.lat.toDouble(),
                customer.long.toDouble()
            )
        } else if (customer.postcode != null) {

            var address = ""
            if (customer.add1 != null) {
                address += customer.add1.trim() + " "
            }
            if (customer.add2 != null) {
                address += customer.add2.trim() + " "
            }
            if (customer.add3 != null) {
                address += customer.add3.trim() + " "
            }
            address += customer.postcode
            custAddressTv.text = address.capitalizeWords

        } else {
            custAddressTv.visibility = View.GONE
        }


        presenter.getUserData()

        apiCallForCustomerDetails()

        anim.duration = 500 //You can manage the blinking time with this parameter
        anim.startOffset = 20
        anim.repeatMode = Animation.REVERSE
        anim.repeatCount = Animation.INFINITE
        reportNameTv.startAnimation(anim)

        todayDateString = DateUtil.getTodaysDateTime()

        smaCallIV.setOnClickListener {
            if (customer.mobNo != null) {
                makeACall(customer.mobNo, this)
            } else {
                CustomDialog().popUpToast(this, "Mobile number not available.")
            }
        }
        addRemarksBtn.setOnClickListener {
            try {
                val intent = Intent(this, AddVisitActivity::class.java)
                intent.putExtra("custAcDetailsObj", Gson().toJson(custAcDetailsObjIntent))
                intent.putExtra("smaCustomer", Gson().toJson(customer))
                intent.putExtra("customerBranchCode", branchCode)

                startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        viewPastVisits.setOnClickListener {
            try {
                val intent = Intent(this, PastVisitListActivity::class.java)
//                intent.putExtra("custAcDetailsObj", Gson().toJson(custAcDetailsObjIntent))
                intent.putExtra("smaCustomer", Gson().toJson(customer))
                startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }


//        if (customer.address != null) {
//            val address = customer.address!!
//            custAddressTv.text = address.add1?.capitalizeWords + ", " +
//                    address.add2?.capitalizeWords + ", " +
//                    address.add3?.capitalizeWords + ", " +
//                    address.add4?.capitalizeWords + " - " +
//                    address.postcode
//        }

//        custAddressTv.setOnClickListener {
//            if (customer.address != null) {
//                val address = customer.address!!
//                val addSearch = address.add1?.capitalizeWords +
//                        address.add2?.capitalizeWords +
//                        address.add3?.capitalizeWords +
//                        address.add4?.capitalizeWords
//                openMapSearchAddress(addSearch)
//            }
//        }
    }

    private fun normalizeMobileNumber(inputNumber: String): String? {
        Log.d("CustDetailsSMAActivity1","normalizeMobileNumber ="+inputNumber)
        // Remove any non-digit characters
        val digitsOnly = inputNumber.replace(Regex("[^0-9]"), "")

        // Check if the resulting string is 10 digits long
        if (digitsOnly.length == 10) {
            return digitsOnly // It's already 10 digits, return as is
        } else if (digitsOnly.startsWith("91") && digitsOnly.length == 12) {
            // If it starts with "91" and is 12 digits long, remove the "91" and return the remaining 10 digits
            return digitsOnly.substring(2)
        } else if (digitsOnly.startsWith("+91") && digitsOnly.length == 13) {
            // If it starts with "+91" and is 13 digits long, remove the "+91" and return the remaining 10 digits
            return digitsOnly.substring(3)
        }

        // Not a valid mobile number format
        return null
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setSuggestionActionsView(reportName: String) {
        var msg = ""
        Log.d("CUSTDETAils", "CustCIF=${customer.cif.trim()}")
        var custCif = "XXXX" + customer.cif.trim().substring(7, customer.cif.trim().length)
        Log.d("CUSTDETAils", "CustCif = $custCif ")
        msg =
            "Dear " + customer.custName.trim() + " , Due to Non-Payment of regular instalment or interest, your Cust No. " + custCif + " is in default. Please make payment immediately to avoid penalty and Legal Action - MAHABANK"

        when (reportName) {
            "SMA0" -> {
                msg =
                    "Dear " + customer.custName.trim() + " , Due to Non-Payment of regular instalment or interest, your Cust no. " + custCif + " is in default and is appearing in SMA-0. Please make payment immediately to avoid penalty.– MAHABANK"
                cardViewSugAct.sugActnLL1.whatsAppLL.imgSugActIV3.startAnimation(anim)
                cardViewSugAct.sugActnLL1.SMSLL.imgSugActIV2.startAnimation(anim)
            }
            "SMA1" -> {
                msg =
                    "Dear " + customer.custName.trim() + "  , Due to Non-Payment of regular instalment or interest, your Cust no. " + custCif + " is in default and is appearing in SMA-1. Please make payment immediately to avoid penalty.– MAHABANK"
                cardViewSugAct.sugActnLL1.callLL.imgSugActIV1.startAnimation(anim)
            }
            "SMA2" -> {
                msg =
                    "Dear " + customer.custName.trim() + " , Due to Non-Payment of regular instalment or interest, your Cust No. " + custCif + " is in default and is appearing in SMA-2. Please make payment immediately to avoid penalty and Legal Action - MAHABANK"
                cardViewSugAct.sugActnLL1.visitLL.imgSugActIV4.startAnimation(anim)
            }
            "Report6" -> {
                cardViewSugAct.sugActnLL1.visitLL.imgSugActIV4.startAnimation(anim)
            }
            "Report7" -> {
                cardViewSugAct.sugActnLL1.visitLL.imgSugActIV4.startAnimation(anim)
            }
            "NPA" -> {
                cardViewSugAct.sugActnLL1.visitLL.imgSugActIV4.startAnimation(anim)
            }
            "" -> {
                msg =
                    "Dear " + customer.custName.trim() + " , Due to Non-Payment of regular instalment or interest, your Cust No. " + custCif + " is in default. Please make payment immediately to avoid penalty and Legal Action - MAHABANK"
            }
            else -> {
                cardViewSugAct.sugActnLL1.visitLL.imgSugActIV4.startAnimation(anim)
            }

        }

        cardViewSugAct.sugActnLL1.callLL.setOnClickListener {
            if (customer.mobNo != null) {
                makeACall(customer.mobNo, this)
            } else {
                CustomDialog().popUpToast(this, "Mobile number not available.")
            }
        }

        cardViewSugAct.sugActnLL1.SMSLL.setOnClickListener {
            var custNo = "XXXX" + customer.cif.trim().substring(7, customer.cif.trim().length)
            var reportName = reportNameTv.text.toString()

//            Please make payment immediately to avoid penalty and Legal Action - MAHABANK'
            if (customer.mobNo != null) {
                //sendASMS(customer.mobNo, msg, this)
               presenter.sendSMS(customer.mobNo,customer.custName.trim(),custNo,reportName)
            } else {
                CustomDialog().popUpToast(this, "Mobile number not available.")
            }
        }

        cardViewSugAct.sugActnLL1.visitLL.imgSugActIV4.setOnClickListener {
            addRemarksBtn.callOnClick()
        }

        cardViewSugAct.sugActnLL1.whatsAppLL.imgSugActIV3.setOnClickListener {
            // For whats App Mobile no Accepted is +919890802231
            customerMobileNo = normalizeMobileNumber(customer.mobNo)
            customerMobileNo = "7588590660"         // this is hard coded for testing remove in production
            customerMobileNo = "9890802231"         // this is hard coded for testing remove in production

            var body = Body(text = accountNoForPayment)
            var bodyList = ArrayList<Body>();
            bodyList.add(body)

            if (customer.mobNo != null) {
                var media = Media(
                    type = "media_template",
                    templateName = "non_payment_instalment",
                    langCode = "en",
                    body = bodyList
                )
                var message = Message(
                    phone = "+91$customerMobileNo",  //"+91" + "9890802231",
                    extra = null,
                    media = media
                )
                var whatsAppMessage = WhatsAppMessage(
                    cif = customer.cif,
                    custMbNo = "+91$customerMobileNo",// "+91" + "7588590660",
                    brCode = customer.brCode,
                    sentBy = user.pfNo,
                    sentOn = todayDateString,
                    senderMbNo = user.mobileNo,
                    msgText = null,
                    msgType = "media_template",
                    msgTemplateName = "non_payment_instalment",
                    msgLangCode = "en",
                    respMessage = null,
                    respStatus = null,
                    respRequestId = null,
                    respReason = null,
                    message = message
                )
                presenter.postWhatsAppMsg(whatsAppMessage)
                //openWhatsApp("+91-" + customer.mobNo, msg, this)
            } else {
                CustomDialog().popUpToast(this, "Mobile number not available.")
            }

        }

//        payNowLL.setOnClickListener {
//            openAcctSelectionDialogue(this)
//        }

    }

    private lateinit var actsAdapter: ArrayAdapter<CustAcDetails>

    @SuppressLint("NewApi")
    @RequiresApi(Build.VERSION_CODES.N)
    private fun openAcctSelectionDialogue(context: Context) {

        var selectedObject: CustAcDetails
        var overdueAmt = 0.0
        val layoutInflater: LayoutInflater = this.layoutInflater

        val dialogView = layoutInflater.inflate(R.layout.custom_dialog_acct_pay, null)

        custAcListGlobal.removeIf { custAcct -> custAcct.overdue.toDouble() < 0 }

        actsAdapter =
            ArrayAdapter<CustAcDetails>(
                this@CustDetailsSmaActivity,
                android.R.layout.simple_list_item_1,
                custAcListGlobal
            )
        dialogView.accSpinner.adapter = actsAdapter

        val customDialog = AlertDialog.Builder(this).setView(dialogView).show()
//        dialogView.tvDialogTitle.setText("")
        val sendLinkBtn = dialogView.findViewById<AppCompatButton>(R.id.btnOK)

        sendLinkBtn.setOnClickListener {
            customDialog.dismiss()
            if (customer.mobNo != null) {
                customerMobileNo = normalizeMobileNumber(customer.mobNo)
                customerMobileNo =
                    "7588590660"  //  hard coded for testing remove in production
                customerMobileNo = "8552033043" //HArdoded for testing remove in production

                val expiryDate = getDateAfterAddingDays(5)
                var payMsgLinkReq = PaymentMsgLinkReq(
                    cif = customer.cif,
                    acno = accountNoForPayment,
                    brcode = customer.brCode,
                    requestedBy = user.pfNo,
                    requestedOn = todayDateString,
                    merchantTxn = "CREMON" + user.pfNo + customer.cif.substring(
                        7,
                        11
                    ) + customer.brCode,
                    key = SHA512_ALGO_KEY,
                    email = "smita.ranveer1@gmail.com", // "syergude@gmail.com",
                    name = customer.custName,
                    amount = overdueAmt.toString(), //"10.0",  // Modify amount as required
                    phone = customerMobileNo,
                    udf1 = "testBom",
                    udf2 = "Arjun",
                    udf3 = "",
                    udf4 = "",
                    udf5 = "",
                    message = "ArjunDemo",
                    expiryDate = expiryDate, // make it todays date +5days
                    operationType1 = "sms",
                    operationType2 = "email",
                    operationType3 = "whatsapp",
                    hash = ""
                )
                var key = SHA512_ALGO_KEY
                var salt = SHA512_ALGO_SALT
                //// key|merchant_txn|name|email|phone|amount|udf1|udf2|udf3|udf4|udf5|message|salt
                // -----hash sequence to be generated--------
                //// Append the fields with pipe ('|') separator
                var appendedString =
                    "${key}|${payMsgLinkReq.merchantTxn}|${payMsgLinkReq.name}|${payMsgLinkReq.email}|${payMsgLinkReq.phone}|${payMsgLinkReq.amount}|${payMsgLinkReq.udf1}|${payMsgLinkReq.udf2}|${payMsgLinkReq.udf3}|${payMsgLinkReq.udf4}|${payMsgLinkReq.udf5}|${payMsgLinkReq.message}|${salt}";

                val sha512Hash: String = generateSha512Hash(appendedString)
                payMsgLinkReq.hash = sha512Hash
                println("SHA-512 Hash: $sha512Hash")
                callPaymentApi(payMsgLinkReq)
            } else {
                CustomDialog().popUpToast(this, "Customer Mobile number not available.")
            }
        }

        dialogView.accSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
                // You can define your actions as you want
            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                selectedObject = dialogView.accSpinner.selectedItem as CustAcDetails
                accountNoForPayment = selectedObject.acNo
                overdueAmt = selectedObject.overdue.toDouble()
                dialogView.overdueAmtTv.text = selectedObject.overdue
            }
        }

    }


    private fun generateSha512Hash(msgInput: String): String {
        try {
            val md = MessageDigest.getInstance("SHA-512")
            val bytes = md.digest(msgInput.toByteArray())
            val hexString = StringBuilder()
            for (byte in bytes) {
                hexString.append(String.format("%02x", byte))
            }
            return hexString.toString()
        } catch (ex: Exception) {
            ex.printStackTrace()
            throw ex
        }
    }

    private fun callPaymentApi(payMsgLinkReq: PaymentMsgLinkReq) {
        presenter.createPaymentLink(payMsgLinkReq)
    }

    override fun displayPaymentLinkSuccess(payMsgLinkResp: CreatePayMsgLinkResp) {
        Toast.makeText(this, payMsgLinkResp.message, Toast.LENGTH_LONG).show()
    }

    override fun displayWhatsAppMsgSuccess(whatsappResponse: WhatsappResponse) {
        Toast.makeText(this, whatsappResponse.message, Toast.LENGTH_LONG).show()
    }

    private fun apiCallForCustomerDetails() {
        if (customer.cif.isNotEmpty() && ValidationUtils.isNetworkAvailable(this))
            presenter.getCustDetails(customer.cif)
        else CustomDialog().showNoInternetAlert(this, "")
    }

    private fun isDateNull(date: String): String {
        return if (date.contains("1899"))
            "-"
        else
            date
    }

    private fun initializeTableView() {
        val tableViewModel = SmaAccountTableVM()
        tableViewAdapter = SmaTableAdapter(tableViewModel)
        tableView1.setAdapter(tableViewAdapter)
        val myTableViewListener = MyTableViewListener(tableView1)
        tableView1.tableViewListener = myTableViewListener
    }

    private fun setHeightToTable(listSize: Int) {
        Log.d("DetailActivity", "listSize${listSize}")
        val displayMetrics = DisplayMetrics()
        this.windowManager.defaultDisplay.getMetrics(displayMetrics)
        val deviceWidth = displayMetrics.widthPixels / 3
//        val layoutParams: ViewGroup.LayoutParams = tableViewAdapter.getCellItemViewType().getLayoutParams()
//        layoutParams.height = (DocPath.parent.getHeight() * 0.3)
        val deviceHeight = displayMetrics.heightPixels / 4
        when {
            listSize < 3 -> tableView1.updateLayoutParams { height = 400 }
            listSize in 4..5 -> tableView1.updateLayoutParams { height = 800 }
            listSize in 6..8 -> tableView1.updateLayoutParams { height = 1200 }
            else -> tableView1.updateLayoutParams { height = 1600 }
        }
        tableContainer.updateLayoutParams { height = ViewGroup.LayoutParams.WRAP_CONTENT }
        tableContainerCard.updateLayoutParams { height = ViewGroup.LayoutParams.WRAP_CONTENT }
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

//    private fun makeACall(number: String) {
//        val intent = Intent(Intent.ACTION_DIAL)
//        intent.data = Uri.parse("tel:$number")
//        startActivity(intent)
//    }

    override fun showError(errorMsg: String) {
        CustomDialog().popUpToast(this@CustDetailsSmaActivity, errorMsg)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun displayCustAcDetails(custAcDetailsObj: CustAcDetailsObj) {

        custAcDetailsObjIntent = custAcDetailsObj
        var custTotBalance = 0.0
        var custTotSancAmt = 0.0
        var reportName = ""
        var custAcList = custAcDetailsObj.custAcDetailsList

        if (custAcList.isNotEmpty()) {
            custAcList = if (custAcList.size >= 500)
                custAcList.take(500)
            else
                custAcList
        }
        custAcListGlobal.addAll(custAcList)
        tableViewAdapter.setUserList(custAcList)
        // setHeightToTable(custAcList?.size!!)

        for (custAcDetails in custAcList) {
            val loanBal = custAcDetails.balance.toDoubleOrNull() ?: 0.0
            custTotBalance += loanBal
            val sancAmt = custAcDetails.sancAmt.toDoubleOrNull() ?: 0.0
            custTotSancAmt += sancAmt

            if (custAcDetails.smaFlag != null)
                reportName = custAcDetails.smaFlag.trim()

            accountNoForPayment = custAcDetails.acNo
        }

        totSancTv.text =
            resources.getString(R.string.rs) + " " + CommonUtil.formatRoundUp(custTotSancAmt.toString())
        custBalanceTv.text =
            resources.getString(R.string.rs) + " " + CommonUtil.formatRoundUp(custTotBalance.toString())

        reportNameTv.text = reportName
        Log.d("CustFlag", reportName)
        setSuggestionActionsView(reportName)

    }

    override fun loginUserDetails(appUser: AppUser) {
        user = appUser
    }

    private fun openMapSearchAddress(address: String) {
        val mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(address))
        // val gmmIntentUri = Uri.parse("geo:0,0?q=1600 Amphitheatre Parkway, Mountain+View, California")
        val mapIntent = Intent(Intent.ACTION_VIEW, mapUri)
        mapIntent.setPackage("com.google.android.apps.maps")
        if (mapIntent.resolveActivity(packageManager) != null)
            startActivity(mapIntent)
    }


}
