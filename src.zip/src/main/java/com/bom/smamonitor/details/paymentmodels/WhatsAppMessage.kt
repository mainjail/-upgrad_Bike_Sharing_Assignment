package com.bom.smamonitor.details.paymentmodels

import com.google.gson.annotations.SerializedName

data class WhatsAppMessage(
    @SerializedName("cif") var cif: String? = null,
    @SerializedName("cust_mb_no") var custMbNo: String? = null,
    @SerializedName("br_code") var brCode: String? = null,
    @SerializedName("sent_by") var sentBy: String? = null,
    @SerializedName("sent_on") var sentOn: String? = null,
    @SerializedName("sender_mb_no") var senderMbNo: String? = null,
    @SerializedName("msg_text") var msgText: String? = null,
    @SerializedName("msg_type") var msgType: String? = null,
    @SerializedName("msg_template_name") var msgTemplateName: String? = null,
    @SerializedName("msg_lang_code") var msgLangCode: String? = null,
    @SerializedName("resp_message") var respMessage: String? = null,
    @SerializedName("resp_status") var respStatus: String? = null,
    @SerializedName("resp_request_id") var respRequestId: String? = null,
    @SerializedName("resp_reason") var respReason: String? = null,
    @SerializedName("message") var message: Message? = Message()
)

data class Body(
    @SerializedName("text") var text: String? = null
)

data class Media(
    @SerializedName("type") var type: String? = null,
    @SerializedName("template_name") var templateName: String? = null,
    @SerializedName("lang_code") var langCode: String? = null,
    @SerializedName("body") var body: ArrayList<Body> = arrayListOf()

)

data class Message(
    @SerializedName("phone") var phone: String? = null,
    @SerializedName("extra") var extra: String? = null,
    @SerializedName("media") var media: Media? = Media()

)

data class WhatsappResponse(
    @SerializedName("message") var message: String? = null,
    @SerializedName("status") var status: String? = null,
    @SerializedName("request_id") var request_id: String? = null,
    @SerializedName("reason") var reason: String? = null,

    )
