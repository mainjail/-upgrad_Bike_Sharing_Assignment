package com.bom.smamonitor.details

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.custlist.model.EnCustAcDetailsObj
import com.bom.smamonitor.details.paymentmodels.CreatePayMsgLinkResp
import com.bom.smamonitor.details.paymentmodels.PaymentMsgLinkReq
import com.bom.smamonitor.details.paymentmodels.WhatsAppMessage
import com.bom.smamonitor.details.paymentmodels.WhatsappResponse
import io.reactivex.Observable


interface DetailsMVPInteractor : MVPInteractor {

//    fun getUserDetails(): AppUser?

    //    fun getVisits(custNo: String): Observable<List<Visit>>
    fun getCustDetails(custNo: String): Observable<EnCustAcDetailsObj>
    fun createPaymentLink(payMsgLinkReq: PaymentMsgLinkReq): Observable<CreatePayMsgLinkResp>
    fun postWhatsAppMessage(whatsAppMessage: WhatsAppMessage): Observable<WhatsappResponse>
    fun sendSMS(number:String,custName: String, custNo:String,reportName:String): Observable<WhatsappResponse>

}