package com.bom.smamonitor.details

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.core.view.updateLayoutParams
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.R
import com.bom.smamonitor.addVisit.AddVisitActivity
import com.bom.smamonitor.addVisit.Visit
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.custlist.model.CustAcDetailsObj
import com.bom.smamonitor.customViews.RVEmptyObserver
import com.bom.smamonitor.details.paymentmodels.CreatePayMsgLinkResp
import com.bom.smamonitor.details.paymentmodels.WhatsappResponse
import com.bom.smamonitor.details.tablew.customTable.MyTableAdapter
import com.bom.smamonitor.details.tablew.customTable.MyTableViewListener
import com.bom.smamonitor.details.tablew.customTable.MyTableViewModel
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.npa.modelNpa.NpaAccount
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.npa.modelNpa.SFSI
import com.bom.smamonitor.npa.modelNpa.Suit
import com.bom.smamonitor.util.CommonUtil
import com.bom.smamonitor.util.CommonUtil.makeACall
import com.bom.smamonitor.util.CustomDialog
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_details.*
import kotlinx.android.synthetic.main.activity_details.custCallIV
import kotlinx.android.synthetic.main.activity_details.custMobileNoTv
import kotlinx.android.synthetic.main.activity_npa_account.*
import kotlinx.android.synthetic.main.content_profile.*
import kotlinx.android.synthetic.main.fragment_ots_appltn2.*
import kotlinx.android.synthetic.main.item_details_suit_data.*
import kotlinx.android.synthetic.main.item_details_suit_data.view.*
import kotlinx.android.synthetic.main.item_layout_npa_accounts.view.*
import kotlinx.android.synthetic.main.item_sfsi_layout.view.*
import java.util.*
import javax.inject.Inject




class DetailsNpaTableActivity : BaseActivity(), DetailsMVPView {

    @Inject
    internal lateinit var presenter: DetailsMVPPresenter<DetailsMVPView, DetailsMVPInteractor>
    private var accountsList: ArrayList<NpaAccount?>? = ArrayList()
    private var tableInputList: ArrayList<NpaAccount?>? = ArrayList()
    private lateinit var npaCustomer: NpaCustomer

    @Inject
    internal lateinit var visitsAdapter: VisitsAdapter

    @Inject
    internal lateinit var layoutManager: LinearLayoutManager

    private val String.capitalizeWords
        get() = this.toLowerCase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.capitalize(Locale.getDefault())
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        presenter.onAttach(this)
        supportActionBar?.title = resources.getString(R.string.Details)
        initView()

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
//        inflater.inflate(R.menu.menu_visit, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_add_visit -> CustomDialog().popUpToast(
                    activity = this,
                    getString(R.string.funcComing)
            )
//            R.id.app_bar_settings -> toast(getString(R.string.settings_clicked))
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return true
    }

    @SuppressLint("SetTextI18n")
    private fun initView() {
//        npaCustomer= intent.getParcelableExtra("NpaCustomer")!!
        val strObj = intent.getStringExtra("NpaCustomer")
        val cust: NpaCustomer = Gson().fromJson(strObj, NpaCustomer::class.java)
        npaCustomer = cust
        accountsList = npaCustomer.accountsList as ArrayList<NpaAccount?>
        tableInputList = if (accountsList?.size!! >= 500)
            accountsList?.take(500) as ArrayList<NpaAccount?>?
        else
            accountsList

        initializeTableView()

        //presenter.getVisits(npaCustomer.custNo)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        visitsRV.layoutManager = layoutManager
        visitsRV.itemAnimator = DefaultItemAnimator()
        visitsRV.adapter = visitsAdapter
        val emptyRvObserver = RVEmptyObserver(emptyView = emptyVisitMsgTv, recyclerView = visitsRV)
        visitsAdapter.registerAdapterDataObserver(emptyRvObserver)
        visitsRV.visibility = View.VISIBLE
        customerNameTv.text = npaCustomer.custName
        custNoTv.text = npaCustomer.custNo
        custMobileNoTv.text = "+" + npaCustomer.mobNo.substring(0, 2) + " - " + npaCustomer.mobNo.substring(
                2, npaCustomer.mobNo.length)


        if (npaCustomer.fraud != null) {
            if (npaCustomer.fraud.equals("Y"))
                custFraudTv.text = "Yes"
            else
                custFraudTv.text = "No"
        } else
            custFraudTv.text = " - "

        if (npaCustomer.address != null) {
            val address = npaCustomer.address!!
            custAddressTv.text = address.add1?.capitalizeWords + ", " +
                    address.add2?.capitalizeWords + ", " +
                    address.add3?.capitalizeWords + ", " +
                    address.add4?.capitalizeWords + " - " +
                    address.postcode
        }

        var i = 0
        var custTotBalance = npaCustomer.custBalance?.toDoubleOrNull() ?: 0.0
        while (i < npaCustomer.accountsList.size) {
            val loanBal = npaCustomer.accountsList[i].loanBalance?.toDoubleOrNull() ?: 0.0
            custTotBalance += loanBal
            i++
        }
        custBalanceTv.text = CommonUtil.formatRoundUp(custTotBalance.toString())

        if (npaCustomer.suit?.suitRefNo != null) {
            suitDataLL.visibility = View.VISIBLE
            emptySuitMsgTv.visibility = View.GONE
            setSuitData(npaCustomer.suit!!)
        } else {
            suitDataLL.visibility = View.GONE
            emptySuitMsgTv.visibility = View.VISIBLE
        }

        if (npaCustomer.sFsi?.dateOfIssue13_2 != null) {
            sFsiIncLL.suitDataLL.visibility = View.VISIBLE
            sFsiIncLL.emptySuitMsgTv.visibility = View.GONE
            setSFSIData(npaCustomer.sFsi!!)
        } else {
            sFsiIncLL.suitDataTitle.text = resources.getString(R.string.SFSI)
            sFsiIncLL.emptySuitMsgTv.text = resources.getString(R.string.noSFSIDataAvailable)
            sFsiIncLL.suitDataLL.visibility = View.GONE
            sFsiIncLL.emptySuitMsgTv.visibility = View.VISIBLE
        }
        addVisitBtn.setOnClickListener {
            try {
                val intent = Intent(this, AddVisitActivity::class.java)
                intent.putExtra("NpaCustomer", Gson().toJson(npaCustomer))
                startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        custCallIV.setOnClickListener {
            makeACall(npaCustomer.mobNo, this)
        }
        custAddressTv.setOnClickListener {
            if (npaCustomer.address != null) {
                val address = npaCustomer.address!!
                val addSearch = address.add1?.capitalizeWords +
                        address.add2?.capitalizeWords +
                        address.add3?.capitalizeWords +
                        address.add4?.capitalizeWords
                openMapSearchAddress(addSearch)
            }
        }
    }


    private fun setSuitData(suit: Suit) {

        suitDataField1.fieldTitleTv.text = resources.getString(R.string.suitRefNo)
        suitDataField1.fieldValueTv.text = suit.suitRefNo

        suitDataField2.fieldTitleTv.text = resources.getString(R.string.suitFIDate)
        suitDataField2.fieldValueTv.text = suit.suitFIDate

        suitDataField3.fieldTitleTv.text = resources.getString(R.string.suitFIDate1)
        suitDataField3.fieldValueTv.text = suit.suitFIDate

        suitDataField4.fieldTitleTv.text = resources.getString(R.string.courtName)
        suitDataField4.fieldValueTv.text = suit.courtName

        suitDataField5.fieldTitleTv.text = resources.getString(R.string.suitAmount)
        suitDataField5.fieldValueTv.text = suit.suitAmount

        suitDataField6.fieldTitleTv.text = resources.getString(R.string.nextHearingDate)
        suitDataField6.fieldValueTv.text = suit.nextHearingDate

        suitDataField7.fieldTitleTv.text = resources.getString(R.string.nextHearingDate1)
        suitDataField7.fieldValueTv.text = suit.nextHearingDate1

        sFsiIncLL.suitDataField7.fieldDividerViewSuit.visibility = View.GONE

    }

    private fun isDateNull(date: String): String {
        if (date.contains("1899"))
            return "-"
        else
            return date
    }

    private fun setSFSIData(sfsi: SFSI) {
        sFsiIncLL.suitDataTitle.text = resources.getString(R.string.SFSI)

        sFsiIncLL.suitDataField1.fieldTitleTv.text = resources.getString(R.string.dateOfIssue13_2)
        sFsiIncLL.suitDataField1.fieldValueTv.text = isDateNull(sfsi.dateOfIssue13_2)

        sFsiIncLL.suitDataField2.fieldTitleTv.text = resources.getString(R.string.dateOfIssue13_4)
        sFsiIncLL.suitDataField2.fieldValueTv.text = isDateNull(sfsi.dateOfIssue13_4)

        sFsiIncLL.suitDataField3.fieldTitleTv.text = resources.getString(R.string.symbPsDate)
        sFsiIncLL.suitDataField3.fieldValueTv.text = isDateNull(sfsi.symbPsDate)

        sFsiIncLL.suitDataField4.fieldTitleTv.text = resources.getString(R.string.applFillDate)
        sFsiIncLL.suitDataField4.fieldValueTv.text = isDateNull(sfsi.applFillDate)

        sFsiIncLL.suitDataField5.fieldTitleTv.text = resources.getString(R.string.permResvdDate)
        sFsiIncLL.suitDataField5.fieldValueTv.text = isDateNull(sfsi.permResvdDate)

        sFsiIncLL.suitDataField6.fieldTitleTv.text = resources.getString(R.string.dateOfPhysicalPosn)
        sFsiIncLL.suitDataField6.fieldValueTv.text = isDateNull(sfsi.dateOfPHYPosn)

        sFsiIncLL.suitDataField7.fieldTitleTv.text = resources.getString(R.string.dateOfPubSale)
        sFsiIncLL.suitDataField7.fieldValueTv.text = isDateNull(sfsi.dateOfPubSale)
        sFsiIncLL.suitDataField7.fieldDividerViewSuit.visibility = View.VISIBLE

        sFsiIncLL.suitDataField8.fieldTitleTv.text = resources.getString(R.string.dateOfAuction)
        sFsiIncLL.suitDataField8.fieldValueTv.text = isDateNull(sfsi.dateOfAuction.substring(0, 10))

        sFsiIncLL.suitDataField8.fieldDividerViewSuit.visibility = View.GONE
        sFsiIncLL.suitDataField8.visibility = View.VISIBLE
    }

    private fun initializeTableView() {
        val tableViewModel = MyTableViewModel()
        val tableViewAdapter = MyTableAdapter(tableViewModel)
        tableView1.setAdapter(tableViewAdapter)
        val myTableViewListener = MyTableViewListener(tableView1)
        tableView1.tableViewListener = myTableViewListener
        tableViewAdapter.setUserList(accountsList)
        setHeightToTable(accountsList?.size!!)
    }

    private fun setHeightToTable(listSize: Int) {

        Log.d("DetailActivity", "listSize${listSize}")
        if (listSize < 3)
            tableView1.updateLayoutParams { height = 300 }
        else if (listSize in 4..5)
            tableView1.updateLayoutParams { height = 700 }
        else
            tableView1.updateLayoutParams { height = 1000 }

        tableContainer.updateLayoutParams { height = ViewGroup.LayoutParams.WRAP_CONTENT }
        tableContainerCard.updateLayoutParams { height = ViewGroup.LayoutParams.WRAP_CONTENT }
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

//    private fun makeACall(number: String) {
//        val intent = Intent(Intent.ACTION_DIAL)
//        intent.data = Uri.parse("tel:$number")
//        startActivity(intent)
//    }

    override fun showError(errorMsg: String) {
        CustomDialog().popUpToast(this@DetailsNpaTableActivity, errorMsg)
    }

//    override fun displayVisits(visitsList: List<Visit>) {
//        visitsAdapter.setVisitsList(visitsList)
//    }

    override fun displayCustAcDetails(custAcDetailsObj: CustAcDetailsObj) {
        TODO("Not yet implemented")
    }

    override fun loginUserDetails(appUser: AppUser) {
        TODO("Not yet implemented")
    }

    override fun displayPaymentLinkSuccess(payMsgLinkResp: CreatePayMsgLinkResp) {
        TODO("Not yet implemented")
    }

    override fun displayWhatsAppMsgSuccess(whatsappResponse: WhatsappResponse) {
        TODO("Not yet implemented")
    }

    private fun openMapSearchAddress(address: String) {
        val mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(address))
        //        val gmmIntentUri = Uri.parse("geo:0,0?q=1600 Amphitheatre Parkway, Mountain+View, California")

        val mapIntent = Intent(Intent.ACTION_VIEW, mapUri)
        mapIntent.setPackage("com.google.android.apps.maps")
        if (mapIntent.resolveActivity(packageManager) != null)
            startActivity(mapIntent)
    }


}
