package com.bom.smamonitor.details.tablew.customTable;

import com.bom.smamonitor.custlist.model.CustAcDetails;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.ColumnHeaderModel;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;
import com.bom.smamonitor.util.DateUtil;

import java.util.ArrayList;
import java.util.List;

public class SmaAccountTableVM {
    // Columns indexes
    public static final int LINK_COLUMN_INDEX1 = 1;
    public static final int LINK_COLUMN_INDEX2 = 2;
    public static final int ZoneName_COLUMN_INDEX = 9;
    DateUtil dateUtil = DateUtil.INSTANCE;
    // Constant size for dummy data sets
//    private static final int COLUMN_SIZE = 500;
//    private static final int ROW_SIZE = 500;

    private List<ColumnHeaderModel> mColumnHeaderModelList;
    private List<RowHeaderModel> mRowHeaderModelList;
    private List<List<Cell>> mCellModelList;


    public SmaAccountTableVM() {
    }


    private List<ColumnHeaderModel> createColumnHeaderModelList() {
        List<ColumnHeaderModel> list = new ArrayList<>();
        // Create Column Headers
//            list.add(new ColumnHeaderModel("0", "Sr. No"));
        list.add(new ColumnHeaderModel("0", "Account No"));
        list.add(new ColumnHeaderModel("1", "Prod Name"));
        list.add(new ColumnHeaderModel("2", "Report"));
        list.add(new ColumnHeaderModel("3", "PTP Date"));

        list.add(new ColumnHeaderModel("4", "Balance"));
        list.add(new ColumnHeaderModel("5", "Sanc Amt"));
        list.add(new ColumnHeaderModel("6", "Overdue"));
        list.add(new ColumnHeaderModel("7", "Old Irac"));
        list.add(new ColumnHeaderModel("8", "New Irac"));

        list.add(new ColumnHeaderModel("9", " Probable NPA Date"));
        list.add(new ColumnHeaderModel("10", "Default Date"));

        list.add(new ColumnHeaderModel("11", "Repay Option"));
        list.add(new ColumnHeaderModel("12", "Pend dues Date"));
        list.add(new ColumnHeaderModel("13", "Inst Amt"));

        list.add(new ColumnHeaderModel("14", "AC Open Date"));


        return list;
    }

    private List<List<Cell>> createCellModelList(List<CustAcDetails> userList) {


        List<List<Cell>> cellList = new ArrayList<>();
        // Creating cell model list from User list for Cell Items
        // In this example, User list is populated from web service
        try {
            for (int i = 0; i < userList.size(); i++) {
                CustAcDetails acDetails = userList.get(i);
                List<Cell> list = new ArrayList<>();

                // The order should be same with column header list;
//                list.add(new Cell("1-" + i, circular.getSrNo()));          // "srNo"
                list.add(new Cell("1-" + i, acDetails.getAcNo()));
//                list.add(new Cell("2-" + i, acDetails.getAcName().trim()));
                list.add(new Cell("2-" + i, acDetails.getProdName().trim()));
                list.add(new Cell("3-" + i, acDetails.getSmaFlag()));
                if (acDetails.getPtpDate() != null) {
                    if ((!acDetails.getPtpDate().equalsIgnoreCase("null"))) {
                        list.add(new Cell("4-" + i, dateUtil.convertDateToddMMyy(acDetails.getPtpDate())));
                    }
                } else {
                    list.add(new Cell("4-" + i, "-"));
                }
                list.add(new Cell("5-" + i, acDetails.getBalance()));
                list.add(new Cell("6-" + i, acDetails.getSancAmt()));
                list.add(new Cell("7-" + i, acDetails.getOverdue()));
                list.add(new Cell("8-" + i, acDetails.getOldIrac()));
                list.add(new Cell("9-" + i, acDetails.getNewIrac()));

                if (acDetails.getProbableNpaDate() != null) {
                    if ((!acDetails.getProbableNpaDate().equalsIgnoreCase("null"))) {
                        list.add(new Cell("10-" + i, dateUtil.convertDateToddMMyy(acDetails.getProbableNpaDate())));
                    }
                } else {
                    list.add(new Cell("10-" + i, "-"));
                }
                if (acDetails.getDefaultDate() != null) {
                    if ((!acDetails.getDefaultDate().equalsIgnoreCase("null"))) {
                        list.add(new Cell("11-" + i, dateUtil.convertDateToddMMyy(acDetails.getDefaultDate())));
                    }
                } else {
                    list.add(new Cell("11-" + i, "-"));
                }
                list.add(new Cell("12-" + i, acDetails.getRepayOption()));

                if (acDetails.getPendDuesDate() != null) {
                    if ((!acDetails.getPendDuesDate().equalsIgnoreCase("null"))) {
                        list.add(new Cell("13-" + i, dateUtil.convertDateToddMMyy(acDetails.getPendDuesDate())));
                    }
                } else {
                    list.add(new Cell("13-" + i, "-"));
                }
                list.add(new Cell("14-" + i, acDetails.getInstAmt()));


                if (acDetails.getAcOpenDate() != null) {
                    if ((!acDetails.getAcOpenDate().equalsIgnoreCase("null"))) {
                        list.add(new Cell("15-" + i, dateUtil.convertDateToddMMyy(acDetails.getAcOpenDate())));
                    }
                } else {
                    list.add(new Cell("15-" + i, "-"));
                }

                cellList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cellList;
    }

    private List<RowHeaderModel> createRowHeaderList(int size) {
        List<RowHeaderModel> list = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            list.add(new RowHeaderModel(String.valueOf(i), String.valueOf(i + 1)));
        }
        return list;
    }

    public List<ColumnHeaderModel> getColumnHeaderModeList() {
        return mColumnHeaderModelList;
    }

    public List<RowHeaderModel> getRowHeaderModelList() {
        return mRowHeaderModelList;
    }

    public List<List<Cell>> getCellModelList() {
        return mCellModelList;
    }

    public void generateListForTableView(List<CustAcDetails> users) {
        mColumnHeaderModelList = createColumnHeaderModelList();
        mCellModelList = createCellModelList(users);
        mRowHeaderModelList = createRowHeaderList(users.size());
    }

}




