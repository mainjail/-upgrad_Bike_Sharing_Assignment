package com.bom.smamonitor.details.tablew.models;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;



/**
 */

public class RowHeaderModel extends Cell {
    public RowHeaderModel(@NonNull String id, @Nullable String data) {
        super(id, data);
    }
}
