package com.bom.smamonitor.details

import com.bom.smamonitor.addVisit.Visit
import com.bom.smamonitor.base.view.BaseMVPView
import com.bom.smamonitor.custlist.model.CustAcDetails
import com.bom.smamonitor.custlist.model.CustAcDetailsObj
import com.bom.smamonitor.details.paymentmodels.CreatePayMsgLinkResp
import com.bom.smamonitor.details.paymentmodels.WhatsappResponse
import com.bom.smamonitor.login.AppUser


interface DetailsMVPView : BaseMVPView {
    fun showError(errorMsg: String)

    //    fun displayVisits(visitsList: List<Visit>)
    fun displayCustAcDetails(custAcDetailsObj: CustAcDetailsObj)
    fun loginUserDetails(appUser: AppUser)
    fun displayPaymentLinkSuccess( payMsgLinkResp: CreatePayMsgLinkResp)
    fun displayWhatsAppMsgSuccess( whatsappResponse: WhatsappResponse)

}