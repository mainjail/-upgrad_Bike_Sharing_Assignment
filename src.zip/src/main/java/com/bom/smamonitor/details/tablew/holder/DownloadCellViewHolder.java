/*
 * Copyright (c) 2018. Evren Coşkun
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

package com.bom.smamonitor.details.tablew.holder;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.bom.smamonitor.R;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractViewHolder;


public class DownloadCellViewHolder extends AbstractViewHolder {
    private final Drawable cell_view_drawable;
    private final Drawable cell_download_drawable;
    @NonNull
    public final ImageView cell_image;

    public DownloadCellViewHolder(@NonNull View itemView) {
        super(itemView);
        cell_image = itemView.findViewById(R.id.cell_image);
        cell_view_drawable = ContextCompat.getDrawable(itemView.getContext(), R.drawable.ic_book);
        cell_download_drawable = ContextCompat.getDrawable(itemView.getContext(), R.drawable.ic_download);
    }

    public void setCellModel(Cell cell) {
        int gender = (int) cell.getData();
        if(gender==1)
            cell_image.setImageDrawable(cell_view_drawable);
        else
            cell_image.setImageDrawable(cell_download_drawable);
    }
}
