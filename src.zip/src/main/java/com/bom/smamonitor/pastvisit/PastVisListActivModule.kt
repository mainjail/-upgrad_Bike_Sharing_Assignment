package com.bom.smamonitor.pastvisit

import com.bom.smamonitor.addVisit.*


import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.details.VisitsAdapter
import dagger.Module
import dagger.Provides

@Module
class PastVisListActivModule {

    @Provides
    internal fun provideLoginInteractor(interactor: PastVisListInteractorImpl): PastVisitsListIteractor = interactor

    @Provides
    internal fun provideLoginPresenter(presenter: PastVisListPresImpl<PastVisitsListMVPView, PastVisitsListIteractor>)
            : PastVisListPresenter<PastVisitsListMVPView, PastVisitsListIteractor> = presenter

    @Provides
    internal fun provideAdapter(activity: PastVisitListActivity): VisitsAdapter = VisitsAdapter(activity)

    @Provides
    internal fun provideLinearLayoutManager(activity: PastVisitListActivity):
            LinearLayoutManager = LinearLayoutManager(activity)


    @Provides
    internal fun provideCategAdapter(activity: PastVisitListActivity): ImageViewListS = ImageViewListS(activity)

//    @Provides
//    internal fun provideLLayoutManager(activity: AddVisitActivity):
//            LinearLayoutManager = LinearLayoutManager(activity)

}