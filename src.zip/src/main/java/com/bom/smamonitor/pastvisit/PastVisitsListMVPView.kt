package com.bom.smamonitor.pastvisit

import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.base.view.BaseMVPView

interface PastVisitsListMVPView : BaseMVPView {

    fun showError(errorMsg: String)
    fun displaySmaVisits(visitsList: List<SmaVisit>)

}