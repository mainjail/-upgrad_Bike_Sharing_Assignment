package com.bom.smamonitor.pastvisit

import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.network.ApiHelper
import io.reactivex.Observable
import javax.inject.Inject

class PastVisListInteractorImpl @Inject internal constructor(
    preferenceHelper: PreferenceHelper,
    apiHelper: ApiHelper
) :
    BaseInteractor(preferenceHelper, apiHelper), PastVisitsListIteractor {

    override fun getSmaVisits(custNo: String): Observable<List<SmaVisit>> =
        apiHelper.getSmaVisits(custNo)


}