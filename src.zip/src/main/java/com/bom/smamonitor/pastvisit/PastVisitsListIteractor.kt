package com.bom.smamonitor.pastvisit

import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.base.interactor.MVPInteractor
import io.reactivex.Observable

interface PastVisitsListIteractor : MVPInteractor {

    //    fun updateUserInSharedPref(loginResponse: LoginResponse, user: User, loggedInMode: AppConstants.LoggedInMode)
    fun getSmaVisits(custNo: String): Observable<List<SmaVisit>>

}