package com.bom.smamonitor.pastvisit

import com.bom.smamonitor.base.presenter.MVPPresenter
import com.bom.smamonitor.login.AppUser

interface PastVisListPresenter <V : PastVisitsListMVPView, I : PastVisitsListIteractor> :
    MVPPresenter<V, I> {

    fun getPrefUserDetails(): AppUser
    fun getSmaVisits(custNo: String)

}