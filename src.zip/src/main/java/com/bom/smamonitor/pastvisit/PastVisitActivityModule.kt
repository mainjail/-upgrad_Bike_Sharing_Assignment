package com.bom.smamonitor.pastvisit

import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.addVisit.*
import com.bom.smamonitor.details.VisitsAdapter
import dagger.Module
import dagger.Provides

@Module
class PastVisitActivityModule {

    @Provides
    internal fun providePastVInteractor(interactor: PastVisListInteractorImpl): PastVisitsListIteractor = interactor

    @Provides
    internal fun providePastVPresenter(presenter: PastVisListPresImpl<PastVisitsListMVPView, PastVisitsListIteractor>)
            : PastVisListPresenter<PastVisitsListMVPView, PastVisitsListIteractor> = presenter

    @Provides
    internal fun provideAdapter(activity: PastVisitListActivity): VisitsAdapter = VisitsAdapter(activity)

    @Provides
    internal fun provideLinearLayoutManager(activity: PastVisitListActivity):
            LinearLayoutManager = LinearLayoutManager(activity)


    @Provides
    internal fun provideCategAdapter(activity: PastVisitListActivity): ImageViewListS = ImageViewListS(activity)

}