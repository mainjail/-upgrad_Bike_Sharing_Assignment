package com.bom.smamonitor.pastvisit

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.R
import com.bom.smamonitor.addVisit.*
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.custlist.model.CustAcDetailsObj
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.customViews.RVEmptyObserver
import com.bom.smamonitor.details.VisitsAdapter
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_add_visit.*
import java.util.*
import javax.inject.Inject

class PastVisitListActivity : BaseActivity(), PastVisitsListMVPView {

    @Inject
    internal lateinit var visitsAdapter: VisitsAdapter

    @Inject
    internal lateinit var imageAdapter: ImageViewListS

    @Inject
    internal lateinit var layoutManager: LinearLayoutManager

    @Inject
    internal lateinit var presenter: PastVisListPresenter<PastVisitsListMVPView, PastVisitsListIteractor>

    private val String.capitalizeWords
        get() = this.lowercase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_past_visits)
        presenter.onAttach(this)
        initView()
        supportActionBar?.title = resources.getString(R.string.viewHistory)
    }

    private lateinit var customer: CustomerRep2

    private fun initView() {

        val user = presenter.getPrefUserDetails()
        val strObj = intent.getStringExtra("smaCustomer")
        customer = Gson().fromJson(strObj, CustomerRep2::class.java)

//        val acDetailsObj = intent.getStringExtra("custAcDetailsObj")
//        val custAcDetailsObj: CustAcDetailsObj =
//        Gson().fromJson(acDetailsObj, CustAcDetailsObj::class.java)
//        custNameTv.text = customer.custName

        layoutManager.orientation = LinearLayoutManager.VERTICAL
        visitsRV.layoutManager = layoutManager
        visitsRV.itemAnimator = DefaultItemAnimator()
        visitsRV.adapter = visitsAdapter
        val emptyRvObserver = RVEmptyObserver(emptyView = emptyVisitMsgTv, recyclerView = visitsRV)
        visitsAdapter.registerAdapterDataObserver(emptyRvObserver)
        visitsRV.visibility = View.VISIBLE
        visitsRV.setHasFixedSize(true)
        visitsRV.isNestedScrollingEnabled = false
        apiCallForVisitsHistory()

    }


    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    private fun apiCallForVisitsHistory() {

        if (customer.cif.isNotEmpty() && ValidationUtils.isNetworkAvailable(this))
            presenter.getSmaVisits(customer.cif)
        else CustomDialog().showNoInternetAlert(this, "")
    }

    override fun showError(errorMsg: String) {
        CustomDialog().popUpToast(this, errorMsg)
    }

    override fun displaySmaVisits(visitsList: List<SmaVisit>) {
        if (visitsList.isNotEmpty())
            visitsAdapter.setVisitsList(visitsList)
        else {
            emptyVisitMsgTv.visibility = View.VISIBLE
            visitsRV.visibility = View.GONE
        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
//        inflater.inflate(R.menu.menu_visit, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return true
    }


}