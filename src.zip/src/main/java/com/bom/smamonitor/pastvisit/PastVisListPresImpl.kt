package com.bom.smamonitor.pastvisit

import android.util.Log
import com.androidnetworking.error.ANError
import com.bom.smamonitor.addVisit.SmaVisit
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject;


class PastVisListPresImpl<V : PastVisitsListMVPView, I : PastVisitsListIteractor>
@Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) : BasePresenter<V, I>(
    interactor = interactor,
    schedulerProvider = schedulerProvider,
    compositeDisposable = disposable
), PastVisListPresenter<V, I> {

    override fun getPrefUserDetails(): AppUser = interactor?.getUserFromSharedPref()!!

    override fun getSmaVisits(custNo: String) {

        getView()?.showProgress()
        interactor?.let {
            it.getSmaVisits(custNo)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ visitsList: List<SmaVisit> ->
                    println("Visits Results:-$visitsList")
                    getView()?.hideProgress()
                    getView()?.displaySmaVisits(visitsList)

                }, { error ->
                    val aNError = error as ANError
                    Log.d("pastVisPresImpl", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }




}
