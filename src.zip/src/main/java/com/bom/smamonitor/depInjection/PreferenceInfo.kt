package com.bom.smamonitor.depInjection


import javax.inject.Qualifier


@Qualifier
@Retention annotation class PreferenceInfo