package com.bom.smamonitor.depInjection.preferences

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.bom.smamonitor.depInjection.PreferenceInfo
import com.bom.smamonitor.util.AppConstants
import javax.inject.Inject


@Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
class AppPreferenceHelper @Inject constructor(
    context: Context,
    @PreferenceInfo private val prefFileName: String
) : PreferenceHelper {


    companion object {
        private val PREF_KEY_USER_LOGGED_IN_MODE = "PREF_KEY_USER_LOGGED_IN_MODE"
        private val PREF_KEY_CURRENT_USER_ID = "PREF_KEY_CURRENT_USER_ID"
        private val PREF_KEY_ACCESS_TOKEN = "PREF_KEY_ACCESS_TOKEN"
        private val PREF_KEY_SESSION_ID = "PREF_KEY_SESSION_ID"
        private val USER_CADRE = "USER_CADRE"

        private val PREF_KEY_CURRENT_USER_NAME = "PREF_KEY_CURRENT_USER_NAME"
        private val PREF_KEY_CURRENT_USER_EMAIL = "PREF_KEY_CURRENT_USER_EMAIL"
        private val PREF_KEY_CURRENT_USER_Login = "PREF_KEY_CURRENT_USER_Login"
        private val USER_MOBIlE_NO = "USER_MOBILE_NO"
        private val USER_DEVICE_TOKEN = "USER_DEVICE_TOKEN"

        private val USER_PF_NO = "USER_PF_NO"
        private val USER_BRANCH_CODE = "USER_BRANCH_CODE"
        private val USER_BRANCH_NAME = "USER_BRANCH_NAME"
        private val USER_DEPT_CODE = "USER_DEPT_CODE"

        private val USER_REGION_CODE = "USER_REGION_CODE"
        private val USER_REGION_NAME = "USER_REGION_NAME"
        private val USER_LAST_LOGIN = "USER_LAST_LOGIN"

        private val USER_LOGIN_PIN = "USER_LOGIN_PIN"
    }

    private val mPrefs: SharedPreferences =
        context.getSharedPreferences(prefFileName, Context.MODE_PRIVATE)

    override fun setCurrentUserLoggedInMode(mode: AppConstants.LoggedInMode) {
        mPrefs.edit { putInt(PREF_KEY_USER_LOGGED_IN_MODE, mode.type) }
    }

    override fun getCurrentUserLoggedInMode() =
        mPrefs.getInt(
            PREF_KEY_USER_LOGGED_IN_MODE,
            AppConstants.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT.type
        )

    override fun getCurrentUserName(): String? = mPrefs.getString(PREF_KEY_CURRENT_USER_NAME, "ABC")

    override fun setCurrentUserName(userName: String?) =
        mPrefs.edit { putString(PREF_KEY_CURRENT_USER_NAME, userName) }

    override fun getCurrentUserEmail(): String? =
        mPrefs.getString(PREF_KEY_CURRENT_USER_EMAIL, "NA")

    override fun setCurrentUserEmail(email: String?) =
        mPrefs.edit { putString(PREF_KEY_CURRENT_USER_EMAIL, email) }

    override fun getAccessToken(): String? = mPrefs.getString(PREF_KEY_ACCESS_TOKEN, "")

    override fun setAccessToken(accessToken: String?) =
        mPrefs.edit { putString(PREF_KEY_ACCESS_TOKEN, accessToken) }

    override fun getCurrentBranchName(): String? =
        mPrefs.getString(USER_BRANCH_NAME, "NA")

    override fun setCurrentBranchName(branchName: String?) =
        mPrefs.edit { putString(USER_BRANCH_NAME, branchName) }

    override fun getUserRegionName(): String? =
        mPrefs.getString(USER_REGION_NAME, "NA")

    override fun setUserRegionName(regionName: String?) =
        mPrefs.edit { putString(USER_REGION_NAME, regionName) }

    override fun getUserLastLogindate(): String? =
        mPrefs.getString(USER_LAST_LOGIN, "NA")

    override fun setUserLastLogindate(lastLoginDate: String?) =
        mPrefs.edit { putString(USER_LAST_LOGIN, lastLoginDate) }

    override fun getCurrentUserId(): Long? {
        val userId = mPrefs.getLong(PREF_KEY_CURRENT_USER_ID, AppConstants.NULL_INDEX)
        return when (userId) {
            AppConstants.NULL_INDEX -> null
            else -> userId
        }
    }

    override fun getCurrentUserPIN(): String? = mPrefs.getString(USER_LOGIN_PIN, null)
    override fun setCurrentUserPIN(userPin: String?) =
        mPrefs.edit { putString(USER_LOGIN_PIN, userPin) }

    override fun setCurrentUserId(userId: Long?) {
        val id = userId ?: AppConstants.NULL_INDEX
        mPrefs.edit { putLong(PREF_KEY_CURRENT_USER_ID, id) }
    }


    override fun getCurrentUserPfNo(): String? = mPrefs.getString(USER_PF_NO, "99999")
    override fun setCurrentUserPfNo(pfNo: String?) = mPrefs.edit { putString(USER_PF_NO, pfNo) }

    override fun getCurrentUserMobileNo(): String? = mPrefs.getString(USER_MOBIlE_NO, "9999900000")
    override fun setCurrentUserMobileNo(mbNo: String?) =
        mPrefs.edit { putString(USER_MOBIlE_NO, mbNo) }

    override fun getCurrentBranchCode(): String? = mPrefs.getString(USER_BRANCH_CODE, "0000")
    override fun setCurrentBranchCode(branchCode: String?) =
        mPrefs.edit { putString(USER_BRANCH_CODE, branchCode) }

    override fun getCurrentDeptCode(): String? = mPrefs.getString(USER_DEPT_CODE, "0000")
    override fun setCurrentDeptCode(deptCode: String?) =
        mPrefs.edit { putString(USER_DEPT_CODE, deptCode) }

    override fun getUserRegionCode(): String? = mPrefs.getString(USER_REGION_CODE, "0000")
    override fun setUserRegionCode(regCode: String?) =
        mPrefs.edit { putString(USER_REGION_CODE, regCode) }

    override fun getCurrentDeviceNotificationToken(): String? =
        mPrefs.getString(USER_DEVICE_TOKEN, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")

    override fun setCurrentDeviceNotificationToken(token: String?) =
        mPrefs.edit { putString(USER_DEVICE_TOKEN, token) }

    override fun getUsersLastLogin(): String? =
        mPrefs.getString(PREF_KEY_CURRENT_USER_Login, "01-01-2020,00:00pm")

    override fun setUsersLastLogin(lastLogin: String?) =
        mPrefs.edit { putString(PREF_KEY_CURRENT_USER_Login, lastLogin) }


    override fun getSessionId(): String? = mPrefs.getString(PREF_KEY_SESSION_ID, "")

    override fun setSessionId(sessionId: String?) =
        mPrefs.edit { putString(PREF_KEY_SESSION_ID, sessionId) }

    override fun getCurrentUserCadre(): String? = mPrefs.getString(USER_CADRE, "")
    override fun setCurrentUserCadre(cadre: String?) {
        mPrefs.edit { putString(USER_CADRE, cadre) }
    }
}