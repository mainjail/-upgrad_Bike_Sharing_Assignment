package com.bom.smamonitor.depInjection

import com.bom.smamonitor.addVisit.AddVisitActivity
import com.bom.smamonitor.addVisit.AddVisitActivityModule
import com.bom.smamonitor.branchMaster.BranchListActivity
import com.bom.smamonitor.branchMaster.BranchListActivityModule
import com.bom.smamonitor.branchMaster.RegionListActivity
import com.bom.smamonitor.branchMaster.RegionListActivityModule
import com.bom.smamonitor.bzsummary.BZSummaryActivity
import com.bom.smamonitor.bzsummary.BZSummaryActivityModule
import com.bom.smamonitor.custlist.CustomerListActivity
import com.bom.smamonitor.dashboardbb.DashboardBBActivity
import com.bom.smamonitor.dashboardbb.fragments.AgriFragmentProvider
import com.bom.smamonitor.dashboardbb.fragments.HomeFragmentProvider
import com.bom.smamonitor.dashboardbb.fragments.NotificationFragmentProvider
import com.bom.smamonitor.dashboardbb.fragments.SearchFragmentProvider
import com.bom.smamonitor.details.CustDetailsSmaActivity
import com.bom.smamonitor.details.CustSmaDetActivModule
import com.bom.smamonitor.details.DetailsNpaTableActivity
import com.bom.smamonitor.details.DetailsTblActivityModule
import com.bom.smamonitor.login.LoginActivity
import com.bom.smamonitor.login.LoginActivityModule
import com.bom.smamonitor.npa.NpaActivityModule
import com.bom.smamonitor.ots.OtsActivity
import com.bom.smamonitor.ots.applEntry.OtsEntryFragmentProvider
import com.bom.smamonitor.pastvisit.PastVisitActivityModule
import com.bom.smamonitor.pastvisit.PastVisitListActivity
import com.bom.smamonitor.pinLockScreen.PinLockActivity
import com.bom.smamonitor.profile.MyProfileActivity
import com.bom.smamonitor.profile.ProfileActivityModule
import com.bom.smamonitor.splash.SplashActivity
import com.bom.smamonitor.splash.view.SplashActivityModule
import com.bom.smamonitor.zonesectrsumry.ZoneSectSumActivityModule
import com.bom.smamonitor.zonesectrsumry.ZoneSectorSumActivity
import com.bom.smamonitor.zonesectrsumry.ZoneSummaryActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityBuilder {

    @ContributesAndroidInjector(modules = [(SplashActivityModule::class)])
    abstract fun bindSplashActivity(): SplashActivity

    @ContributesAndroidInjector(modules = [(LoginActivityModule::class)])
    abstract fun bindLoginActivity(): LoginActivity

    @ContributesAndroidInjector(modules = [(NpaActivityModule::class)])
    abstract fun bindCustListActivity(): CustomerListActivity

    @ContributesAndroidInjector(modules = [(BranchListActivityModule::class)])
    abstract fun bindBranchListActivity(): BranchListActivity

    @ContributesAndroidInjector(modules = [(RegionListActivityModule::class)])
    abstract fun bindRegionListActivity(): RegionListActivity

    @ContributesAndroidInjector(modules = [(AddVisitActivityModule::class)])
    abstract fun bindAddVisitActivity(): AddVisitActivity

    @ContributesAndroidInjector(modules = [(PastVisitActivityModule::class)])
    abstract fun bindPastVisitActivity(): PastVisitListActivity

    @ContributesAndroidInjector(modules = [(DetailsTblActivityModule::class)])
    abstract fun bindViewCircularTableActivity(): DetailsNpaTableActivity

    @ContributesAndroidInjector(modules = [(CustSmaDetActivModule::class)])
    abstract fun bindCustDetailsSmaActivity(): CustDetailsSmaActivity

    @ContributesAndroidInjector(modules = [(ProfileActivityModule::class)])
    abstract fun bindProfileActivity(): MyProfileActivity

    @ContributesAndroidInjector(modules = [(ZoneSectSumActivityModule::class)])
    abstract fun bindZoneSectSumActivity(): ZoneSectorSumActivity

    @ContributesAndroidInjector(modules = [(ZoneSectSumActivityModule::class)])
    abstract fun bindZoneSumActivity(): ZoneSummaryActivity

    @ContributesAndroidInjector(modules = [(SplashActivityModule::class)])
    abstract fun bindPinLockActivity(): PinLockActivity

    @ContributesAndroidInjector(modules = [(BZSummaryActivityModule::class)])
    abstract fun bindBZSummaryActivity(): BZSummaryActivity

    @ContributesAndroidInjector(modules = [ (HomeFragmentProvider::class),(NotificationFragmentProvider::class),SearchFragmentProvider::class, AgriFragmentProvider::class])
    abstract fun bindMainActivity(): DashboardBBActivity


//    @ContributesAndroidInjector(modules = [(DashboardBBActivityModule::class)])
//    abstract fun bindMainActivity(): DashboardBBActivity



    @ContributesAndroidInjector(modules = [OtsEntryFragmentProvider::class])
    abstract fun bindOtsActivity(): OtsActivity
}
