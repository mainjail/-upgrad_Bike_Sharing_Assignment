package com.bom.smamonitor.depInjection.preferences

import com.bom.smamonitor.util.AppConstants


interface PreferenceHelper {


    fun getCurrentUserLoggedInMode(): Int
    fun setCurrentUserLoggedInMode(mode: AppConstants.LoggedInMode)

    fun getCurrentUserId(): Long?
    fun setCurrentUserId(userId: Long?)

    fun getCurrentUserPIN(): String?
    fun setCurrentUserPIN(pin:String?)

    fun getCurrentUserName(): String?
    fun setCurrentUserName(userName: String?)

    fun getCurrentUserPfNo(): String?
    fun setCurrentUserPfNo(pfNo: String?)

    fun getCurrentUserMobileNo(): String?
    fun setCurrentUserMobileNo(mbNo: String?)

    fun getCurrentDeviceNotificationToken(): String?
    fun setCurrentDeviceNotificationToken(token: String?)

    fun getCurrentBranchCode(): String?
    fun setCurrentBranchCode(branchCode: String?)

    fun getCurrentDeptCode(): String?
    fun setCurrentDeptCode(deptCode: String?)

    fun getUserRegionCode(): String?
    fun setUserRegionCode(regCode: String?)

    fun getUsersLastLogin(): String?
    fun setUsersLastLogin(lastLogin: String?)

    fun getCurrentUserEmail(): String?

    fun setCurrentUserEmail(email: String?)

    fun getAccessToken(): String?

    fun setAccessToken(accessToken: String?)
    fun getCurrentBranchName(): String?
    fun setCurrentBranchName(branchName: String?)
    fun getUserRegionName(): String?
    fun setUserRegionName(regionName: String?)

    fun getUserLastLogindate(): String?
    fun setUserLastLogindate(lastLoginDate: String?)
    fun setSessionId(sessionId: String?)

    fun setCurrentUserCadre(cadre: String?)
    fun getCurrentUserCadre():String?

    fun getSessionId():String?

}