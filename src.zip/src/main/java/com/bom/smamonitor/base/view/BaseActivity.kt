package com.bom.smamonitor.base.view

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.MenuItem
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bom.smamonitor.ProjectApplicationClass
import com.bom.smamonitor.R
import com.bom.smamonitor.base.SessionOutListener
import com.bom.smamonitor.login.LoginActivity
import com.bom.smamonitor.pinLockScreen.PinLockActivity
import com.bom.smamonitor.util.AppConstants
import com.bom.smamonitor.util.CommonUtil.showLoadingDialog
import dagger.android.AndroidInjection


@Suppress("DEPRECATION")
abstract class BaseActivity : AppCompatActivity(), BaseMVPView, SessionOutListener {

    private var isUserTimedOut = false
    private var progressDialog: ProgressDialog? = null

//    //Declare handler
//    private var timeoutHandler: Handler? = null
//    private var interactionTimeoutRunnable: Runnable? = null

    private var TAG = "BaseActvt"

    override fun onCreate(savedInstanceState: Bundle?) {
        performDI()
        super.onCreate(savedInstanceState)
        (application as ProjectApplicationClass).registerSessionListener(this)
        (application as ProjectApplicationClass).startUserSession()
        //Initialise handler
//        timeoutHandler = Handler()
//        interactionTimeoutRunnable = Runnable {
//            // Handle Timeout stuffs here
//            Log.d(TAG, "Session Timed out after 3 minutes on inactivity.")
//            Toast.makeText(this, "Session Timed out.", Toast.LENGTH_SHORT)                .show()
//            val intent = Intent(this@BaseActivity, PinLockActivity::class.java)
//            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            startActivity(intent)
//            finish()
//        }
        //start countdown
       // startHandler()
    }

    // reset handler on user interaction
    override fun onUserInteraction() {
        Log.d(TAG, "onUserInteraction")
      //  resetHandler()
        super.onUserInteraction()
    }




    protected override fun onResume() {
        super.onResume()
        if (isUserTimedOut) {
            //show TimerOut dialog
            Log.d(TAG, "Session Timed  after 3 minutes on inactivity.")
            Toast.makeText(this, "Session Timed out.", Toast.LENGTH_SHORT)
                .show()
            val intent = Intent(this@BaseActivity, PinLockActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        } else {
            (application as ProjectApplicationClass).onUserInteracted()
        }
    }

    override fun onSessionTimeout() {
        isUserTimedOut = true
    }





//    //restart countdown
//    private fun resetHandler() {
//        Log.d(TAG, "sessionReset")
//        timeoutHandler?.removeCallbacks(interactionTimeoutRunnable!!);
//        startHandler()
//    }
//
//    // start countdown
//    private fun startHandler() {
//        Log.d(TAG, "session timer start.")
//
////        timeoutHandler?.postAtTime(interactionTimeoutRunnable!!, System.currentTimeMillis())
////        Log.d(TAG,System.currentTimeMillis().toString())
//
//        timeoutHandler?.postDelayed(
//            interactionTimeoutRunnable!!,
//            AppConstants.MAX_TIME_OUT_SESSION.toLong()
//        ) //for 10 second
//    }

    override fun hideProgress() {
        progressDialog?.let { if (it.isShowing) it.cancel() }
    }

    override fun showProgress() {
        hideProgress()
        progressDialog = showLoadingDialog(this)
    }

    private fun performDI() = AndroidInjection.inject(this)

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun initToolbar() {
        window.statusBarColor = ContextCompat.getColor(this, R.color.colorPrimaryDark)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(resources.getDrawable(R.drawable.ic_action_back))
        supportActionBar?.setDisplayShowHomeEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}