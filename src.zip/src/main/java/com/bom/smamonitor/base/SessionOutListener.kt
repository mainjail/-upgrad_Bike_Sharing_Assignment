package com.bom.smamonitor.base

interface SessionOutListener {
    fun onSessionTimeout()

}