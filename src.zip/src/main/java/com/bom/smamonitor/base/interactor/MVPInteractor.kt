package com.bom.smamonitor.base.interactor

import com.bom.smamonitor.login.AppUser

interface MVPInteractor {

    fun isUserLoggedIn(): Boolean
    fun doesUserHavePIN(): String?
    fun performUserLogout()
    fun getUserFromSharedPref(): AppUser
    fun performSessionTimeout()

}
