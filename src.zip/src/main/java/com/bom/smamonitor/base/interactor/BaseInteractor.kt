package com.bom.smamonitor.base.interactor

import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.network.ApiHelper
import com.bom.smamonitor.util.AppConstants

open class BaseInteractor() : MVPInteractor {

    protected lateinit var preferenceHelper: PreferenceHelper
    protected lateinit var apiHelper: ApiHelper

    constructor(preferenceHelper: PreferenceHelper, apiHelper: ApiHelper) : this() {
        this.preferenceHelper = preferenceHelper
        this.apiHelper = apiHelper
    }

    override fun isUserLoggedIn() = this.preferenceHelper.getCurrentUserLoggedInMode()!=
            AppConstants.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT.type

    override fun doesUserHavePIN()= this.preferenceHelper.getCurrentUserPIN()


    override fun getUserFromSharedPref(): AppUser {

        return AppUser(
            preferenceHelper.getCurrentUserPfNo().toString(),
            preferenceHelper.getCurrentUserName(),
            preferenceHelper.getCurrentBranchCode(),
            preferenceHelper.getCurrentBranchName(),
            preferenceHelper.getUserRegionCode(),
            preferenceHelper.getUserRegionName(),
            preferenceHelper.getCurrentUserEmail(),
            preferenceHelper.getCurrentDeptCode(),
            "",
            preferenceHelper.getCurrentUserMobileNo(),
            preferenceHelper.getCurrentDeviceNotificationToken(),
            "",
            preferenceHelper.getUserLastLogindate(),
            preferenceHelper.getSessionId(),
            preferenceHelper.getCurrentUserPIN()
        )
    }

    override fun performUserLogout() = preferenceHelper.let {
        it.setCurrentUserId(null)
        it.setAccessToken(null)
        it.setCurrentUserEmail(null)
        it.setCurrentUserMobileNo(null)
        it.setCurrentUserPfNo(null)
        it.setCurrentBranchCode(null)
        it.setCurrentDeptCode(null)
        it.setCurrentUserPIN(null)
        it.setSessionId(null)              //session clear
        it.setCurrentUserCadre(null)
        it.setCurrentUserLoggedInMode(AppConstants.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT)
    }

    override fun performSessionTimeout() = preferenceHelper.let {
          it.setSessionId(null)              //session clear
    }
}