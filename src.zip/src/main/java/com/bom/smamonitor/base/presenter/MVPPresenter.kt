package com.bom.smamonitor.base.presenter

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.base.view.BaseMVPView

interface MVPPresenter<V : BaseMVPView, I : MVPInteractor> {

    fun onAttach(view: V?)

    fun onDetach()

    fun getView(): V?

    fun sessionTimeout()

}