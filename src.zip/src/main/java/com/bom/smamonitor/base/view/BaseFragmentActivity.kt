@file:Suppress("DEPRECATION")

package com.bom.smamonitor.base.view

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bom.smamonitor.ProjectApplicationClass
import com.bom.smamonitor.R
import com.bom.smamonitor.base.SessionOutListener
import com.bom.smamonitor.pinLockScreen.PinLockActivity
import com.bom.smamonitor.util.CommonUtil
import dagger.android.AndroidInjection
import java.util.*


@Suppress("DEPRECATION")
abstract class BaseFragmentActivity : AppCompatActivity(), BaseMVPView, BaseFragment.CallBack,
    SessionOutListener {
    private var isUserTimedOut = false

    private val TAG = "BaseFrgAct"
    private var progressDialog: ProgressDialog? = null
    private var timeoutHandler: Handler? = null
    private var interactionTimeoutRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        performDI()
        super.onCreate(savedInstanceState)

        (application as ProjectApplicationClass).registerSessionListener(this)
        (application as ProjectApplicationClass).startUserSession()

//        timeoutHandler = Handler()
//        interactionTimeoutRunnable = Runnable {
//            val currentDateMS: Long = Date().time
//            Log.d(TAG, "time: $currentDateMS")
//            Log.d(TAG, "Session Timed  after 3 minutes on inactivity.")
//            Toast.makeText(this, "Session Timed out.", Toast.LENGTH_SHORT)
//                .show()
//            val intent = Intent(this@BaseFragmentActivity, PinLockActivity::class.java)
//            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            startActivity(intent)
//            finish()
//        }
//        startHandler()


    }

    // reset handler on user interaction
    override fun onUserInteraction() {
        Log.d(TAG, "onUserInteraction")
//        resetHandler()
        super.onUserInteraction()
    }

    //
//    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
////        resetHandler()
//        Log.d(TAG, "dispatchTouchEvent")
//        return super.dispatchTouchEvent(ev)
//    }
    protected override fun onResume() {
        super.onResume()
        if (isUserTimedOut) {
            //show TimerOut dialog
            Log.d(TAG, "Session Timed  after 3 minutes on inactivity.")
            Toast.makeText(this, "Session Timed out.", Toast.LENGTH_SHORT)
                .show()
            val intent = Intent(this@BaseFragmentActivity, PinLockActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        } else {
            (application as ProjectApplicationClass).onUserInteracted()
        }
    }

    override fun onSessionTimeout() {
        isUserTimedOut = true
    }



//    //restart countdown
//    private fun resetHandler() {
//        Log.d(TAG, "sessionReset")
//        timeoutHandler?.removeCallbacks(interactionTimeoutRunnable!!);
//        startHandler()
//
//    }
//
//    // start countdown
//    private fun startHandler() {
//        Log.d(TAG, "startHandler")
//
//        timeoutHandler?.postAtTime(interactionTimeoutRunnable!!, System.currentTimeMillis())
//        val millis = System.currentTimeMillis()
//
//
//        val seconds = millis / 1000
//
//        val currentDateMS: Long = Date().time
//        //Log.d(TAG, "time: "+currentDateMS)
//
//        timeoutHandler?.postDelayed(interactionTimeoutRunnable!!, 30000)
//    }

    override fun hideProgress() {
        progressDialog?.let { if (it.isShowing) it.cancel() }
    }

    override fun showProgress() {
        hideProgress()
        progressDialog = CommonUtil.showLoadingDialog(this)
    }

    private fun performDI() = AndroidInjection.inject(this)

    override fun initToolbar() {
        window.statusBarColor = ContextCompat.getColor(this, R.color.colorPrimaryDark)
    }


}