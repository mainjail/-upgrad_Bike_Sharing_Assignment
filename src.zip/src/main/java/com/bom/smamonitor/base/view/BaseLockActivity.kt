package com.bom.smamonitor.base.view

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bom.smamonitor.R
import com.bom.smamonitor.util.AppConstants
import com.bom.smamonitor.util.CommonUtil.showLoadingDialog
import dagger.android.AndroidInjection


@Suppress("DEPRECATION")
abstract class BaseLockActivity : AppCompatActivity(), BaseMVPView {

    private var progressDialog: ProgressDialog? = null

    private var TAG = "BaseLockAc"

    override fun onCreate(savedInstanceState: Bundle?) {
        performDI()
        super.onCreate(savedInstanceState)

    }

    // reset handler on user interaction
    override fun onUserInteraction() {
        super.onUserInteraction()
        Log.d(TAG,"onUserInteraction")
    }






    override fun hideProgress() {
        progressDialog?.let { if (it.isShowing) it.cancel() }
    }

    override fun showProgress() {
        hideProgress()
        progressDialog = showLoadingDialog(this)
    }

    private fun performDI() = AndroidInjection.inject(this)

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun initToolbar() {
        window.statusBarColor = ContextCompat.getColor(this, R.color.colorPrimaryDark)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(resources.getDrawable(R.drawable.ic_action_back))
        supportActionBar?.setDisplayShowHomeEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}