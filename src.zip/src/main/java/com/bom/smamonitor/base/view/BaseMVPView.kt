package com.bom.smamonitor.base.view

interface BaseMVPView  {

    fun initToolbar()
    fun showProgress()
    fun hideProgress()
}