package com.bom.smamonitor.addVisit

import com.bom.smamonitor.base.presenter.MVPPresenter
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.User

interface AddVisitMVPPresenter<V : AddVisitMVPView, I : AddVisitMVPInteractor> :
    MVPPresenter<V, I> {

    fun addVisit(smaVisit: SmaVisit)
    fun getPrefUserDetails(): AppUser
    fun addVisitSmaRetrofit(visit: SmaVisit)
    fun addSmaStressVisit(visit :SmaStressVisit)
//    fun getVisits(custNo: String)

    fun addVisitRetrofit(visit: Visit)
}
