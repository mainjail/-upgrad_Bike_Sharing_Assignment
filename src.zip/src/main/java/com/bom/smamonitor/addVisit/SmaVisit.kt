package com.bom.smamonitor.addVisit

import com.google.gson.annotations.SerializedName


data class SmaVisit(

    @SerializedName("visitId")
    val visitId: String?,

    @SerializedName("visitDate")
    val visitDate: String,

    @SerializedName("ptpDate")
    val ptpDate: String,

    @SerializedName("custNo")
    val custNo: String,

//    @SerializedName("acNo")
//    val acNo: String,

    @SerializedName("report")
    val report: String,

    @SerializedName("defaultSince")
    val defaultSinceDate: String,

    @SerializedName("custName")
    val custName: String,

    @SerializedName("visitorName")
    val visitorName: String,

    @SerializedName("visitorPfNo")
    val visitorPfNo: String,

    @SerializedName("collectionAction")
    val collectionAction: String,

    @SerializedName("comments")
    val comments: String,

    @SerializedName("latitude")
    val latitude: String,

    @SerializedName("longitude")
    val longitude: String,

    @SerializedName("brCode")
    val brCode: String

)

