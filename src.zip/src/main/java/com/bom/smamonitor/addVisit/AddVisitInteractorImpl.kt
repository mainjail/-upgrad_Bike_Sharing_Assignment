package com.bom.smamonitor.addVisit


import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.login.User
import com.bom.smamonitor.network.ApiHelper
import io.reactivex.Observable
import javax.inject.Inject

class AddVisitInteractorImpl @Inject internal constructor(
    preferenceHelper: PreferenceHelper,
    apiHelper: ApiHelper
) :
    BaseInteractor(preferenceHelper, apiHelper), AddVisitMVPInteractor {

    override fun addVisitApiCall(smaVisit: SmaVisit) = apiHelper.addSmaVisit(smaVisit)


    override fun getSmaVisits(custNo: String): Observable<List<SmaVisit>>
            = apiHelper.getSmaVisits(custNo)


//    override fun getUserFromSharedPref(): User {
//
//        val user = User(
//            preferenceHelper.getCurrentUserPfNo().toString(),
//            preferenceHelper.getCurrentUserName(),
//            preferenceHelper.getCurrentBranchCode(),
//            "",
//            preferenceHelper.getCurrentUserEmail(),
//            "",
//            "",
//            preferenceHelper.getCurrentUserMobileNo()
//        )
//        return user
//    }

}