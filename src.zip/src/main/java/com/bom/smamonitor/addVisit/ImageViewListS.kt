package com.bom.smamonitor.addVisit


import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.dashboard.ImageViewModel
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.category_item_layout.view.*

class ImageViewListS(val activity: Activity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var listOfCategories = listOf<ImageViewModel>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return SimpleIvHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.category_item_layout,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int = listOfCategories.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val simpleIvHolder = viewHolder as SimpleIvHolder
        simpleIvHolder.bindView(listOfCategories[position])
    }

    fun setCategoryList(listOfMovies: List<ImageViewModel>) {
        this.listOfCategories = listOfMovies
        notifyDataSetChanged()
    }

    inner class SimpleIvHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindView(movieModel: ImageViewModel) {
            itemView.catTitle.text = movieModel.imageName
            Glide.with(itemView.context).load(movieModel.imageUri).into(itemView.imageCat)
        }
    }
}