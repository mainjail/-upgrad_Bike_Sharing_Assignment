package com.bom.smamonitor.addVisit

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewParent
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText

import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView.Adapter
import com.bom.smamonitor.R
import com.bom.smamonitor.addVisit.LocationHelper.MyLocationListener
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.custlist.model.CustAcDetailsObj
import com.bom.smamonitor.custlist.model.CustomerRep2
import com.bom.smamonitor.dashboard.ImageViewModel
import com.bom.smamonitor.details.VisitsAdapter
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.DateUtil
import com.bom.smamonitor.util.ValidationUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_add_visit.*
import kotlinx.android.synthetic.main.dialog_bottom_sheet_picker.*
import kotlinx.android.synthetic.main.fragment_home.reportSpinnerHomeFrg
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject


class AddVisitActivity : BaseActivity(), AddVisitMVPView {

    private var isPtpDateSelected = false
    private var isnoticeServedTypeDateSelected = false
    private var probableDateOfUpgradationSelected = false

    private var isChipSelected = false
    private var isGalleryOpen = false
    private val Storage_PERM_ID = 111
    private var reportName = "-"
    private lateinit var customer: CustomerRep2
    private val TAG = "AddVistAct"
    private val PERMISSION_ID = 110

    private var isLocSaved = false


    private val calendar1 = Calendar.getInstance()
    private val calendar2 = Calendar.getInstance()
    private val calendar3 = Calendar.getInstance()
    private val calendar4 = Calendar.getInstance()

    private val myFormat = "yyyy-MM-dd" // mention the format you need
    private val sdf = SimpleDateFormat(myFormat, Locale.US)

    var myLatitude: String = "Null"
    var myLongitude: String = "Null"
    var isLocationRefresh = false

    private var isSpinnerSelected = false
    private var spinnerval:String = "Null"

    private var isSpinnerSelected1 = false
    private var spinnerval1:String = "Null"

    private var isSpinnerSelected2 = false
    private var spinnerval2:String = "Null"

    private var isSpinnerSelected3 = false
    private var spinnerval3:String = "Null"

    private var isSpinnerSelected4 = true
    private var spinnerval4:String = "Null"

    private var isSpinnerSelected5 = false
    private var spinnerval5:String = "Null"

    private var isSpinnerSelected6 = false
    private var spinnerval6:String = "Null"

    private var isSpinnerSelected7 = false
    private var spinnerval7:String = "Null"

    private var isSpinnerSelected8 = false
    private var spinnerval8:String = "Null"

    private var isSpinnerSelected9 = true
    private var spinnerval9:String = "Null"

    private var isSpinnerSelected10 = false
    private var spinnerval10:String = "Null"

    private var isSpinnerSelected11 = false
    private var spinnerval11:String = "Null"

    private var isSpinnerSelected12 = true
    private var spinnerval12:String = "Null"

    private var isSpinnerSelected13 = false
    private var spinnerval13:String = "Null"

    private var isSpinnerSelected14 = false
    private var spinnerval14:String = "Null"

    private var category:String = "Null"

    private var isSpinnerSelected15 = false
    private var spinnerval15:String = "Null"

    private var customerBalance :Double = 0.00
    private var branchCode = ""


    private val String.capitalizeWords
        get() = this.lowercase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        }

    @Inject
    internal lateinit var visitsAdapter: VisitsAdapter

    @Inject
    internal lateinit var imageAdapter: ImageViewListS

    @Inject
    internal lateinit var layoutManager: LinearLayoutManager

    @Inject
    internal lateinit var presenter: AddVisitMVPPresenter<AddVisitMVPView, AddVisitMVPInteractor>

    private val dateSetListener1 =
        DatePickerDialog.OnDateSetListener { datePickerView, year, monthOfYear, dayOfMonth ->
            calendar1.set(Calendar.YEAR, year)
            calendar1.set(Calendar.MONTH, monthOfYear)
            calendar1.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            dateTv.text = sdf.format(calendar1.time)
        }

    private val dateSetListener2 =
        DatePickerDialog.OnDateSetListener { datePickerView, year, monthOfYear, dayOfMonth ->
            calendar2.set(Calendar.YEAR, year)
            calendar2.set(Calendar.MONTH, monthOfYear)
            calendar2.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            ptpDateTv.text = sdf.format(calendar2.time)
            isPtpDateSelected = true
        }

    private val dateSetListener3 =
        DatePickerDialog.OnDateSetListener { datePickerView, year, monthOfYear, dayOfMonth ->
            calendar3.set(Calendar.YEAR, year)
            calendar3.set(Calendar.MONTH, monthOfYear)
            calendar3.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            noticeServedTypeDate.text = sdf.format(calendar3.time)
            isnoticeServedTypeDateSelected = true
        }

    private val dateSetListener4 =
        DatePickerDialog.OnDateSetListener { datePickerView, year, monthOfYear, dayOfMonth ->
            calendar4.set(Calendar.YEAR, year)
            calendar4.set(Calendar.MONTH, monthOfYear)
            calendar4.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            probableDateOfUpgradationTv.text = sdf.format(calendar4.time)
            probableDateOfUpgradationSelected = true
        }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_visit)
        presenter.onAttach(this)
        initView()
        supportActionBar?.title = resources.getString(R.string.UpdateRemarks)
    }

    private fun initView() {
        val user = presenter.getPrefUserDetails()
        val strObj = intent.getStringExtra("smaCustomer")
        branchCode = intent.getStringExtra("customerBranchCode").toString()

        customer = Gson().fromJson(strObj, CustomerRep2::class.java)

        val acDetailsObj = intent.getStringExtra("custAcDetailsObj")
        val custAcDetailsObj: CustAcDetailsObj =
            Gson().fromJson(acDetailsObj, CustAcDetailsObj::class.java)

        custNameTv.text = customer.custName
        if (customer.defaultDate != null
        )
            defDateTv.text = DateUtil.convertDateToddMMyy(customer.defaultDate)

        visitorNameTv.text = user.name
        visitorPfNo.text = user.pfNo
        dateTv.text = sdf.format(calendar1.time)
        dateTv.isClickable = false

        ptpDateTv.text = sdf.format(calendar2.time)

        var custAcList = custAcDetailsObj.custAcDetailsList
        if (custAcList.isNotEmpty()) {
            for (custAcDetails in custAcList) {
                Log.e("custAcDetails",custAcDetails.balance)
                customerBalance = custAcDetails.balance.toDouble()

                if (custAcDetails.smaFlag != null) {
                    reportName = custAcDetails.smaFlag.trim()
                    reportTv.text = reportName
                }

            }
        }

//        layoutManager.orientation = LinearLayoutManager.VERTICAL
//        visitsRV.layoutManager = layoutManager
//        visitsRV.itemAnimator = DefaultItemAnimator()
//        visitsRV.adapter = visitsAdapter
//        val emptyRvObserver = RVEmptyObserver(emptyView = emptyVisitMsgTv, recyclerView = visitsRV)
//        visitsAdapter.registerAdapterDataObserver(emptyRvObserver)
//        visitsRV.visibility = View.VISIBLE
//        visitsRV.setHasFixedSize(true)
//        visitsRV.isNestedScrollingEnabled = false
        actionChipGrp.isSelectionRequired = true
        actionChipGrp.isSingleSelection = true
//        apiCallForVisitsHistory()
        getLocation()

        dateTv.setOnClickListener {
            // openDatePickerDialog1()
        }
        ptpDateTv.setOnClickListener {
            openDatePickerDialog2()
        }
        noticeServedTypeDate.setOnClickListener {
            openDatePickerDialog3()
        }
        probableDateOfUpgradationTv.setOnClickListener {
            openDatePickerDialog4()
        }
        getMyLocTv.setOnClickListener {
            isLocationRefresh = true
            getLocation()
        }
        attachTv.setOnClickListener {
            showBottomDialog()
        }
//        val accList: MutableList<String> = ArrayList()
//
//        if (custAcDetailsObj.custAcDetailsList.isNotEmpty()) {
//            for (custAc in custAcDetailsObj.custAcDetailsList) {
//                accList.add(custAc.acNo)
//            }
//        }

//        val adapter1 =            ArrayAdapter(this, android.R.layout.simple_list_item_1, accList.toTypedArray())
//        accNoSpinner.adapter = adapter1

        actionChipGrp.setOnCheckedChangeListener(ChipGroup.OnCheckedChangeListener { chipGroup, i ->
            Log.i(TAG, i.toString() + "")
            isChipSelected = true
        })


        addVisitBtn.setOnClickListener {
            Log.e(
                "AdVist", isLocSaved.toString() + " " + et_comments.text
                        + " " + actionChipGrp.isSelected
            )

            Log.e("Cersai Asset", verificationOfChargeCAD.text.toString().trim());
            Log.e("Any other remark", remarksByVisitingOfficialHeader.text.toString().trim());
            Log.e("Major Irregularity", majorIrragularityTxt.text.toString().trim());
            Log.e("detailsOfAcBankName", detailsOfAcBankName.text.toString().trim());

            Log.e("SpinnerValueAvailable", isSpinnerSelected.toString());
            Log.e("SpinnerValueAvailable1", isSpinnerSelected1.toString());
            Log.e("SpinnerValueAvailable2", isSpinnerSelected2.toString());
            Log.e("SpinnerValueAvailable3", isSpinnerSelected3.toString());
            Log.e("SpinnerValueAvailable4", isSpinnerSelected4.toString());
            Log.e("SpinnerValueAvailable5", isSpinnerSelected5.toString());
            Log.e("SpinnerValueAvailable6", isSpinnerSelected6.toString());
            Log.e("SpinnerValueAvailable7", isSpinnerSelected7.toString());
            Log.e("SpinnerValueAvailable8", isSpinnerSelected8.toString());
            Log.e("SpinnerValueAvailable9", isSpinnerSelected9.toString());
            Log.e("SpinnerValueAvailable10", isSpinnerSelected10.toString());
            Log.e("SpinnerValueAvailable11", isSpinnerSelected11.toString());
            Log.e("SpinnerValueAvailable12", isSpinnerSelected12.toString());
            Log.e("SpinnerValueAvailable13", isSpinnerSelected13.toString());
            Log.e("SpinnerValueAvailable14", isSpinnerSelected14.toString());
            Log.e("SpinnerValueAvailable15", isSpinnerSelected15.toString());
            Log.e("noticeServedTypeDate", noticeServedTypeDate.text.toString());
            Log.e("probableDateOfUpgrade", probableDateOfUpgradationTv.text.toString());



            if (et_comments.text?.isNotEmpty()!!
                && verificationOfChargeCAD.text?.isNotEmpty()!!
                && remarksByVisitingOfficialHeader.text?.isNotEmpty()!!
                && majorIrragularityTxt.text?.isNotEmpty()!!
                && isLocSaved && isChipSelected && isPtpDateSelected
                && isSpinnerSelected && isSpinnerSelected1
                && isSpinnerSelected2 && isSpinnerSelected3
                && isSpinnerSelected4 && isSpinnerSelected5
                && isSpinnerSelected6 && isSpinnerSelected7
                && isSpinnerSelected8 && isSpinnerSelected9
                && isSpinnerSelected10 && isSpinnerSelected11
                && isSpinnerSelected12 && isSpinnerSelected13
                && isSpinnerSelected14 && isSpinnerSelected15
            ) {

                Log.e("spinnerval", spinnerval);
                Log.e("spinnerval2", spinnerval2);
                Log.e("spinnerval10", spinnerval10);
                Log.e("spinnerval13", spinnerval13);
                Log.e("spinnerval6", spinnerval6);
                Log.e("spinnerval9", spinnerval9);
                Log.e("spinnerval7", spinnerval7);
                Log.e("spinnerval10", spinnerval10);


                if (spinnerval == "Absconding"
                    || spinnerval == "Not Traceable"
                    || spinnerval2 == "No"
                    || spinnerval10 == "Closed"
                    || spinnerval13 == "No Cash flow"
                    || spinnerval6 == "Not as per sanction"
                    || spinnerval9 == "Negative variation"
                    || spinnerval7 == "No Stock"
                    || spinnerval15 == "Yes"
                ) {
                    Log.e("category", category);
                    category = "RED"
                } else if (spinnerval10 == "Low Level" || spinnerval13 == "Inadequate" || spinnerval7 == "Inadequate") {
                    category = "AMBER"
                    Log.e("category", category);
                } else {
                    category = "GREEN"
                    Log.e("category", category);
                }
                Log.e("category", category);
                val selectedChipText =
                    actionChipGrp.findViewById<Chip>(actionChipGrp.checkedChipId).text.toString()





                val visit = SmaVisit(
                    null, dateTv.text.toString(), ptpDateTv.text.toString(), customer.cif,
                    reportTv.text.toString(), defDateTv.text.toString(),
                    customer.custName.trim().capitalizeWords,
                    user.name.toString().trim().capitalizeWords,
                    user.pfNo, selectedChipText,
                    et_comments.text.toString().trim(),
                    myLatitude, myLongitude,
                    user.curBranch.toString()
                )

                if (ValidationUtils.isNetworkAvailable(this)) {
                    presenter.addVisitSmaRetrofit(visit)
                } else {
                    CustomDialog().showNoInternetAlert(this, "")
                }

//                val visitorName = user.name.toString().trim().uppercase() + "-" + user.pfNo + "-MANAGER";
//
//                val mobNo = if (customer.mobNo == null) "9999999999" else customer.mobNo
//                Log.e("mobNo2", mobNo);
//                val stressVisit = SmaStressVisit(
//                    dateTv.text.toString(),
//                    customer.cif,
//                    customer.custName.trim().capitalizeWords,
//                    mobNo,
//                    visitorName,
//                    user.branchName.toString(),
//                    user.curBranch.toString(),
//                    user.regionName.toString(),
//                    user.regionCode.toString(),
//                    spinnerval, //varification of borrower spinner
//                    spinnerval1, //varification of charge  spinner
//                    spinnerval2, //varification of charge 7/12 spinner
//                    verificationOfChargeCAD.text.toString().trim(), // cersai asset id
//                    spinnerval3, // notice served spinner
//                    spinnerval4, // notice served type spinner
//                    noticeServedTypeDate.text.toString(), //notice served type date
//                    spinnerval12,// other bank ac closed
//                    spinnerval5, // cash recovery
//                    remarksByVisitingOfficialHeader.text.toString().trim(), // any other remark by vo
//                    majorIrragularityTxt.text.toString().trim(), // major irrg
//                    spinnerval6, //end use spinner
//                    spinnerval7, //stock spinner
//                    spinnerval8,  //stock verification spinner
//                    spinnerval9, //stock verification status spinner
//                    spinnerval10, // sma reason activity status spinner
//                    spinnerval11, //ac with other bank spinner
//                    detailsOfAcBankName.text.toString(), // bank name edittext
//                    spinnerval13, //cash flow spinner
//                    spinnerval14, // prob upgradation spinner
//                    probableDateOfUpgradationTv.text.toString(), // prob upgrad date
//                    user.pfNo,
//                    category,
//                    user.curBranch.toString(),
//                    customer.balance,
//                    spinnerval15, //fraud flag spinner
//                    myLatitude,
//                    myLongitude,
//                    et_comments.text.toString().trim()
//                )
//
//                if (ValidationUtils.isNetworkAvailable(this)) {
//                    presenter.addSmaStressVisit(stressVisit)
//                } else {
//                    CustomDialog().showNoInternetAlert(this, "")
//                }

            } else {
                CustomDialog().popUpToast(
                    this@AddVisitActivity,
                    "Please enter/Select All fields in update. "
                )
            }


//              old code
//            if (et_comments.text?.isNotEmpty()!! &&
//                isLocSaved && isChipSelected && isPtpDateSelected
//            ) {
//
//                val selectedChipText =  actionChipGrp.findViewById<Chip>(actionChipGrp.checkedChipId).text.toString()
//
//                val visit = SmaVisit(
//                    null, dateTv.text.toString(), ptpDateTv.text.toString(), customer.cif,
//                    reportTv.text.toString(), defDateTv.text.toString(),
//                    customer.custName.trim().capitalizeWords,
//                    user.name.toString().trim().capitalizeWords,
//                    user.pfNo, selectedChipText,
//                    et_comments.text.toString().trim(),
//                    myLatitude, myLongitude,
//                    user.curBranch.toString()
//                )
//
//                if (ValidationUtils.isNetworkAvailable(this))
//                    presenter.addVisitSmaRetrofit(visit)
//                else CustomDialog().showNoInternetAlert(this, "")
//
//            } else {
//                CustomDialog().popUpToast(
//                    this@AddVisitActivity,
//                    "Please enter/Select All fields in update. "
//                )
//            }



        }

        val spinner : Spinner = findViewById(R.id.verificationOfBorrowerName)
        val spItems = listOf("Select","Available at the time of visit","Verified Through relative/friend/neighbour","Not Traceable","Absconding")
        val adapter = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        spinner.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item: $selectedItem")
                isSpinnerSelected = true;
                spinnerval = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected = false;
            }

        }

        val spinner1 : Spinner = findViewById(R.id.verificationOfChargeHB)
        val spItems1 = listOf("Select","Available","Not Available","NA")
        val adapter1 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems1)
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner1.adapter = adapter1

        spinner1.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner1: $selectedItem")
                isSpinnerSelected1 = true;
                spinnerval1 = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected1 = false;
            }

        }

        val spinner2 : Spinner = findViewById(R.id.verificationOfChargeEBC)
        val spItems2 = listOf("Select","Yes","No","NA")
        val adapter2 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems2)
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner2.adapter = adapter2

        spinner2.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner2: $selectedItem")
                isSpinnerSelected2 = true;
                spinnerval2 = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected2 = false;
            }
        }

        val spinner3 : Spinner = findViewById(R.id.noticeServedHeader)
        val spItems3 = listOf("Select","Yes","No")
        val adapter3 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems3)
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner3.adapter = adapter3

        spinner3.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner3: $selectedItem")
                isSpinnerSelected3 = true;
                spinnerval3 = selectedItem;
                if(position == 1){
                    noticeServedTypeHeader.visibility = View.VISIBLE
                    noticeServedTypeDateHeader.visibility = View.VISIBLE
                } else{
                    noticeServedTypeHeader.visibility = View.GONE
                    noticeServedTypeDateHeader.visibility = View.GONE
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected3 = false;
            }
        }

        val spinner4 : Spinner = findViewById(R.id.noticeServedType)
        val spItems4 = listOf("Select","13(2)","Seizure","Symbolic Possession","Recall Notice")
        val adapter4 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems4)
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner4.adapter = adapter4

        spinner4.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner4: $selectedItem")
                isSpinnerSelected4 = true;
                spinnerval4 = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected4 = false;
            }
        }

        val spinner5 : Spinner = findViewById(R.id.cashRecoveryHeader)
        val spItems5 = listOf("Select","Yes","No")
        val adapter5 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems5)
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner5.adapter = adapter5

        spinner5.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner5: $selectedItem")
                isSpinnerSelected5 = true;
                spinnerval5 = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected5 = false;
            }
        }


        val spinner6 : Spinner = findViewById(R.id.endUseHeader)
        val spItems6 = listOf("Select","Shed/House/Property constructed as per sanction term","Machinery/Vehicle purchased as per sanctioned","Not as per sanction",
            "NA")
        val adapter6 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems6)
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner6.adapter = adapter6

        spinner6.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner6: $selectedItem")
                isSpinnerSelected6 = true;
                spinnerval6 = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected6 = false;
            }
        }


        val spinner7 : Spinner = findViewById(R.id.stockHeader)
        val spItems7 = listOf("Select","Adequate","Inadequate","No Stock","NA")
        val adapter7= ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems7)
        adapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner7.adapter = adapter7

        spinner7.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner7: $selectedItem")
                isSpinnerSelected7 = true;
                spinnerval7 = selectedItem;


            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected7 = false;
            }
        }

        val spinner8 : Spinner = findViewById(R.id.stockVerificationSp)
        val spItems8 = listOf("Select","Yes","No")
        val adapter8 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems8)
        adapter8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner8.adapter = adapter8

        spinner8.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner8: $selectedItem")
                isSpinnerSelected8 = true;
                spinnerval8 = selectedItem;
                if(position == 1){
                    stockVerificationSecurity.visibility = View.VISIBLE
                } else {
                    stockVerificationSecurity.visibility = View.GONE
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected8 = false;
            }
        }

        val spinner9 : Spinner = findViewById(R.id.stockVerificationSecuritySp)
        val spItems9 = listOf("Select","Tallied","Positive variation","Negative variation")
        val adapter9 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems9)
        adapter9.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner9.adapter = adapter9

        spinner9.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner9: $selectedItem")
                isSpinnerSelected9 = true;
                spinnerval9 = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected9 = false;
            }
        }

        val spinner10 : Spinner = findViewById(R.id.activityStatusSp)
        val spItems10 = listOf("Select","Running","Low Level","Closed","NA")
        val adapter10 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems10)
        adapter10.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner10.adapter = adapter10

        spinner10.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner10: $selectedItem")
                isSpinnerSelected10 = true;
                spinnerval10 = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected10 = false;
            }
        }

        val spinner11 : Spinner = findViewById(R.id.acWithOtherBankHeaderSp)
        val spItems11 = listOf("Select","Yes","No","NA")
        val adapter11 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems11)
        adapter11.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner11.adapter = adapter11

        spinner11.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner11: $selectedItem")
                isSpinnerSelected11 = true;
                spinnerval11 = selectedItem;

                if(position == 1){
                    otherBankAcClosedHeader.visibility = View.VISIBLE
                    detailsOfAcBankNameHeader.visibility = View.VISIBLE

                } else {
                    otherBankAcClosedHeader.visibility = View.GONE
                    detailsOfAcBankNameHeader.visibility = View.GONE

                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected11 = false;
            }
        }

        val spinner12 : Spinner = findViewById(R.id.otherBankAcClosedHeaderSp)
        val spItems12 = listOf("Select","Letter issued","Not issued","NA")
        val adapter12 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems12)
        adapter12.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner12.adapter = adapter12

        spinner12.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner12: $selectedItem")
                isSpinnerSelected12 = true;
                spinnerval12 = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected12 = false;
            }
        }

        val spinner13 : Spinner = findViewById(R.id.cashFlowHeaderSp)
        val spItems13 = listOf("Select","Adequate","Inadequate","No Cash flow","NA")
        val adapter13 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems13)
        adapter13.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner13.adapter = adapter13

        spinner13.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner13: $selectedItem")
                isSpinnerSelected13 = true;
                spinnerval13 = selectedItem;
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected13 = false;
            }
        }

        val spinner14 : Spinner = findViewById(R.id.probUpgradationSp)
        val spItems14 = listOf("Select","Yes","No")
        val adapter14 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems14)
        adapter14.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner14.adapter = adapter14

        spinner14.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner14: $selectedItem")
                isSpinnerSelected14 = true;
                spinnerval14 = selectedItem;
                if(position == 1){
                    probableDateOfUpgradationHeader.visibility = View.VISIBLE
                } else {
                    probableDateOfUpgradationHeader.visibility = View.GONE
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected14 = false;
            }
        }

        val spinner15 : Spinner = findViewById(R.id.suspFraudSp)
        val spItems15 = listOf("Select","Yes","No")
        val adapter15 = ArrayAdapter(this,android.R.layout.simple_spinner_item,spItems15)
        adapter15.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner15.adapter = adapter15

        spinner15.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parentView.getItemAtPosition(position) as String
                // Handle the item selection (e.g., display it in a TextView)
                println("Selected item spinner15: $selectedItem")
                isSpinnerSelected15 = true;
                spinnerval15 = selectedItem;

            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                isSpinnerSelected15 = false;
            }
        }

        //  edit text cersai validation
        val et : EditText = findViewById(R.id.verificationOfChargeCAD)
        et.addTextChangedListener(object:TextWatcher {
            override fun beforeTextChanged(s:CharSequence?, start :Int, count : Int,after: Int){

            }

            override fun onTextChanged(s:CharSequence?, start :Int, before : Int, count : Int){

            }

            override fun afterTextChanged(s:Editable?){
                s?.let {
                    val filteredText = it.filter { char ->
                        char == ',' || char == '.' || char.isWhitespace()
                                || char == 'A' || char == 'a'
                                || char == 'B' || char == 'b'
                                || char == 'C' || char == 'c'
                                || char == 'D' || char == 'd'
                                || char == 'E' || char == 'e'
                                || char == 'F' || char == 'f'
                                || char == 'G' || char == 'g'
                                || char == 'H' || char == 'h'
                                || char == 'I' || char == 'i'
                                || char == 'J' || char == 'j'
                                || char == 'K' || char == 'k'
                                || char == 'L' || char == 'l'
                                || char == 'M' || char == 'm'
                                || char == 'N' || char == 'n'
                                || char == 'O' || char == 'o'
                                || char == 'P' || char == 'p'
                                || char == 'Q' || char == 'q'
                                || char == 'R' || char == 'r'
                                || char == 'S' || char == 's'
                                || char == 'T' || char == 't'
                                || char == 'U' || char == 'u'
                                || char == 'V' || char == 'v'
                                || char == 'W' || char == 'w'
                                || char == 'X' || char == 'x'
                                || char == 'Y' || char == 'y'
                                || char == 'Z' || char == 'z'
                                || char == '1' || char == '2'
                                || char == '3' || char == '4'
                                || char == '5' || char == '6'
                                || char == '7' || char == '8'
                                || char == '9' || char == '0'
                    }
                    println("enteredText: $it")
                    println("filteredText: $filteredText")

                    if(it.toString() != filteredText.toString()){
                        et.setText(filteredText)
                        et.setSelection(filteredText.length)
                    }
                }
            }
        })

        val et1 : EditText = findViewById(R.id.remarksByVisitingOfficialHeader)
        et1.addTextChangedListener(object:TextWatcher {
            override fun beforeTextChanged(s:CharSequence?, start :Int, count : Int,after: Int){

            }

            override fun onTextChanged(s:CharSequence?, start :Int, before : Int, count : Int){

            }

            override fun afterTextChanged(s:Editable?){
                s?.let {
                    val filteredText = it.filter { char ->
                        char == ',' || char == '.' || char.isWhitespace()
                                || char == 'A' || char == 'a'
                                || char == 'B' || char == 'b'
                                || char == 'C' || char == 'c'
                                || char == 'D' || char == 'd'
                                || char == 'E' || char == 'e'
                                || char == 'F' || char == 'f'
                                || char == 'G' || char == 'g'
                                || char == 'H' || char == 'h'
                                || char == 'I' || char == 'i'
                                || char == 'J' || char == 'j'
                                || char == 'K' || char == 'k'
                                || char == 'L' || char == 'l'
                                || char == 'M' || char == 'm'
                                || char == 'N' || char == 'n'
                                || char == 'O' || char == 'o'
                                || char == 'P' || char == 'p'
                                || char == 'Q' || char == 'q'
                                || char == 'R' || char == 'r'
                                || char == 'S' || char == 's'
                                || char == 'T' || char == 't'
                                || char == 'U' || char == 'u'
                                || char == 'V' || char == 'v'
                                || char == 'W' || char == 'w'
                                || char == 'X' || char == 'x'
                                || char == 'Y' || char == 'y'
                                || char == 'Z' || char == 'z'
                                || char == '1' || char == '2'
                                || char == '3' || char == '4'
                                || char == '5' || char == '6'
                                || char == '7' || char == '8'
                                || char == '9' || char == '0'
                    }
                    println("enteredText: $it")
                    println("filteredText: $filteredText")

                    if(it.toString() != filteredText.toString()){
                        et1.setText(filteredText)
                        et1.setSelection(filteredText.length)
                    }
                }
            }
        })


        val et2 : EditText = findViewById(R.id.majorIrragularityTxt)
        et2.addTextChangedListener(object:TextWatcher {
            override fun beforeTextChanged(s:CharSequence?, start :Int, count : Int,after: Int){

            }

            override fun onTextChanged(s:CharSequence?, start :Int, before : Int, count : Int){

            }

            override fun afterTextChanged(s:Editable?){
                s?.let {
                    val filteredText = it.filter { char ->
                        char == ',' || char == '.' || char.isWhitespace()
                                || char == 'A' || char == 'a'
                                || char == 'B' || char == 'b'
                                || char == 'C' || char == 'c'
                                || char == 'D' || char == 'd'
                                || char == 'E' || char == 'e'
                                || char == 'F' || char == 'f'
                                || char == 'G' || char == 'g'
                                || char == 'H' || char == 'h'
                                || char == 'I' || char == 'i'
                                || char == 'J' || char == 'j'
                                || char == 'K' || char == 'k'
                                || char == 'L' || char == 'l'
                                || char == 'M' || char == 'm'
                                || char == 'N' || char == 'n'
                                || char == 'O' || char == 'o'
                                || char == 'P' || char == 'p'
                                || char == 'Q' || char == 'q'
                                || char == 'R' || char == 'r'
                                || char == 'S' || char == 's'
                                || char == 'T' || char == 't'
                                || char == 'U' || char == 'u'
                                || char == 'V' || char == 'v'
                                || char == 'W' || char == 'w'
                                || char == 'X' || char == 'x'
                                || char == 'Y' || char == 'y'
                                || char == 'Z' || char == 'z'
                                || char == '1' || char == '2'
                                || char == '3' || char == '4'
                                || char == '5' || char == '6'
                                || char == '7' || char == '8'
                                || char == '9' || char == '0'
                    }
                    println("enteredText: $it")
                    println("filteredText: $filteredText")

                    if(it.toString() != filteredText.toString()){
                        et2.setText(filteredText)
                        et2.setSelection(filteredText.length)
                    }
                }
            }
        })

        val et3 : EditText = findViewById(R.id.detailsOfAcBankName)
        et3.addTextChangedListener(object:TextWatcher {
            override fun beforeTextChanged(s:CharSequence?, start :Int, count : Int,after: Int){

            }

            override fun onTextChanged(s:CharSequence?, start :Int, before : Int, count : Int){

            }

            override fun afterTextChanged(s:Editable?){
                s?.let {
                    val filteredText = it.filter { char ->
                        char == ',' || char == '.' || char.isWhitespace()
                                || char == 'A' || char == 'a'
                                || char == 'B' || char == 'b'
                                || char == 'C' || char == 'c'
                                || char == 'D' || char == 'd'
                                || char == 'E' || char == 'e'
                                || char == 'F' || char == 'f'
                                || char == 'G' || char == 'g'
                                || char == 'H' || char == 'h'
                                || char == 'I' || char == 'i'
                                || char == 'J' || char == 'j'
                                || char == 'K' || char == 'k'
                                || char == 'L' || char == 'l'
                                || char == 'M' || char == 'm'
                                || char == 'N' || char == 'n'
                                || char == 'O' || char == 'o'
                                || char == 'P' || char == 'p'
                                || char == 'Q' || char == 'q'
                                || char == 'R' || char == 'r'
                                || char == 'S' || char == 's'
                                || char == 'T' || char == 't'
                                || char == 'U' || char == 'u'
                                || char == 'V' || char == 'v'
                                || char == 'W' || char == 'w'
                                || char == 'X' || char == 'x'
                                || char == 'Y' || char == 'y'
                                || char == 'Z' || char == 'z'
                                || char == '1' || char == '2'
                                || char == '3' || char == '4'
                                || char == '5' || char == '6'
                                || char == '7' || char == '8'
                                || char == '9' || char == '0'
                    }
                    println("enteredText: $it")
                    println("filteredText: $filteredText")

                    if(it.toString() != filteredText.toString()){
                        et3.setText(filteredText)
                        et3.setSelection(filteredText.length)
                    }
                }
            }
        })




    }


    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

//    private fun apiCallForVisitsHistory() {
//        if (customer.cif.isNotEmpty() && ValidationUtils.isNetworkAvailable(this))
//            presenter.getVisits(customer.cif)
//        else CustomDialog().showNoInternetAlert(this, "")
//    }

    override fun showError(errorMsg: String) {
        CustomDialog().popUpToast(this@AddVisitActivity, errorMsg)
    }

    override fun addSmaVisitSuccess(visitList: SmaVisit) {
        //  CustomDialog().popUpToast(this@AddVisitActivity, "Remarks updated successfully...!")
       // onBackPressed()
       // finish()
        val user = presenter.getPrefUserDetails()


        val visitorName = user.name.toString().trim().uppercase() + "-" + user.pfNo + "-MANAGER";

        val mobNo = if (customer.mobNo == null) "9999999999" else customer.mobNo
        Log.e("mobNo2", mobNo);
        val stressVisit = SmaStressVisit(
            dateTv.text.toString(),
            customer.cif,
            customer.custName.trim().capitalizeWords,
            mobNo,
            visitorName,
            user.branchName.toString(),
            user.curBranch.toString(),
            user.regionName.toString(),
            user.regionCode.toString(),
            spinnerval, //varification of borrower spinner
            spinnerval1, //varification of charge  spinner
            spinnerval2, //varification of charge 7/12 spinner
            verificationOfChargeCAD.text.toString().trim(), // cersai asset id
            spinnerval3, // notice served spinner
            spinnerval4, // notice served type spinner
            noticeServedTypeDate.text.toString(), //notice served type date
            spinnerval12,// other bank ac closed
            spinnerval5, // cash recovery
            remarksByVisitingOfficialHeader.text.toString().trim(), // any other remark by vo
            majorIrragularityTxt.text.toString().trim(), // major irrg
            spinnerval6, //end use spinner
            spinnerval7, //stock spinner
            spinnerval8,  //stock verification spinner
            spinnerval9, //stock verification status spinner
            spinnerval10, // sma reason activity status spinner
            spinnerval11, //ac with other bank spinner
            detailsOfAcBankName.text.toString(), // bank name edittext
            spinnerval13, //cash flow spinner
            spinnerval14, // prob upgradation spinner
            probableDateOfUpgradationTv.text.toString(), // prob upgrad date
            user.pfNo,
            category,
            branchCode,
            customerBalance,
            spinnerval15, //fraud flag spinner
            myLatitude,
            myLongitude,
            et_comments.text.toString().trim()
        )

        if (ValidationUtils.isNetworkAvailable(this)) {
            presenter.addSmaStressVisit(stressVisit)
        } else {
            CustomDialog().showNoInternetAlert(this, "")
        }

    }

    override fun addSmaStressVisitSuccess(visitList: SmaStressVisit) {
        CustomDialog().popUpToast(this@AddVisitActivity, "Remarks updated successfully...!")
        onBackPressed()
        finish()
    }

//    override fun displaySmaVisits(visitsList: List<SmaVisit>) {
//
//        if (visitsList.isNotEmpty())
//            visitsAdapter.setVisitsList(visitsList)
//        else {
//            emptyVisitMsgTv.visibility = View.VISIBLE
//            visitsRV.visibility = View.GONE
//        }
//
//    }

    override fun addVisitSuccess(visitList: Visit) {

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
//        inflater.inflate(R.menu.menu_visit, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return true
    }

    //Open DatePicker dialog with future date disabled
    private fun openDatePickerDialog1() {
        val datePickerDialog1 = DatePickerDialog(
            this@AddVisitActivity, dateSetListener1,
            calendar1.get(Calendar.YEAR),
            calendar1.get(Calendar.MONTH),
            calendar1.get(Calendar.DAY_OF_MONTH)
        )

        datePickerDialog1.datePicker.maxDate = (Calendar.getInstance().timeInMillis)
        datePickerDialog1.show()
    }

    private fun openDatePickerDialog2() {
        val datePickerDialog2 = DatePickerDialog(
            this@AddVisitActivity, dateSetListener2,
            calendar2.get(Calendar.YEAR),
            calendar2.get(Calendar.MONTH),
            calendar2.get(Calendar.DAY_OF_MONTH)
        )

        datePickerDialog2.datePicker.minDate = (Calendar.getInstance().timeInMillis)
//        datePickerDialog1.datePicker.updateDate(Calendar.YEAR,1,1)App
        datePickerDialog2.show()
    }

    private fun openDatePickerDialog3() {
        val datePickerDialog3 = DatePickerDialog(
            this@AddVisitActivity, dateSetListener3,
            calendar3.get(Calendar.YEAR),
            calendar3.get(Calendar.MONTH),
            calendar3.get(Calendar.DAY_OF_MONTH)
        )

        //  datePickerDialog3.datePicker.minDate = (Calendar.getInstance().timeInMillis)
        val minDateCalendar = Calendar.getInstance().apply {
            set(2010,Calendar.JANUARY,1)
        }

        datePickerDialog3.datePicker.minDate = minDateCalendar.timeInMillis
        datePickerDialog3.datePicker.maxDate  = Calendar.getInstance().timeInMillis
        datePickerDialog3.show()
    }

    private fun openDatePickerDialog4() {
        val datePickerDialog4 = DatePickerDialog(
            this@AddVisitActivity, dateSetListener4,
            calendar4.get(Calendar.YEAR),
            calendar4.get(Calendar.MONTH),
            calendar4.get(Calendar.DAY_OF_MONTH)
        )

        datePickerDialog4.datePicker.minDate = (Calendar.getInstance().timeInMillis)
        datePickerDialog4.show()
    }

    private fun isLocationEnabled(): Boolean {
        val locationManager: LocationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun checkPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun checkStoragePermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            ),
            PERMISSION_ID
        )
    }

    private fun requestStoragePermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ),
            Storage_PERM_ID
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_ID) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PERMISSION_GRANTED)) {
                getLocation()
            } else {
                turnOnGPSDialog()
            }
        } else if (requestCode == Storage_PERM_ID) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PERMISSION_GRANTED)) {
                if (isGalleryOpen) {
                    selectImagesFromGallery()
                } else {
                    selectPDF()
                }
            } else {
                turnOnStoragePerm()
            }
        }
    }

    private fun openGpsEnableSetting() {
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        val uri: Uri = Uri.fromParts("package", packageName, null)
        intent.data = uri
        startActivity(intent)

    }

    private fun turnOnGPSDialog() {
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Location Permission")
        builder.setMessage("The app needs location permissions. Please grant this permission to continue using the features of the app.")
        builder.setPositiveButton(android.R.string.yes,
            DialogInterface.OnClickListener { dialogInterface, i ->
                val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                startActivity(intent)
            })
        builder.setNegativeButton(android.R.string.no, null)
        builder.show()
    }

    private fun turnOnStoragePerm() {
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("Location Permission")
        builder.setMessage("The app needs location permissions. Please grant this permission to continue using the features of the app.")
        builder.setPositiveButton(android.R.string.yes,
            DialogInterface.OnClickListener { dialogInterface, i ->
                val intent = Intent(Settings.ACTION_APPLICATION_SETTINGS)
                startActivity(intent)
            })
        builder.setNegativeButton(android.R.string.no, null)
        builder.show()
    }

    @SuppressLint("SetTextI18n")
    private fun getLocation() {

        if (checkPermissions()) {
            if (isLocationEnabled()) {

                val locationHelper =
                    LocationHelper(this@AddVisitActivity, activity = this@AddVisitActivity)
                locationProBar.show()
                locationProBar.visibility = View.VISIBLE

                try {
                    locationHelper.startListeningUserLocation(object : MyLocationListener {

                        override fun onLocationChanged(location: Location?) {
                            Log.d(
                                "Location cached",
                                " : onLocationChanged " + location!!.latitude + "," + location.longitude
                            )
                            isLocSaved = true
                            locationProBar.visibility = View.GONE
                            myLatitude = location.latitude.toString()
                            myLongitude = location.longitude.toString()
                            getMyLocTv.text = "$myLatitude, $myLongitude"
                            getAddressFromLocation(location)
                        }

                        override fun onLocationDetected(location: Location?) {

                            isLocSaved = true
                            myLatitude = location?.latitude.toString()
                            myLongitude = location?.longitude.toString()
                            Log.d(
                                "Location cached ",
                                ": onLocationDetected " + location!!.latitude + "," + location.longitude
                            )
                            getMyLocTv.text = "$myLatitude, $myLongitude"
                            locationProBar.visibility = View.GONE
                            getAddressFromLocation(location)
                        }

                        override fun onLocationFailed(error: String) {
                            locationProBar.visibility = View.GONE
                            Toast.makeText(this@AddVisitActivity, error, Toast.LENGTH_LONG).show()
                            Toast.makeText(
                                this@AddVisitActivity,
                                "Error capturing Location. Please try again",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    })
//            locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
//            // Request location updates
////            locationManager?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, locationListener)
                    //        locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)
                } catch (ex: SecurityException) {
                    CustomDialog().popUpToast(
                        this@AddVisitActivity,
                        "Security Exception, No location Available"
                    )
                    Log.d("myTag", "Security Exception, no location available")
                }

            } else {
                turnOnGPSDialog()
            }
        } else {
            requestPermissions()
        }
    }

    private fun getAddressFromLocation(location: Location?) {
        try {
            val latitude = location!!.latitude
            val longitude = location.longitude
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(latitude, longitude, 1)

            if (addresses != null && addresses.size > 0) {

                val address: String = addresses[0].getAddressLine(0)
                val city: String = addresses[0].locality
                val state: String = addresses[0].adminArea
                val country: String = addresses[0].countryName
                val postalCode: String = addresses[0].postalCode

                getMyLocTv.text = "$address"

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    val REQUEST_CODE = 200

    private fun selectImagesFromGallery() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "image/*"
        startActivityForResult(intent, REQUEST_CODE)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        //Receive images
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE) {
            // if multiple images are selected
            if (data?.clipData != null) {
                val count = data.clipData!!.itemCount
                var filename = ""
                val listImages = arrayListOf<ImageViewModel>()
                for (i in 0 until count) {
                    val imageUri: Uri = data.clipData!!.getItemAt(i).uri
                    filename = filename + "\n" + i + "-" + imageUri.path + "\n"
                    val docModel = ImageViewModel(imageUri.path!!, imageUri)
                    listImages.add(docModel)
                }
                selectedFilesLv.adapter = imageAdapter
                selectedFilesLv.layoutManager = layoutManager
                imageAdapter.setCategoryList(listImages)
                attachTv.text = filename

            } else if (data?.data != null) {
                val imageUri: Uri = data.data!!
                attachTv.text = imageUri.path + "\n"
            }
        }
    }

    private fun selectPDF() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "application/pdf"
        startActivityForResult(intent, REQUEST_CODE)
    }

    private fun showBottomDialog() {

        val dialog = BottomSheetDialog(this)
        dialog.setContentView(R.layout.dialog_bottom_sheet_picker)
        dialog.galleryLL?.setOnClickListener {
            isGalleryOpen = true
            if (checkStoragePermissions()) {
                selectImagesFromGallery()
            } else {
                requestStoragePermissions()
            }
            dialog.dismiss()
        }

        dialog.selectDocLL?.setOnClickListener {
            isGalleryOpen = false
            if (checkStoragePermissions()) {
                selectPDF()
            } else {
                requestStoragePermissions()
            }
            dialog.dismiss()
        }

        dialog.show()
    }


}