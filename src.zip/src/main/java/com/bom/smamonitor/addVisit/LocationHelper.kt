package com.bom.smamonitor.addVisit

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class LocationHelper(var context: Context, val activity: Activity) {

    private val TAG = "Location Helper"
    private val LOCATION_REFRESH_TIME = 3000  // 3 seconds. The Minimum Time to get location update
    private val LOCATION_REFRESH_DISTANCE =
        30  // 30 meters. The Minimum Distance to be changed to get location update
    private val MY_PERMISSIONS_REQUEST_LOCATION = 100
    var myLocationListener: MyLocationListener? = null

    //    private var fusedLocationClient: FusedLocationProviderClient? = null
    private var lastLocation: Location? = null


    interface MyLocationListener {
        fun onLocationChanged(location: Location?)
        fun onLocationDetected(location: Location?)
        fun onLocationFailed(error: String)
    }

    fun startListeningUserLocation(myListener: MyLocationListener?) {
        myLocationListener = myListener
        val mLocationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val mLocationListener: LocationListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                //your code here
                print("Location changed:-$location")
                Log.d(TAG, "Location changed:-$location")

                myLocationListener!!.onLocationChanged(location)
                mLocationManager.removeUpdates(this)
            }

            override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }

        val se: ScheduledExecutorService = Executors
            .newSingleThreadScheduledExecutor()

        if (ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            mLocationManager.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER, LOCATION_REFRESH_TIME.toLong(),
                LOCATION_REFRESH_DISTANCE.toFloat(), mLocationListener
            )
            se.schedule(Runnable {
                if (lastLocation == null) {
                    lastLocation =
                        mLocationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    Log.d(TAG, "last location from GPS = $lastLocation")
                    if (lastLocation != null && myLocationListener != null) {
                        myLocationListener!!.onLocationDetected(lastLocation)
                        mLocationManager.removeUpdates(mLocationListener)
                    } else {
                        myLocationListener!!.onLocationFailed("Error locating your device.")
                        mLocationManager.removeUpdates(mLocationListener)
                    }
                }
            }, 30, TimeUnit.SECONDS)

//          currentLocation = mLocationManager
//                        .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
//            mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0.0f, mLocationListener); //currentLocation
//            mLocationManager.requestSingleUpdate(
//                    LocationManager.GPS_PROVIDER, mLocationListener, Looper.myLooper()
//            )
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    (context as Activity), Manifest.permission.ACCESS_FINE_LOCATION
                ) || ActivityCompat.shouldShowRequestPermissionRationale(
                    (context as Activity), Manifest.permission.ACCESS_COARSE_LOCATION
                )
            ) {
                // permission is denied by user, you can show your alert dialog here to send user to App settings to enable permission

                Toast.makeText(
                    context, "Please turn on your location service...",
                    Toast.LENGTH_LONG
                ).show()
                val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                context.startActivity(intent)

            } else {
                ActivityCompat.requestPermissions(
                    (context as Activity),
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ),
                    MY_PERMISSIONS_REQUEST_LOCATION
                )
            }
        }
    }


//    private fun getLastLocation() {
//        fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
//            fusedLocationClient?.lastLocation!!.addOnCompleteListener(context) { task ->
//                if (task.isSuccessful && task.result != null) {
//                    lastLocation = task.result
//                }
//                else {
//                    Log.w(TAG, "getLastLocation:exception", task.exception)
//                    Toast.makeText(context,"No location detected. Make sure location is enabled on the device.", Toast.LENGTH_LONG).show()
//                }
//            }
//    }


}