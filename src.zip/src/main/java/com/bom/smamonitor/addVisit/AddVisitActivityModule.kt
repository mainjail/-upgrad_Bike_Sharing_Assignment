package com.bom.smamonitor.addVisit

import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.custlist.CustomerListActivity
import com.bom.smamonitor.custlist.SmaCustAdapter
import com.bom.smamonitor.dashboard.CategoriesItemAdapter
import com.bom.smamonitor.details.VisitsAdapter
import dagger.Module
import dagger.Provides

@Module
class AddVisitActivityModule {

    @Provides
    internal fun provideLoginInteractor(interactor: AddVisitInteractorImpl): AddVisitMVPInteractor = interactor

    @Provides
    internal fun provideLoginPresenter(presenter: AddVisitPresenterImpl<AddVisitMVPView, AddVisitMVPInteractor>)
            : AddVisitMVPPresenter<AddVisitMVPView, AddVisitMVPInteractor> = presenter

    @Provides
    internal fun provideAdapter(activity: AddVisitActivity): VisitsAdapter = VisitsAdapter(activity)

    @Provides
    internal fun provideLinearLayoutManager(activity: AddVisitActivity):
            LinearLayoutManager = LinearLayoutManager(activity)


    @Provides
    internal fun provideCategAdapter(activity: AddVisitActivity): ImageViewListS = ImageViewListS(activity)

//    @Provides
//    internal fun provideLLayoutManager(activity: AddVisitActivity):
//            LinearLayoutManager = LinearLayoutManager(activity)

}