package com.bom.smamonitor.addVisit


import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.login.User
import io.reactivex.Observable

interface AddVisitMVPInteractor : MVPInteractor {

    //    fun updateUserInSharedPref(loginResponse: LoginResponse, user: User, loggedInMode: AppConstants.LoggedInMode)
    fun getSmaVisits(custNo: String): Observable<List<SmaVisit>>
     fun addVisitApiCall(visit: SmaVisit): Observable<List<SmaVisit>>

}