package com.bom.smamonitor.addVisit

import android.util.Log
import com.androidnetworking.error.ANError
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.network.retrofitApi.NpaTrackerApiReceiver
import com.bom.smamonitor.network.retrofitApi.SmaDashApiReceiver
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject


class AddVisitPresenterImpl<V : AddVisitMVPView, I : AddVisitMVPInteractor>
@Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) : BasePresenter<V, I>(
    interactor = interactor,
    schedulerProvider = schedulerProvider,
    compositeDisposable = disposable
),
    AddVisitMVPPresenter<V, I> {

    val TAG = "addVpresImpl"


    override fun addVisit(visit: SmaVisit) {
        getView()?.showProgress()
        interactor?.let {
            it.addVisitApiCall(visit)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ list: List<SmaVisit> ->
                    println("Visits Results:-$list")
                    try {
                        if (list.isNotEmpty()) {
                            val visitNew = list[0]
                            //getView()?.addVisitSuccess(visitNew)
                        } else {
                            getView()?.showError("Error while sending visit. Please try again.")
                        }
                    } catch (e: Exception) {
                        getView()?.showError(e.localizedMessage)
                        e.printStackTrace()
                    }
                    getView()?.hideProgress()
                }, { error ->
                    val aNError = error as ANError
                    Log.d("visitPresImpl", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun getPrefUserDetails(): AppUser = interactor?.getUserFromSharedPref()!!


    override fun addVisitRetrofit(visit: Visit) {
        getView()?.showProgress()
        val retriever = NpaTrackerApiReceiver()
        val callBack = object : Callback<List<Visit>> {
            override fun onFailure(call: Call<List<Visit>>, t: Throwable) {
                getView()?.hideProgress()
                getView()?.showError(t.localizedMessage.toString())
                Log.d("visitPresImpl", t.localizedMessage.toString())
            }

            override fun onResponse(
                call: Call<List<Visit>>,
                response: Response<List<Visit>>
            ) {
                response.isSuccessful.let {
                    println("response:-$response")
                    val books: List<Visit> = response.body()!!
                    println("list.size:-${books.size}")

                    getView()?.hideProgress()
                    if (books.isNotEmpty())
                        getView()?.addVisitSuccess(books[0])
                    else
                        getView()?.showError("No result found...!!, Please verify input.")
                }
            }
        }
        retriever.addVisitRetroService(visit, callBack)
    }


    override fun addVisitSmaRetrofit(visit: SmaVisit) {

        getView()?.showProgress()
        val retriever = SmaDashApiReceiver()
        val callBack = object : Callback<List<SmaVisit>> {

            override fun onFailure(call: Call<List<SmaVisit>>, t: Throwable) {
                getView()?.hideProgress()
                getView()?.showError(t.localizedMessage.toString())
                Log.d("visitPresImpl", t.localizedMessage.toString())
            }

            override fun onResponse(
                call: Call<List<SmaVisit>>,
                response: Response<List<SmaVisit>>
            ) {
                Log.d(
                    "visitPresImpl",
                    "Success ${response.body()},${response.code()}, " +
                            "${response.errorBody()}"
                )
                response.isSuccessful.let {
                    println(" Response:- $response")
                    val books: List<SmaVisit> = response.body()!!
                    println("List.size:-${books.size}")
                    getView()?.hideProgress()
                    if (books.isNotEmpty())
                        getView()?.addSmaVisitSuccess(books[0])
                    else
                        getView()?.showError("No result found...!! Please verify input.")
                }
            }
        }
        retriever.addSmaVisitRetroService2(visit, callBack)
    }

    override fun addSmaStressVisit(visit: SmaStressVisit) {

        getView()?.showProgress()
        val retriever = SmaDashApiReceiver()
        val callBack = object : Callback<List<SmaStressVisit>> {

            override fun onFailure(call: Call<List<SmaStressVisit>>, t: Throwable) {
                getView()?.hideProgress()
                getView()?.showError(t.localizedMessage.toString())
                Log.d("visitPresImpl", t.localizedMessage.toString())
            }

            override fun onResponse(
                call: Call<List<SmaStressVisit>>,
                response: Response<List<SmaStressVisit>>
            ) {
                Log.d(
                    "stressVisitPresImpl",
                    "Success ${response.body()},${response.code()}, " +
                            "${response.errorBody()}"
                )
                response.isSuccessful.let {
                    println(" Response:- $response")
                    val books: List<SmaStressVisit> = response.body()!!
                    println("List.size:-${books.size}")
                    getView()?.hideProgress()
                    if (books.isNotEmpty())
                        getView()?.addSmaStressVisitSuccess(books[0])
                    else
                        getView()?.showError("No result found...!! Please verify input.")
                }
            }
        }
        retriever.addSmaStressVisitRetroService2(visit, callBack)
    }


//    override fun getVisits(custNo: String) {
//
//        getView()?.showProgress()
//        interactor?.let {
//            it.getSmaVisits(custNo)
//                .compose(schedulerProvider.ioToMainObservableScheduler())
//                .subscribe({ visitsList: List<SmaVisit> ->
//                    println("Visits Results:-$visitsList")
//                    getView()?.hideProgress()
//                    getView()?.displaySmaVisits(visitsList)
//
//                }, { error ->
//                    val aNError = error as ANError
//                    Log.d("DetailsPresImpl", aNError.message.toString())
//                    getView()?.hideProgress()
//                    getView()?.showError(aNError.errorDetail.toString())
//                })
//        }
//    }


}
