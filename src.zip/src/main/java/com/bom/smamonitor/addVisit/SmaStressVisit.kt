package com.bom.smamonitor.addVisit

import com.google.gson.annotations.SerializedName
import java.util.Date


data class SmaStressVisit(

    @SerializedName("visitDate")
    val visitDate: String,

    @SerializedName("custNo")
    val custNo: String,

    @SerializedName("custName")
    val custName: String,

    @SerializedName("custMob")
    val custMob: String,


    @SerializedName("visitorName")
    val visitorName: String,

    @SerializedName("branchName")
    val branchName: String,

    @SerializedName("branchCode")
    val branchCode: String,

    @SerializedName("zoneName")
    val zoneName: String,

    @SerializedName("zoneCode")
    val zoneCode: String,

    @SerializedName("verificationOfBorrower")
    val verificationOfBorrower: String,

    @SerializedName("verificationOfChargeHB")
    val verificationOfChargeHB: String,

    @SerializedName("verificationOfChargeEBC")
    val verificationOfChargeEBC: String,

    @SerializedName("cersaiAssetId")
    val cersaiAssetId: String,

    @SerializedName("noticeServed")
    val noticeServed: String,

    @SerializedName("noticeServedType")
    val noticeServedType: String,

    @SerializedName("noticeServedDate")
    val noticeServedDate: String,

    @SerializedName("effortOtherBank")
    val effortOtherBank: String,

    @SerializedName("cashRecovery")
    val cashRecovery: String,

    @SerializedName("remarksByVisitingOfficer")
    val remarksByVisitingOfficer: String,

    @SerializedName("majorIrragularity")
    val majorIrragularity: String,

    @SerializedName("endUse")
    val endUse: String,

    @SerializedName("stock")
    val stock: String,

    @SerializedName("stockVerification")
    val stockVerification: String,

    @SerializedName("stockVerificationSecurity")
    val stockVerificationSecurity: String,

    @SerializedName("activityStatus")
    val activityStatus: String,

    @SerializedName("acWithOtherBank")
    val acWithOtherBank: String,

    @SerializedName("detailsOfAcBankName")
    val detailsOfAcBankName: String,

    @SerializedName("cashFlow")
    val cashFlow: String,

    @SerializedName("probUpgradation")
    val probUpgradation: String,

    @SerializedName("probableDateOfUpgradation")
    val probableDateOfUpgradation: String,

    @SerializedName("visitorPfNo")
    val visitorPfNo: String,

    @SerializedName("category")
    val category: String,

    @SerializedName("brCode")
    val brCode: String,

    @SerializedName("custBalance")
    val custBalance: Double,

    @SerializedName("suspesiousFraud")
    val suspesiousFraud: String,

    @SerializedName("latitude")
    val latitude: String,

    @SerializedName("longitude")
    val longitude: String,


    @SerializedName("comments")
    val comments: String,

)


