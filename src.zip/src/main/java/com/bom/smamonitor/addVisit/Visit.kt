package com.bom.smamonitor.addVisit

import com.google.gson.annotations.SerializedName

data class Visit(

        @SerializedName("visitId")
        val visitId: String?,

        @SerializedName("visitDate")
        val visitDate: String,

        @SerializedName("custNo")
        val custNo: String,

        @SerializedName("custName")
        val custName: String,

        @SerializedName("visitorName")
        val visitorName: String,

        @SerializedName("visitorPfNo")
        val visitorPfNo: String,

        @SerializedName("comments")
        val comments: String,

        @SerializedName("latitude")
        val latitude: String,

        @SerializedName("longitude")
        val longitude: String,

//        @SerializedName("branchCode")
//        val branchCode: String


)
