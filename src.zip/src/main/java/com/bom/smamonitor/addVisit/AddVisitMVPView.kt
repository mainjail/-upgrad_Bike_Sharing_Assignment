package com.bom.smamonitor.addVisit


import com.bom.smamonitor.base.view.BaseMVPView

interface AddVisitMVPView : BaseMVPView {
    fun showError(errorMsg:String)
    fun addSmaVisitSuccess(visitList: SmaVisit)
    fun addSmaStressVisitSuccess(visitList: SmaStressVisit)

//    fun displaySmaVisits(visitsList: List<SmaVisit>)
//    fun displayVisits(visitsList: List<Visit>)

    fun addVisitSuccess(visitList: Visit)
}
