package com.bom.smamonitor.addVisit
//
//import android.content.Context
//import android.os.Bundle
//
//import android.location.Criteria
//
//import android.location.LocationManager
//
//
//
//
//class SingleShotLocationProvider {
//
//    // calls back to calling thread, note this is for low grain: if you want higher precision, swap the
//    // contents of the else and if. Also be sure to check gps permission/settings are allowed.
//    // call usually takes <10ms
//    fun requestSingleUpdate(
//        context: Context,
//        callback: SingleShotLocationProvider.LocationCallback
//    ) {
//        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
//        val isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
//        if (isNetworkEnabled) {
//            val criteria = Criteria()
//            criteria.accuracy = Criteria.ACCURACY_COARSE
//            locationManager.requestSingleUpdate(criteria, object : LocationListener() {
//                fun onLocationChanged(location: Location) {
//                    callback.onNewLocationAvailable(
//                        GPSCoordinates(
//                            location.getLatitude(),
//                            location.getLongitude()
//                        )
//                    )
//                }
//
//                fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
//                fun onProviderEnabled(provider: String?) {}
//                fun onProviderDisabled(provider: String?) {}
//            }, null)
//        } else {
//            val isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
//            if (isGPSEnabled) {
//                val criteria = Criteria()
//                criteria.accuracy = Criteria.ACCURACY_FINE
//                locationManager.requestSingleUpdate(criteria, object : LocationListener() {
//                    fun onLocationChanged(location: Location) {
//                        callback.onNewLocationAvailable(
//                            GPSCoordinates(
//                                location.getLatitude(),
//                                location.getLongitude()
//                            )
//                        )
//                    }
//
//                    fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
//                    fun onProviderEnabled(provider: String?) {}
//                    fun onProviderDisabled(provider: String?) {}
//                }, null)
//            }
//        }
//    }
//
//    interface LocationCallback {
//        fun onNewLocationAvailable(location: GPSCoordinates?)
//    }
//
//    // consider returning Location instead of this dummy wrapper class
//    class GPSCoordinates {
//        var longitude = -1f
//        var latitude = -1f
//
//        constructor(theLatitude: Float, theLongitude: Float) {
//            longitude = theLongitude
//            latitude = theLatitude
//        }
//
//        constructor(theLatitude: Double, theLongitude: Double) {
//            longitude = theLongitude.toFloat()
//            latitude = theLatitude.toFloat()
//        }
//    }
//}