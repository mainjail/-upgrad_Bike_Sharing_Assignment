package com.bom.smamonitor.profile

import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.branchMaster.Branch
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.network.ApiHelper
import io.reactivex.Observable
import javax.inject.Inject

class ProfileInteractorImpl @Inject internal constructor(
    preferenceHelper: PreferenceHelper,
    apiHelper: ApiHelper
) :
    BaseInteractor(preferenceHelper, apiHelper), ProfileMVPInteractor {


//    override fun getUserFromSharedPref(): AppUser {
//
//        val user = AppUser(
//            preferenceHelper.getCurrentUserPfNo().toString(),
//            preferenceHelper.getCurrentUserName(),
//            preferenceHelper.getCurrentBranchCode(),
//            preferenceHelper.getCurrentBranchName(),
//            preferenceHelper.getUserRegionCode(),
//            preferenceHelper.getUserRegionName(),
//            preferenceHelper.getCurrentUserEmail(),
//            "",
//            "",
//            preferenceHelper.getCurrentUserMobileNo(),
//            preferenceHelper.getCurrentDeviceNotificationToken(),
//            "",
//            preferenceHelper.getUserLastLogindate()
//        )
//        return user
//    }

    override fun getBranchHead(branchCode: String?): Observable<List<Branch>> =
        apiHelper.getBranchHeadInfo(branchCode)

}