package com.bom.smamonitor.profile


import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.branchMaster.Branch
import com.bom.smamonitor.login.AppUser
import io.reactivex.Observable

interface ProfileMVPInteractor : MVPInteractor {


//    fun getUserFromSharedPref(): AppUser
    fun getBranchHead(branchCode: String?): Observable<List<Branch>>
}
