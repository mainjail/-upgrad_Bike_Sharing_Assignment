package com.bom.smamonitor.profile

import com.bom.smamonitor.base.presenter.MVPPresenter
import com.bom.smamonitor.login.AppUser

interface ProfileMVPPresenter<V : ProfileMVPView, I : ProfileMVPInteractor> :
    MVPPresenter<V, I> {

    fun getPrefUserDetails(): AppUser
    fun getBranchHead(branchCode: String?)

}
