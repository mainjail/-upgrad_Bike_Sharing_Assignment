package com.bom.smamonitor.profile

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import androidx.core.app.ActivityCompat
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.util.Pair
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.branchMaster.Branch
import com.bom.smamonitor.branchMaster.ViewImageActivity
import com.bom.smamonitor.network.ApiEndPoint
import com.bom.smamonitor.util.CommonUtil
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_profile.*
import kotlinx.android.synthetic.main.content_profile.*
import java.util.*
import javax.inject.Inject


class MyProfileActivity : BaseActivity(), ProfileMVPView {

    @Inject
    internal lateinit var presenter: ProfileMVPPresenter<ProfileMVPView, ProfileMVPInteractor>
    private val String.capitalizeWords
        get() = this.lowercase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.replaceFirstChar {
                if (it.isLowerCase()) it.titlecase(
                    Locale.getDefault()
                ) else it.toString()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        presenter.onAttach(this)
        window.statusBarColor = ContextCompat.getColor(this, R.color.colorPrimaryDark)
        setSupportActionBar(toolbar)
        initView()
    }


    private fun initView() {
//        val params = collapseTB_layout.layoutParams as AppBarLayout.LayoutParams
//        params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_SNAP // list other flags here by |
//        collapseTB_layout.layoutParams = params

//        val value = if (intent.hasExtra("branchCode")) {
//            val branchCode = intent.getStringExtra("branchCode")
//            if (ValidationUtils.isNetworkAvailable(this))
//                presenter.getBranchHead(branchCode)
//            else CustomDialog().showNoInternetAlert(this, "")
//
//        } else
            setUpMyProfileView()
    }

    private fun setUpMyProfileView() {
        val user = presenter.getPrefUserDetails()
        toolbar?.title = resources.getString(R.string.myProfile)

        nameTv.text = user.name.toString().trim()
        mobNoTv.text = user.mobileNo
        emailTv.text = user.email
        emailProfileTv.text = user.name.toString().trim()
        nameprofileTv.text = user.pfNo
        branchTv.text = user.curBranch.toString().trim()

        addressTv.visibility = View.GONE
        emailLL.visibility = View.VISIBLE
        branchDetailsCard.visibility = View.GONE
        loadImage(user.pfNo)
        setUpOnClickListener()
    }

    private fun setUpOnClickListener() {
        custCallIV.setOnClickListener { CommonUtil.makeACall(mobNoTv.text.toString(), this) }
        backToHomeBtn.setOnClickListener { onBackPressed() }
    }

    override fun showError(errorMsg: String) {
    }

    @SuppressLint("SetTextI18n")
    override fun setUpBranchProfileView(branchHeads: List<Branch>) {
        try {
            val branchHead = branchHeads[0]
            toolbar?.title = resources.getString(R.string.user_profile)
            loadImage(branchHead.brHeadPfNo.trim())

            emailProfileTv.text = branchHead.brHeadDesgn
            nameprofileTv.text = branchHead.brHeadPfNo

            if (branchHead.brHeadName.isNotEmpty())
                nameTv.text = branchHead.brHeadName.toString().trim()
            else
                nameTv.text = "-"

            if (branchHead.brHeadMobile.isNotEmpty())
                mobNoTv.text = branchHead.brHeadMobile
            else
                mobNoTv.text = "-"

            branchTv.text = branchHead.brName + "  (" + branchHead.brBusinessHour + ")"
            headPrevBranchTv.text = branchHead.brHeadPrevBranch.toString().trim()
            workingSinceTv.text = branchHead.brHeadWorkingSince.substring(0, 10)

            branchDetailsCard.visibility = View.VISIBLE
            emailLL.visibility = View.GONE
            emailSepView.visibility = View.GONE
            addressTv.visibility = View.VISIBLE

            landlineTv.text = branchHead.brLandline.trim()
            addressTv.text = branchHead.brAdd1.capitalizeWords + ", " +
                    branchHead.brAdd2.capitalizeWords +
                    ", " + branchHead.brAdd3.capitalizeWords + " - " + branchHead.brPincode

            stateTv.text = branchHead.brState.trim()
            brOpenTv.text = branchHead.brOpenDate.substring(0, 10)

            if (branchHead.cpcComHeadName.isEmpty())
                cpcComHeadTv.text = branchHead.cpcComHeadName + " /" + branchHead.cpcComHeadMobile
            else cpcComHeadTv.text = "-"

            if (branchHead.cpcRetailHeadName.isEmpty())
                cpcRetailHeadTv.text = "-"
            else
                cpcRetailHeadTv.text =
                    branchHead.cpcRetailHeadName.trim() + " /" + branchHead.cpcRetailsHeadMobile

            setUpOnClickListener()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadImage(pfNo: String) {

        val imageUrl = ApiEndPoint.ENDPOINT_GET_BRANCH_Head_Photo + pfNo + ".jpg"
        userIv.setOnClickListener { showExpandableImage(this, imageUrl, "", userIv) }

        Glide.with(this@MyProfileActivity)
            .load(imageUrl)
            .placeholder(R.mipmap.ic_profile_pic)
//                .error(R.drawable.ic_admin_user)
//            .override(100, 200) // resizes the image to 100x200 pixels but does not respect aspect ratio
            .centerCrop() // scale to fill the ImageView and crop any extra
            .into(userIv)
    }

    private fun showExpandableImage(
        context: Context?,
        imageUri: String?,
        title: String?,
        view: View?
    ) {
        var imageUri = imageUri
        try {

            val intent = Intent(context, ViewImageActivity::class.java)
            intent.putExtra("image", imageUri)
            intent.putExtra("title", title)
            if (TextUtils.isEmpty(imageUri)) {
                imageUri = getURLForResource(R.mipmap.ic_profile_pic) // default image in drawable
            }
            val bodyPair = Pair(view, imageUri)
            val options = ActivityOptionsCompat.makeSceneTransitionAnimation(
                (context as Activity?)!!,
                bodyPair
            )
            ActivityCompat.startActivity(this, intent, options.toBundle())

        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    private fun getURLForResource(resourceId: Int): String? {
        return Uri.parse("android.resource://com.yourpackage.name/$resourceId").toString()
    }
}