package com.bom.smamonitor.profile

import android.util.Log
import com.androidnetworking.error.ANError
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.branchMaster.Branch
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

class ProfilePresenterImpl<V:ProfileMVPView,I:ProfileMVPInteractor>
@Inject internal constructor(
        interactor: I,
        schedulerProvider: SchedulerProvider,
        disposable: CompositeDisposable
) : BasePresenter<V, I>(
interactor = interactor,
schedulerProvider = schedulerProvider,
compositeDisposable = disposable
), ProfileMVPPresenter<V,I> {


    override fun getPrefUserDetails(): AppUser = interactor?.getUserFromSharedPref()!!

    override fun getBranchHead(branchCode: String?) {
        getView()?.showProgress()
        interactor?.let {
            it.getBranchHead(branchCode)
                    .compose(schedulerProvider.ioToMainObservableScheduler())
                    .subscribe({ branches:List<Branch> ->
                        println("Branches Results:-$branches")
                        getView()?.let { view ->
                            view.setUpBranchProfileView(branches)
                            view.hideProgress()
                        }
                    },{ error ->
                        Log.d("ProfilePresImpl", error.toString())
                        val aNError = error as ANError
                        Log.d("ProfilePresImpl", aNError.message.toString())
                        getView()?.hideProgress()
                        getView()?.showError(aNError.errorDetail.toString())
                    })
        }
    }

}