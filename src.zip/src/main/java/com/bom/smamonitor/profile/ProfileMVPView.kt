package com.bom.smamonitor.profile


import com.bom.smamonitor.base.view.BaseMVPView
import com.bom.smamonitor.branchMaster.Branch

interface ProfileMVPView : BaseMVPView {
    fun showError(errorMsg:String)
    fun setUpBranchProfileView(branchHeads: List<Branch>)
}
