package com.bom.smamonitor.profile

import dagger.Module
import dagger.Provides

@Module
class ProfileActivityModule {

    @Provides
    internal fun provideInteractor(interactor: ProfileInteractorImpl): ProfileMVPInteractor = interactor

    @Provides
    internal fun providePresenter(presenter: ProfilePresenterImpl<ProfileMVPView, ProfileMVPInteractor>)
            : ProfileMVPPresenter<ProfileMVPView, ProfileMVPInteractor> = presenter
}

