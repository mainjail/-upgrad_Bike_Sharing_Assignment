package com.bom.smamonitor.customViews

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.bom.smamonitor.ots.OtsModel

class CustomSpinnerAdapter(context: Context, textViewResourceId: Int, val list: List<OtsModel>) : ArrayAdapter<OtsModel>(
        context, textViewResourceId,        list) {

    override fun getCount() = list.size

    override fun getItem(position: Int) = list[position]

    override fun getItemId(position: Int) = list[position].id.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        return (super.getDropDownView(position, convertView, parent) as TextView).apply {
            text = list[position].OtsScheme
        }
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        return (super.getDropDownView(position, convertView, parent) as TextView).apply {
            text = list[position].OtsScheme
        }
    }
}