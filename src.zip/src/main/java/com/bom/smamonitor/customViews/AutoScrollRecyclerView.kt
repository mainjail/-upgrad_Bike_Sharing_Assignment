package com.bom.smamonitor.customViews

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import androidx.annotation.Nullable
import androidx.recyclerview.widget.RecyclerView
import java.lang.ref.WeakReference


class AutoScrollRecyclerView : RecyclerView {
    private var autoPollTask // Scroll thread
            : AutoPollTask? = null
    private var running // Is it rolling?
            = false
    private var canRun // Can it be automatically scrolled, depending on whether the data exceeds the screen
            = false

    constructor(context: Context?) : super(context!!) {}
    constructor(context: Context?, @Nullable attrs: AttributeSet?) : super(context!!, attrs) {
        autoPollTask = AutoPollTask(this) // Instantiate the scroll refresh thread
    }

    internal class AutoPollTask(reference: AutoScrollRecyclerView?) : Runnable {
        private val mReference: WeakReference<AutoScrollRecyclerView> = WeakReference(reference)
        override fun run() {
            val recyclerView: AutoScrollRecyclerView? =
                mReference.get() // Get the recyclerview object
            if (recyclerView != null && recyclerView.running && recyclerView.canRun) {
                recyclerView.scrollBy(2, 2)
                // Note the difference between scrollBy and scrollTo
                //delayed to send
                recyclerView.postDelayed(recyclerView.autoPollTask, delayTime)
            }
        }

    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_OUTSIDE -> {
            }
        }
        return super.onTouchEvent(e)
    }

    //Open: If it is running, stop first -> then open
    fun start() {
        if (running) stop()
        canRun = true
        running = true
        postDelayed(autoPollTask, delayTime)
    }

    fun stop() {
        running = false
        removeCallbacks(autoPollTask)
    }

    companion object {
        private const val delayTime: Long =
            45 // How long after the interval to perform scrolling
    }
}
