package com.bom.smamonitor.customViews

import android.view.View
import androidx.recyclerview.widget.RecyclerView

@Suppress("DEPRECATED_IDENTITY_EQUALS")
class RVEmptyObserver(private var emptyView: View, private var recyclerView: RecyclerView): RecyclerView.AdapterDataObserver() {


    private fun checkIfEmpty() {
        if (recyclerView.adapter != null) {
            val emptyViewVisible = recyclerView.adapter!!.itemCount === 0
            emptyView.visibility = if (emptyViewVisible) View.VISIBLE else View.GONE
            recyclerView.visibility = if (emptyViewVisible) View.GONE else View.VISIBLE
        }
    }

    override fun onChanged() {
        checkIfEmpty()
    }

    override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
        checkIfEmpty()
    }

    override fun onItemRangeRemoved(positionStart: Int, itemCount: Int) {
        checkIfEmpty()
    }
}