package com.bom.smamonitor.branchMaster


import androidx.recyclerview.widget.LinearLayoutManager
import dagger.Module
import dagger.Provides


@Module
class BranchListActivityModule {

    @Provides
    internal fun provideNpaInteractor(interactor: BranchListInteractorImpl): BranchListMVPInteractor = interactor

    @Provides
    internal fun provideNpaPresenter(presenter: BranchListPresenterImpl<BranchListMVPView, BranchListMVPInteractor>)
            : BranchListMVPPresenter<BranchListMVPView, BranchListMVPInteractor> = presenter

    @Provides
    internal fun provideAdapter(): BranchListAdapter = BranchListAdapter()

    @Provides
    internal fun provideLinearLayoutManager(activity:  BranchListActivity):
            LinearLayoutManager = LinearLayoutManager(activity)

}