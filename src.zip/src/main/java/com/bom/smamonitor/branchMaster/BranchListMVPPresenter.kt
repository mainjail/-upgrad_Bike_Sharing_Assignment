package com.bom.smamonitor.branchMaster

import com.bom.smamonitor.base.presenter.MVPPresenter

interface BranchListMVPPresenter <V: BranchListMVPView, I: BranchListMVPInteractor> : MVPPresenter<V, I> {

    fun onGetBranchesClicked(regionCode: Int)

    fun onGetRegions()


}