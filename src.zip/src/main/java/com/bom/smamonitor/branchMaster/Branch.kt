package com.bom.smamonitor.branchMaster

import com.google.gson.annotations.SerializedName

data class Branch(


        @SerializedName("REGCODE")
        val regionCode: String,
        @SerializedName("BRCODE")
        val brCode: String,
        @SerializedName("BRNAME")
        val brName: String,
        @SerializedName("BRANCH_HEAD_NAME")
        val brHeadName: String,

        @SerializedName("BRANCH_HEAD_DESIGNATION")
        val brHeadDesgn: String,

        @SerializedName("BRANCH_HEAD_PFNO")
        val brHeadPfNo: String,

        @SerializedName("BRANCH_HEAD_PREVBRANCH")
        val brHeadPrevBranch: String,

        @SerializedName("BRANCH_HEAD_WORKING_SINCE")
        val brHeadWorkingSince: String,

        @SerializedName("BRANCH_LANDLINE")
        val brLandline: String,

        @SerializedName("BRANCH_HEAD_MOBILE")
        val brHeadMobile: String,

        @SerializedName("BRANCH_STATE")
        val brState: String,
        @SerializedName("BRANCH_CATEGORY")
        val brCategory: String,
        @SerializedName("BRANCH_OPEN_DATE")
        val brOpenDate: String,
        @SerializedName("BRANCH_AREA")
        val branchArea: String,
        @SerializedName("BRANCH_ADD1")
        val brAdd1: String,
        @SerializedName("BRANCH_ADD2")
        val brAdd2: String,
        @SerializedName("BRANCH_ADD3")
        val brAdd3: String,
        @SerializedName("PINCODE")
        val brPincode: String,
        @SerializedName("BUSINESS_HOUR")
        val brBusinessHour: String,
        @SerializedName("DZM_PFNO")
        val dzmPfNo: String,

        @SerializedName("DZM_NAME")
        val dzmName: String,
        @SerializedName("DZM_MOBILE")
        val dzmMobile: String,
        @SerializedName("CPC_COM_HEAD_NAME")
        val cpcComHeadName: String,
        @SerializedName("CPC_COM_HEAD_MOBILE")
        val cpcComHeadMobile: String,
        @SerializedName("CPC_RETAIL_HEAD_NAME")
        val cpcRetailHeadName: String,
        @SerializedName("CPC_RETAIL_HEAD_MOBILE")
        val cpcRetailsHeadMobile: String,
        @SerializedName("DY_BRANCH_HEAD_NAME")
        val dyBranchHeadName: String,

        @SerializedName("DY_BRANCH_HEAD_MOBILE")
        val dyBrHeadMobile: String,
        @SerializedName("BSR_CODE")
        val bsrCode: String,
        @SerializedName("ATM_STATUS")
        val atmStatus: String,

        var isMenuShown: Boolean = false

)


//{
//        "REGCODE": 27,
//        "BRCODE": 562,
//        "BRNAME": "SHENOLI",
//        "BRANCH_HEAD_NAME": "ARVIND KUMAR",
//        "BRANCH_HEAD_DESIGNATION": "Sr.MANAGER",
//        "BRANCH_HEAD_PFNO": 29742,
//        "BRANCH_HEAD_PREVBRANCH": "00134_SATARA",
//        "BRANCH_HEAD_WORKING_SINCE": "2020-08-03T00:00:00.000Z",
//        "BRANCH_LANDLINE": "02164-269567",
//        "BRANCH_HEAD_MOBILE": "9028087040",
//        "BRANCH_STATE": "MAHARASHTRA",
//        "BRANCH_CATEGORY": "Medium",
//        "BRANCH_OPEN_DATE": "1978-08-31T00:00:00.000Z",
//        "BRANCH_AREA": "RURAL",
//        "BRANCH_ADD1": "ANU SONAI COMPLEX",
//        "BRANCH_ADD2": "AT POST SHENOLI TAL KARAD",
//        "BRANCH_ADD3": "SHENOLI",
//        "PINCODE": "415110",
//        "BUSINESS_HOUR": "11.00 A.M.to 6.00 P.M.",
//        "DZM_PFNO": "17983",
//        "DZM_NAME": "HAJARE YESHWANT ANANT-",
//        "DZM_MOBILE": "9890372935",
//        "CPC_COM_HEAD_NAME": "SUMIT KUMAR",
//        "CPC_COM_HEAD_MOBILE": "9665860012",
//        "CPC_RETAIL_HEAD_NAME": "SUMIT KUMAR",
//        "CPC_RETAIL_HEAD_MOBILE": "9665860012",
//        "DY_BRANCH_HEAD_NAME": "",
//        "DY_BRANCH_HEAD_MOBILE": "",
//        "BSR_CODE": "230582",
//        "ATM_STATUS": "YES"
//},
