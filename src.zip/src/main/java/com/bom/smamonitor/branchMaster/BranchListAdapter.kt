package com.bom.smamonitor.branchMaster

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.npa.NpaCustomersActivity
import com.bom.smamonitor.profile.MyProfileActivity
import kotlinx.android.synthetic.main.item_branch_list_layout.view.*
import java.util.*

class BranchListAdapter : RecyclerView.Adapter<BranchListAdapter.CustomViewHolder>(), Filterable {

    private var originalListBranch = mutableListOf<Branch>()
    private var branchList = mutableListOf<Branch>()
    private val viewPool = RecyclerView.RecycledViewPool()
    var previousExpandedPosition = -1
    var mExpandedPosition = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = CustomViewHolder(
            LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_branch_list_layout, parent, false)
    )

    override fun getItemCount() = this.branchList.size

    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) = holder.let {
        it.clear()
        it.onBind(position)
        it.setOnItemClickListener(branchList[position], position)
    }

    internal fun addResultsToList(products: List<Branch>) {
        println("addResultsToList called:-" + products.size)
        this.branchList = products.toMutableList()
        notifyDataSetChanged()
        this.originalListBranch = branchList
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(charSequence: CharSequence): FilterResults {
                val results = FilterResults()
                if (charSequence.isNotEmpty()) {
                    val charString = charSequence.toString().toLowerCase(Locale.getDefault())

                    val filteredPlayers = ArrayList<Branch>()
                    for (item in originalListBranch) {
                        if (item.brName.toLowerCase(Locale.getDefault()).contains(charString.toLowerCase(Locale.getDefault()))
                                || item.brCode.contains(charString)
                        ) {
                            filteredPlayers.add(item)
                        }
                    }
                    results.count = filteredPlayers.size
                    results.values = filteredPlayers
                } else {
                    results.count = originalListBranch.size
                    results.values = originalListBranch
                }
                return results
            }

            override fun publishResults(charSequence: CharSequence, filterResults: FilterResults) {
                branchList = filterResults.values as MutableList<Branch>
                notifyDataSetChanged()
            }
        }
    }

    inner class CustomViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun clear() {
        }

        fun onBind(position: Int) {
            val branch: Branch = branchList[position]
            inflateData(branch)
            setOnItemClickListener(branch, position)
        }

        fun setOnItemClickListener(branch: Branch, position: Int) {
            val isExpanded = position === mExpandedPosition
            itemView.menuLL.visibility = if (isExpanded) View.VISIBLE else View.GONE
            itemView.isActivated = isExpanded
            if (isExpanded) previousExpandedPosition = position
            itemView.setOnClickListener {
                mExpandedPosition = if (isExpanded) -1 else position
                notifyItemChanged(previousExpandedPosition)
                notifyItemChanged(position)
            }
        }

        @SuppressLint("SetTextI18n")
        private fun inflateData(branch: Branch) {
            itemView.branchNameTv.text = branch.brName.trim()
            itemView.branchCodeTv.text = branch.brCode.trim()
            itemView.noOfBranchTv.text = branch.brHeadPfNo.trim()

//            val expanded: Boolean = branch.isMenuShown
//            itemView.menuLL.visibility = (if (expanded) View.VISIBLE else View.GONE)

            itemView.openBusTv.setOnClickListener {
                try {
//                    val intent = Intent(itemView.context, BusiMetricsActivity::class.java)
//                    intent.putExtra("branchCode", branch.brCode.trim())
//                    intent.putExtra("branchName", branch.brName.trim())
//                    itemView.context.startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            itemView.openNpaTv.setOnClickListener {
                try {
                    val intent = Intent(itemView.context, NpaCustomersActivity::class.java)
                    intent.putExtra("branchCode", branch.brCode.trim())
                    intent.putExtra("branchName", branch.brName.trim())
                    itemView.context.startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            itemView.openProfTv.setOnClickListener {
                try {
                    val intent = Intent(itemView.context, MyProfileActivity::class.java)
                    intent.putExtra("branchCode", branch.brCode.trim())
                    itemView.context.startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

    }

}