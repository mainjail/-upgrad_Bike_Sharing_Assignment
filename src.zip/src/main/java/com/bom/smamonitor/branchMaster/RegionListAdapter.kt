package com.bom.smamonitor.branchMaster

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import kotlinx.android.synthetic.main.item_branch_list_layout.view.*
import java.util.*

class RegionListAdapter : RecyclerView.Adapter<RegionListAdapter.CustomViewHolder>(), Filterable {


    private var originalListRegions = mutableListOf<Region>()
    private var branchList = mutableListOf<Region>()
    private val viewPool = RecyclerView.RecycledViewPool()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = CustomViewHolder(
            LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_branch_list_layout, parent, false)
    )

    override fun getItemCount() = this.branchList.size

    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) = holder.let {
        it.clear()
        it.onBind(position)
    }

    internal fun addResultsToList(products: List<Region>) {
        println("addResultsToList called:-" + products.size)
        this.branchList = products.toMutableList()
        notifyDataSetChanged()
        this.originalListRegions = branchList
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(charSequence: CharSequence): FilterResults {
                val results = FilterResults()
                if (charSequence.isNotEmpty()) {
                    val charString = charSequence.toString().toLowerCase(Locale.getDefault())

                    val filteredPlayers = ArrayList<Region>()
                    for (item in originalListRegions) {
                        if (item.regionName.toLowerCase(Locale.getDefault()).contains(charString.toLowerCase(Locale.getDefault()))
                                || item.regionCode.contains(charString)
                        ) {
                            filteredPlayers.add(item)
                        }
                    }
                    results.count = filteredPlayers.size
                    results.values = filteredPlayers
                } else {
                    results.count = originalListRegions.size
                    results.values = originalListRegions
                }
                return results
            }

            override fun publishResults(charSequence: CharSequence, filterResults: FilterResults) {

                branchList = filterResults.values as MutableList<Region>
                notifyDataSetChanged()
            }
        }
    }

    inner class CustomViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun clear() {
//            itemView.coverImageView.setImageDrawable(null)
//            itemView.titleTextView.text = ""
        }

        fun onBind(position: Int) {
            val region: Region = branchList[position]
            inflateData(region)
            setItemClickListener(region)
        }

        private fun setItemClickListener(region: Region) {
        }

        @SuppressLint("SetTextI18n")
        private fun inflateData(region: Region) {
            itemView.menuLL.visibility = View.GONE

            itemView.branchNameTv .text = region.regionName.trim()
            itemView.branchCodeTv.text = region.regionCode.trim()
            itemView.noOfBranchTv.text = region.noOfBranches.trim()

            itemView.setOnClickListener {
                try {
                    val intent = Intent(itemView.context, BranchListActivity::class.java)
                    intent.putExtra("regionCode", region.regionCode)
                    intent.putExtra("regionName", region.regionName)

                    itemView.context.startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

    }
}