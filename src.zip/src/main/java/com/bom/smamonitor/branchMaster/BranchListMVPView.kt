package com.bom.smamonitor.branchMaster

import com.bom.smamonitor.base.view.BaseMVPView

interface BranchListMVPView:BaseMVPView {
    fun displayBranchList(branchList: List<Branch>)
    fun showError(msg: String)
    fun displayRegionsList(regions: List<Region>)

}