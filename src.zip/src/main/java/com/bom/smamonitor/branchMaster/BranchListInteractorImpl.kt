package com.bom.smamonitor.branchMaster

import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.network.ApiHelper
import io.reactivex.Observable
import javax.inject.Inject

class BranchListInteractorImpl @Inject internal constructor(preferenceHelper: PreferenceHelper, apiHelper: ApiHelper) :
        BaseInteractor(preferenceHelper, apiHelper), BranchListMVPInteractor {

    override fun getBranches(regionCode: Int): Observable<List<Branch>> = apiHelper.getBranches(regionCode)

    override fun getRegions(): Observable<List<Region>> = apiHelper.getRegions()


}