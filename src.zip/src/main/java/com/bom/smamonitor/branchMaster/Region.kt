package com.bom.smamonitor.branchMaster

import com.google.gson.annotations.SerializedName

data class Region(
    @SerializedName("Region_Code")
val regionCode:String,
    @SerializedName("Region_Name")
val regionName:String,

    @SerializedName("No_of_Branches")
    val noOfBranches:String


)
