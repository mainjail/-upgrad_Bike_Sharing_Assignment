package com.bom.smamonitor.branchMaster

import com.bom.smamonitor.base.interactor.MVPInteractor
import io.reactivex.Observable

interface BranchListMVPInteractor: MVPInteractor {
    fun getBranches(regionCode: Int): Observable<List<Branch>>
    fun getRegions(): Observable<List<Region>>

}