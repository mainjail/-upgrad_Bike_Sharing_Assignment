package com.bom.smamonitor.branchMaster

import android.os.Bundle
import android.text.TextUtils
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.bom.smamonitor.R
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_profile.*
import kotlinx.android.synthetic.main.activity_view_image.*


class ViewImageActivity: AppCompatActivity() {

    private  var imgPath:String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_image)

        imgPath = intent.extras!!.getString("image")
//        my_title = getIntent().extras!!.getString("title")
//        if (!TextUtils.isEmpty(my_title)) {
//            title!!.text = my_title
//        }
        if (!TextUtils.isEmpty(imgPath)) {
            ViewCompat.setTransitionName(fullImageView, imgPath)
            Glide.with(this@ViewImageActivity)
                    .load(imgPath)
                    .placeholder(R.mipmap.ic_profile_pic)
//                .error(R.drawable.ic_admin_user)
//            .override(100, 200) // resizes the image to 100x200 pixels but does not respect aspect ratio
                    .centerCrop() // scale to fill the ImageView and crop any extra
                    .into(fullImageView)
        } else {
            ViewCompat.setTransitionName(fullImageView, "NotAvailable")
        }
    }

}