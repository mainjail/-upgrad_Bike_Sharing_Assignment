package com.bom.smamonitor.branchMaster

import android.annotation.SuppressLint
import android.app.SearchManager
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.util.CommonUtil.goBackToHome
import com.bom.smamonitor.util.CustomDialog
import kotlinx.android.synthetic.main.activity_branch_list.*
import javax.inject.Inject


class BranchListActivity : BaseActivity(), BranchListMVPView {

    @Inject
    internal lateinit var adapter: BranchListAdapter

    @Inject
    internal lateinit var layoutManager: LinearLayoutManager

    @Inject
    internal lateinit var presenter: BranchListMVPPresenter<BranchListMVPView, BranchListMVPInteractor>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_branch_list)
        presenter.onAttach(this)
        supportActionBar?.title = this.resources.getString(R.string.listOfBranches)
        supportActionBar?.setHomeAsUpIndicator(resources.getDrawable(R.drawable.ic_action_back))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        setUp()
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    @SuppressLint("SuspiciousIndentation")
    private fun setUp() {
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        branchesRV.layoutManager = layoutManager
        branchesRV.itemAnimator = DefaultItemAnimator()
        branchesRV.adapter = adapter

        branchCodeTv.text = resources.getString(R.string.branch_code)
        branchNameTv.text = resources.getString(R.string.branch_name)
        noOfBranchTv.text = resources.getString(R.string.branch_head)
//        setRecycledViewPool(viewPool)

        val mDivider = ContextCompat.getDrawable(this, R.drawable.divider)
        val hItemDecoration = DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL)
        hItemDecoration.setDrawable(mDivider!!)

        fieldContainerLL.visibility = View.VISIBLE
        val regionCode = intent.getStringExtra("regionCode")
        val regionName = intent.getStringExtra("regionName")

//        if (regionCode != null && isNetworkAvailable(this@BranchListActivity))

            presenter.onGetBranchesClicked(regionCode!!.toInt())
//        else CustomDialog().showNoInternetAlert(this,"")
        supportActionBar?.subtitle = "Zone:$regionName"

        homeFab.setOnClickListener {
            goBackToHome(this@BranchListActivity)
        }
//        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
//            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
//                if (dy > 0 || dy < 0 && fab.isShown()) fab.hide()
//            }
//            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
//                if (newState == RecyclerView.SCROLL_STATE_IDLE) fab.show()
//                super.onScrollStateChanged(recyclerView, newState)
//            }
//        })
    }


    @SuppressLint("SetTextI18n")
    override fun displayBranchList(branchList: List<Branch>) = branchList.let {
        text_view.text = it.size.toString()
        adapter.addResultsToList(it)
    }

    override fun showError(errorMsg: String) {
        CustomDialog().showAlert(this, errorMsg)
    }

    override fun displayRegionsList(regions: List<Region>) {
    }



    @Suppress("DEPRECATION")
    @SuppressLint("NewApi")
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu_search, menu)
        val searchManager = getSystemService(SEARCH_SERVICE) as SearchManager
        val searchView = menu?.findItem(R.id.action_search)?.actionView as SearchView
        val searchableInfo =
                searchManager.getSearchableInfo(componentName)
        searchView.setSearchableInfo(searchableInfo)

        searchView.queryHint = resources.getString(R.string.search_hint_branch)
//        searchView.outlineSpotShadowColor = resources.getColor(R.color.white)
        searchView.maxWidth = Integer.MAX_VALUE
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                adapter.filter.filter(query)
                return false
            }

            override fun onQueryTextChange(query: String): Boolean {
                adapter.filter.filter(query)
                return false
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return if (id == R.id.action_search) {
            true
        } else super.onOptionsItemSelected(item)
    }


}