package com.bom.smamonitor.branchMaster

import android.util.Log
import com.androidnetworking.error.ANError
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

class BranchListPresenterImpl<V : BranchListMVPView, I : BranchListMVPInteractor>
@Inject internal constructor(interactor: I, schedulerProvider: SchedulerProvider, disposable: CompositeDisposable) :
        BasePresenter<V, I>(
                interactor = interactor,
                schedulerProvider = schedulerProvider,
                compositeDisposable = disposable
        ),
        BranchListMVPPresenter<V, I> {

    val TAG = "NpaPresenterImpl"

    override fun onGetBranchesClicked(regionCode: Int) {
            getView()?.showProgress()
            interactor?.let {
                it.getBranches(regionCode)
                        .compose(schedulerProvider.ioToMainObservableScheduler())
                        .subscribe({ branches:List<Branch> ->
                            println("Branches Results:-$branches")
                            getView()?.let { view ->
                                view.displayBranchList(branches)
                                view.hideProgress()
                            }
                        },{ error ->
                            val aNError = error as ANError
                            Log.d("branchPresImpl", aNError.cause.toString())
                            Log.d("branchPresImpl", aNError.message.toString())
                            getView()?.hideProgress()
                            getView()?.showError(aNError.errorDetail.toString())
                        })
            }
        }

    override fun onGetRegions()  {
        getView()?.showProgress()
        interactor?.let {
            it.getRegions()
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({  regions:List<Region> ->
                    println("Regions Results:-$regions")
                    getView()?.let { view ->
                        view.displayRegionsList(regions)
                        view.hideProgress()
                    }
                },{ error ->
                    val aNError = error as ANError
                    Log.d("RegionPresImpl", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

}