package com.bom.smamonitor.aboutapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bom.smamonitor.BuildConfig
import com.bom.smamonitor.R
import com.bom.smamonitor.profile.ProfileMVPInteractor
import com.bom.smamonitor.profile.ProfileMVPPresenter
import com.bom.smamonitor.profile.ProfileMVPView
import kotlinx.android.synthetic.main.activity_about_app.*
import javax.inject.Inject

class AboutAppActivity : AppCompatActivity() {

    @Inject
    internal lateinit var presenter: ProfileMVPPresenter<ProfileMVPView, ProfileMVPInteractor>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_app)
        window.statusBarColor = ContextCompat.getColor(this, R.color.colorPrimaryDark)
//        setSupportActionBar(toolbar)
        supportActionBar?.title = resources.getString(R.string.AboutAppTitle)
        initView()
    }

    private fun initView() {
       // appVersionTv.text = BuildConfig.VERSION_CODE.toString() + "." + BuildConfig.VERSION_NAME
        appVersionTv.text = "1.0.2"
        appReleaseTv.text = "01 MAR, 2023"
        btnBackToHome.setOnClickListener {
            onBackPressed()
        }
    }

}