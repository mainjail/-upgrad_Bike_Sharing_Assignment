package com.bom.smamonitor.ots.applEntry

import com.bom.smamonitor.base.presenter.MVPPresenter
import com.bom.smamonitor.ots.Repayment

interface OtsEntryMVPPresenter<V : OtsEntryMVPView, I : OtsEntryMVPInteractor> :
        MVPPresenter<V, I> {

    fun onViewPrepared()
    fun getCustomerDetails(cif: String)
    fun getOtsCustomerExisting(cif: String)
    fun getOtsModels()
    fun addRepaymentPlan(repayment: Repayment)
    fun getCustomerCbsDetails(cif: String)
    fun addOtsApplicationToDb(otsEntry: OtsEntryDetail)
    fun getAllOtsEntries()
    fun geOtsEntriesByInwrdNo(inwardNo: String)
    fun getOtsStatusList()


}