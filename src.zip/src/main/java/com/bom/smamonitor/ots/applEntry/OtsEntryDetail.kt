package com.bom.smamonitor.ots.applEntry

import com.google.gson.annotations.SerializedName

data class OtsEntryDetail(

        @SerializedName("inwardno")
        val inwardNo: String,
        @SerializedName("cif")
        val cif: String,
        @SerializedName("borr_name")
        val borrName: String,
        @SerializedName("brno")
        val brNo: String,
        @SerializedName("brname")
        val brName: String,
        @SerializedName("regcode")
        val regCode: String,
        @SerializedName("regname")
        val regName: String,
        @SerializedName("ots_model")
        val otsModel: String,
        @SerializedName("name_proprietor")
        val nameProprietor: String,
        @SerializedName("minimum_expected_rec")
        val minimumExpectedRec: String,
        @SerializedName("one_time_offer_amt")
        val oneTimeOfferAmt: String,
        @SerializedName("downpayment_amt")
        val downPaymentAmt: String,
        @SerializedName("sources_funds")
        val sourcesFunds: String,
        @SerializedName("reasons_for_ots")
        val reasonForOts: String,
        @SerializedName("authorized_person_name")
        val authorizedPersonName: String,
        @SerializedName("sanction_authority")
        val sanctionAuthority: String,
        @SerializedName("sanction_date")
        val sanctionDate: String,
        @SerializedName("latest_status")
        var latestStatus: String,
        @SerializedName("entryby")
        val entryBy: String,
        @SerializedName("entryon")
        val entryOn: String,
        @SerializedName("ledger_balance")
        val ledgerBalance: String,
        @SerializedName("unapplied_interest")
        val unAppliedInterest: String,
        @SerializedName("total_dues")
        val totalDues: String,
        @SerializedName("irac")
        val irac: String,
        @SerializedName("irac_date")
        val iracDate: String,
        @SerializedName("prop_inward_date")
        val propInwardDate: String,
        @SerializedName("prop_type")
        val propType: String,
        @SerializedName("ots_through")
        val otsThrough: String
)
//[{
//    "inwardno": "GGDY-10085425363-35",
//    "cif": "10085425364",
//    "borr_name": "THORAT MANGLA SHANKARRAO",
//    "brno": "622",
//    "brname": "Akola Umri",
//    "regcode": "45",
//    "regname": "Akola Region",
//    "ots_model": "GGDY",
//    "name_proprietor": "",
//    "minimum_expected_rec": "NULL",
//    "one_time_offer_amt": "2",
//    "downpayment_amt": "2",
//    "sources_funds": "OWN FUND",
//    "reasons_for_ots": "Activity Closed",
//    "authorized_person_name": "THORAT  MANGLA     SHANKARRAO",
//    "sanction_authority": "NULL",
//    "sanction_date": "NULL",
//    "latest_status": "16",
//    "entryby": "NULL",
//    "entryon": "NULL",
//    "pk": 4,
//    "ledger_balance": "-1",
//    "unapplied_interest": "61635.1",
//    "total_dues": "61636.1",
//    "irac": "08",
//    "irac_date": "8/30/2008",
//    "prop_inward_date": "31/05/2019",
//    "prop_type": "NULL",
//    "ots_through": "Offline"
//}
//]