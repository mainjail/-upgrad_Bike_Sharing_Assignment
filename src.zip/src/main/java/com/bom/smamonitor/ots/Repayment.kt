package com.bom.smamonitor.ots

import com.google.gson.annotations.SerializedName

data class Repayment (
    @SerializedName("cif")
    val cif: String,
    @SerializedName("ots_model")
    val otsModel: String,
    @SerializedName("amount")
    val amount: String,
    @SerializedName("repayment_date")
    val repaymentDate: String
    )

//{
//    "cif": "40049225352",
//    "ots_model": "M121",
//    "repayment_date": "10/10/2021",
//    "amount": "618000"
//}