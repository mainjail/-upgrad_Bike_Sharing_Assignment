package com.bom.smamonitor.ots.applEntry

import com.bom.smamonitor.ots.statusFrag.StatusOtsFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
internal abstract class OtsEntryFragmentProvider {

    @ContributesAndroidInjector(modules = [OtsEntryFragmentModule::class])
    internal abstract fun provideEmiCalciFragmentFactory(): OtsEntryFragment

    @ContributesAndroidInjector(modules = [OtsEntryFragmentModule::class])
    internal abstract fun provideRDCalciFragmentFactory(): StatusOtsFragment
//
//    @ContributesAndroidInjector(modules = [OtsEntryFragmentModule::class])
//    internal abstract fun provideFDCalciFragmentFactory(): FDCalciFragment
}