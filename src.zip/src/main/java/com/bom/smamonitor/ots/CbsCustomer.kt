package com.bom.smamonitor.ots

import com.google.gson.annotations.SerializedName

data class CbsCustomer (
        @SerializedName("CUST_ID")
        val custId:String,
        @SerializedName("CUST_TAX_PAN")
        val custTaxPAN:String,
        @SerializedName("CUST_VOTER_ID")
        val custVoterId:String,
        @SerializedName("EMAIL_ADD1")
        val emailId1:String,
        @SerializedName("BIRTH_DATE_1")
        val birthDate:String,
)
//        @SerializedName("COUNTRY_CODE")
//        val COUNTRY_CODE:String,
//        @SerializedName("MID_NAME")
//        val MID_NAME:String,
//        @SerializedName("NAME1")
//        val NAME1:String,
//        @SerializedName("NAME2")
//        val NAME2:String,
//        @SerializedName("PHONE_NO_RES")
//        val PHONE_NO_RES:String,
//        @SerializedName("POSTCODE")
//        val POSTCODE:String,
//        @SerializedName("STATE_CODE")
//        val STATE_CODE:String,
//        @SerializedName("TITLE_CODE")
//        val TITLE_CODE:String,
//        @SerializedName("ID1")
//        val ID1:String,
//        @SerializedName("OCCUP_DESCRIP")
//        val OCCUP_DESCRIP:String,
//        @SerializedName("OCCUPANCY")
//        val OCCUPANCY:String,
//        @SerializedName("OCCUPATION_CODE")
//        val OCCUPATION_CODE:String,
//        @SerializedName("SEX_CODE")
//        val SEX_CODE:String,
//        @SerializedName("ACCOUNT_SYSTEM")
//        val ACCOUNT_SYSTEM:String,
//        @SerializedName("APPLY_TDS")
//        val APPLY_TDS:String,
//        @SerializedName("ATM_FLAG")
//        val ATM_FLAG:String,
//        @SerializedName("BSR_ORG_CODE")
//        val BSR_ORG_CODE:String,
//        @SerializedName("BUS_SECTOR_CODE")
//        val BUS_SECTOR_CODE:String,
//
//        @SerializedName("ADD1")
//        val inwardNo:String,
//        @SerializedName("ADD2")
//        val inwardNo:String,
//        @SerializedName("ADD3")
//        val inwardNo:String,
//        @SerializedName("ADD4")
//        val inwardNo:String,
//        @SerializedName("CITY_CODE")
//        val inwardNo:String,
//        @SerializedName("COUNTRY_CODE")
//        val inwardNo:String,
//        @SerializedName("MID_NAME")
//        val inwardNo:String,
//        @SerializedName("NAME1")
//        val inwardNo:String,
//        @SerializedName("NAME2")
//        val inwardNo:String,
//        @SerializedName("PHONE_NO_RES")
//        val inwardNo:String,
//        @SerializedName("POSTCODE")
//        val inwardNo:String,
//        @SerializedName("STATE_CODE")
//        val inwardNo:String,
//        @SerializedName("TITLE_CODE")
//        val inwardNo:String,
//        @SerializedName("ID1")
//        val inwardNo:String,
//        @SerializedName("OCCUP_DESCRIP")
//        val inwardNo:String,
//        @SerializedName("OCCUPANCY")
//        val inwardNo:String,
//        @SerializedName("OCCUPATION_CODE")
//        val inwardNo:String,
//        @SerializedName("SEX_CODE")
//        val inwardNo:String,
//        @SerializedName("ACCOUNT_SYSTEM")
//        val inwardNo:String,
//        @SerializedName("APPLY_TDS")
//        val inwardNo:String,
//        @SerializedName("ATM_FLAG")
//        val inwardNo:String,
//        @SerializedName("BSR_ORG_CODE")
//        val inwardNo:String,
//
//        )
//////[
//////{
//////    "CUST_ID": "00000040009357432",
//////    "ADD1": "904, TWIN TOWER,                        ",
//////    "ADD2": "                                        ",
//////    "ADD3": "AUNDH, PUNE                             ",
//////    "ADD4": "                                        ",
//////    "CITY_CODE": "411",
//////    "COUNTRY_CODE": "IN",
//////    "MID_NAME": "S                                       ",
//////    "NAME1": "SUNITA                                  ",
//////    "NAME2": "KUKODE                                  ",
//////    "PHONE_NO_RES": "            ",
//////    "POSTCODE": "00411007",
//////    "STATE_CODE": "52 ",
//////    "TITLE_CODE": "02",
//////    "ID1": "10062280901   13    ",
//////    "OCCUP_DESCRIP": "                              ",
//////    "OCCUPANCY": "H",
//////    "OCCUPATION_CODE": 0,
//////    "SEX_CODE": "F",
//////    "ACCOUNT_SYSTEM": "   ",
//////    "APPLY_TDS": "Y",
//////    "ATM_FLAG": "0",
//////    "BSR_ORG_CODE": "42 ",
//////    "BUS_SECTOR_CODE": "     ",
//
//////    "CK_CNTY_LMT_IND": " ",
//////    "CK_CUST_LMT_IND": " ",
//////    "CK_CUST_PA_LMT_IND": " ",
//////    "CK_INDU_LMT_IND": " ",
//////    "CK_SECTOR_LMT_IND": " ",
//////    "COUNTRY_OF_RISK": "IN",
//////    "CREATE_DT": 39807,
//////    "CROSS_BORDER_RISK": "ZZ",
//////    "CUST_ACCT_NO": "0000004000935743",
//////    "CUST_EVAL_FLAG": "Y",
//////    "CUST_TAX_PAN": "                    ",
//////    "CUST_VOTER_ID": "                    ",
//////    "CUSTOMER_STATUS": "000",
//////    "CUSTOMER_TYPE": "01",
//////    "DELIVERY_MODE": "  ",
//////    "DOMESTIC_RISK": "01",
//////    "EXP_AMT": 0,
//////    "GRUP_CODE": "     ",
//////    "HOME_BRANCH_NO": "00330",
//////    "INDUSTRY_CODE": "    ",
//////    "LANGUAGE_CODE": "01",
//////    "LAST_STAT_CHG_DT": 0,
//////    "LAST_STMT_DT": 0,
//////    "LAST_USED_ACCT_NO": 4000935743,
//////    "LOCKER_HOLDER": "0",
//////    "MAIL_IND": " ",
//////    "MAIL_IND_EXP_DT": 0,
//////    "MISLA_ORG_CODE": "413",
//////    "MSGS_PENDING": 0,
//////    "NATIONALITY_CD": "IN ",
//////    "NO_MASTER_STATUS": "0",
//////    "NO_OF_MESSAGES": 0,
//////    "NOTICE_CUST_NO": 0,
//////    "NOTICE_IND": " ",
//////    "NOTICE_PROCESS_IND": " ",
//////    "NPA_NON_TRADE": " ",
//////    "NPA_TRADE": " ",
//////    "PMNT_RETURN_DT": 0,
//////    "POST_CHECKER_ID": "0000000",
//////    "PRIM_ACCT": 4000935743,
//////    "RESI_STATUS": "1",
//////    "SEC_ACCESS_IND": "0",
//////    "SEGMENT_CODE": "0101",
//////    "SOC_NO": "003",
//////    "STMT_CYCLE": "00",
//////    "STMT_DAY": "00",
//////    "STMT_FREQUENCY": " ",
//////    "TFN_IND": "0",
//////    "TFN_STATUS": " ",
//////    "THIS_ACCT_STATUS": "0",
//////    "TIER_CUST_TYPE": "010203  ",
//////    "TRADE_CUSTOMER": " ",
//////    "VIP_CODE": "0",
//////    "SOC_ATT1": null,
//////    "SOC_ATT2": null,
//////    "SOC_ATT3": null,
//////    "SOC_ATT4": null,
//////    "SOC_ATT5": null,
//////    "TELEX_NO": "   ",
//////    "PHONE_NO_BUS": " ",
//////    "FATHER_NAME": "   ",
//////    "MOTHER_NAME": "    ",
//////    "RELATIVE_CODE": " ",
//////    "EXPI_DATE": 99999999,
//////    "FAX_NO": "            ",
//////    "RECNO": "",
//////    "CUST_NO": "0000004000935743",
//////    "CODE": "AA",
//////    "DELI": "0",
//////    "INST_NO": "003",
//////    "EMAIL_ADD1": null,
//////    "EMAIL_ADD2": null,
//////    "BIRTH_DATE_1": 26775,
//////    "DEATH_DATE": 0,
//////    "DATE": "2021-02-05T00:00:00.000Z",
//////    "Cust_Type": 0,
//////    "INTERNET_BANKING": null,
//////    "UID_NO": null,
//////    "UID_LINK_AC": null,
//////    "UID_LINK_DATE": null,
//////    "annual_income": "00",
//////    "COMPANY_CIN": null,
//////    "Passport_No": ""
//////}
//////]