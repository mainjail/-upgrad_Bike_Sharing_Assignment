package com.bom.smamonitor.ots

import com.google.gson.annotations.SerializedName

data class OtsStatus (
    @SerializedName("status_code")
    val statusCode: String,
    @SerializedName("status_description")
    val statusDesc: String,
    @SerializedName("status_flag")
    val statusFlag: String
    )
//{
//    "status_code": "11",
//    "status_description": "Presently Processing at HO",
//    "status_flag": "P"
//},