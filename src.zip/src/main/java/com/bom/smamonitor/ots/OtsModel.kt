package com.bom.smamonitor.ots

import com.google.gson.annotations.SerializedName

data class OtsModel (
    @SerializedName("id")
    val id: String,
    @SerializedName("OtsScheme")
    val OtsScheme: String,
    @SerializedName("SchemeCode")
    val SchemeCode: String,
    @SerializedName("Status")
    val Status: String
    )
//{
//    "id": 7,
//    "OtsScheme": "Maha Rahat Yojana  With Covid Discount 2021–22",
//    "SchemeCode": "RYC21",
//    "Status": 1
//},