package com.bom.smamonitor.ots.applEntry

import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.network.ApiHelper
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.ots.CbsCustomer
import com.bom.smamonitor.ots.OtsModel
import com.bom.smamonitor.ots.OtsStatus
import io.reactivex.Observable
import javax.inject.Inject

class OtsEntryInteractorImpl @Inject internal constructor(preferenceHelper: PreferenceHelper, apiHelper: ApiHelper) :
    BaseInteractor(preferenceHelper, apiHelper), OtsEntryMVPInteractor {

    override fun getCustomerCbsDetails(cif: String): Observable<List<CbsCustomer>> = apiHelper.getCustomerCbsDetails(cif)
    override fun getCustomerDetails(cif: String): Observable<List<NpaCustomer>> =apiHelper.getNpaCustomerByCustNo(cif)
    override fun getOtsCustomerExisting(cif: String): Observable<List<OtsEntryDetail>> =  apiHelper.getOtsEntryDetails(cif)
    override fun getOtsModels(): Observable<List<OtsModel>> = apiHelper.getOtsModels()
    override fun getOtsStatusMaster(): Observable<List<OtsStatus>> = apiHelper.getOtsStatusMaster()
    override fun getAllOtsEntries(): Observable<List<OtsEntryDetail>> = apiHelper.getAllOtsEntries()
    override fun getOtsByInwardNo(inwardNo: String): Observable<List<OtsEntryDetail>> =apiHelper.getOtsByInwardNo(inwardNo)


}