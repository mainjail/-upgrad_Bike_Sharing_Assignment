package com.bom.smamonitor.ots.statusFrag.statusTable;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bom.smamonitor.details.tablew.customTable.MyTableViewModel;
import com.bom.smamonitor.details.tablew.holder.ColumnHeaderViewHolder;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.popup.ColumnHeaderLongPressPopup;
import com.evrencoskun.tableview.TableView;
import com.evrencoskun.tableview.listener.ITableViewListener;


public class StatusOts_TbViewListener implements ITableViewListener {
    private static final String LOG_TAG = StatusOts_TbViewListener.class.getSimpleName();

    private final TableView mTableView;
    @NonNull
    private final Context mContext;

    public StatusOts_TbViewListener(TableView pTableView) {
        this.mContext = pTableView.getContext();
        this.mTableView = pTableView;
    }

    @Override
    public void onCellClicked(@NonNull RecyclerView.ViewHolder cellView, int column, int row) {
        Log.d(LOG_TAG, "onCellClicked has been clicked for x= " + column + " y= " + row);
        switch (column) {
            case MyTableViewModel.LINK_COLUMN_INDEX1:
            case MyTableViewModel.LINK_COLUMN_INDEX2:
                Cell cellItem = (Cell) mTableView.getAdapter().getCellItem(column, row);
//                if (cellItem.getData() != null) {
//                    String fileName = cellItem.getData().toString();
////                    openInWebView(fileName);
////                    openPdfView(fileName);
//                } else {
//                    showToast("No content available.");
//                }
                break;
        }
    }


    @Override
    public void onCellDoubleClicked(@NonNull RecyclerView.ViewHolder cellView, int column, int row) {

    }

    @Override
    public void onCellLongPressed(@NonNull RecyclerView.ViewHolder cellView, int column, int row) {
        Log.d(LOG_TAG, "onCellLongPressed has been clicked for " + row);
    }

    @Override
    public void onColumnHeaderClicked(@NonNull RecyclerView.ViewHolder columnHeaderView, int
            column) {
        Log.d(LOG_TAG, "onColumnHeaderClicked has been clicked for " + column);
    }

    @Override
    public void onColumnHeaderDoubleClicked(@NonNull RecyclerView.ViewHolder columnHeaderView, int column) {

    }


    @Override
    public void onColumnHeaderLongPressed(@NonNull RecyclerView.ViewHolder columnHeaderView, int column) {
        if (columnHeaderView != null && columnHeaderView instanceof ColumnHeaderViewHolder) {
            // Create Long Press Popup
            ColumnHeaderLongPressPopup popup = new ColumnHeaderLongPressPopup(
                    (ColumnHeaderViewHolder) columnHeaderView, mTableView);
            // Show
            popup.show();
        }

    }

    @Override
    public void onRowHeaderClicked(@NonNull RecyclerView.ViewHolder rowHeaderView, int row) {
        Log.d(LOG_TAG, "onRowHeaderClicked has been clicked for " + row);
    }

    @Override
    public void onRowHeaderDoubleClicked(@NonNull RecyclerView.ViewHolder rowHeaderView, int row) {

    }

    @Override
    public void onRowHeaderLongPressed(@NonNull RecyclerView.ViewHolder rowHeaderView, int row) {
        Log.d(LOG_TAG, "onRowHeaderLongPressed has been clicked for " + row);
//        // Create Long Press Popup
//        RowHeaderLongPressPopup popup = new RowHeaderLongPressPopup(rowHeaderView, mTableView);
//        // Show
//        popup.show();
    }

    private void showToast(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
    }
}
