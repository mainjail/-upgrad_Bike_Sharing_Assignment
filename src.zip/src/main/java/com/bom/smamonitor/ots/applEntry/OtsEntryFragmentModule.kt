package com.bom.smamonitor.ots.applEntry

import dagger.Module
import dagger.Provides

@Module
class OtsEntryFragmentModule {

    @Provides
    internal fun provideBlogPresenter(presenter: OtsEntryPresenterImpl<OtsEntryMVPView, OtsEntryMVPInteractor>)
            : OtsEntryMVPPresenter<OtsEntryMVPView, OtsEntryMVPInteractor> = presenter

    @Provides
    internal fun provideBlogInteractor(interactor: OtsEntryInteractorImpl): OtsEntryMVPInteractor =
        interactor

}