package com.bom.smamonitor.ots.statusFrag

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseFragment
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.ots.CbsCustomer
import com.bom.smamonitor.ots.OtsModel
import com.bom.smamonitor.ots.OtsStatus
import com.bom.smamonitor.ots.Repayment
import com.bom.smamonitor.ots.applEntry.OtsEntryDetail
import com.bom.smamonitor.ots.applEntry.OtsEntryMVPInteractor
import com.bom.smamonitor.ots.applEntry.OtsEntryMVPPresenter
import com.bom.smamonitor.ots.applEntry.OtsEntryMVPView
import com.bom.smamonitor.ots.statusFrag.statusTable.StatusOt_TableViewModel
import com.bom.smamonitor.ots.statusFrag.statusTable.StatusOts_TbAdapter
import com.bom.smamonitor.ots.statusFrag.statusTable.StatusOts_TbViewListener
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import kotlinx.android.synthetic.main.fragment_status_update.*
import javax.inject.Inject

class StatusOtsFragment : BaseFragment(), OtsEntryMVPView {


    override fun displayCustomerDetails(customer: NpaCustomer) {
        TODO("Not yet implemented")
    }

    override fun displayCustCbsDetails(cbsCustomer: CbsCustomer) {
        TODO("Not yet implemented")
    }

    override fun displayOTSInwdList() {
        TODO("Not yet implemented")
    }

    override fun displayCustOtsExisting() {
        TODO("Not yet implemented")
    }

    override fun repaymentAddSuccess(repayment: Repayment) {
        TODO("Not yet implemented")
    }

    override fun validateDetails(errorCode: Int) {
        TODO("Not yet implemented")
    }

    private val TAG = "StatOtsFrag"
    val tableViewModel = StatusOt_TableViewModel()
    val tableViewAdapter = StatusOts_TbAdapter(tableViewModel)
    private lateinit var otsModels: List<OtsModel>
    private lateinit var statusList: List<OtsStatus>

    private fun initializeTableView() {
        statusTableView.setAdapter(tableViewAdapter)
        val myTableViewListener = StatusOts_TbViewListener(statusTableView)
        statusTableView.tableViewListener = myTableViewListener
//        tableViewAdapter.setUserList(accountsList)
    }

    override fun initToolbar() {
        activity?.window?.statusBarColor =
            ContextCompat.getColor(requireContext(), R.color.colorPrimaryDark)
    }

    companion object {
        fun newInstance(): StatusOtsFragment {
            return StatusOtsFragment()
        }
    }

    private lateinit var searchInwdNo: String

    @Inject
    internal lateinit var presenter: OtsEntryMVPPresenter<OtsEntryMVPView, OtsEntryMVPInteractor>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_status_update, container, false)!!


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onDestroyView() {
        presenter.onDetach()
        super.onDestroyView()
    }

    override fun setUp() {
        presenter.onViewPrepared()
        if (ValidationUtils.isNetworkAvailable(requireContext()))

            presenter.getOtsModels()
        else
            CustomDialog().showNoInternetAlert(requireActivity(), "")

        searchOtsEntryBtn.setOnClickListener {
            searchInwdNo = inwardNoSearchEt.text.toString()
            if (searchInwdNo.isNotEmpty())
                if (ValidationUtils.isNetworkAvailable(requireContext()))
                    presenter.geOtsEntriesByInwrdNo(searchInwdNo)
                else
                    CustomDialog().showNoInternetAlert(requireActivity(), "")
            else
                CustomDialog().popUpToast(requireActivity(), "Please enter valid Inward No.")
        }
        initializeTableView()
    }


    override fun displayOTSList(otsList: List<OtsEntryDetail>) {

        val crunchIterator: Iterator<OtsStatus> = statusList.iterator()
        otsList.forEach { otsItem ->
            println(otsItem.latestStatus)
            for ( tempItem in statusList){
                if (otsItem.latestStatus == tempItem.statusCode) {
                    otsItem.latestStatus = tempItem.statusDesc
                    println(otsItem.latestStatus)
                }
            }
        }
        tableViewAdapter.setUserList(otsList)
    }

    override fun setOtsStatusMaster(otsStatusList: List<OtsStatus>) {
        Log.d(TAG, "otsStatus:-${otsStatusList}")
        statusList = otsStatusList
        presenter.getAllOtsEntries()
    }

    override fun setOTSModels(otsModelList: List<OtsModel>) {
        Log.d(TAG, "otsModels:-${otsModelList}")
        otsModels = otsModelList
        presenter.getOtsStatusList()
    }

    override fun showError(error: String) {
        CustomDialog().popUpToast(requireActivity(), error)
    }


}