package com.bom.smamonitor.ots

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.bom.smamonitor.ots.applEntry.OtsEntryFragment
import com.bom.smamonitor.ots.statusFrag.StatusOtsFragment


class OtsPagesAdapter(fa: FragmentActivity) : FragmentStateAdapter(fa) {

    override fun getItemCount(): Int {
        return tabCount
    }
    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> OtsEntryFragment.newInstance()
            1 -> StatusOtsFragment.newInstance()
//            2 -> FDCalciFragment.newInstance()
            else -> throw IllegalStateException("position $position is invalid for this viewpager")
        }
    }

    private var tabCount = 0

    internal fun setCount(count: Int) {
        this.tabCount = count
    }
}

