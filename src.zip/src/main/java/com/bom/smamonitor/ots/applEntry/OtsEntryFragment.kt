package com.bom.smamonitor.ots.applEntry

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.updateLayoutParams
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseFragment
import com.bom.smamonitor.customViews.CustomSpinnerAdapter
import com.bom.smamonitor.details.tablew.customTable.MyTableAdapter
import com.bom.smamonitor.details.tablew.customTable.MyTableViewListener
import com.bom.smamonitor.details.tablew.customTable.MyTableViewModel
import com.bom.smamonitor.npa.modelNpa.NpaAccount
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.ots.CbsCustomer
import com.bom.smamonitor.ots.OtsModel
import com.bom.smamonitor.ots.OtsStatus
import com.bom.smamonitor.ots.Repayment
import com.bom.smamonitor.util.CommonUtil
import com.bom.smamonitor.util.CustomDialog
import com.bom.smamonitor.util.ValidationUtils
import kotlinx.android.synthetic.main.fragment_ots_appltn2.*
import kotlinx.android.synthetic.main.fragment_ots_appltn2.nameTableContainer_ots
import kotlinx.android.synthetic.main.include_input_ots.*
import kotlinx.android.synthetic.main.include_input_ots.view.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject


class OtsEntryFragment : BaseFragment(), OtsEntryMVPView, AdapterView.OnItemSelectedListener {

    override fun displayOTSInwdList() {
        CustomDialog().popUpToast(requireActivity(), "Application saved Successfully.")
    }

    private lateinit var dataAdapter: CustomSpinnerAdapter
    private lateinit var searchCustNo: String
    private var accountsList: ArrayList<NpaAccount?>? = ArrayList()
    lateinit var npaCustomerSave: NpaCustomer
    var otsModelSelected = ""

    override fun showError(error: String) {
        CustomDialog().popUpToast(requireActivity(), error)
    }


    override fun initToolbar() {
        activity?.window?.statusBarColor =
            ContextCompat.getColor(requireContext(), R.color.colorPrimaryDark)
    }


    companion object {
        fun newInstance(): OtsEntryFragment {
            return OtsEntryFragment()
        }
    }

    @Inject
    internal lateinit var presenter: OtsEntryMVPPresenter<OtsEntryMVPView, OtsEntryMVPInteractor>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_ots_appltn2, container, false)!!


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
    }

    private fun setVisibilityContent(setCardVisible: Boolean) {
        
        if (setCardVisible) {
            nameTableContainer_ots.visibility = View.VISIBLE
            if(npaCustomerSave!=null) {
                val listSize = npaCustomerSave.accountsList.size
                Log.d("otsEntryFrag","listSize${listSize}")
                if (listSize < 3)
                    tableView1_ots.updateLayoutParams { height = 300 }
                else if (listSize in 4..5)
                    tableView1_ots.updateLayoutParams { height = 700 }
                else{
                    tableView1_ots.updateLayoutParams { height = 1000 }
                }
            }
        } else {
            nameTableContainer_ots.visibility = View.GONE
            tableView1_ots.updateLayoutParams{height= WRAP_CONTENT}
        }

        outerTableLL.updateLayoutParams { height = WRAP_CONTENT }
        tableContainer_ots_Card.updateLayoutParams{height= WRAP_CONTENT}
    }

    override fun setUp() {

        presenter.onViewPrepared()
        setVisibilityContent(false)

        val stringArr2: Array<String> = resources.getStringArray(R.array.ProposalTypeArray)
        val dataAdapter2 =
            ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, stringArr2)
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_list_item_1)
        inputOtsLL.proposalTypeSpinner.adapter = dataAdapter2

        onOffRdGrp.isEnabled = false

        inputOtsLL.propInwdEt.setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> //Do Something
                        openDatePickerDialog()
                }
                return v?.onTouchEvent(event) ?: true
            }
        })

        inputOtsLL.repayDayEt.setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> //Do Something
                        openDatePickerDialog2()
                }
                return v?.onTouchEvent(event) ?: true
            }
        })
        inputOtsLL.otsModelSpinner.onItemSelectedListener = this

        searchCifBtn.setOnClickListener {
            searchCustNo = custNoSearchEt.text.toString()
            if (searchCustNo.length == 11)
                if (ValidationUtils.isNetworkAvailable(requireContext()))
                    presenter.getOtsCustomerExisting(searchCustNo)
                else
                    CustomDialog().showNoInternetAlert(requireActivity(), "")
            else
                CustomDialog().popUpToast(requireActivity(), "Please enter valid CIF.")
        }

        addRepaymentBtn_ots.setOnClickListener {
            val otsModelSelect = otsModelSpinner.selectedItem as OtsModel
            val otsModelSelectedCode = otsModelSelect.SchemeCode
            val repayment = Repayment(
                custNoTv_ots.text.toString(), otsModelSelectedCode,
                etAmtInRs.text.toString(), repayDayEt.text.toString()
            )
            presenter.addRepaymentPlan(repayment)
        }

        SubmitOTSBtn_ots.setOnClickListener {
            val inwardNo = ""
            val otsModelSelect = otsModelSpinner.selectedItem as OtsModel
            val otsModelSelectedCode = otsModelSelect.SchemeCode

            val otsEntryDetail = OtsEntryDetail(
                inwardNo = inwardNo,
                cif = custNoTv_ots.text.toString(),
                borrName = customerNameTv_ots.text.toString().trim(),
                brNo = npaCustomerSave.brCode.toString().trim(),
                brName = npaCustomerSave.brName.trim(),
                regCode = npaCustomerSave.regCode.toString().trim(),
                regName = "",
                otsModel = otsModelSelectedCode.trim(),
                nameProprietor = etNameProp.text.toString().trim(),
                minimumExpectedRec = "",
                oneTimeOfferAmt = etOneTimeOffer.text.toString().trim(),
                downPaymentAmt = etDownPayment.text.toString().trim(),
                sourcesFunds = etSrcFunds.text.toString().trim(),
                reasonForOts = resnInBriefEt.text.toString().trim(),
                authorizedPersonName = nameOfAuthPersonEt.text.toString().trim(),
                sanctionAuthority = "",
                sanctionDate = "",
                latestStatus = "1",
                entryBy = "",
                entryOn = "",
                ledgerBalance = BalanceTv_ots.text.toString().trim(),
                unAppliedInterest = unappliedIntTv_ots.text.toString().trim(),
                totalDues = totalDuesTv_ots.text.toString().trim(),
                irac = npaCustomerSave.accountsList[0].oldIrac,
                iracDate = "",
                propInwardDate = propInwdEt.text.toString().trim(),
                propType = proposalTypeSpinner.selectedItem.toString().trim(),
                otsThrough = "Mobile"
            )
            basicSubmitAlertDialog(otsEntryDetail)

        }
    }

    private fun basicSubmitAlertDialog(otsEntryDetail: OtsEntryDetail) {
        val builder = AlertDialog.Builder(requireContext(), R.style.MyAlertDialogStyle)
        with(builder) {
            setTitle("Alert")
            setMessage("Are you sure, you want to submit application?")
            setPositiveButton("Submit", null)
            setNegativeButton("Cancel", null)
            setIcon(resources.getDrawable(android.R.drawable.ic_dialog_alert))
        }
        val alertDialog = builder.create()
        alertDialog.show()
        val cancelBtn = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE)
        cancelBtn.setTextColor(Color.BLACK)
        cancelBtn.setOnClickListener {
            alertDialog.dismiss()
        }
        val okBtn = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE)
        with(okBtn) {
            setTextColor(resources.getColor(R.color.colorPrimary))
            setOnClickListener {
                finalSubmitOtsApplicationApi(otsEntryDetail)
                alertDialog.dismiss()
            }
        }

    }

    private fun finalSubmitOtsApplicationApi(otsEntryDetail: OtsEntryDetail) {
        if (ValidationUtils.isNetworkAvailable(requireContext()))
            presenter.addOtsApplicationToDb(otsEntryDetail)
        else
            CustomDialog().showNoInternetAlert(requireActivity(), "")
    }

    override fun validateDetails(errorCode: Int) {
        var errorMsg = ""
        when (errorCode) {
            1 -> errorMsg =
                getString(R.string.empty_Cif)
            2 -> errorMsg =
                getString(R.string.empty_otsModel)
            3 -> errorMsg =
                getString(R.string.empty_propType)
            4 -> errorMsg =
                getString(R.string.empty_propInwdDate)
            5 -> errorMsg =
                getString(R.string.empty_nameOfProprietor)
            6 -> errorMsg =
                getString(R.string.empty_One_timeAmt)
            7 -> errorMsg =
                getString(R.string.empty_downPayment)
            8 -> errorMsg =
                getString(R.string.empty_sourceFunds)
            9 -> errorMsg =
                getString(R.string.empty_resnInBrief)
            10 -> errorMsg =
                getString(R.string.empty_NameAuthPerson)
            11 -> errorMsg =
                getString(R.string.empty_repaymentDate)
            12 -> errorMsg =
                getString(R.string.empty_Amount)
        }
        Toast.makeText(requireContext(), errorMsg, Toast.LENGTH_LONG).show()
    }

    private val calendar1 = Calendar.getInstance()
    private val calendar2 = Calendar.getInstance()

    private val myFormat = "yyyy-MM-dd" // mention the format you need
    private val sdf = SimpleDateFormat(myFormat, Locale.US)

    private val dateSetListener1 =
        DatePickerDialog.OnDateSetListener { datePickerView, year, monthOfYear, dayOfMonth ->
            calendar1.set(Calendar.YEAR, year)
            calendar1.set(Calendar.MONTH, monthOfYear)
            calendar1.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            inputOtsLL.propInwdEt.setText(sdf.format(calendar1.time).toString())
        }

    private val dateSetListener2 =
        DatePickerDialog.OnDateSetListener { datePickerView, year, monthOfYear, dayOfMonth ->
            calendar2.set(Calendar.YEAR, year)
            calendar2.set(Calendar.MONTH, monthOfYear)
            calendar2.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            inputOtsLL.repayDayEt.setText(sdf.format(calendar2.time).toString())
        }

    //Open DatePicker dialog with future date disabled
    private fun openDatePickerDialog() {
        val datePickerDialog1 = DatePickerDialog(
            requireContext(), dateSetListener1,
            calendar1.get(Calendar.YEAR),
            calendar1.get(Calendar.MONTH),
            calendar1.get(Calendar.DAY_OF_MONTH)
        )

        datePickerDialog1.datePicker.maxDate = (Calendar.getInstance().timeInMillis)
        datePickerDialog1.show()
    }

    private fun openDatePickerDialog2() {
        val datePickerDialog2 = DatePickerDialog(
            requireContext(), dateSetListener2, calendar2.get(Calendar.YEAR),
            calendar2.get(Calendar.MONTH), calendar2.get(Calendar.DAY_OF_MONTH)
        )
//        datePickerDialog2.datePicker.minDate = (Calendar.getInstance().timeInMillis)
        datePickerDialog2.show()
    }

    override fun onDestroyView() {
        presenter.onDetach()
        super.onDestroyView()
    }

    private val String.capitalizeWords
        get() = this.toLowerCase(Locale.getDefault()).split(" ").joinToString(" ") {
            it.capitalize(Locale.getDefault())
        }

    @SuppressLint("SetTextI18n")
    override fun displayCustomerDetails(npaCustomer: NpaCustomer) {
        presenter.getCustomerCbsDetails(searchCustNo)
        presenter.getOtsModels()

        npaCustomerSave = npaCustomer
        accountsList = npaCustomer.accountsList as ArrayList<NpaAccount?>
        customerNameTv_ots.text = npaCustomer.custName
        custNoTv_ots.text = npaCustomer.custNo
        BranchCodeTv_ots.text = npaCustomer.brCode.toString() + "-" + npaCustomer.brName
        ZoneCodeTv_ots.text = npaCustomer.regCode.toString()

        custMobileNoTv.text =
            "+" + npaCustomer.mobNo.substring(0, 2) + " - " + npaCustomer.mobNo.substring(
                2,
                npaCustomer.mobNo.length
            )

        val totalLedgerBalance = calculateTotalBalance(npaCustomer).toString()
        BalanceTv_ots.text = CommonUtil.formatRoundUp(totalLedgerBalance)
        val totalUnAppliedInt = calculateTotalUnAppliedInt(npaCustomer).toString()
        unappliedIntTv_ots.text = CommonUtil.formatRoundUp(totalUnAppliedInt)

        val totalDues = calculateTotalDues(npaCustomer).toString()
        totalDuesTv_ots.text = CommonUtil.formatRoundUp(totalDues)

        if (npaCustomer.address != null) {
            val address = npaCustomer.address
            custAddressTv_ots.text = address.add1?.capitalizeWords + ", " +
                    address.add2?.capitalizeWords + ", " +
                    address.add3?.capitalizeWords + ", " +
                    address.add4?.capitalizeWords + " - " +
                    address.postcode
        }

        initializeTableView()

        custCallIV.setOnClickListener { CommonUtil.makeACall(npaCustomer.mobNo, requireContext()) }

        custAddressTv_ots.setOnClickListener {
            if (npaCustomer.address != null) {
                val address = npaCustomer.address
                val addSearch = address.add1?.capitalizeWords +
                        address.add2?.capitalizeWords +
                        address.add3?.capitalizeWords +
                        address.add4?.capitalizeWords
                openMapSearchAddress(addSearch)
            }
        }
        setVisibilityContent(setCardVisible = true)

    }

    private fun calculateTotalDues(npaCustomer: NpaCustomer): BigDecimal {
        var i = 0
        var custTotalDues = 0.0
        while (i < npaCustomer.accountsList.size) {
            val interest = npaCustomer.accountsList[i].unappliedInt.toDoubleOrNull() ?: 0.0
            val ledgerBalance = npaCustomer.accountsList[i].loanBalance?.toDoubleOrNull() ?: 0.0
            custTotalDues += interest + ledgerBalance
            i++
        }
        val duesDecimal = BigDecimal(custTotalDues).setScale(2, RoundingMode.HALF_EVEN)
        return duesDecimal
    }

    private fun calculateTotalBalance(npaCustomer: NpaCustomer): BigDecimal {
        var i = 0
        var custTotBalance = npaCustomer.custBalance?.toDoubleOrNull() ?: 0.0
        while (i < npaCustomer.accountsList.size) {
            val loanBal = npaCustomer.accountsList[i].loanBalance?.toDoubleOrNull() ?: 0.0
            custTotBalance += loanBal
            i++
        }
        val balanceDecimal = BigDecimal(custTotBalance).setScale(2, RoundingMode.HALF_EVEN)
        return balanceDecimal
    }

    private fun calculateTotalUnAppliedInt(npaCustomer: NpaCustomer): BigDecimal {
        var i = 0
        var custTotUnInt = 0.0
        while (i < npaCustomer.accountsList.size) {
            val interest = npaCustomer.accountsList[i].unappliedInt.toDoubleOrNull() ?: 0.0
            custTotUnInt += interest
            i++
        }
        val balanceDecimal = BigDecimal(custTotUnInt).setScale(2, RoundingMode.HALF_EVEN)
        return balanceDecimal
    }

    @SuppressLint("QueryPermissionsNeeded")
    private fun openMapSearchAddress(address: String) {
        val mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(address))
        //        val gmmIntentUri = Uri.parse("geo:0,0?q=1600 Amphitheatre Parkway, Mountain+View, California")
        val mapIntent = Intent(Intent.ACTION_VIEW, mapUri)
        mapIntent.setPackage("com.google.android.apps.maps")
        if (mapIntent.resolveActivity(requireActivity().packageManager) != null)
            startActivity(mapIntent)
    }

    private fun initializeTableView() {
        val tableViewModel = MyTableViewModel()
        val tableViewAdapter = MyTableAdapter(tableViewModel)
        tableView1_ots.setAdapter(tableViewAdapter)
        val myTableViewListener = MyTableViewListener(tableView1_ots)
        tableView1_ots.tableViewListener = myTableViewListener
        tableViewAdapter.setUserList(accountsList)
    }

    override fun displayCustOtsExisting() {
        val custNo = custNoSearchEt.text.toString()
        if (custNo.length == 11)
            presenter.getCustomerDetails(custNo)
        else
            CustomDialog().popUpToast(requireActivity(), "Please enter valid CIF.")
    }

    override fun setOTSModels(otsModelList: List<OtsModel>) {
//        val dataAdapter: ArrayAdapter<OtsModel> =
//        ArrayAdapter<OtsModel>(requireContext(), android.R.layout.simple_spinner_dropdown_item, otsModelList)
        dataAdapter = CustomSpinnerAdapter(
            requireContext(), android.R.layout.simple_spinner_dropdown_item,
            otsModelList
        )
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//        val stringArr: Array<String> = resources.getStringArray(R.array.OTSModelArray)
//        val dataAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, stringArr)
//        dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1)
        inputOtsLL.otsModelSpinner.adapter = dataAdapter

    }

    override fun onItemSelected(arg0: AdapterView<*>, arg1: View, position: Int, id: Long) {
        // use position to know the selected item
//    otsModelSelected=inputOtsLL.otsModelSpinner.selectedItem
    }

    override fun onNothingSelected(arg0: AdapterView<*>) {

    }

    override fun repaymentAddSuccess(repayment: Repayment) {
        addRepaymentBtn_ots.isEnabled = false
        CustomDialog().popUpToast(requireActivity(), "Repayment Plan saved successfully.")
    }

    override fun displayOTSList(otsList: List<OtsEntryDetail>) {
        TODO("Not yet implemented")
    }

    override fun setOtsStatusMaster(otsModel: List<OtsStatus>) {
        TODO("Not yet implemented")
    }

    override fun displayCustCbsDetails(customer: CbsCustomer) {
        if (customer.custTaxPAN.isNotEmpty())
            custPANTv_ots.text = customer.custTaxPAN
        if (customer.birthDate.isNotEmpty())
            custDobTv_ots.text = customer.birthDate
        if (customer.emailId1.isNotEmpty())
            custEmailTv_ots.text = customer.emailId1
    }

}