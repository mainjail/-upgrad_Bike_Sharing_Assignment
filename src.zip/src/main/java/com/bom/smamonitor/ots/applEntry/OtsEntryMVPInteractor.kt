package com.bom.smamonitor.ots.applEntry

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.ots.CbsCustomer
import com.bom.smamonitor.ots.OtsModel
import com.bom.smamonitor.ots.OtsStatus
import io.reactivex.Observable

interface OtsEntryMVPInteractor : MVPInteractor {

    fun getCustomerCbsDetails(cif: String): Observable<List<CbsCustomer>>
    fun getCustomerDetails(cif: String): Observable<List<NpaCustomer>>
    fun getOtsCustomerExisting(cif: String): Observable<List<OtsEntryDetail>>
    fun getOtsModels(): Observable<List<OtsModel>>

    fun getOtsStatusMaster(): Observable<List<OtsStatus>>

    fun getAllOtsEntries(): Observable<List<OtsEntryDetail>>
    fun getOtsByInwardNo(inwardNo: String): Observable<List<OtsEntryDetail>>

}