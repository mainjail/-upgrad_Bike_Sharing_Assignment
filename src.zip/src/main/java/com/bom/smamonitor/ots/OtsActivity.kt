package com.bom.smamonitor.ots

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseActivity
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.support.HasSupportFragmentInjector
import kotlinx.android.synthetic.main.activity_ots.*
import javax.inject.Inject

class OtsActivity : BaseActivity(), HasSupportFragmentInjector {

    @Inject
    internal lateinit var fragmentDispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>
    private lateinit var otsPagesAdapter: OtsPagesAdapter
    var frag1Title = ""

    var frag2Title =""

    override fun supportFragmentInjector(): AndroidInjector<Fragment> {
        return fragmentDispatchingAndroidInjector
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ots)
        initView()
        supportActionBar?.title = resources.getString(R.string.MahaOtsApplication)
    }

    private fun initView() {
//        val user = presenter.getPrefUserDetails()
        frag1Title = resources.getString(R.string.OtsApplicatn)
        frag2Title = resources.getString(R.string.OTSStatus)
        
        otsPagesAdapter = OtsPagesAdapter(fa = this)
        calculatorToolbar.title = this.resources.getString(R.string.MahaOtsApplication)
        calculatorToolbar.navigationIcon = this.resources.getDrawable(R.drawable.ic_action_back)
        calculatorToolbar.setNavigationOnClickListener { onBackPressed() }
        setUpFeedPagerAdapter()
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun setUpFeedPagerAdapter() {
        calciViewPager.adapter = otsPagesAdapter
        otsPagesAdapter.setCount(2)
//        calciViewPager.setPageTransformer(ZoomOutPageTransformer())

        calciViewPager.registerOnPageChangeCallback(fragmentPageChangeCallback)

        val titles = arrayOf(frag1Title, frag2Title)
        val icons = arrayOf(
                resources.getDrawable(R.mipmap.ic_dollerstack150),
                resources.getDrawable(R.mipmap.ic_handcalculator_150),
        )
        TabLayoutMediator(calciTabs, calciViewPager) { tab, position ->
            tab.text = titles[position]
            tab.icon = icons[position]
        }.attach()


        calciTabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                calciViewPager.currentItem = tab.position
                when (tab.position) {
                    0 -> calculatorToolbar.title = frag1Title
                    1 -> calculatorToolbar.title = frag2Title
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    override fun onBackPressed() {
        if (calciViewPager.currentItem == 0) {
            // If the user is currently looking at the first step, allow the system to handle the
            // Back button. This calls finish() on this activity and pops the back stack.
            super.onBackPressed()
        } else {
            // Otherwise, select the previous step.
            calciViewPager.currentItem = calciViewPager.currentItem - 1
        }
    }

    override fun onDestroy() {
        calciViewPager.unregisterOnPageChangeCallback(fragmentPageChangeCallback)
        super.onDestroy()
    }

    var fragmentPageChangeCallback = object : ViewPager2.OnPageChangeCallback() {
        override fun onPageSelected(position: Int) {
            when (position) {
                0 -> calculatorToolbar.title = frag1Title
                1 -> calculatorToolbar.title = frag2Title
            }
        }
    }
}