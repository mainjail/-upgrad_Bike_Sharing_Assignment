package com.bom.smamonitor.ots.applEntry

import android.util.Log
import com.androidnetworking.error.ANError
import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.network.retrofitApi.NpaTrackerApiReceiver
import com.bom.smamonitor.network.retrofitApi.SmaDashApiReceiver
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.ots.CbsCustomer
import com.bom.smamonitor.ots.OtsModel
import com.bom.smamonitor.ots.OtsStatus
import com.bom.smamonitor.ots.Repayment
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject


class OtsEntryPresenterImpl<V : OtsEntryMVPView, I : OtsEntryMVPInteractor> @Inject constructor(
        interactor: I, schedulerProvider: SchedulerProvider,
        compositeDisposable: CompositeDisposable
) :
        BasePresenter<V, I>(
                interactor = interactor, schedulerProvider = schedulerProvider,
                compositeDisposable = compositeDisposable
        ), OtsEntryMVPPresenter<V, I> {

    override fun onViewPrepared() {
    }

    override fun getCustomerCbsDetails(cif: String) {
        getView()?.showProgress()
        interactor?.let {
            it.getCustomerCbsDetails(cif)
                    .compose(schedulerProvider.ioToMainObservableScheduler())
                    .subscribe({ listCbsCustomers: List<CbsCustomer> ->
//                        println("Products Results:-$listCbsCustomers")
                        try {
                            getView()?.let { view ->
                                if (listCbsCustomers.isNotEmpty()) {
                                    val customer = listCbsCustomers[0]
                                    getView()?.displayCustCbsDetails(customer)
                                } else {
                                    getView()?.showError("No results Found")
                                }
                                view.hideProgress()
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }, { error ->
                        val aNError = error as ANError
                        Log.d("getCustomerCbsDetails", aNError.message.toString())
                        getView()?.hideProgress()
                        getView()?.showError(aNError.errorDetail.toString())
                    })
        }
    }

    override fun getCustomerDetails(cif: String) {
        getView()?.showProgress()
        interactor?.let {
            it.getCustomerDetails(cif)
                    .compose(schedulerProvider.ioToMainObservableScheduler())
                    .subscribe({ products: List<NpaCustomer> ->
//                        println("getCustomerDetails Results:-$products")
                        try {
                            getView()?.let { view ->
                                if (products.isNotEmpty()) {
                                    val customer = products[0]
                                    getView()?.displayCustomerDetails(customer)
                                } else {
                                    getView()?.showError("No results Found")
                                }
                                getView()?.hideProgress()
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }, { error ->
                        val aNError = error as ANError
                        Log.d("getCustomerDetails", aNError.message.toString())
                        getView()?.hideProgress()
                        getView()?.showError(aNError.errorDetail.toString())
                    })
        }
    }

    override fun addOtsApplicationToDb(otsEntry: OtsEntryDetail) {

        when {
            otsEntry.cif.isEmpty() -> getView()?.validateDetails(1)
            otsEntry.otsModel.isEmpty() -> getView()?.validateDetails(2)
            otsEntry.propType.isEmpty() -> getView()?.validateDetails(3)
            otsEntry.propInwardDate.isEmpty() -> getView()?.validateDetails(4)
            otsEntry.nameProprietor.isEmpty() -> getView()?.validateDetails(5)

            otsEntry.oneTimeOfferAmt.isEmpty() -> getView()?.validateDetails(6)
            otsEntry.downPaymentAmt.isEmpty() -> getView()?.validateDetails(7)
            otsEntry.sourcesFunds.isEmpty() -> getView()?.validateDetails(8)
            otsEntry.reasonForOts.isEmpty() -> getView()?.validateDetails(9)
            otsEntry.authorizedPersonName.isEmpty() -> getView()?.validateDetails(10)

            else -> {
                getView()?.showProgress()
                val retriever = NpaTrackerApiReceiver()
                val callBack = object : Callback<List<OtsEntryDetail>> {
                    override fun onFailure(call: Call<List<OtsEntryDetail>>, t: Throwable) {
                        getView()?.hideProgress()
                        getView()?.showError(t.localizedMessage)

                        Log.d("addOtsApi", t.message.toString())

                    }

                    override fun onResponse(
                            call: Call<List<OtsEntryDetail>>,
                            response: Response<List<OtsEntryDetail>>
                    ) {
                        response.isSuccessful.let {
                            println("response:-$response")
                            getView()?.hideProgress()
                            getView()?.displayOTSInwdList()
                        }
                    }
                }
                retriever.addOtsApplication(otsEntry, callBack)
            }
        }
    }

    override fun getOtsCustomerExisting(cif: String) {
        getView()?.showProgress()
        interactor?.let {
            it.getOtsCustomerExisting(cif)
                    .compose(schedulerProvider.ioToMainObservableScheduler())
                    .subscribe({ listOtsEntries: List<OtsEntryDetail> ->
                        println("Products Results:-$listOtsEntries")
                        try {
                            getView()?.let { view ->
                                if (listOtsEntries.isNotEmpty()) {
                                    val customer = listOtsEntries[0]
                                    if (customer.cif.isNullOrEmpty())
                                        getView()?.displayCustOtsExisting()
                                    else
                                        getView()?.showError("Customer's OTS entry already exists.")

                                } else {
                                    getView()?.displayCustOtsExisting()
                                }
                                getView()?.hideProgress()
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }, { error ->
                        val aNError = error as ANError
                        Log.d("OtsPresImpl", aNError.message.toString())
                        getView()?.hideProgress()
                        getView()?.showError(aNError.errorDetail.toString())
                    })
        }
    }

    override fun getOtsModels() {
        getView()?.showProgress()
        interactor?.let {
            it.getOtsModels()
                    .compose(schedulerProvider.ioToMainObservableScheduler())
                    .subscribe({ listOtsModels: List<OtsModel> ->
//                        println("listOtsModels Results:-$listOtsModels")
                        try {
                            getView()?.let { view ->
                                    getView()?.setOTSModels(listOtsModels)
                                view.hideProgress()
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }, { error ->
                        val aNError = error as ANError
                        Log.d("getOtsModels", aNError.message.toString())
                        getView()?.hideProgress()
                        getView()?.showError(aNError.errorDetail.toString())
                    })
        }
    }

    override fun addRepaymentPlan(repayment: Repayment) {
        when {
            repayment.cif.isEmpty() -> getView()?.validateDetails(1)
            repayment.repaymentDate.isEmpty() -> getView()?.validateDetails(11)
            repayment.amount.isEmpty() -> getView()?.validateDetails(12)
            repayment.otsModel.isEmpty() -> getView()?.validateDetails(2)

            else -> {
                getView()?.showProgress()
                val retriever = NpaTrackerApiReceiver()
                val callBack = object : Callback<List<Repayment>> {
                    override fun onFailure(call: Call<List<Repayment>>, t: Throwable) {
                        getView()?.hideProgress()
                        getView()?.showError(t.localizedMessage)
                        Log.d("addRepaymentPlan", t.message.toString())
                    }

                    override fun onResponse(
                            call: Call<List<Repayment>>,
                            response: Response<List<Repayment>>
                    ) {
                        response.isSuccessful.let {
//                            println("response:-$response")
                            val books: List<Repayment> = response.body()!!
                            println("list.size:-${books.size}")
                            if (books.isNotEmpty())
                                getView()?.repaymentAddSuccess(books[0])
                            else
                                getView()?.showError(response.message())
                            getView()?.hideProgress()
                        }
                    }
                }
                retriever.addRepaymentPlanService(repayment, callBack)
            }
        }
    }

    override fun getAllOtsEntries() {
        getView()?.showProgress()
        interactor?.let {
            it.getAllOtsEntries()
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ listOtsEntries: List<OtsEntryDetail> ->
//                    println("getAllOtsEntries Results:-$listOtsEntries")
                    try {
                        getView()?.let { view ->
                            if (listOtsEntries.isNotEmpty()) {
                                getView()?.displayOTSList(listOtsEntries)
                            } else {
                                getView()?.showError("No results found.")
                            }
                            view.hideProgress()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("getAllOtsEntries", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }
    }

    override fun geOtsEntriesByInwrdNo(inwardNo: String) {
        getView()?.showProgress()
        interactor?.let {
            it.getOtsByInwardNo(inwardNo)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ listOtsEntries: List<OtsEntryDetail> ->
//                        println("otsInwardList Results:-$listOtsEntries")
                    try {
                        getView()?.let { view ->
                            if (listOtsEntries.isNotEmpty()) {
//                                val customer = listOtsEntries[0]
                                getView()?.displayOTSList(listOtsEntries)
                            } else {
                                getView()?.showError("No results Found")
                            }
                            view.hideProgress()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("otsInwardList Search", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }    }

    override fun getOtsStatusList() {
        getView()?.showProgress()
        interactor?.let {
            it.getOtsStatusMaster()
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({ listOtsStatus: List<OtsStatus> ->
//                    println("listOtsStatus Results:-$listOtsStatus")
                    try {
                        getView()?.let { view ->
                            getView()?.setOtsStatusMaster(listOtsStatus)
                            view.hideProgress()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, { error ->
                    val aNError = error as ANError
                    Log.d("listOtsStatus", aNError.message.toString())
                    getView()?.hideProgress()
                    getView()?.showError(aNError.errorDetail.toString())
                })
        }    }

}
