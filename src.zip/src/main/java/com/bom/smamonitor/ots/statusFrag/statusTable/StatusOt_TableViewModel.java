package com.bom.smamonitor.ots.statusFrag.statusTable;


import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.ColumnHeaderModel;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;
import com.bom.smamonitor.ots.applEntry.OtsEntryDetail;

import java.util.ArrayList;
import java.util.List;

public class StatusOt_TableViewModel {
    // Columns indexes
    public static final int LINK_COLUMN_INDEX1 = 3;
    public static final int LINK_COLUMN_INDEX2 = 4;
    public static final int GENDER_COLUMN_INDEX = 9;

    // Constant size for dummy data sets
//    private static final int COLUMN_SIZE = 500;
//    private static final int ROW_SIZE = 500;

    private List<ColumnHeaderModel> mColumnHeaderModelList;
    private List<RowHeaderModel> mRowHeaderModelList;
    private List<List<Cell>> mCellModelList;


    public StatusOt_TableViewModel() {
    }



    private List<ColumnHeaderModel> createColumnHeaderModelList() {
        List<ColumnHeaderModel> list = new ArrayList<>();
        // Create Column Headers
//            list.add(new ColumnHeaderModel("0", "Sr. No"));
        list.add(new ColumnHeaderModel("0", "Inward No"));
        list.add(new ColumnHeaderModel("1", "Zone Name"));
        list.add(new ColumnHeaderModel("2", "Branch Name"));
        list.add(new ColumnHeaderModel("3", "Branch Code"));
        list.add(new ColumnHeaderModel("4", "Customer No"));
        list.add(new ColumnHeaderModel("5", "Customer Name"));

        list.add(new ColumnHeaderModel("6", "OTS Model"));
        list.add(new ColumnHeaderModel("7", "Ledger Balance"));
        list.add(new ColumnHeaderModel("8", "OT Offer Amt"));
        list.add(new ColumnHeaderModel("9", "Latest Status"));
//        list.add(new ColumnHeaderModel("10", "Int Req Freq"));
//        list.add(new ColumnHeaderModel("11", "Loan Repay"));
//        list.add(new ColumnHeaderModel("12", "Repay Freq"));
//        list.add(new ColumnHeaderModel("13", "Repay Day"));
//        list.add(new ColumnHeaderModel("14", "Unapplied Int"));

//        list.add(new ColumnHeaderModel("15", "Limit"));
//        list.add(new ColumnHeaderModel("7", "AC Open Date"));

        return list;
    }

    private List<List<Cell>> createCellModelList(List<OtsEntryDetail> otsList) {


        List<List<Cell>> cellList = new ArrayList<>();
        // Creating cell model list from User list for Cell Items
        // In this example, User list is populated from web service
        try {
            for (int i = 0; i < otsList.size(); i++) {
                OtsEntryDetail otsEntryDetail = otsList.get(i);
                List<Cell> list = new ArrayList<>();

                // The order should be same with column header list;
//                list.add(new Cell("1-" + i, circular.getSrNo()));          // "srNo"
                list.add(new Cell("1-" + i, otsEntryDetail.getInwardNo().trim()));
                list.add(new Cell("2-" + i, otsEntryDetail.getRegName().trim()));
                list.add(new Cell("3-" + i, otsEntryDetail.getBrName().trim()));
                list.add(new Cell("4-" + i, otsEntryDetail.getBrNo().trim()));
                list.add(new Cell("5-" + i, otsEntryDetail.getCif().trim()));
                list.add(new Cell("6-" + i, otsEntryDetail.getBorrName().trim()));

                list.add(new Cell("7-" + i, otsEntryDetail.getOtsModel().trim()));
                list.add(new Cell("8-" + i, otsEntryDetail.getLedgerBalance().trim()));

                list.add(new Cell("9-" + i, otsEntryDetail.getOneTimeOfferAmt().trim()));
                list.add(new Cell("10-" + i, otsEntryDetail.getLatestStatus()));
//                list.add(new Cell("11-" + i, otsEntryDetail.getIntRepFreq()));
//
//                list.add(new Cell("12-" + i, otsEntryDetail.getLoanRepay()));
//                list.add(new Cell("13-" + i, otsEntryDetail.getRepayFreq()));
//                list.add(new Cell("14-" + i, otsEntryDetail.getRepayDay()));
//                list.add(new Cell("15-" + i, otsEntryDetail.getUnappliedInt()));
//
                cellList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cellList;
    }

    private List<RowHeaderModel> createRowHeaderList(int size) {
        List<RowHeaderModel> list = new ArrayList<>();
        for (int i = 0; i < size; i++) { //ROW_SIZE=usersList.size();
            // In this example, Row headers just shows the index of the TableView List.
            list.add(new RowHeaderModel(String.valueOf(i), String.valueOf(i + 1)));
        }
        return list;
    }

    public List<ColumnHeaderModel> getColumnHeaderModeList() {
        return mColumnHeaderModelList;
    }

    public List<RowHeaderModel> getRowHeaderModelList() {
        return mRowHeaderModelList;
    }

    public List<List<Cell>> getCellModelList() {
        return mCellModelList;
    }

    public void generateListForTableView(List<OtsEntryDetail> otsEntry) {
        mColumnHeaderModelList = createColumnHeaderModelList();
        mCellModelList = createCellModelList(otsEntry);
        mRowHeaderModelList = createRowHeaderList(otsEntry.size());
    }


}



