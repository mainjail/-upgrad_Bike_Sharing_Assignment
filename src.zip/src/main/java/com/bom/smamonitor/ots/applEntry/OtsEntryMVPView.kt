package com.bom.smamonitor.ots.applEntry

import com.bom.smamonitor.base.view.BaseMVPView
import com.bom.smamonitor.npa.modelNpa.NpaCustomer
import com.bom.smamonitor.ots.CbsCustomer
import com.bom.smamonitor.ots.OtsModel
import com.bom.smamonitor.ots.OtsStatus
import com.bom.smamonitor.ots.Repayment


interface OtsEntryMVPView : BaseMVPView {

    fun displayOTSInwdList()
    fun displayCustomerDetails(customer: NpaCustomer)
    fun displayCustCbsDetails(cbsCustomer: CbsCustomer)
    fun displayCustOtsExisting()
    fun setOTSModels( otsModelList : List<OtsModel>)
    fun repaymentAddSuccess(repayment: Repayment)
    fun displayOTSList(otsList: List<OtsEntryDetail>)

    fun setOtsStatusMaster(otsStatusList: List<OtsStatus>)

    fun showError(error: String)
    fun validateDetails(errorCode: Int)

}