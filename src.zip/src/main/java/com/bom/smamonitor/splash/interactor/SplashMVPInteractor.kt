package com.bom.smamonitor.splash.interactor

import com.bom.smamonitor.base.interactor.MVPInteractor
import com.bom.smamonitor.login.AppUser

interface SplashMVPInteractor : MVPInteractor {

    fun savePinToSharedPref(userPin: String?)
    fun getPinFromSharedPrefs(): String?
//    fun getApiUserFromSharedPref(): AppUser?
}