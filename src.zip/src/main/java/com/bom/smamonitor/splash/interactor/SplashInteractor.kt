package com.bom.smamonitor.splash.interactor

import android.content.Context
import com.bom.smamonitor.base.interactor.BaseInteractor
import com.bom.smamonitor.depInjection.preferences.PreferenceHelper
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.network.ApiHelper
import javax.inject.Inject


class SplashInteractor @Inject constructor(private val mContext: Context,
                                           preferenceHelper: PreferenceHelper, apiHelper: ApiHelper)
    : BaseInteractor(preferenceHelper, apiHelper), SplashMVPInteractor {

    override fun savePinToSharedPref(userPin: String?) {
        preferenceHelper.setCurrentUserPIN(userPin)
    }

    override fun getPinFromSharedPrefs(): String? {
        return preferenceHelper.getCurrentUserPIN()
    }

//    override fun getApiUserFromSharedPref(): AppUser? {
//        return AppUser(
//            preferenceHelper.getCurrentUserPfNo().toString(),
//            preferenceHelper.getCurrentUserName(),
//            preferenceHelper.getCurrentBranchCode(), "", "", "","",
//            preferenceHelper.getCurrentUserMobileNo(),
//                preferenceHelper.getCurrentDeviceNotificationToken()
//
//        );
//    }


}