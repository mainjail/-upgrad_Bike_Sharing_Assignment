
package com.bom.smamonitor.splash.presenter

import com.bom.smamonitor.base.presenter.MVPPresenter
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.splash.interactor.SplashMVPInteractor
import com.bom.smamonitor.splash.view.SplashMVPView


interface SplashMVPPresenter<V : SplashMVPView, I : SplashMVPInteractor> : MVPPresenter<V, I>{
    fun decidePinOrNotPin(): Unit?
    fun savePinToSharedPrefs(userPin:String)
    fun getPinFromSharedPrefs(): String?
    fun getUserFromSharedPrefs(): AppUser?
    //fun saveUserLog(user: AppUser)



}