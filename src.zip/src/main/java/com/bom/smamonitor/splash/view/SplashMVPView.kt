package com.bom.smamonitor.splash.view

import com.bom.smamonitor.base.view.BaseMVPView

interface SplashMVPView : BaseMVPView {

    fun showSuccessToast()
    fun showErrorToast()
    fun openPinLockActivity()
    fun openLoginActivity()
    fun openMainActivity()
}