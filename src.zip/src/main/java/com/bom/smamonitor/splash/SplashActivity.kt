package  com.bom.smamonitor.splash

import android.content.Intent
import android.os.Bundle
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseActivity
import com.bom.smamonitor.dashboardbb.DashboardBBActivity
import com.bom.smamonitor.login.LoginActivity
import com.bom.smamonitor.pinLockScreen.PinLockActivity
import com.bom.smamonitor.splash.interactor.SplashMVPInteractor
import com.bom.smamonitor.splash.presenter.SplashMVPPresenter
import com.bom.smamonitor.splash.view.SplashMVPView
import javax.inject.Inject

class SplashActivity : BaseActivity(), SplashMVPView {

    @Inject
    lateinit var presenter: SplashMVPPresenter<SplashMVPView, SplashMVPInteractor>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        presenter.onAttach(this)
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    override fun showSuccessToast() {
    }

    override fun showErrorToast() {
    }


    override fun openPinLockActivity() {
        val intent = Intent(this, PinLockActivity::class.java)
//        val intent = Intent(this, DashboardBBActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun openLoginActivity() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun openMainActivity() {
        val intent = Intent(this, DashboardBBActivity::class.java)
        startActivity(intent)
        finish()
    }
}
