package com.bom.smamonitor.splash.presenter

import com.bom.smamonitor.base.presenter.BasePresenter
import com.bom.smamonitor.login.AppUser
import com.bom.smamonitor.splash.interactor.SplashMVPInteractor
import com.bom.smamonitor.splash.view.SplashMVPView
import com.bom.smamonitor.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject


class SplashPresenterImpl<V : SplashMVPView, I : SplashMVPInteractor>
@Inject internal constructor(interactor: I, schedulerProvider: SchedulerProvider, disposable: CompositeDisposable)
    : BasePresenter<V, I>(interactor = interactor, schedulerProvider = schedulerProvider, compositeDisposable = disposable),
    SplashMVPPresenter<V, I> {

    override fun onAttach(view: V?) {
        super.onAttach(view)
        decideActivityToOpen()
    }

    private fun decideActivityToOpen() = getView()?.let {
        if (isUserLoggedIn())
            it.openPinLockActivity()
        else
            it.openLoginActivity()
    }



    override fun decidePinOrNotPin() = getView()?.let {
        if (doesUserHavePIN())
            it.openPinLockActivity()
        else
            it.openLoginActivity()
    }


    private fun isUserLoggedIn(): Boolean {
        interactor?.let { return it.isUserLoggedIn() }
        return false
    }

    private fun doesUserHavePIN(): Boolean {
        interactor?.let {
            val userPin = it.doesUserHavePIN()
            if (userPin != null) {
                return true
            }
        }
        return false
    }

    override fun savePinToSharedPrefs(userPin: String) {
        interactor?.savePinToSharedPref(userPin)
        getView()?.openMainActivity()
    }

    override fun getPinFromSharedPrefs(): String? {
        return interactor?.getPinFromSharedPrefs()
    }


    override fun getUserFromSharedPrefs(): AppUser? {
        return interactor?.getUserFromSharedPref()
    }

}