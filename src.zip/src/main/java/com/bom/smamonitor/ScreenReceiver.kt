package com.bom.smamonitor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter

class ScreenReceiver :BroadcastReceiver(){
//    protected ScreenReceiver() {
//        // register receiver that handles screen on and screen off logic
//        IntentFilter filter = new IntentFilter();
//        filter.addAction(Intent.ACTION_SCREEN_ON);
//        filter.addAction(Intent.ACTION_SCREEN_OFF);
//        registerReceiver(this, filter);
//    }

    private var isScreenOff=false

    override fun onReceive(p0: Context?, p1: Intent?) {
        val intent = Intent()
        if (intent.action.equals(Intent.ACTION_SCREEN_OFF)) {
            isScreenOff = true
        } else if (intent.action.equals(Intent.ACTION_SCREEN_ON)) {
            isScreenOff = false
        }
    }

}

