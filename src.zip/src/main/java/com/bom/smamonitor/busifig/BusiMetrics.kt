package com.bom.smamonitor.busifig

import com.google.gson.annotations.SerializedName

data class BusiMetrics(
        @SerializedName("year")
        val year: String,
        @SerializedName("BusinessFigures")
        val businessFigure: BusinessFigures
//        val npaFigures: NpaFigures
)

data class BusinessFigures(
        @SerializedName("Total Business")
        val totalBusiness: String?,

        @SerializedName("TOTAL DEPOSIT")
        val totalDeposits: String,

        @SerializedName("CASA")
        val cASA: String,
        @SerializedName("CURRENT")
        val current: String,

        @SerializedName("SAVING")
        val saving: String,
        @SerializedName("TERM DEPOSIT")
        val termDeposits: String,

        @SerializedName("TOTAL ADVANCES")
        val totalAdvances: String,

        var nPA: String?,
        var npaRecovery: String?
)

//{
//    "year": "2020-04-05",
//    "BusinessFigures": {
//    "Total Business": 140.8058,
//    "TOTAL DEPOSIT": 102.0761,
//    "CASA": 37.8811,
//    "CURRENT": 8.7925,
//    "SAVING": 29.0885,
//    "TERM DEPOSIT": 64.1949,
//    "TOTAL ADVANCES": 38.7296
//}
//}
data class NpaFigures(
        @SerializedName("BrCode")
        val brCode: String,
        @SerializedName("Year")
        val year: String,
        @SerializedName("NPA")
        val nPA: String?,
        @SerializedName("NpaRecovery")
        val npaRecovery: String?
)
//{
//    "NPA": "120123197.96",
//    "NpaRecovery": "4735367.21",
//    "BrCode": "140",
//    "Year": "2018"
//},