package com.bom.smamonitor.busifig

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bom.smamonitor.R
import com.bom.smamonitor.util.CommonUtil.roundUpto2Decimal
import com.bom.smamonitor.util.DateUtil.convertDateToddMMyy
import kotlinx.android.synthetic.main.item_figures.view.*
import java.util.*


class FiguresAdapter : RecyclerView.Adapter<FiguresAdapter.BusiFigViewHolder>() {

    //    private var busiMetricsList = mutableListOf<NpaCustomer>()
    private var figuresList = mutableListOf<BusiMetrics>()
    private val viewPool = RecyclerView.RecycledViewPool()

    val String.capitalizeWords
        get() = this.toLowerCase(Locale.getDefault()).split(" ").joinToString(" ") { it.capitalize(Locale.getDefault()) }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = BusiFigViewHolder(
            LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_figures, parent, false)
    )

    override fun getItemCount() = this.figuresList.size

    override fun onBindViewHolder(holder: BusiFigViewHolder, position: Int) = holder.let {
        it.clear()
        it.onBind(position)
    }

    internal fun addResultsToList(busiMetricsList: List<BusiMetrics>) {
        println("addResultsToList called:-" + busiMetricsList.size)
        this.figuresList = busiMetricsList.toMutableList()
        notifyDataSetChanged()
    }


    inner class BusiFigViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun clear() {
        }

        fun onBind(position: Int) {
            val busiMetrics: BusiMetrics = figuresList[position]
            inflateData(busiMetrics)
            setItemClickListener(busiMetrics)
        }

        private fun setItemClickListener(npaCustomer: BusiMetrics) {
            itemView.setOnClickListener {
            }
        }

        @SuppressLint("RtlHardcoded")
        private fun inflateData(busiMetrics: BusiMetrics) {

            itemView.yearTv.text = convertDateToddMMyy(busiMetrics.year)

            val businessFigures = busiMetrics.businessFigure
            itemView.totalBusiTv.text = checkNull(businessFigures.totalBusiness.toString())
            itemView.totalDepositsTv.text = checkNull(businessFigures.totalDeposits)
            itemView.currentTv.text = checkNull(businessFigures.current)
            itemView.casaTv.text = checkNull(businessFigures.cASA)
            itemView.savingsTv.text = checkNull(businessFigures.saving)
            itemView.termDepositsTv.text = checkNull(businessFigures.termDeposits)
            itemView.totalAdvancesTv.text = checkNull(businessFigures.totalAdvances)
            itemView.npaTv.text = convertToLakhs(businessFigures.nPA.toString())
            itemView.npaRecoveryTv.text = convertToLakhs(businessFigures.npaRecovery.toString())

//            itemView.totalBusiTv.gravity = CENTER RIGHT
//            itemView.totalAdvancesTv.gravity = RIGHT
//            itemView.totalDepositsTv.gravity = RIGHT
//            itemView.currentTv.gravity = RIGHT
//            itemView.savingsTv.gravity = RIGHT
//            itemView.termDepositsTv.gravity = RIGHT
//            itemView.casaTv.gravity = RIGHT
//            itemView.npaRecoveryTv.gravity = RIGHT
//            itemView.npaTv.gravity = RIGHT
        }
    }

    private fun checkNull(entry: String): String {
        var value = "-"
        if (entry.isBlank()||entry.equals("null"))
            value = "-"
        else
            value = entry
        return value
    }

    fun convertToLakhs(entry:String):String{
        var value = "-"
        if (entry.isBlank()||entry.equals("null")){
            value = "-"
        }else{
            try {
//            value= Math.floorDiv(entry.toInt(),100000).toString()
                val num = entry.toDouble()
                value = roundUpto2Decimal(num.div(100000))

            }catch (e:Exception){
                e.printStackTrace()
            }
        }
        return value
    }


}
