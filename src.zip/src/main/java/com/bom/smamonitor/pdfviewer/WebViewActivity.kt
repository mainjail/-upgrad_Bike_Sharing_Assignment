package com.bom.smamonitor.pdfviewer

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.bom.smamonitor.R
import com.bom.smamonitor.network.ApiEndPoint
import kotlinx.android.synthetic.main.activity_web_view.*


class WebViewActivity : AppCompatActivity() {


    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)
        webView.webViewClient = WebViewClient()
        webView.settings.setSupportZoom(true)
        webView.settings.javaScriptEnabled = true
//        class JsObject {
//            @JavascriptInterface
//            override fun toString(): String {
//                return "injectedObject"
//            }
//        }
//        webView.settings.javaScriptEnabled = true
//        webView.addJavascriptInterface(JsObject(), "injectedObject")
//        webView.loadData("", "text/html", null)
//        webView.loadUrl("javascript:alert(injectedObject.toString())")


        initView()
//        val url = FileUtils.getPdfUrl()
//        webView.loadUrl("https://docs.google.com/gview?embedded=true&url=$url")
    }

    private fun initView() {
        if (intent != null) {
            val fileName = intent.getStringExtra("FileName")
            val downloadFileUrl = ApiEndPoint.ENDPOINT_DOWNLOAD_FILE + fileName
            println("filename from intent:- $downloadFileUrl")
//            webView.addJavascriptInterface()

            webView.loadUrl(downloadFileUrl)
        }
    }

}
