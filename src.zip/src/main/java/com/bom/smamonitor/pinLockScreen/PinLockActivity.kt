package com.bom.smamonitor.pinLockScreen

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.Observer
import com.beautycoder.pflockscreen.PFFLockScreenConfiguration
import com.beautycoder.pflockscreen.fragments.PFLockScreenFragment
import com.beautycoder.pflockscreen.fragments.PFLockScreenFragment.OnPFLockScreenCodeCreateListener
import com.beautycoder.pflockscreen.fragments.PFLockScreenFragment.OnPFLockScreenLoginListener
import com.beautycoder.pflockscreen.viewmodels.PFPinCodeViewModel
import com.bom.smamonitor.R
import com.bom.smamonitor.base.view.BaseLockActivity
import com.bom.smamonitor.dashboardbb.DashboardBBActivity
import com.bom.smamonitor.splash.interactor.SplashMVPInteractor
import com.bom.smamonitor.splash.presenter.SplashMVPPresenter
import com.bom.smamonitor.splash.view.SplashMVPView
import kotlinx.android.synthetic.main.activity_lock_screen.*
import javax.inject.Inject


class PinLockActivity : BaseLockActivity(), SplashMVPView {

    val TAG = "PinLockAct"

    @Inject
    lateinit var presenter: SplashMVPPresenter<SplashMVPView, SplashMVPInteractor>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock_screen)
        presenter.onAttach(this)
        checkIfPinExists()
        setUserInfo()

    }

    private fun setUserInfo() {
        val user = presenter.getUserFromSharedPrefs()
        employeeNameTv.text = user!!.name!!.trim()
        Log.d("notificationToken",user.notificationId.toString())
//        User Notification token:elYfN5QUSIOGD7qVq8gGCR:APA91bExTmEtNTLNUmvDLnZmnGJ6HXlh5E8g2sf3uAni_W7adn8Rsgc4Ojwjs3cE6v-HMn4fXwdvAsh5VziCIHIr8cNOPPvqJF27t0Wgxfadzq34lzZolmqt-sdRj_UkfdzojH9g_wGE
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    private fun checkIfPinExists() {
        PFPinCodeViewModel().isPinCodeEncryptionKeyExist.observe(
            this,
            Observer { result ->
                if (result == null) {
                    return@Observer
                }
                if (result.error != null) {
                    Toast.makeText(
                        this@PinLockActivity,
                        "Can not get pin code info",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@Observer
                }
                Log.d(TAG,"checkIfPinExists:-${result.result}")
                showLockScreenFragment(result.result)
            }
        )
    }


    private val mCodeCreateListener: OnPFLockScreenCodeCreateListener =
        object : OnPFLockScreenCodeCreateListener {
            override fun onCodeCreated(encodedCode: String) {

                Toast.makeText(this@PinLockActivity, "PIN created", Toast.LENGTH_SHORT).show()
                presenter.savePinToSharedPrefs(encodedCode)
            }

            override fun onNewCodeValidationFailed() {
                Toast.makeText(this@PinLockActivity, "PIN validation error", Toast.LENGTH_SHORT)
                    .show()
            }
        }

    private val mLoginListener: OnPFLockScreenLoginListener = object : OnPFLockScreenLoginListener {
        override fun onCodeInputSuccessful() {
            Toast.makeText(this@PinLockActivity, "Code successful", Toast.LENGTH_SHORT).show()
            openMainActivity()
        }

        override fun onFingerprintSuccessful() {
            Toast.makeText(this@PinLockActivity, "Fingerprint successful", Toast.LENGTH_SHORT).show()
            openMainActivity()
        }

        override fun onPinLoginFailed() {
            Toast.makeText(this@PinLockActivity, "Pin failed", Toast.LENGTH_SHORT).show()
        }

        override fun onFingerprintLoginFailed() {
            Toast.makeText(this@PinLockActivity, "Fingerprint failed", Toast.LENGTH_SHORT).show()
        }

    }




    private fun showLockScreenFragment(isPinExist: Boolean) {
        try {
            Log.d(TAG,"isPinExists ShowLockFrag:-${isPinExist}")
            val builder = PFFLockScreenConfiguration.Builder(this)
                .setTitle(if (isPinExist && !presenter.getPinFromSharedPrefs().isNullOrEmpty()) "Unlock with your pin code or fingerprint" else
                        "Create PIN")
                .setCodeLength(6)
//            .setLeftButton("Reset PIN?")
                .setNewCodeValidation(true)
                .setNewCodeValidationTitle("Please enter PIN again")
                .setUseFingerprint(true)

            val fragment = PFLockScreenFragment()
            fragment.setOnLeftButtonClickListener {
//            PFPinCodeViewModel().delete()
                Toast.makeText(
                    this,
                    "Current PIN removed. Please reset your PIN",
                    Toast.LENGTH_LONG
                ).show()
            }
//            builder.setMode(
//                if (isPinExist)
//                    PFFLockScreenConfiguration.MODE_AUTH
//                else PFFLockScreenConfiguration.MODE_CREATE)
            if (isPinExist && !presenter.getPinFromSharedPrefs().isNullOrEmpty()) {
//                PFFLockScreenConfiguration.MODE_AUTH
                builder.setMode(PFFLockScreenConfiguration.MODE_AUTH)
                    fragment.setEncodedPinCode(presenter.getPinFromSharedPrefs())
                    fragment.setLoginListener(mLoginListener)
            } else {
                builder.setMode(PFFLockScreenConfiguration.MODE_CREATE)
                Toast.makeText(this, "Please reset your PIN", Toast.LENGTH_LONG).show()
            }

            fragment.setConfiguration(builder.build())
            fragment.setCodeCreateListener(mCodeCreateListener)
            supportFragmentManager.beginTransaction()
                .replace(R.id.container_view, fragment).commit()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun showSuccessToast() {
//        TODO("Not yet implemented")
    }

    override fun showErrorToast() {
    }

    override fun openMainActivity() {

        val intent = Intent(this@PinLockActivity, DashboardBBActivity::class.java)
        startActivity(intent)
        finish()
    }



    override fun openPinLockActivity() {
    }

    override fun openLoginActivity() {
    }


}