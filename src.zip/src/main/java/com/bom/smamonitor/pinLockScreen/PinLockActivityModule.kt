package com.bom.smamonitor.pinLockScreen

import com.bom.smamonitor.splash.interactor.SplashInteractor
import com.bom.smamonitor.splash.interactor.SplashMVPInteractor
import com.bom.smamonitor.splash.presenter.SplashMVPPresenter
import com.bom.smamonitor.splash.presenter.SplashPresenterImpl
import com.bom.smamonitor.splash.view.SplashMVPView
import dagger.Module
import dagger.Provides


@Module
class PinLockActivityModule {

    @Provides
    internal fun provideSplashInteractor(splashInteractor: SplashInteractor): SplashMVPInteractor = splashInteractor

    @Provides
    internal fun provideSplashPresenter(splashPresenterImpl: SplashPresenterImpl<SplashMVPView, SplashMVPInteractor>)
            : SplashMVPPresenter<SplashMVPView, SplashMVPInteractor> = splashPresenterImpl
}