package com.bom.smamonitor.abcd;

import com.bom.smamonitor.dashboardbb.models.AgriObj;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.ColumnHeaderModel;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class AbcdTableViewModel {

    public static final int LINK_COLUMN_INDEX1 = 1;
    public static final int LINK_COLUMN_INDEX2 = 2;

    // Constant size for dummy data sets
//    private static final int COLUMN_SIZE = 500;
//    private static final int ROW_SIZE = 500;

    private List<ColumnHeaderModel> mColumnHeaderModelList;
    private List<RowHeaderModel> mRowHeaderModelList;
    private List<List<Cell>> mCellModelList;


    public AbcdTableViewModel() {
    }

    private List<ColumnHeaderModel> createColumnHeaderModelList(Integer callFromMode) {
        List<ColumnHeaderModel> list = new ArrayList<>();
        list.add(new ColumnHeaderModel("0", "CODE"));
        //list.add(new ColumnHeaderModel("1", "ZONE NAME"));
        list.add(new ColumnHeaderModel("1", "ACCOUNTS (A)"));
        list.add(new ColumnHeaderModel("2", "AGRI A BALANCE"));
        list.add(new ColumnHeaderModel("3", "ACCOUNTS (B)"));
        list.add(new ColumnHeaderModel("4", "AGRI B BALANCE"));
        list.add(new ColumnHeaderModel("5", "ACCOUNTS (C)"));
        list.add(new ColumnHeaderModel("6", "AGRI C BALANCE"));
        list.add(new ColumnHeaderModel("7", "ACCOUNTS (D)"));
        list.add(new ColumnHeaderModel("8", "AGRI D BALANCE"));
        list.add(new ColumnHeaderModel("9", "ACCOUNTS (A+B+C+D)"));
        list.add(new ColumnHeaderModel("10", "AGRI A+B+C+D BALANCE"));
        return list;
    }

    private String toLacs(double num) {
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.DOWN);
        try {
            num = (num / 100000);  // in lac
        } catch (Exception e) {
            e.printStackTrace();
        }
        return df.format(num);
    }

    private String toCrores(double num) {
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.DOWN);
        try {
            num = num / 10000000;// in crores
        } catch (Exception e) {
            e.printStackTrace();
        }
        return df.format(num);
    }

    private List<List<Cell>> createCellModelList(List<AgriObj> agriObjs, Integer callFromMode, Boolean isViewInLacs) {

        List<List<Cell>> cellList = new ArrayList<>();
        try {
            for (int i = 0; i < agriObjs.size(); i++) {
                AgriObj abcdObj = agriObjs.get(i);
                List<Cell> list = new ArrayList<>();
                list.add(new Cell("1-" + i, abcdObj.getRegCode()));
               // list.add(new Cell("2-" + i, abcdObj.getRegName()));
                list.add(new Cell("2-" + i, abcdObj.getAgriACnt()));
                list.add(new Cell("3-" + i, abcdObj.getAgriAAmt()));
                list.add(new Cell("4-" + i, abcdObj.getAgriBCnt()));
                list.add(new Cell("5-" + i, abcdObj.getAgriBAmt()));
                list.add(new Cell("6-" + i, abcdObj.getAgriCCnt()));
                list.add(new Cell("7-" + i, abcdObj.getAgriCAmt()));
                list.add(new Cell("8-" + i, abcdObj.getAgriDCnt()));
                list.add(new Cell("9-" + i, abcdObj.getAgriDAmt()));
                list.add(new Cell("10-" + i, abcdObj.getAgriECnt()));
                list.add(new Cell("11-" + i, abcdObj.getAgriEAmt()));
                cellList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cellList;
    }

    private String formatRoundUp(double num) {
        return String.format("%.02f", num);
    }

    private List<RowHeaderModel> createRowHeaderList(List<AgriObj> agriObjs, int size, int callFromMode) {
        List<RowHeaderModel> list = new ArrayList<>();

        try {
            for (int i = 0; i < size; i++) {
                AgriObj agriObj = agriObjs.get(i);
                if (agriObj.getRegName() != null) {
                    if (!agriObj.getRegName().isEmpty()) {
                        list.add(new RowHeaderModel(String.valueOf(i), agriObj.getRegName().trim()));
                    }
                }
            }
        } catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<ColumnHeaderModel> getColumnHeaderModeList() {
        return mColumnHeaderModelList;
    }

    public List<RowHeaderModel> getRowHeaderModelList() {
        return mRowHeaderModelList;
    }

    public List<List<Cell>> getCellModelList() {
        return mCellModelList;
    }

    public void generateListForZoneWiseTableView(List<AgriObj> list,
                                                 Integer callFromMode, Boolean isViewInLacs) {
        mColumnHeaderModelList = createColumnHeaderModelList(callFromMode);
        mCellModelList = createCellModelList(list, callFromMode, isViewInLacs);
        mRowHeaderModelList = createRowHeaderList(list, list.size(), callFromMode);
    }

//    public void generateListForBranchWiseTableView(List<BranchSectSummary> branchSectSummaries, Boolean isZone) {
//        mColumnHeaderModelList = createColumnHeaderModelList(isZone);
//        mCellModelList = createCellModelList(branchSectSummaries,isZone);
//        mRowHeaderModelList = createRowHeaderList(branchSectSummaries.size());
//    }
}



