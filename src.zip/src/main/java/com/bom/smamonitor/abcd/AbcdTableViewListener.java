package com.bom.smamonitor.abcd;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bom.smamonitor.bzsummary.BZSummaryActivity;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;
import com.evrencoskun.tableview.TableView;
import com.evrencoskun.tableview.listener.ITableViewListener;

public class AbcdTableViewListener implements ITableViewListener {

    private static final String LOG_TAG = AbcdTableViewListener.class.getSimpleName();

    private final TableView mTableView;
    @NonNull
    private final Context mContext;
    private final Integer callFromMode;

    public AbcdTableViewListener(TableView pTableView, Integer callFromMode) {
        this.mContext = pTableView.getContext();
        this.mTableView = pTableView;
        this.callFromMode = callFromMode;
    }

    @Override
    public void onCellClicked(@NonNull RecyclerView.ViewHolder cellView, int column, int row) {
        Log.d(LOG_TAG, "onCellClicked has been clicked for x= " + column + " y= " + row);
        switch (column) {
            case AbcdTableViewModel.LINK_COLUMN_INDEX2:
            case 0:
            case AbcdTableViewModel.LINK_COLUMN_INDEX1:
                Cell cellRegCode = (Cell) mTableView.getAdapter().getCellItem(0, row);
                RowHeaderModel rowItem = (RowHeaderModel) mTableView.getAdapter().getRowHeaderItem(row);
                callOnItemClick(cellRegCode, rowItem);
                break;
        }
    }


    private void callOnItemClick(Cell cellRegCode, RowHeaderModel rowHeaderModel) {
        String regName = "";
        if (cellRegCode != null) {
            if (cellRegCode.getData() != null) {
                String regCode = cellRegCode.getData().toString();
                if (rowHeaderModel != null) {
                    if (rowHeaderModel.getData() != null)
                        regName = rowHeaderModel.getData().toString();
                }
            } else {
                showToast("No content available.");
            }
        }
    }

    private void openZoneDashboardView(String regCode, String regName) {
        if (!regName.equalsIgnoreCase("Total")) {
            Intent intent = new Intent(mContext, BZSummaryActivity.class);
            intent.putExtra("regionCode", regCode);
            intent.putExtra("regionName", regName);
            mContext.startActivity(intent);
        }
    }

    private void openBranchDashboardView(String brCode, String brName) {
        if (!brName.equalsIgnoreCase("Total")) {
            Intent intent = new Intent(mContext, BZSummaryActivity.class);
            intent.putExtra("branchCode", brCode);
            intent.putExtra("branchName", brName);
            mContext.startActivity(intent);
        }
    }


    @Override
    public void onCellDoubleClicked(@NonNull RecyclerView.ViewHolder cellView, int column, int row) {
    }

    @Override
    public void onCellLongPressed(@NonNull RecyclerView.ViewHolder cellView, int column, int row) {
        Log.d(LOG_TAG, "onCellLongPressed has been clicked for " + row);
    }

    @Override
    public void onColumnHeaderClicked(@NonNull RecyclerView.ViewHolder columnHeaderView, int
            column) {
        Log.d(LOG_TAG, "onColumnHeaderClicked has been clicked for " + column);
    }

    @Override
    public void onColumnHeaderDoubleClicked(@NonNull RecyclerView.ViewHolder columnHeaderView, int column) {

    }


    @Override
    public void onColumnHeaderLongPressed(@NonNull RecyclerView.ViewHolder columnHeaderView, int column) {
//        if (columnHeaderView != null && columnHeaderView instanceof ColumnHeaderViewHolder) {
//            ColumnHeaderLongPressPopup popup = new ColumnHeaderLongPressPopup(
//                    (ColumnHeaderViewHolder) columnHeaderView, mTableView);
//            popup.show();
//        }

    }

    @Override
    public void onRowHeaderClicked(@NonNull RecyclerView.ViewHolder rowHeaderView, int row) {
        Log.d(LOG_TAG, "onRowHeaderClicked has been clicked for " + row);
    }

    @Override
    public void onRowHeaderDoubleClicked(@NonNull RecyclerView.ViewHolder rowHeaderView, int row) {
        RowHeaderModel rowItem = (RowHeaderModel) mTableView.getAdapter().getRowHeaderItem(row);
        Cell cellRegCode = (Cell) mTableView.getAdapter().getCellItem(0, row);
        callOnItemClick(cellRegCode,rowItem);
    }

    @Override
    public void onRowHeaderLongPressed(@NonNull RecyclerView.ViewHolder rowHeaderView, int row) {
        Log.d(LOG_TAG, "onRowHeaderLongPressed has been clicked for " + row);
//        // Create Long Press Popup
//        RowHeaderLongPressPopup popup = new RowHeaderLongPressPopup(rowHeaderView, mTableView);
//        // Show
//        popup.show();
    }

    private void showToast(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
    }
}

