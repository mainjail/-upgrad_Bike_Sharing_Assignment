package com.bom.smamonitor.abcd;


import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bom.smamonitor.R;
import com.bom.smamonitor.dashboardbb.models.AgriObj;
import com.bom.smamonitor.details.tablew.holder.CellViewHolder;
import com.bom.smamonitor.details.tablew.holder.ColumnHeaderViewHolder;
import com.bom.smamonitor.details.tablew.holder.RowHeaderViewHolder;
import com.bom.smamonitor.details.tablew.models.Cell;
import com.bom.smamonitor.details.tablew.models.ColumnHeaderModel;
import com.bom.smamonitor.details.tablew.models.RowHeaderModel;
import com.evrencoskun.tableview.adapter.AbstractTableAdapter;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractSorterViewHolder;
import com.evrencoskun.tableview.adapter.recyclerview.holder.AbstractViewHolder;
import com.evrencoskun.tableview.sort.SortState;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class AbcdTableAdapter extends AbstractTableAdapter<ColumnHeaderModel, RowHeaderModel, Cell> {
    // Cell View Types by Column Position
    private static final int LINK_CELL_TYPE2 = 2;
    private static final int LINK_CELL_TYPE1 = 1;


    private static final String LOG_TAG = AbcdTableAdapter.class.getSimpleName();

    @NonNull
    private final AbcdTableViewModel mTableViewModel;
    private final int mCallFromMode;

    public AbcdTableAdapter(@NonNull AbcdTableViewModel tableViewModel, int callFromMode) {
        super();
        this.mTableViewModel = tableViewModel;
        this.mCallFromMode = callFromMode;
    }

    @NonNull
    @Override
    public AbstractViewHolder onCreateCellViewHolder(@NonNull ViewGroup parent, int viewType) {
//        Log.e(LOG_TAG, " onCreateCellViewHolder has been called");
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View layout;
        layout = inflater.inflate(R.layout.table_view_cell_layout, parent, false);
        return new CellViewHolder(layout);
    }

    /**
     * That is where you set Cell View Model data to your custom Cell ViewHolder. This method is
     * Called by Cell RecyclerView of the TableView to display the data at the specified position.
     * This method gives you everything you need about a cell item.
     *
     * @param holder         : This is one of your cell ViewHolders that was created on
     *                       ```onCreateCellViewHolder``` method. In this example we have created
     *                       "CellViewHolder" holder.
     * @param cellItemModel  : This is the cell view model located on this X and Y position. In this
     *                       example, the model class is "Cell".
     * @param columnPosition : This is the X (Column) position of the cell item.
     * @param rowPosition    : This is the Y (Row) position of the cell item.
     * @see #onCreateCellViewHolder(ViewGroup, int) ;
     */

    @Override
    public void onBindCellViewHolder(@NonNull AbstractViewHolder holder, @Nullable Cell cellItemModel, int
            columnPosition, int rowPosition) {
        CellViewHolder viewHolder = (CellViewHolder) holder;
        viewHolder.setCellModel(cellItemModel, columnPosition);
        viewHolder.setCellTypeFace(rowPosition == (mTableViewModel.getCellModelList().size() - 1));
    }

    @NotNull
    @Override
    public AbstractSorterViewHolder onCreateColumnHeaderViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout
                .table_view_column_header_layout, parent, false);
        return new ColumnHeaderViewHolder(layout, getTableView());
    }

    @Override
    public void onBindColumnHeaderViewHolder(@NonNull AbstractViewHolder holder, @Nullable ColumnHeaderModel columnHeaderItemModel,
                                             int columnPosition) {
        // Get the holder to update cell item text
        ColumnHeaderViewHolder columnHeaderViewHolder = (ColumnHeaderViewHolder) holder;
        columnHeaderViewHolder.setColumnHeaderModel(columnHeaderItemModel, columnPosition);
    }

    @NotNull
    @Override
    public AbstractViewHolder onCreateRowHeaderViewHolder(ViewGroup parent, int viewType) {
        // Get Row Header xml Layout
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.table_view_row_header_layout,
                parent, false);
        return new RowHeaderViewHolder(layout);
    }

    @Override
    public void onBindRowHeaderViewHolder(@NonNull AbstractViewHolder holder, @Nullable RowHeaderModel rowHeaderItemModel, int rowPosition) {
        RowHeaderViewHolder rowHeaderViewHolder = (RowHeaderViewHolder) holder;

        rowHeaderViewHolder.row_header_textview.setText(String.valueOf(rowHeaderItemModel.getData()));
        if(rowHeaderItemModel.getData()=="TOTAL"){
            rowHeaderViewHolder.row_header_textview.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        }else {
            rowHeaderViewHolder.row_header_textview.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        }
//        rowHeaderViewHolder.row_header_container.getLayoutParams().width = LinearLayout.LayoutParams.WRAP_CONTENT;
//        rowHeaderViewHolder.row_header_container.requestLayout();

    }


    @NonNull
    @Override
    public View onCreateCornerView(@NonNull ViewGroup parent) {
        // Get Corner xml layout
        View corner = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.table_view_corner_layout, parent, false);
        TextView cornerTV = corner.findViewById(R.id.cornerTextView);

            cornerTV.setText("ZONE NAME");

        corner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SortState sortState = AbcdTableAdapter.this.getTableView()
                        .getRowHeaderSortingStatus();
//                if (sortState != SortState.ASCENDING) {
//                    Log.d("TableViewAdapter", "Order Ascending");
//                    ZoneSectTableAdapter.this.getTableView().sortRowHeader(SortState.ASCENDING);
//                } else {
//                    Log.d("TableViewAdapter", "Order Descending");
//                    ZoneSectTableAdapter.this.getTableView().sortRowHeader(SortState.DESCENDING);
//                }
            }
        });

        return corner;
    }

    @Override
    public int getColumnHeaderItemViewType(int position) {
        return 0;
    }

    @Override
    public int getRowHeaderItemViewType(int position) {
        return 0;
    }

    @Override
    public int getCellItemViewType(int position) {
//        return MyTableViewModel.getCellItemViewType(position);
        // The unique ID for this type of cell item
        // If you have different items for Cell View by X (Column) position,
        // then you should fill this method to be able create different
        // type of CellViewHolder on "onCreateCellViewHolder"
        switch (position) {
            case AbcdTableViewModel.LINK_COLUMN_INDEX1:
                return LINK_CELL_TYPE1;

            default:
                return 0;
        }
    }


    /**
     * This method is not a generic Adapter method. It helps to generate lists from single user
     * list for this adapter.
     */
    public void setReportData(List<AgriObj> agriObjList, Integer callFromMode) {
        mTableViewModel.generateListForZoneWiseTableView(agriObjList, callFromMode,true);
        setAllItems(mTableViewModel.getColumnHeaderModeList(),
                mTableViewModel.getRowHeaderModelList(),
                mTableViewModel.getCellModelList());
    }

}
